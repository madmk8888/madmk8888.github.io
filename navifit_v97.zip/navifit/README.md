# NaviFit - 안드로이드 앱 (폰 테스트용)

프로토타입(HTML)의 기능들을 네이티브로 옮긴 프로젝트예요.

## 이번 버전에 실제로 작동하는 것
- 이동수단 4종 선택 → 목적지 입력 → 실제 GPS 경로 안내
- 실시간 위치 추적 (포그라운드 서비스, 화면 꺼져도 동작)
- 이동한 길 형광색 표시 + 계획 경로 회색 표시
- 운동(도보/자전거) 종료 시 "저장할까요?" → Room DB 저장
- 주행(오토바이/차) 안전운전 점수 (과속/급가속/최고속도) + 리셋 + 자동저장
- 오토바이 고속도로 회피 (avoid=highways)
- 음성 안내 (오토바이/차, TTS)
- 마커 뽑기: 모양×색 조합, 프리미엄(교환권) 뽑기 확률 상향, 레인보우 0.15%, 합성, 장착(영구저장)
- 만보기: 기기 걸음 센서 기반, 화면 꺼져도 백그라운드 측정, 자정 리셋, 30만보=교환권 1장
- 운동 분석 (주간 요약 + 규칙기반 조언)
- 랭킹/커뮤니티: UI+로컬 로직 (⚠️ 진짜 전세계 공유는 서버 필요 - 아래 참고)

## 실행 방법 (Android Studio)
1. Android Studio 열기 → "Open" → 이 폴더(navifit) 선택
2. `app/src/main/AndroidManifest.xml` 과 `MainActivity.kt` 에서
   `YOUR_GOOGLE_MAPS_API_KEY` 를 본인 키로 교체 (2군데)
3. Cloud Console에서 이 키에 **Maps SDK for Android** + **Directions API** 활성화
4. 폰을 USB로 연결 (개발자옵션 > USB 디버깅 켜기) → Run ▶ 버튼
5. 첫 실행 시 위치/활동/알림 권한 모두 허용

## 알아둘 것
- Firebase는 지금 꺼둠 (google-services.json 없이도 빌드되게). 기록은 폰 로컬(Room)에 저장됨.
  나중에 서버 랭킹/커뮤니티 하려면: Firebase 프로젝트 생성 → json 배치 → build.gradle 주석 해제
- 광고는 RewardAdManager의 ENABLE_REAL_ADS=false 라 지금은 광고 없이 바로 보상 (배포 전 교체)
- 랭킹은 가상 데이터. 커뮤니티는 이 폰 안에서만 동작 (비속어/스팸 필터, 신고 버튼 UI 포함)
- 마커 이모지는 임시. 상용화 시 일러스트 에셋으로 교체 권장
