# -*- coding: utf-8 -*-
"""
전국 단속카메라 CSV → 내 Firebase(Firestore) 업로드 스크립트 (1회 실행)
=======================================================================

왜 필요한가?
  data.go.kr의 단속카메라 "오픈API 활용신청"이 찾기 어려워졌지만,
  같은 데이터의 CSV 파일은 계속 무료로 내려받을 수 있음.
  이 스크립트가 CSV를 내 Firebase에 올려두면, 앱은 API 키 없이
  Firestore에서 전국 카메라를 자동 동기화함 (완전 무료).

사용법 (컴퓨터에서 딱 한 번):
  1) CSV 다운로드
     https://www.data.go.kr/data/15028200/standard.do
     페이지에서 [CSV] 버튼 → 파일 저장 (예: cameras.csv)
     ※ 페이지가 바뀌었으면 data.go.kr에서 "무인교통단속카메라" 검색 → 표준데이터 → 파일데이터

  2) Firebase 서비스 계정 키 다운로드
     Firebase 콘솔 → 프로젝트 설정(톱니) → 서비스 계정 → "새 비공개 키 생성"
     → serviceAccountKey.json 으로 저장 (이 파일은 절대 공유/커밋 금지!)

  3) 실행
     pip install firebase-admin
     python upload_safety_cameras.py cameras.csv serviceAccountKey.json

  끝. 앱을 다시 실행하면 "✅ Firebase에서 단속카메라 N건 동기화 완료" 로그가 뜸.
  (데이터가 갱신되면 이 스크립트만 다시 돌리면 됨 - 표준데이터는 매월 초 갱신)

저장 구조 (앱의 SafetyCameraStore.syncFromFirebase와 맞춰져 있음 - 바꾸지 말 것):
  컬렉션 safety_camera_chunks
    문서 chunk_0, chunk_1, ... : { "json": "[{...},{...}]", "count": N, "updatedAt": ms }
  카메라 수천 개를 문서 하나에 JSON 문자열로 묶어 저장 → 앱은 문서 3~4개만 읽으면 끝
  (문서당 1MB 제한이 있어 800KB 기준으로 자동 분할)
"""
import csv, json, sys, time, io

def detect(row, *names):
    """CSV 헤더 이름이 조금씩 달라도 찾아냄"""
    for n in names:
        for k in row.keys():
            if n in k:
                return k
    return None

def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    csv_path, key_path = sys.argv[1], sys.argv[2]

    import firebase_admin
    from firebase_admin import credentials, firestore
    firebase_admin.initialize_app(credentials.Certificate(key_path))
    db = firestore.client()

    cameras = []
    # 공공데이터 CSV는 cp949(euc-kr)인 경우가 많음 → utf-8 실패 시 cp949로 재시도
    for enc in ("utf-8-sig", "cp949", "euc-kr"):
        try:
            with io.open(csv_path, "r", encoding=enc) as f:
                reader = csv.DictReader(f)
                rows = list(reader)
            break
        except (UnicodeDecodeError, UnicodeError):
            rows = None
    if not rows:
        print("CSV 인코딩을 읽지 못했어요. 엑셀에서 'CSV UTF-8'로 다시 저장해보세요.")
        sys.exit(1)

    lat_k = detect(rows[0], "위도", "latitude")
    lng_k = detect(rows[0], "경도", "longitude")
    se_k  = detect(rows[0], "단속구분", "regltSe")
    lim_k = detect(rows[0], "제한속도", "lmttVe")
    if not lat_k or not lng_k:
        print("위도/경도 컬럼을 찾지 못했어요. CSV 헤더:", list(rows[0].keys()))
        sys.exit(1)

    for r in rows:
        try:
            lat = float(r[lat_k]); lng = float(r[lng_k])
        except (ValueError, TypeError, KeyError):
            continue
        if not (33.0 < lat < 39.5 and 124.0 < lng < 132.0):   # 한국 범위 밖 이상치 제거
            continue
        se = (r.get(se_k) or "") if se_k else ""
        cam_type = "SIGNAL_CAMERA" if ("신호" in se or se.strip() in ("2", "02")) \
                   else ("SECTION_START" if "구간" in se else "SPEED_CAMERA")
        cam = {"type": cam_type, "lat": round(lat, 6), "lng": round(lng, 6)}
        if lim_k:
            try:
                lim = int(float(r[lim_k]))
                if 10 <= lim <= 130:
                    cam["limit"] = lim
            except (ValueError, TypeError):
                pass
        cameras.append(cam)

    if len(cameras) < 100:
        print(f"카메라를 {len(cameras)}건밖에 못 읽었어요. CSV 파일을 확인하세요.")
        sys.exit(1)

    # 800KB 기준으로 청크 분할 후 업로드
    CHUNK_BYTES = 800 * 1024
    chunks, cur = [], []
    cur_size = 2
    for c in cameras:
        s = json.dumps(c, ensure_ascii=False, separators=(",", ":"))
        if cur_size + len(s.encode()) + 1 > CHUNK_BYTES:
            chunks.append(cur); cur = []; cur_size = 2
        cur.append(c); cur_size += len(s.encode()) + 1
    if cur:
        chunks.append(cur)

    col = db.collection("safety_camera_chunks")
    # 기존 청크 삭제 (개수가 줄었을 때 잔여물 방지)
    for d in col.stream():
        d.reference.delete()
    now = int(time.time() * 1000)
    for i, ch in enumerate(chunks):
        col.document(f"chunk_{i}").set({
            "json": json.dumps(ch, ensure_ascii=False, separators=(",", ":")),
            "count": len(ch),
            "updatedAt": now,
        })
        print(f"chunk_{i}: {len(ch)}건 업로드")

    print(f"\n✅ 완료! 전국 단속카메라 {len(cameras)}건을 문서 {len(chunks)}개로 업로드했어요.")
    print("앱을 실행하면 7일 주기로 자동 동기화됩니다 (로그 태그: NaviFit-Camera)")

if __name__ == "__main__":
    main()
