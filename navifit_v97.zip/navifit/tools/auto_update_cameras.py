# -*- coding: utf-8 -*-
"""
전국 단속카메라 자동 업데이트 스크립트 (GitHub Actions에서 매월 자동 실행)
==========================================================================

사람이 매월 CSV를 받아 올릴 필요 없이, GitHub Actions가 매월 자동으로:
  data.go.kr 오픈API에서 전국 카메라 전체를 받아 → 내 Firebase에 업로드

동작 순서:
  ① 환경변수 DATA_GO_KR_KEY 가 있으면 → 오픈API에서 전체 페이지 수집 (권장)
  ② 없거나 실패하면 → 환경변수 CSV_URL 에서 CSV 다운로드 시도
  ③ 변환 후 Firestore safety_camera_chunks 에 청크 업로드 (앱 포맷과 동일)

필요한 GitHub Secrets (레포 Settings → Secrets and variables → Actions):
  FIREBASE_SERVICE_ACCOUNT : Firebase 콘솔 → 프로젝트 설정 → 서비스 계정 →
                             "새 비공개 키 생성"으로 받은 JSON 파일의 "내용 전체"를 붙여넣기
  DATA_GO_KR_KEY (권장)    : data.go.kr 일반 인증키(Decoding). 표준데이터 API는 자동승인.
                             ※ 포털에서 신청 메뉴를 못 찾겠으면 이 시크릿은 비워두고
                               CSV_URL 만 넣어도 됨.
  CSV_URL (선택)           : 카메라 CSV 직접 다운로드 주소 (data.go.kr 파일데이터의
                             다운로드 링크 주소 복사). API 키가 없을 때의 예비 경로.

수동 실행 테스트: GitHub 레포 → Actions 탭 → "단속카메라 자동 업데이트" → Run workflow
"""
import csv, io, json, os, sys, time
import urllib.request, urllib.parse

API_URL = "https://api.data.go.kr/openapi/tn_pubr_public_unmanned_traffic_camera_api"


def http_get(url, timeout=60):
    req = urllib.request.Request(url, headers={"User-Agent": "navifit-camera-sync/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def classify(se, lat, lng, limit):
    if not (33.0 < lat < 39.5 and 124.0 < lng < 132.0):
        return None
    t = "SIGNAL_CAMERA" if ("신호" in se or se.strip() in ("2", "02")) \
        else ("SECTION_START" if "구간" in se else "SPEED_CAMERA")
    cam = {"type": t, "lat": round(lat, 6), "lng": round(lng, 6)}
    if limit and 10 <= limit <= 130:
        cam["limit"] = limit
    return cam


def fetch_from_api(key):
    """data.go.kr 오픈API에서 전체 수집 (1000건 × 최대 60페이지)"""
    already_encoded = any(x in key for x in ("%2B", "%2F", "%3D"))
    service_key = key if already_encoded else urllib.parse.quote(key, safe="")
    cams, page = [], 1
    while page <= 60:
        url = f"{API_URL}?serviceKey={service_key}&pageNo={page}&numOfRows=1000&type=json"
        try:
            body = json.loads(http_get(url).decode("utf-8", "replace"))
            items = body["response"]["body"]["items"]
        except Exception as e:
            print(f"[API] page {page} 실패: {e}")
            break
        if not items:
            break
        for o in items:
            try:
                lat = float(o.get("latitude", "")); lng = float(o.get("longitude", ""))
            except ValueError:
                continue
            se = (o.get("regltSe") or "") + (o.get("regltSeNm") or "")
            try:
                limit = int(float(o.get("lmttVe") or 0))
            except ValueError:
                limit = 0
            cam = classify(se, lat, lng, limit)
            if cam:
                cams.append(cam)
        if len(items) < 1000:
            break
        page += 1
    print(f"[API] 총 {len(cams)}건 수집")
    return cams


def fetch_from_csv(url):
    """CSV 예비 경로 (utf-8 → cp949 순으로 시도)"""
    raw = http_get(url)
    rows = None
    for enc in ("utf-8-sig", "cp949", "euc-kr"):
        try:
            rows = list(csv.DictReader(io.StringIO(raw.decode(enc))))
            break
        except (UnicodeDecodeError, UnicodeError):
            continue
    if not rows:
        return []

    def col(*names):
        for n in names:
            for k in rows[0].keys():
                if n in k:
                    return k
        return None

    lat_k, lng_k = col("위도", "latitude"), col("경도", "longitude")
    se_k, lim_k = col("단속구분", "regltSe"), col("제한속도", "lmttVe")
    cams = []
    for r in rows:
        try:
            lat = float(r[lat_k]); lng = float(r[lng_k])
        except (ValueError, TypeError, KeyError):
            continue
        se = (r.get(se_k) or "") if se_k else ""
        try:
            limit = int(float(r.get(lim_k) or 0)) if lim_k else 0
        except (ValueError, TypeError):
            limit = 0
        cam = classify(se, lat, lng, limit)
        if cam:
            cams.append(cam)
    print(f"[CSV] 총 {len(cams)}건 수집")
    return cams


def upload(cams):
    import firebase_admin
    from firebase_admin import credentials, firestore
    sa = os.environ["FIREBASE_SERVICE_ACCOUNT"]
    cred = credentials.Certificate(json.loads(sa))
    firebase_admin.initialize_app(cred)
    db = firestore.client()

    CHUNK = 800 * 1024
    chunks, cur, size = [], [], 2
    for c in cams:
        s = json.dumps(c, ensure_ascii=False, separators=(",", ":"))
        if size + len(s.encode()) + 1 > CHUNK:
            chunks.append(cur); cur, size = [], 2
        cur.append(c); size += len(s.encode()) + 1
    if cur:
        chunks.append(cur)

    col = db.collection("safety_camera_chunks")
    for d in col.stream():
        d.reference.delete()
    now = int(time.time() * 1000)
    for i, ch in enumerate(chunks):
        col.document(f"chunk_{i}").set({
            "json": json.dumps(ch, ensure_ascii=False, separators=(",", ":")),
            "count": len(ch), "updatedAt": now,
        })
        print(f"chunk_{i}: {len(ch)}건")
    print(f"✅ 업로드 완료: {len(cams)}건 / 문서 {len(chunks)}개")


def main():
    cams = []
    key = os.environ.get("DATA_GO_KR_KEY", "").strip()
    if key:
        cams = fetch_from_api(key)
    if len(cams) < 100:
        csv_url = os.environ.get("CSV_URL", "").strip()
        if csv_url:
            cams = fetch_from_csv(csv_url)
    if len(cams) < 100:
        print("❌ 카메라를 100건 이상 수집하지 못했습니다. "
              "DATA_GO_KR_KEY 또는 CSV_URL 시크릿을 확인하세요.")
        sys.exit(1)   # 실패로 종료 → GitHub이 이메일로 알려줌. 기존 Firestore 데이터는 그대로 유지됨
    upload(cams)


if __name__ == "__main__":
    main()
