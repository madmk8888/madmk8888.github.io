plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.devtools.ksp") // Room 어노테이션 프로세싱용
    // ✅ Firebase 플러그인은 아래에서 "google-services.json이 있을 때만" 조건부 적용
    //    (파일이 없어도 빌드·설치가 되도록. 없으면 Firebase 기능만 꺼지고 앱은 정상 동작)
    id("com.google.gms.google-services") apply false
}

// ✅ app/google-services.json 이 있을 때만 Firebase 플러그인 적용
//    파일 받는 법: Firebase 콘솔 → 프로젝트 설정(톱니) → 내 앱(Android com.navifit)
//    → google-services.json 다운로드 → 이 파일을 app/ 폴더에 복사
if (file("google-services.json").exists()) {
    apply(plugin = "com.google.gms.google-services")
} else {
    println("⚠️ app/google-services.json 이 없어 Firebase 없이 빌드합니다 (구글로그인·친구·DM·공유키 서버기능 꺼짐)")
}

android {
    namespace = "com.navifit"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.navifit"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Jetpack Compose
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material")          // ✅ pullRefresh (운동장 당겨서 새로고침)
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")  // ✅ v36 NotificationCompat (알림)
    // ✅ v41 번역: ML Kit 온디바이스 번역 (완전 무료·무제한·오프라인·API키 불필요)
    implementation("com.google.mlkit:translate:17.0.2")
    implementation("com.google.mlkit:language-id:17.0.5")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.1")

    // 지도 - Google Maps SDK가 타일/지도데이터 자동 업데이트를 알아서 처리함
    // (개발자가 수동으로 지도 업데이트할 필요 없음)
    implementation("com.google.android.gms:play-services-maps:18.2.0")
    implementation("com.google.android.gms:play-services-location:21.2.0")
    implementation("com.google.android.libraries.places:places:3.5.0")
    implementation("com.google.maps.android:maps-compose:4.4.1")

    // 경로 안내 (Directions API 호출용 HTTP 클라이언트)
    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // 로컬 DB (운동/주행 기록 저장)
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // 그래프/차트 (운동 분석 화면용)
    implementation("com.patrykandpatrick.vico:compose:1.13.1")
    implementation("io.coil-kt:coil-compose:2.6.0")

    // 코루틴
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Firebase 인증 - 구글 + 익명만 사용
    // Firebase - BOM으로 버전 통합 관리 (BOM 없으면 개별 라이브러리 버전을 못 찾음)
    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))
    implementation("com.google.firebase:firebase-auth-ktx")
    implementation("com.google.firebase:firebase-firestore-ktx")
    implementation("com.google.android.gms:play-services-auth:21.2.0")

    // 코루틴에서 Firebase Task를 await()로 쓰기 위한 확장
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")
}
