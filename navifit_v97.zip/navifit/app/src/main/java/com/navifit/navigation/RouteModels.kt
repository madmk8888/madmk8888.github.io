package com.navifit.navigation

data class LatLngPoint(
    val latitude: Double,
    val longitude: Double
)

/**
 * 경로 안내 한 단계 (예: "300m 앞에서 우회전")
 */
data class RouteStep(
    val instruction: String,       // 음성/텍스트로 보여줄 안내문
    val distanceMeters: Int,
    val durationSeconds: Int,
    val startLocation: LatLngPoint,
    val endLocation: LatLngPoint,
    val maneuver: String?          // "turn-right", "turn-left", "straight" 등
)

data class RouteResult(
    val steps: List<RouteStep>,
    val totalDistanceMeters: Int,
    val totalDurationSeconds: Int,
    val overviewPolyline: String,  // 지도에 그릴 인코딩된 경로선
    val mode: TravelMode
)

/**
 * 실시간 주행/운동 중 현재 상태
 */
data class LiveTrackingState(
    val currentLocation: LatLngPoint?,
    val elapsedSeconds: Long = 0,
    val distanceTraveledMeters: Double = 0.0,
    val currentSpeedKmh: Double = 0.0,
    val nextInstruction: String? = null,
    val nextInstructionDistanceMeters: Int? = null,
    val isOffRoute: Boolean = false
)
