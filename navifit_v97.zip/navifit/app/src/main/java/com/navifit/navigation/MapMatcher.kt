package com.navifit.navigation

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sqrt

/**
 * ✅ v73 오프라인 맵매칭 (무료·무제한, API 호출 없음).
 *
 * Roads API(유료) 대신, GPS 궤적을 "이미 받아둔 경로 폴리라인" 또는 "자기 자신의 부드러운 궤적"에
 * 투영해서 지그재그·튐을 깔끔하게 정리한다. 안내 경로가 있을 때 특히 정확.
 *
 * 원리: 각 GPS 점을 경로의 가장 가까운 선분에 수직 투영(projection) → 도로 위로 붙임.
 *      경로에서 너무 멀면(이탈) 원래 점 유지.
 */
object MapMatcher {

    /**
     * GPS 궤적을 경로 폴리라인에 맵매칭. 경로가 없으면 이동평균으로 부드럽게만 처리.
     * @param trace 원본 GPS 궤적
     * @param route 안내 경로 폴리라인 (없으면 null)
     * @param maxSnapMeters 이 거리 안이면 경로에 붙임(그 이상은 이탈로 보고 원본 유지)
     */
    fun match(trace: List<LatLngPoint>, route: List<LatLngPoint>?, maxSnapMeters: Double = 25.0): List<LatLngPoint> {
        if (trace.size < 2) return trace
        // 경로가 있으면 경로에 스냅
        if (route != null && route.size >= 2) {
            return trace.map { p -> snapToPolyline(p, route, maxSnapMeters) ?: p }
        }
        // 경로 없으면 이동평균(3점)으로 지터만 완화
        return smooth(trace)
    }

    /** 한 점을 폴리라인의 가장 가까운 선분에 투영. maxSnap 초과면 null(이탈). */
    private fun snapToPolyline(p: LatLngPoint, poly: List<LatLngPoint>, maxSnap: Double): LatLngPoint? {
        var best: LatLngPoint? = null
        var bestDist = Double.MAX_VALUE
        for (i in 1 until poly.size) {
            val proj = projectOnSegment(p, poly[i - 1], poly[i])
            val d = fastDist(p, proj)
            if (d < bestDist) { bestDist = d; best = proj }
        }
        return if (bestDist <= maxSnap) best else null
    }

    /** 점 p를 선분 a-b에 수직 투영한 좌표 반환. */
    private fun projectOnSegment(p: LatLngPoint, a: LatLngPoint, b: LatLngPoint): LatLngPoint {
        // 위경도를 평면 근사(작은 거리라 오차 무시): 경도는 위도 코사인 보정
        val latRad = Math.toRadians(a.latitude)
        val kx = cos(latRad)
        val ax = a.longitude * kx; val ay = a.latitude
        val bx = b.longitude * kx; val by = b.latitude
        val px = p.longitude * kx; val py = p.latitude
        val dx = bx - ax; val dy = by - ay
        val len2 = dx * dx + dy * dy
        if (len2 == 0.0) return a
        var t = ((px - ax) * dx + (py - ay) * dy) / len2
        t = t.coerceIn(0.0, 1.0)
        val projX = ax + t * dx
        val projY = ay + t * dy
        return LatLngPoint(projY, projX / kx)
    }

    /** 3점 이동평균 스무딩 (지터 완화). 끝점은 유지. */
    private fun smooth(trace: List<LatLngPoint>): List<LatLngPoint> {
        if (trace.size < 3) return trace
        val out = ArrayList<LatLngPoint>(trace.size)
        out.add(trace.first())
        for (i in 1 until trace.size - 1) {
            val a = trace[i - 1]; val b = trace[i]; val c = trace[i + 1]
            out.add(LatLngPoint(
                (a.latitude + b.latitude + c.latitude) / 3,
                (a.longitude + b.longitude + c.longitude) / 3
            ))
        }
        out.add(trace.last())
        return out
    }

    private fun fastDist(a: LatLngPoint, b: LatLngPoint): Double {
        val latRad = Math.toRadians(a.latitude)
        val dx = (b.longitude - a.longitude) * cos(latRad) * 111_320.0
        val dy = (b.latitude - a.latitude) * 110_540.0
        return sqrt(dx * dx + dy * dy)
    }
}
