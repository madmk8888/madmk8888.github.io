package com.navifit.i18n

import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext

/**
 * ✅ v43 UI 자동 번역 레이어.
 *
 * 문제: 화면 문구가 199곳 한국어로 하드코딩돼 있어서, 영어를 골라도 탭만 영어고
 *      나머지(버튼·안내문·다이얼로그)는 전부 한국어로 남아 "번역이 이상한" 상태였음.
 *      15개 언어 × 199개 문구를 손으로 번역하는 건 현실적으로 불가능.
 *
 * 해결: 한국어 원문을 ML Kit(무료·온디바이스)로 실행 중에 번역하고 디스크에 캐시.
 *      - 한국어 사용자: 번역 자체를 안 함 (원문 그대로, 성능 영향 0)
 *      - 다른 언어: 첫 실행 때 한 번 번역하고 캐시 → 이후엔 즉시 표시
 *      - 번역 실패/모델 미다운로드 시엔 한국어 원문을 보여줌 (빈 화면 방지)
 *
 * 사용: Text(tr("게시하기")) 처럼 문자열만 감싸면 됨. 나머지 파라미터는 그대로.
 */
object TranslationCache {
    private const val PREF = "ui_translation_cache"
    private val memory = mutableMapOf<String, String>()

    fun get(ctx: android.content.Context, ko: String, lang: String): String? {
        val key = "$lang|$ko"
        memory[key]?.let { return it }
        val v = ctx.getSharedPreferences(PREF, android.content.Context.MODE_PRIVATE)
            .getString(key, null)
        if (v != null) memory[key] = v
        return v
    }

    fun put(ctx: android.content.Context, ko: String, lang: String, translated: String) {
        val key = "$lang|$ko"
        memory[key] = translated
        ctx.getSharedPreferences(PREF, android.content.Context.MODE_PRIVATE)
            .edit().putString(key, translated).apply()
    }

    /** 언어를 바꿨을 때 메모리 캐시 정리 (디스크 캐시는 언어별로 분리돼 있어 유지) */
    fun clearMemory() = memory.clear()
}

/**
 * 한국어 원문을 현재 앱 언어로 자동 번역해서 반환.
 * 번역이 준비되기 전엔 원문을 그대로 반환하므로 화면이 비지 않음.
 */
@Composable
fun tr(ko: String): String {
    val ctx = LocalContext.current
    val lang = LanguageStore.current(ctx).code
    if (lang == "ko" || ko.isBlank()) return ko

    // 캐시에 있으면 즉시 (재조합 때마다 번역 호출하지 않음)
    val cached = TranslationCache.get(ctx, ko, lang)
    var out by remember(ko, lang) { mutableStateOf(cached ?: ko) }

    LaunchedEffect(ko, lang) {
        if (TranslationCache.get(ctx, ko, lang) == null) {
            val r = TranslationService.translate(ko, "ko", lang)
            if (r != null) {
                TranslationCache.put(ctx, ko, lang, r)
                out = r
            }
        }
    }
    return out
}
