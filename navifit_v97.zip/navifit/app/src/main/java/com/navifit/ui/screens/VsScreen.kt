package com.navifit.ui.screens

import com.navifit.i18n.tr
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.navifit.vs.VsMatchSystem
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * ✅ VS 실시간 대결 화면 (운동장과 내정보 사이 탭).
 *  옵션 선택 → 매칭(1000명 풀에서 추출, 없으면 봇) → 10초 카운트다운(배너광고) →
 *  100m 달리기 → 광고 → 승/패 + 포인트 결산.
 *
 * 실제 달리기 측정은 운동 화면과 연동해야 하지만, 여기서는 대결 성사·상대 표시·
 * 결산 로직을 완성해 테스트 가능하게 함(도착시간은 상대=평균기록, 나=측정값/데모).
 */
enum class VsPhase { OPTION, MATCHING, COUNTDOWN, RUNNING, RESULT }

/**
 * ✅ v66 VS 게임 상태 홀더 (탭을 바꿔도 대결이 초기화되지 않도록 화면 밖에 보관).
 * MainActivity가 이 객체 하나를 remember로 유지하고 VsScreen에 주입.
 */
class VsGameState {
    var phase by mutableStateOf(VsPhase.OPTION)
    var option by mutableStateOf(VsMatchSystem.MatchOption.ALL)
    var opponent by mutableStateOf<VsMatchSystem.Opponent?>(null)
    var countdown by mutableStateOf(10)
    var myPoints by mutableStateOf(0)
    var settlement by mutableStateOf<VsMatchSystem.Settlement?>(null)
    var myTime by mutableStateOf(0.0)
    var runProgress by mutableStateOf(0.0)
    var lastPolyline by mutableStateOf<String?>(null)
    var isFriendMatch by mutableStateOf(false)
    var isFalseStart by mutableStateOf(false)   // ✅ v71 부정출발 여부
    var forfeited by mutableStateOf(false)      // ✅ v77 기권 여부
    // ✅ v81
    var opponentLeftRoom by mutableStateOf(false)   // 상대가 방을 나갔는지 (다시대결 비활성화용)
    var matchWaitSeconds by mutableStateOf(0)       // 매칭 대기 경과 초
    var matchingBotNotice by mutableStateOf(false)  // "봇과 대결합니다" 안내 표시
    var rematchAsking by mutableStateOf(false)      // 다시대결 상대 의사 묻는 중
    var started = false   // runBattle 중복 방지
}

@Composable
fun VsScreen(
    myNickname: String,
    state: VsGameState,
    onMeasure100m: ((onProgress: (Double) -> Unit, onDone: (timeSec: Double, polyline: String?) -> Unit) -> Unit)? = null,
    onSaveRoute: ((polyline: String, timeSeconds: Double) -> Unit)? = null,
    onShowAd: ((onDone: () -> Unit) -> Unit)? = null
) {
    val ctx = LocalContext.current
    val pool = remember { VsMatchSystem.generateOpponentPool() }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { state.myPoints = VsMatchSystem.myPoints(ctx) }

    /**
     * ✅ v85 실제 경기 진행 (매칭 이후 단계).
     * 재대결에서는 매칭을 건너뛰고 이 함수만 다시 호출해서 바로 카운트다운으로 들어간다.
     * (기존 버그: 재대결 수락 후 runBattle()을 통째로 불러서 "상대 찾는 중"으로 되돌아갔음)
     */
    fun startCountdownAndRace() {
        scope.launch {
            VsMatchSystem.markStreakStartIfNeeded(ctx)
            state.phase = VsPhase.COUNTDOWN
            state.countdown = 10
            // ✅ v90 카운트다운 진동 (3·2·1) + 출발 강한 진동
            //   화면을 안 봐도 출발 타이밍을 알 수 있게
            while (state.countdown > 0) {
                if (state.countdown <= 3) com.navifit.tracking.HapticFeedback.countdownTick(ctx)
                delay(1000); state.countdown--
            }
            com.navifit.tracking.HapticFeedback.raceStart(ctx)
            state.phase = VsPhase.RUNNING
            state.runProgress = 0.0

            val opp = state.opponent ?: run { state.phase = VsPhase.OPTION; return@launch }
            var settled = false
            fun doSettle(myT: Double, poly: String?, isFalseStart: Boolean) {
                if (settled) return
                settled = true
                state.myTime = myT; state.lastPolyline = poly
                val mult = when {
                    state.isFriendMatch -> 0.0
                    isFalseStart -> 0.5
                    opp.isBot -> 0.1
                    else -> 1.0
                }
                val settle = {
                    val st = VsMatchSystem.settle(ctx, state.myPoints, opp.points,
                        if (isFalseStart) 9999.0 else myT, opp.avgTime100m, mult)
                    state.settlement = st
                    state.myPoints = st.newMyPoints
                    state.isFalseStart = isFalseStart
                    if (!isFalseStart) poly?.let { onSaveRoute?.invoke(it, myT) }
                    // ✅ v90 승패 진동 (승리=리듬감 / 패배=둔탁)
                    if (st.iWon) com.navifit.tracking.HapticFeedback.win(ctx)
                    else com.navifit.tracking.HapticFeedback.lose(ctx)
                    state.phase = VsPhase.RESULT
                }
                if (onShowAd != null) onShowAd.invoke { settle() } else settle()
            }

            // 상대가 자기 기록 시간에 도착하면, 내가 아직 100m 못 갔으면 즉시 패배 처리.
            val oppFinishJob = launch {
                delay((opp.avgTime100m * 1000).toLong())
                if (!settled && state.runProgress < 100.0) {
                    doSettle(opp.avgTime100m + 5.0, state.lastPolyline, false)
                }
            }

            if (onMeasure100m != null) {
                onMeasure100m({ p -> state.runProgress = p }, { t, poly ->
                    oppFinishJob.cancel()
                    doSettle(t, poly, t >= 999.0)
                })
            } else {
                delay((opp.avgTime100m * 1000).toLong() + 500)
                oppFinishJob.cancel()
                doSettle((12..18).random() + Math.random(), null, false)
            }
        }
    }

    // 대결 성사 → 카운트다운 → 실측(봇 시간과 레이스) → 광고 → 결산
    fun runBattle(friendCode: String? = null) {
        state.phase = VsPhase.MATCHING
        state.isFriendMatch = friendCode != null
        state.opponentLeftRoom = false
        scope.launch {
            var found: VsMatchSystem.Opponent? = null
            if (friendCode != null) {
                delay(1200)
                found = VsMatchSystem.findFriendByCode(friendCode, pool)
            } else {
                // ✅ v81 실사용자 매칭 대기 최대 120초. 못 찾으면 봇과 대결 안내 후 매칭.
                state.matchWaitSeconds = 0
                var waited = 0
                while (waited < 120) {
                    delay(1000); waited++; state.matchWaitSeconds = waited
                    found = VsMatchSystem.findOpponent(state.myPoints, state.option, pool)
                    if (found != null && waited >= 2) break
                    found = null
                }
                if (found == null) {
                    state.matchingBotNotice = true
                    delay(1500)   // "봇과 대결합니다" 안내 노출
                    found = VsMatchSystem.createTieredBot(state.option, state.myPoints)
                    state.matchingBotNotice = false
                }
            }
            state.opponent = found
            // 매칭 끝 → 실제 경기 단계로
            startCountdownAndRace()
        }
    }

    var showScoreHelp by remember { mutableStateOf(false) }
    var showRematchConfirm by remember { mutableStateOf(false) }

    fun resetToOption() {
        state.phase = VsPhase.OPTION; state.opponent = null; state.settlement = null
        state.runProgress = 0.0; state.isFalseStart = false; state.forfeited = false
        state.rematchAsking = false; state.opponentLeftRoom = false
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(tr("⚔️ VS 대결"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.width(6.dp))
            // ✅ v81 점수체계 설명 (?)
            Box(
                Modifier.size(22.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant, androidx.compose.foundation.shape.CircleShape)
                    .clickable { showScoreHelp = true },
                contentAlignment = Alignment.Center
            ) { Text("?", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            Spacer(Modifier.weight(1f))
            Box(Modifier.background(Color(0xFF243247), RoundedCornerShape(20.dp)).padding(horizontal = 14.dp, vertical = 6.dp)) {
                Text("💠 ${state.myPoints} P", color = Color(0xFF7CC7FF), fontWeight = FontWeight.Bold)
            }
        }
        Text(tr("100m 달리기 실시간 대결 · 이기면 포인트 상승"), fontSize = 11.sp, color = Color(0xFF8B93AC))
        Spacer(Modifier.height(16.dp))

        when (state.phase) {
            VsPhase.OPTION -> OptionView(state.option, { state.option = it },
                onMatch = { runBattle() }, onFriendMatch = { code -> runBattle(code) })
            VsPhase.MATCHING -> MatchingView(
                optionLabel = optionLabel(state.option),
                waited = state.matchWaitSeconds,
                botNotice = state.matchingBotNotice
            )
            VsPhase.COUNTDOWN -> state.opponent?.let { CountdownView(it, myNickname, state.myPoints, state.countdown) }
            VsPhase.RUNNING -> RunningView(state.runProgress, onForfeit = {
                // ✅ v77 기권: 이긴 사람(상대)은 0점, 기권자는 -50P
                val opp = state.opponent
                if (opp != null) {
                    val cur = VsMatchSystem.myPoints(ctx)
                    val newPts = (cur - 50).coerceAtLeast(0)
                    VsMatchSystem.setMyPoints(ctx, newPts)
                    state.myPoints = newPts
                    state.settlement = VsMatchSystem.Settlement(-50, 0, newPts, false)
                    state.isFalseStart = false
                    state.forfeited = true
                    state.phase = VsPhase.RESULT
                }
            })
            VsPhase.RESULT -> {
                val s = state.settlement; val opp = state.opponent
                if (s != null && opp != null) ResultView(
                    s, opp, state.myTime, state.isFriendMatch, state.isFalseStart, state.forfeited,
                    rematchAsking = state.rematchAsking,
                    opponentLeft = state.opponentLeftRoom,
                    onRematch = {
                        // ✅ v81 다시대결: 상대 의사를 묻는 대기 → 수락/거절
                        state.rematchAsking = true
                        scope.launch {
                            delay((2000..4000).random().toLong())
                            state.rematchAsking = false
                            // 봇은 항상 수락, 사람은 70% 수락
                            val accepted = opp.isBot || Math.random() < 0.7
                            if (accepted) showRematchConfirm = true
                            else { state.opponentLeftRoom = true }
                        }
                    },
                    onExit = { resetToOption() }
                )
            }
        }
    }

    // ✅ v81 점수체계 설명 팝업
    if (showScoreHelp) {
        AlertDialog(
            onDismissRequest = { showScoreHelp = false },
            title = { Text(tr("💠 포인트 점수 체계")) },
            text = {
                Column {
                    Text(tr("• 이기면 포인트를 얻고, 지면 잃어요."), fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(tr("• 상대 점수가 나보다 높을수록 이겼을 때 더 많이 받고, 졌을 때 덜 잃어요."), fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    Text(tr("• 예) 500점 vs 500점 → 약 ±50P / 1000점 vs 10점(내가 하위) → 이기면 최대 +100P"), fontSize = 12.sp, color = Color(0xFF8B93AC))
                    Spacer(Modifier.height(10.dp))
                    Text(tr("배율"), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(tr("• 사람과 대결: 100%\n• 🤖 봇과 대결: 10%만 적용\n• 👥 친선전(친구): 포인트 변동 없음\n• 🚫 부정 출발: 잃는 포인트 50%만 적용\n• 🏳️ 기권: -50P 고정 (상대는 승리)"),
                        fontSize = 12.sp, lineHeight = 18.sp, color = Color(0xFF8B93AC))
                    Spacer(Modifier.height(10.dp))
                    Text(tr("🤖 봇 등급별 기록"), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(tr("• 초고수 10.3초 · 고수 12초 · 중수 14초 · 하수 16초\n• 상대가 먼저 100m에 도착하면 그 즉시 패배로 끝나요"),
                        fontSize = 12.sp, lineHeight = 18.sp, color = Color(0xFF8B93AC))
                }
            },
            confirmButton = { TextButton(onClick = { showScoreHelp = false }) { Text(tr("확인")) } }
        )
    }

    // ✅ v81 상대가 재대결 수락 → 진행할지 확인
    if (showRematchConfirm) {
        AlertDialog(
            onDismissRequest = { showRematchConfirm = false },
            title = { Text(tr("상대가 재대결을 수락했어요")) },
            text = { Text("${state.opponent?.nickname ?: "상대"} 님과 다시 대결할까요?\n취소를 누르면 방에서 나갑니다.") },
            confirmButton = {
                TextButton(onClick = {
                    showRematchConfirm = false
                    // ✅ v85 상대를 그대로 유지한 채 바로 카운트다운 → 매칭 화면으로 안 돌아감
                    state.settlement = null; state.runProgress = 0.0
                    state.isFalseStart = false; state.forfeited = false
                    state.opponentLeftRoom = false
                    startCountdownAndRace()
                }) { Text(tr("확인")) }
            },
            dismissButton = {
                TextButton(onClick = { showRematchConfirm = false; resetToOption() }) { Text(tr("취소")) }
            }
        )
    }
}

/** ✅ v81 매칭 대기 화면: 경과 초 + 2분 초과 시 봇 안내 */
@Composable
private fun MatchingView(optionLabel: String, waited: Int, botNotice: Boolean) {
    Column(Modifier.fillMaxWidth().padding(top = 60.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        val pulse: Float by rememberInfiniteTransition(label = "m").animateFloat(
            0.75f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "p")
        Text("🔍", fontSize = 46.sp, modifier = Modifier.alpha(pulse))
        Spacer(Modifier.height(14.dp))
        if (botNotice) {
            Text(tr("🤖 상대를 못 찾았어요"), fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFFBBF6E))
            Spacer(Modifier.height(8.dp))
            Text(tr("봇과 대결합니다!"), fontSize = 14.sp, color = Color(0xFFC7CBD9))
        } else {
            Text(tr("상대를 찾는 중..."), fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onBackground)
            Spacer(Modifier.height(8.dp))
            Text(tr("옵션: %s").format(optionLabel), fontSize = 13.sp, color = Color(0xFF8B93AC))
            Spacer(Modifier.height(4.dp))
            Text(tr("%s초 경과 · 2분(120초) 안에 못 찾으면 봇과 대결해요").format(waited),
                fontSize = 12.sp, color = Color(0xFF8B93AC), textAlign = TextAlign.Center)
            Spacer(Modifier.height(14.dp))
            LinearProgressIndicator(
                progress = { (waited / 120f).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth(0.7f).height(6.dp).clip(RoundedCornerShape(3.dp)),
                color = Color(0xFF3B82F6), trackColor = Color(0xFF243247)
            )
        }
    }
}

@Composable
private fun RunningView(progress: Double, onForfeit: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        // ═══ ✅ v85 화려한 달리기 연출 ═══
        val t = rememberInfiniteTransition(label = "run")
        // 상하 바운스 (달리는 리듬)
        val bounce by t.animateFloat(0f, -20f,
            infiniteRepeatable(tween(260, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b")
        // 좌우 살짝 흔들림
        val sway by t.animateFloat(-4f, 4f,
            infiniteRepeatable(tween(520, easing = LinearEasing), RepeatMode.Reverse), label = "s")
        // 후광 맥동
        val glow by t.animateFloat(0.35f, 1f,
            infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "g")
        // 반짝이 회전
        val spark by t.animateFloat(0f, 360f,
            infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "sp")
        // 스피드 라인 흐름
        val dash by t.animateFloat(0f, 30f,
            infiniteRepeatable(tween(420, easing = LinearEasing)), label = "d")

        Box(Modifier.height(120.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
            // 뒤쪽 오로라 후광
            Box(
                Modifier.size(104.dp).graphicsLayer { alpha = glow * 0.55f }
                    .background(
                        Brush.radialGradient(
                            listOf(Color(0xFF34D399), Color(0x0034D399))
                        ), androidx.compose.foundation.shape.CircleShape
                    )
            )
            // 스피드 라인 (뒤로 흐르는 잔상)
            Row(
                Modifier.fillMaxWidth().offset(y = bounce.dp * 0.4f),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(3) { i ->
                    Box(
                        Modifier
                            .offset(x = (-46 - i * 16 - dash * 0.5f).dp)
                            .width((16 + i * 8).dp).height(2.5.dp)
                            .graphicsLayer { alpha = (1f - i * 0.28f) * glow }
                            .background(Color(0xFF7CE7B8), RoundedCornerShape(2.dp))
                    )
                }
            }
            // 반짝이 4개 (러너 주변을 도는 별)
            repeat(4) { i ->
                val ang = Math.toRadians((spark + i * 90.0))
                Text(
                    "✨", fontSize = (11 + i % 2 * 4).sp,
                    modifier = Modifier
                        .offset(x = (kotlin.math.cos(ang) * 46).dp, y = (kotlin.math.sin(ang) * 30 + bounce * 0.3).dp)
                        .graphicsLayer { alpha = 0.5f + 0.5f * glow }
                )
            }
            // 러너 본체
            Text(
                "🏃‍♂️", fontSize = 60.sp,
                modifier = Modifier
                    .offset(x = sway.dp, y = bounce.dp)
                    .graphicsLayer { rotationZ = sway * 0.7f }
            )
        }

        Text(tr("100m 전력 질주!"), fontSize = 19.sp, fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onBackground)
        Spacer(Modifier.height(14.dp))

        // 미터 숫자 (진행할수록 색이 뜨거워짐)
        val ratio = (progress / 100.0).toFloat().coerceIn(0f, 1f)
        val meterColor = lerp(Color(0xFF34D399), Color(0xFFFFD22E), ratio)
        Text("%.0f m".format(progress), fontSize = 52.sp, fontWeight = FontWeight.ExtraBold, color = meterColor)
        Text("/ 100 m", fontSize = 14.sp, color = Color(0xFF8B93AC))
        Spacer(Modifier.height(16.dp))

        // 그라데이션 진행바 + 선두 러너 아이콘
        Box(Modifier.fillMaxWidth(0.82f)) {
            Box(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp))
                .background(Color(0xFF243247)))
            Box(
                Modifier.fillMaxWidth(ratio).height(12.dp).clip(RoundedCornerShape(6.dp))
                    .background(Brush.horizontalGradient(
                        listOf(Color(0xFF34D399), Color(0xFF7CE7B8), Color(0xFFFFD22E))))
            )
        }
        Spacer(Modifier.height(18.dp))
        Text(tr("실제로 뛰어야 미터가 올라가요 (GPS 측정)"), fontSize = 11.sp, color = Color(0xFF8B93AC))
        Spacer(Modifier.height(18.dp))
        OutlinedButton(
            onClick = onForfeit,
            modifier = Modifier.fillMaxWidth(0.6f).height(42.dp), shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF6B6B))
        ) { Text(tr("🏳️ 기권하기 (-50P)"), fontSize = 13.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun OptionView(selected: VsMatchSystem.MatchOption, onSelect: (VsMatchSystem.MatchOption) -> Unit,
                      onMatch: () -> Unit, onFriendMatch: (String) -> Unit) {
    var showFriendDialog by remember { mutableStateOf(false) }
    Column {
        Text(tr("매칭 옵션 선택"), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground)
        Spacer(Modifier.height(10.dp))
        VsMatchSystem.MatchOption.values().forEach { opt ->
            val sel = selected == opt
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)
                .background(if (sel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface, RoundedCornerShape(14.dp))
                .border(BorderStroke(if (sel) 1.5.dp else 1.dp, if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant), RoundedCornerShape(14.dp))
                .clickable { onSelect(opt) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = sel, onClick = { onSelect(opt) })
                Spacer(Modifier.width(6.dp))
                Column {
                    Text(optionLabel(opt), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                    Text(optionDesc(opt), fontSize = 11.sp, color = Color(0xFF8B93AC))
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Button(onClick = onMatch, modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935))) {
            Text(tr("⚔️ 매칭 시작"), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { showFriendDialog = true }, modifier = Modifier.fillMaxWidth().height(46.dp),
            shape = RoundedCornerShape(14.dp)) {
            Text(tr("👥 친구와 대결 (고유코드 입력)"), fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Text(tr("친구 대결은 포인트 변동이 없어요 (친선전)"), fontSize = 10.sp, color = Color(0xFF8B93AC),
            modifier = Modifier.padding(top = 4.dp))
    }
    if (showFriendDialog) {
        var code by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showFriendDialog = false },
            title = { Text(tr("친구와 대결")) },
            text = {
                Column {
                    Text(tr("친구의 고유코드를 입력하세요 (예: KR-3F7K9M)"), fontSize = 12.sp, color = Color(0xFF8B93AC))
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = code, onValueChange = { code = it.uppercase() },
                        singleLine = true, placeholder = { Text("KR-XXXXXX") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (code.isNotBlank()) { showFriendDialog = false; onFriendMatch(code.trim()) }
                }) { Text(tr("대결 시작")) }
            },
            dismissButton = { TextButton(onClick = { showFriendDialog = false }) { Text(tr("취소")) } }
        )
    }
}

@Composable
private fun CountdownView(opp: VsMatchSystem.Opponent, myNick: String, myPoints: Int, count: Int) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        // 상대 정보
        OpponentCard(opp)
        Spacer(Modifier.height(24.dp))
        val pulse: Float by rememberInfiniteTransition(label = "cd").animateFloat(
            1f, 1.3f, infiniteRepeatable(tween(500), RepeatMode.Reverse), label = "p")
        Text("$count", fontSize = (70f * pulse).sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFE53935))
        Text(tr("곧 시작합니다!"), fontSize = 14.sp, color = Color(0xFF8B93AC))
        Spacer(Modifier.height(6.dp))
        Text(tr("⚠️ 정지 상태에서 출발하세요. 미리 달리면 부정출발로 몰수패 처리되고 포인트를 회수합니다"),
            fontSize = 11.sp, color = Color(0xFFFBBF6E), textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 20.dp))
        Spacer(Modifier.height(20.dp))
        // 하단 배너광고 자리 (10초간만)
        Box(Modifier.fillMaxWidth().height(56.dp).background(Color(0xFF14161B), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center) {
            Text(tr("[ 배너광고 영역 ]"), color = Color(0xFF5A6072), fontSize = 12.sp)
        }
    }
}

@Composable
private fun OpponentCard(opp: VsMatchSystem.Opponent) {
    Row(Modifier.fillMaxWidth().background(
        Brush.horizontalGradient(listOf(Color(0xFF2A1520), Color(0xFF15151A))), RoundedCornerShape(16.dp))
        .border(BorderStroke(1.dp, Color(0x55E53935)), RoundedCornerShape(16.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(50.dp).clip(CircleShape).background(if (opp.isBot) Color(0xFF3A3F4B) else Color(0xFF243247)),
            contentAlignment = Alignment.Center) {
            Text(if (opp.isBot) "🤖" else "🏃", fontSize = 24.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(opp.nickname, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = Color.White)
                if (opp.isBot) {
                    Spacer(Modifier.width(6.dp))
                    Box(Modifier.background(Color(0xFFE53935), RoundedCornerShape(6.dp)).padding(horizontal = 5.dp, vertical = 1.dp)) {
                        Text("RUN BOT", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Text("${countryFlag(opp.country)} ${opp.country} · 💠 ${opp.points}P", fontSize = 12.sp, color = Color(0xFFC7CBD9))
        }
    }
}

@Composable
private fun ResultView(
    s: VsMatchSystem.Settlement, opp: VsMatchSystem.Opponent, myTime: Double,
    isFriend: Boolean, isFalseStart: Boolean, forfeited: Boolean,
    rematchAsking: Boolean, opponentLeft: Boolean,
    onRematch: () -> Unit, onExit: () -> Unit
) {
    val won = s.iWon && !forfeited && !isFalseStart
    // ✅ v81 화려한 결산 UI - 승리는 금빛/민트 글로우, 패배는 붉은 톤
    val glow: Float by rememberInfiniteTransition(label = "g").animateFloat(
        0.45f, 1f, infiniteRepeatable(tween(1100), RepeatMode.Reverse), label = "gl")
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
        // ── 상단 배너 ──
        Box(
            Modifier.fillMaxWidth().height(150.dp)
                .background(
                    Brush.verticalGradient(
                        if (won) listOf(Color(0xFF10603F), Color(0xFF0C2E24))
                        else listOf(Color(0xFF5C1F26), Color(0xFF2A1216))
                    ), RoundedCornerShape(20.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                when {
                    forfeited -> {
                        Text("🏳️", fontSize = 40.sp)
                        Text(tr("기권"), fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFFF9A9A))
                        Text(tr("상대 승리 · 나 -50P"), fontSize = 12.sp, color = Color(0xFFE8C4C4))
                    }
                    isFalseStart -> {
                        Text("🚫", fontSize = 40.sp)
                        Text(tr("부정 출발"), fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFFF9A9A))
                        Text(tr("정지 상태에서 출발해야 해요 · 몰수패"), fontSize = 11.sp, color = Color(0xFFE8C4C4))
                    }
                    won -> {
                        Text("🏆", fontSize = 46.sp, modifier = Modifier.alpha(glow))
                        Text("VICTORY", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF6FE3A5))
                        Text(tr("승리했어요!"), fontSize = 13.sp, color = Color(0xFFB6F5D8))
                    }
                    else -> {
                        Text("💥", fontSize = 42.sp)
                        Text("DEFEAT", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFFF8080))
                        Text(tr("다음엔 이길 수 있어요"), fontSize = 13.sp, color = Color(0xFFE8C4C4))
                    }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        // ── 기록 대결표 ──
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            RecordCell("나", if (myTime >= 999.0) "몰수" else "%.2f초".format(myTime),
                if (won) Color(0xFF34D399) else Color(0xFFAAB0BD), Modifier.weight(1f))
            Text("VS", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF8B93AC),
                modifier = Modifier.padding(horizontal = 8.dp))
            RecordCell(opp.nickname, "%.2f초".format(opp.avgTime100m),
                if (!won) Color(0xFFFF6B6B) else Color(0xFFAAB0BD), Modifier.weight(1f))
        }
        Spacer(Modifier.height(14.dp))
        // ── 포인트 결산 ──
        Column(Modifier.fillMaxWidth()
            .then(com.navifit.ui.theme.NaviTheme.subtleCard(16.dp))
            .padding(18.dp)) {
            if (isFriend) {
                Text(tr("👥 친선전 (포인트 변동 없음)"), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFFFBBF6E))
            } else {
                Text(tr("포인트 결산"), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                Spacer(Modifier.height(10.dp))
                ResultRow("이번 대결", "${if (s.myDelta >= 0) "+" else ""}${s.myDelta} P", if (s.myDelta >= 0) Color(0xFF34D399) else Color(0xFFFF6B6B))
                ResultRow("현재 포인트", "${s.newMyPoints} P", Color(0xFF3B82F6))
                if (opp.isBot && !forfeited) Text(tr("🤖 봇 대결은 사람 대결의 10% 포인트만 적용돼요"),
                    fontSize = 10.sp, color = Color(0xFF8B93AC), modifier = Modifier.padding(top = 6.dp))
                if (isFalseStart) Text(tr("🚫 부정 출발은 잃는 포인트의 50%만 적용돼요"),
                    fontSize = 10.sp, color = Color(0xFF8B93AC), modifier = Modifier.padding(top = 4.dp))
            }
        }
        Spacer(Modifier.height(16.dp))
        // ── 버튼 ──
        if (rematchAsking) {
            Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(14.dp)).padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(Modifier.size(26.dp), strokeWidth = 3.dp, color = Color(0xFF3B82F6))
                Spacer(Modifier.height(10.dp))
                Text(tr("상대방의 의사를 묻는 중입니다..."), fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = onExit, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(14.dp)) {
                Text(tr("나가기"), fontWeight = FontWeight.Bold)
            }
        } else {
            if (opponentLeft) {
                Text(tr("상대방이 방을 나갔어요 (다시 대결 불가)"), fontSize = 11.sp, color = Color(0xFFFF9A9A))
                Spacer(Modifier.height(6.dp))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onRematch, enabled = !opponentLeft,
                    modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(14.dp)) {
                    Text(tr("다시 대결"), fontWeight = FontWeight.Bold)
                }
                OutlinedButton(onClick = onExit, modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(14.dp)) {
                    Text(tr("나가기"), fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun RecordCell(name: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Column(modifier
        .then(com.navifit.ui.theme.NaviTheme.subtleCard(14.dp))
        .padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(name, fontSize = 11.sp, color = Color(0xFF8B93AC), maxLines = 1)
        Spacer(Modifier.height(4.dp))
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = color)
    }
}

@Composable
private fun ResultRow(label: String, value: String, color: Color) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 13.sp, color = Color(0xFF8B93AC))
        Text(value, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = color)
    }
}

private fun optionLabel(o: VsMatchSystem.MatchOption) = when (o) {
    VsMatchSystem.MatchOption.ALL -> "🌍 전체 랜덤 매칭"
    VsMatchSystem.MatchOption.SIMILAR -> "⚖️ 내 점수대 매칭"
    VsMatchSystem.MatchOption.HIGH -> "🔥 고수만 매칭"
    VsMatchSystem.MatchOption.LOW -> "🌱 하수만 매칭"
}
private fun optionDesc(o: VsMatchSystem.MatchOption) = when (o) {
    VsMatchSystem.MatchOption.ALL -> "포인트 상관없이 아무나"
    VsMatchSystem.MatchOption.SIMILAR -> "비슷한 실력끼리 (±50P 이내)"
    VsMatchSystem.MatchOption.HIGH -> "나보다 강한 상대 (이기면 큰 보상)"
    VsMatchSystem.MatchOption.LOW -> "나보다 약한 상대 (안전하게)"
}
private fun countryFlag(c: String) = when (c) {
    "KR" -> "🇰🇷"; "JP" -> "🇯🇵"; "US" -> "🇺🇸"; "GB" -> "🇬🇧"
    "FR" -> "🇫🇷"; "CN" -> "🇨🇳"; "DE" -> "🇩🇪"; "ES" -> "🇪🇸"; else -> "🌍"
}
