package com.navifit.social

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * ✅ v81 RM 단체 대화방.
 *
 * · 친구 여러 명을 골라 방을 만들고, 방 이름을 직접 정할 수 있다.
 * · 지금은 로컬 저장(SharedPreferences) 기반 — 실서버 연동 시
 *   Firestore `group_rooms/{roomId}` + `messages` 서브컬렉션으로 그대로 옮기면 된다.
 */
object GroupRoomStore {
    private const val PREFS = "rm_group_rooms"
    private const val KEY = "rooms"

    data class Member(val uid: String, val nickname: String)
    data class Message(val senderUid: String, val senderName: String, val text: String, val at: Long)
    data class Room(
        val id: String,
        val name: String,
        val members: List<Member>,
        val messages: List<Message>,
        val createdAt: Long
    ) {
        val lastMessage: String get() = messages.lastOrNull()?.text ?: "아직 대화가 없어요"
        val lastAt: Long get() = messages.lastOrNull()?.at ?: createdAt
    }

    fun list(c: Context): List<Room> = try {
        val raw = c.getSharedPreferences(PREFS, 0).getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val mArr = o.optJSONArray("members") ?: JSONArray()
            val msgArr = o.optJSONArray("messages") ?: JSONArray()
            Room(
                id = o.optString("id"),
                name = o.optString("name"),
                members = (0 until mArr.length()).map { j ->
                    val m = mArr.getJSONObject(j)
                    Member(m.optString("uid"), m.optString("nickname"))
                },
                messages = (0 until msgArr.length()).map { j ->
                    val m = msgArr.getJSONObject(j)
                    Message(m.optString("senderUid"), m.optString("senderName"),
                        m.optString("text"), m.optLong("at"))
                },
                createdAt = o.optLong("createdAt")
            )
        }.sortedByDescending { it.lastAt }
    } catch (_: Exception) { emptyList() }

    fun create(c: Context, name: String, members: List<Member>): Room {
        val room = Room(
            id = "grp_" + System.currentTimeMillis(),
            name = name.ifBlank { members.joinToString(", ") { it.nickname }.take(24) },
            members = members,
            messages = emptyList(),
            createdAt = System.currentTimeMillis()
        )
        save(c, list(c) + room)
        return room
    }

    /** 방 이름 변경 */
    fun rename(c: Context, roomId: String, newName: String) {
        if (newName.isBlank()) return
        save(c, list(c).map { if (it.id == roomId) it.copy(name = newName.trim()) else it })
    }

    fun delete(c: Context, roomId: String) {
        save(c, list(c).filter { it.id != roomId })
    }

    fun send(c: Context, roomId: String, senderUid: String, senderName: String, text: String) {
        if (text.isBlank()) return
        val msg = Message(senderUid, senderName, text.trim(), System.currentTimeMillis())
        save(c, list(c).map { if (it.id == roomId) it.copy(messages = it.messages + msg) else it })
    }

    fun get(c: Context, roomId: String): Room? = list(c).firstOrNull { it.id == roomId }

    private fun save(c: Context, rooms: List<Room>) {
        val arr = JSONArray()
        rooms.forEach { r ->
            val mArr = JSONArray()
            r.members.forEach { m ->
                mArr.put(JSONObject().apply { put("uid", m.uid); put("nickname", m.nickname) })
            }
            val msgArr = JSONArray()
            r.messages.takeLast(300).forEach { m ->
                msgArr.put(JSONObject().apply {
                    put("senderUid", m.senderUid); put("senderName", m.senderName)
                    put("text", m.text); put("at", m.at)
                })
            }
            arr.put(JSONObject().apply {
                put("id", r.id); put("name", r.name)
                put("members", mArr); put("messages", msgArr)
                put("createdAt", r.createdAt)
            })
        }
        c.getSharedPreferences(PREFS, 0).edit().putString(KEY, arr.toString()).apply()
    }
}
