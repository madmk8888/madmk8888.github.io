package com.navifit.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.navifit.i18n.tr
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.navifit.data.ActivityRecord
import com.navifit.i18n.AppLanguage
import kotlinx.coroutines.launch

/**
 * 내정보 화면.
 * - 프로필 카드: 닉네임, 계정 상태(게스트/구글), 이메일
 * - 닉네임 변경 (중복 확인 포함, 게스트는 변경 불가)
 * - 구글 계정 연결 / 연동 확인
 * - 누적 통계 요약
 * - 로그아웃 (구글 연동된 계정은 재로그인 시 정보 복원 안내)
 */
@Composable
fun ProfileScreen(
    nickname: String,
    isAnonymous: Boolean,
    googleEmail: String?,
    records: List<ActivityRecord>,
    totalSteps: Int,
    uniqueCode: String? = null,
    // 닉네임 변경: (새 닉네임, 결과 콜백(성공여부, 메시지))
    onChangeNickname: (String, (Boolean, String) -> Unit) -> Unit,
    onGoogleLink: () -> Unit,
    onVerifyLink: ((String) -> Unit) -> Unit,
    onLogout: () -> Unit,
    onOpenCameraTest: () -> Unit = {},   // ✅ v50 단속카메라 API 테스트 화면 진입
    currentLanguage: AppLanguage = AppLanguage.KOREAN,
    onLanguageChange: (AppLanguage) -> Unit = {}
) {
    var showNicknameDialog by remember { mutableStateOf(false) }
    var showLogoutDialog by remember { mutableStateOf(false) }
    var verifyMessage by remember { mutableStateOf<String?>(null) }
    val bioContext = androidx.compose.ui.platform.LocalContext.current
    var bio by remember { mutableStateOf(com.navifit.social.BioStore.load(bioContext)) }
    var bioSavedMsg by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        // ✅ v61 단속카메라 테스트 → 화장실 API 테스트로 변경
        androidx.compose.material3.OutlinedButton(
            onClick = onOpenCameraTest,
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
        ) { Text(tr("🚻 화장실 API 테스트"), fontSize = 12.sp) }
        Text(com.navifit.i18n.LocalStrings.current.myInfo, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(14.dp))

        // ===== ✅ 소개 한 줄 (최대 100자) - 랭킹 화면에서 내 이름 아래에 보임 =====
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(14.dp)) {
                Text(tr("💬 소개 한 줄"), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = bio,
                    onValueChange = { if (it.length <= com.navifit.social.BioStore.MAX_LENGTH) { bio = it; bioSavedMsg = null } },
                    placeholder = { Text(tr("나를 한 줄로 소개해보세요 (랭킹에서 보여요)"), fontSize = 12.sp) },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                    supportingText = { Text("${bio.length}/${com.navifit.social.BioStore.MAX_LENGTH}", fontSize = 10.sp) }
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                    bioSavedMsg?.let { Text(it, fontSize = 11.sp, color = Color(0xFF5BBD8B), modifier = Modifier.padding(end = 8.dp)) }
                    Button(onClick = {
                        com.navifit.social.BioStore.save(bioContext, bio)
                        bioSavedMsg = "저장됨 ✅"
                    }, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp)) { Text(tr("저장"), fontSize = 12.sp) }
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        // ===== 프로필 카드 =====
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(58.dp).clip(CircleShape)
                            .background(Brush.sweepGradient(listOf(
                                Color(0xFFFF8FA3), Color(0xFFC9A5F5), Color(0xFF8B9FFF), Color(0xFF7EDDB8), Color(0xFFFF8FA3)
                            ))).padding(3.dp)
                    ) {
                        Box(Modifier.fillMaxSize().clip(CircleShape).background(Color(0xFF1E1B27)), contentAlignment = Alignment.Center) {
                            Text(if (isAnonymous) "👤" else "🙋", fontSize = 24.sp)
                        }
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(nickname, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        if (isAnonymous) {
                            Text(tr("게스트 (비회원)"), fontSize = 12.sp, color = Color(0xFFE8B34B), fontWeight = FontWeight.Bold)
                        } else {
                            Text(tr("✅ Google 계정 연동됨"), fontSize = 12.sp, color = Color(0xFF5BBD8B), fontWeight = FontWeight.Bold)
                            googleEmail?.let { Text(it, fontSize = 11.sp, color = Color.Gray) }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ===== 개인 고유코드: RM/친구추가에 사용 (닉네임은 중복될 수 있지만 이 코드는 절대 안 겹침) =====
        Card(
            Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF2E3A5C))
        ) {
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr("🔑 내 고유코드"), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(
                        uniqueCode ?: "발급 중...",
                        fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = Color(0xFF6E85F0)
                    )
                    Text(tr("이 코드를 아는 사람만 나에게 RM을 보내거나 친구로 추가할 수 있어요"), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (uniqueCode != null) {
                    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
                    OutlinedButton(onClick = {
                        clipboard.setText(androidx.compose.ui.text.AnnotatedString(uniqueCode))
                    }) { Text(tr("복사"), fontSize = 12.sp) }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ✅ v61: 내비게이션 설정 섹션 제거 (교차로 자동 확대 설정 삭제 요청)

        Spacer(Modifier.height(12.dp))

        // ===== v35 프라이버시 =====
        SectionTitle("프라이버시 · 안전")
        val ctx = androidx.compose.ui.platform.LocalContext.current
        var dmScope by remember { mutableStateOf(com.navifit.social.PrivacySettings.dmScope(ctx)) }
        var cmtScope by remember { mutableStateOf(com.navifit.social.PrivacySettings.commentScope(ctx)) }
        var privateAcc by remember { mutableStateOf(com.navifit.social.PrivacySettings.isPrivateAccount(ctx)) }
        var showDist by remember { mutableStateOf(com.navifit.social.PrivacySettings.showDistance(ctx)) }

        ScopeSelectorRow("💌", "RM 받기", dmScope.label, dmScope.desc,
            com.navifit.social.PrivacySettings.DmScope.values().map { it.label }) { idx ->
            val v = com.navifit.social.PrivacySettings.DmScope.values()[idx]
            dmScope = v; com.navifit.social.PrivacySettings.setDmScope(ctx, v)
        }
        ScopeSelectorRow("💬", "내 글 댓글 허용", cmtScope.label, cmtScope.desc,
            com.navifit.social.PrivacySettings.CommentScope.values().map { it.label }) { idx ->
            val v = com.navifit.social.PrivacySettings.CommentScope.values()[idx]
            cmtScope = v; com.navifit.social.PrivacySettings.setCommentScope(ctx, v)
        }
        NavToggleRow("🔒", "비공개 계정", "기록·경로를 친구에게만 공개해요", privateAcc) {
            privateAcc = it; com.navifit.social.PrivacySettings.setPrivateAccount(ctx, it)
        }
        NavToggleRow("📍", "거리 표시 허용", "운동장에서 나와의 거리(반올림)를 표시해요", showDist) {
            showDist = it; com.navifit.social.PrivacySettings.setShowDistance(ctx, it)
        }

        Spacer(Modifier.height(12.dp))

        // ===== 계정 설정 =====
        SectionTitle("계정")
        SettingRow(
            icon = "🆔", title = "닉네임 변경",
            subtitle = if (isAnonymous) "게스트는 닉네임을 바꿀 수 없어요 (구글 연결 후 가능)" else "중복되지 않는 닉네임으로 변경",
            enabled = !isAnonymous
        ) { showNicknameDialog = true }

        if (isAnonymous) {
            Card(
                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF2E3A5C))
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text(tr("🔗 구글 계정을 연결하면"), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(
                        tr("· 지금까지의 기록·마커·걸음수가 그대로 유지돼요\n· 닉네임을 직접 정할 수 있어요\n· 글쓰기 제한 해제, 에픽·레전더리 마커 장착, DM·사진첨부 가능"),
                        fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface, lineHeight = 16.sp
                    )
                    Spacer(Modifier.height(10.dp))
                    GoogleSignInButton(enabled = true, onClick = onGoogleLink, label = "Google 계정 연결하기")
                }
            }
        } else {
            SettingRow(icon = "🔍", title = "연동 확인", subtitle = "구글 계정 연동 상태를 다시 확인해요") {
                onVerifyLink { msg -> verifyMessage = msg }
            }
            verifyMessage?.let {
                Text(it, fontSize = 12.sp, color = Color(0xFF5BBD8B), modifier = Modifier.padding(start = 8.dp, bottom = 6.dp))
            }
        }

        SettingRow(icon = "🚪", title = "로그아웃", subtitle = if (isAnonymous)
            "⚠️ 게스트는 로그아웃하면 기록을 복구할 수 없어요" else "다시 로그인하면 정보가 자동으로 복원돼요") {
            showLogoutDialog = true
        }

        Spacer(Modifier.height(12.dp))

        // ===== 누적 통계 =====
        SectionTitle("나의 누적 기록")
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                StatCol("총 거리", "%.1fkm".format(records.sumOf { it.distanceMeters } / 1000))
                StatCol("기록 수", "${records.size}회")
                StatCol("걸음수", "%,d보".format(totalSteps))
            }
        }
        Spacer(Modifier.height(6.dp))

        // ✅ v60: 오토바이/자동차 안전점수 섹션 제거 (요청). 대신 경로 저장 설정 추가.
        SectionTitle("경로 보관함")
        val vaultCtx = androidx.compose.ui.platform.LocalContext.current
        var askFolder by remember { mutableStateOf(com.navifit.ui.screens.RouteVaultStore.askFolderOnSave(vaultCtx)) }
        NavToggleRow("📁", "경로 저장 시 폴더 선택", "켜면 저장할 때 폴더를 고르고, 끄면 '운동 이력' 폴더로 바로 저장돼요", askFolder) {
            askFolder = it; com.navifit.ui.screens.RouteVaultStore.setAskFolderOnSave(vaultCtx, it)
        }

        Spacer(Modifier.height(12.dp))
        // ✅ v76 달리기·자전거 경로 옵션
        SectionTitle("길안내 경로 옵션 (달리기·자전거)")
        val wpCtx = androidx.compose.ui.platform.LocalContext.current
        var wpref by remember { mutableStateOf(com.navifit.navigation.WorkoutRoutePreference.load(wpCtx)) }
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(12.dp)) {
                Text(tr("경로를 어떻게 안내할지 골라요"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                com.navifit.navigation.WorkoutRoutePreference.entries.forEach { p ->
                    val sel = wpref == p
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)
                        .background(if (sel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                        .clickable { wpref = p; com.navifit.navigation.WorkoutRoutePreference.save(wpCtx, p) }
                        .padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(p.emoji, fontSize = 18.sp)
                        Spacer(Modifier.width(10.dp))
                        Text(p.label, fontSize = 14.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                            color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                        if (sel) Text("✓", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        // ✅ v81 운동장 공개 범위 - 화살표로 펼치기 (기본 접힘, 설정 화면이 짧아짐)
        SectionTitle("운동장 공개 범위")
        val pgCtx = androidx.compose.ui.platform.LocalContext.current
        var scopeExpanded by remember { mutableStateOf(false) }
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(12.dp)) {
                Row(
                    Modifier.fillMaxWidth().clickable { scopeExpanded = !scopeExpanded },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(tr("게시물 공개 설정"), fontSize = 13.sp, fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface)
                        Text(tr("글·사진·동영상별로 누가 볼 수 있는지 정해요"), fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(if (scopeExpanded) "▲" else "▼", fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (scopeExpanded) {
                    Spacer(Modifier.height(10.dp))
                    listOf("글" to "post", "사진" to "photo", "동영상" to "video").forEach { (label, kind) ->
                        var scope by remember { mutableStateOf(com.navifit.social.UserProfileStore.contentScope(pgCtx, kind)) }
                        Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(top = 6.dp, bottom = 4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            listOf("전체" to "all", "친구만" to "friends", "나만" to "me", "아무도" to "none").forEach { (sl, sv) ->
                                val sel = scope == sv
                                Box(Modifier.weight(1f)
                                    .background(if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(9.dp))
                                    .clickable { scope = sv; com.navifit.social.UserProfileStore.setContentScope(pgCtx, kind, sv) }
                                    .padding(vertical = 7.dp), contentAlignment = Alignment.Center) {
                                    Text(sl, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                                        color = if (sel) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        SectionTitle("화면 테마")
        val themeSetter = com.navifit.LocalThemeSetter.current
        val themeCtx = androidx.compose.ui.platform.LocalContext.current
        var themeMode by remember { mutableStateOf(
            themeCtx.getSharedPreferences("settings", 0).getString("theme", "dark") ?: "dark"
        ) }
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("dark" to "🌙 다크", "light" to "☀️ 라이트").forEach { (mode, label) ->
                    val sel = themeMode == mode
                    Box(
                        Modifier.weight(1f)
                            .background(if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                RoundedCornerShape(12.dp))
                            .clickable { themeMode = mode; themeSetter(mode) }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(label, fontWeight = FontWeight.Bold,
                            color = if (sel) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        SectionTitle("언어 설정")
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(12.dp)) {
                Text(tr("커뮤니티·랭킹을 포함한 앱 전체 표시 언어를 바꿔요"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    AppLanguage.entries.forEach { lang ->
                        val sel = lang == currentLanguage
                        Box(
                            Modifier.padding(end = 6.dp)
                                .background(if (sel) Color(0xFF8B9FFF) else Color(0xFF2A2635), RoundedCornerShape(14.dp))
                                .clickable { onLanguageChange(lang) }
                                .padding(horizontal = 12.dp, vertical = 7.dp)
                        ) { Text("${lang.flag} ${lang.nativeName}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (sel) Color.White else MaterialTheme.colorScheme.onSurface) }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        SectionTitle("앱 정보")
        SettingRow(icon = "📱", title = "버전", subtitle = "NaviFit v1.0", enabled = false) {}
        Spacer(Modifier.height(40.dp))
    }

    // ===== 닉네임 변경 다이얼로그 =====
    if (showNicknameDialog) {
        var input by remember { mutableStateOf(nickname) }
        var checking by remember { mutableStateOf(false) }
        var error by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { if (!checking) showNicknameDialog = false },
            title = { Text(tr("닉네임 변경")) },
            text = {
                Column {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it; error = null },
                        singleLine = true, placeholder = { Text(tr("2~12자, 한글/영문/숫자")) },
                        isError = error != null
                    )
                    error?.let { Text(it, color = Color(0xFFFF8FA3), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
                    if (checking) Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                        CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text(tr("중복 확인 중..."), fontSize = 12.sp, color = Color.Gray)
                    }
                }
            },
            confirmButton = {
                TextButton(enabled = !checking, onClick = {
                    checking = true
                    onChangeNickname(input.trim()) { ok, msg ->
                        checking = false
                        if (ok) showNicknameDialog = false else error = msg
                    }
                }) { Text(tr("변경")) }
            },
            dismissButton = { TextButton(enabled = !checking, onClick = { showNicknameDialog = false }) { Text(tr("취소")) } }
        )
    }

    // ===== 로그아웃 확인 =====
    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = { Text(tr("로그아웃 할까요?")) },
            text = {
                Text(
                    if (isAnonymous)
                        "게스트 계정은 로그아웃하면 다시 접속할 방법이 없어서 기록·마커·걸음수가 모두 사라져요.\n\n구글 계정을 먼저 연결해두면 안전하게 보관돼요."
                    else
                        "구글 계정에 정보가 저장되어 있어요.\n다음에 같은 구글 계정으로 로그인하면 닉네임과 기록이 자동으로 복원돼요."
                )
            },
            confirmButton = {
                TextButton(onClick = { showLogoutDialog = false; onLogout() }) {
                    Text(tr("로그아웃"), color = Color(0xFFFF8FA3))
                }
            },
            dismissButton = { TextButton(onClick = { showLogoutDialog = false }) { Text(tr("취소")) } }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    // ✅ v81 설정 화면 글자 크기 통일 (섹션 제목 13sp)
    Text(text, fontSize = 13.sp, fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp))
}

/** v35: 3지선다 선택 행 (DM 범위, 댓글 범위) */
@Composable
private fun ScopeSelectorRow(
    icon: String, title: String, current: String, desc: String,
    options: List<String>, onSelect: (Int) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Card(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 20.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                Text(desc, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Box {
                TextButton(onClick = { expanded = true }) { Text(current, fontSize = 12.sp, color = Color(0xFF8B9FFF)) }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    options.forEachIndexed { i, opt ->
                        DropdownMenuItem(text = { Text(opt) }, onClick = { onSelect(i); expanded = false })
                    }
                }
            }
        }
    }
}

/** v27: 내비 설정용 스위치 행 */
@Composable
private fun NavToggleRow(icon: String, title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    // ✅ v81 설정 행 크기·색 통일 (아이콘 18sp · 제목 13sp · 설명 11sp, 테마 대응)
    Card(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 18.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                Text(subtitle, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = checked, onCheckedChange = onChange)
        }
    }
}

@Composable
private fun SettingRow(icon: String, title: String, subtitle: String, enabled: Boolean = true, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable(enabled = enabled, onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, fontSize = 20.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                    color = if (enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
                Text(subtitle, fontSize = 11.sp, color = Color.Gray)
            }
            if (enabled) Text("›", fontSize = 20.sp, color = Color.Gray)
        }
    }
}

@Composable
private fun StatCol(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = Color(0xFFEDEAF4))
        Text(label, fontSize = 11.sp, color = Color.Gray)
    }
}
