package com.navifit.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/**
 * ✅ v61 화장실 API 테스트 화면 (기존 단속카메라 테스트 대체).
 * 카카오 로컬 검색으로 내 위치 주변 화장실을 불러와 목록으로 보여줌 - API 동작 확인용.
 */
@Composable
fun CameraApiTestScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var status by remember { mutableStateOf("아래 버튼을 눌러 주변 화장실을 검색하세요") }
    var toilets by remember { mutableStateOf<List<Triple<String, String, Double>>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("←", fontSize = 20.sp, modifier = Modifier.clickable { onBack() }.padding(end = 12.dp))
            Text("🚻 화장실 API 테스트", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.height(12.dp))
        Button(
            enabled = !loading,
            onClick = {
                loading = true; status = "검색 중..."
                scope.launch {
                    val (list, msg) = fetchToiletsForTest(context)
                    toilets = list; status = msg; loading = false
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (loading) "검색 중..." else "🔍 주변 화장실 검색 (서울시청 기준)") }
        Spacer(Modifier.height(10.dp))
        Text(status, fontSize = 12.sp, color = Color(0xFF8B93AC))
        Spacer(Modifier.height(10.dp))
        LazyColumn {
            items(toilets) { (name, addr, dist) ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), shape = RoundedCornerShape(12.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("🚻 $name", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        if (addr.isNotBlank()) Text("📍 $addr", fontSize = 11.sp, color = Color(0xFF8B93AC))
                        Text("약 ${dist.toInt()}m", fontSize = 10.sp, color = Color(0xFF3B82F6))
                    }
                }
            }
        }
    }
}

private suspend fun fetchToiletsForTest(context: android.content.Context): Pair<List<Triple<String, String, Double>>, String> =
    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val key = com.navifit.navigation.NavApiKeys.kakaoRestKey(context)
            ?: return@withContext emptyList<Triple<String, String, Double>>() to "❌ 카카오 REST 키가 없어요 (api_keys.properties 확인)"
        // 서울시청 기준
        val lat = 37.5665; val lng = 126.9780
        try {
            val url = "https://dapi.kakao.com/v2/local/search/keyword.json" +
                "?query=" + java.net.URLEncoder.encode("화장실", "UTF-8") +
                "&x=$lng&y=$lat&radius=2000&size=15&sort=distance"
            val client = okhttp3.OkHttpClient.Builder()
                .connectTimeout(8, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(8, java.util.concurrent.TimeUnit.SECONDS).build()
            val res = client.newCall(
                okhttp3.Request.Builder().url(url).addHeader("Authorization", "KakaoAK $key").build()
            ).execute()
            val body = res.body?.string() ?: return@withContext emptyList<Triple<String, String, Double>>() to "❌ 응답 없음"
            val docs = org.json.JSONObject(body).optJSONArray("documents")
                ?: return@withContext emptyList<Triple<String, String, Double>>() to "❌ 결과 파싱 실패: ${body.take(120)}"
            val list = (0 until docs.length()).mapNotNull { i ->
                val d = docs.optJSONObject(i) ?: return@mapNotNull null
                val name = d.optString("place_name", "화장실")
                val addr = d.optString("road_address_name", "").ifBlank { d.optString("address_name", "") }
                val dist = d.optString("distance", "0").toDoubleOrNull() ?: 0.0
                Triple(name, addr, dist)
            }
            if (list.isEmpty()) emptyList<Triple<String, String, Double>>() to "주변에 검색된 화장실이 없어요"
            else list to "✅ ${list.size}곳 검색됨 (카카오 로컬 API 정상 동작)"
        } catch (e: Exception) {
            emptyList<Triple<String, String, Double>>() to
                "❌ 오류: ${e.message}\n\n※ 'NotAuthorizedError / app disabled OPEN_MAP_AND_LOCAL'가 뜨면 카카오 개발자 콘솔 문제예요:\n" +
                "1) developers.kakao.com → 내 앱 → 카카오맵/로컬 API '사용 설정' ON\n" +
                "2) 앱 상태가 '개발 중'이 아닌 활성 상태인지 확인\n" +
                "3) REST API 키가 맞는지 확인 (JavaScript 키 아님)"
        }
    }
