package com.navifit.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.navifit.data.ActivityRecord
import com.navifit.navigation.TravelMode
import com.navifit.workout.WorkoutAnalyzer
import com.navifit.i18n.LocalStrings

/**
 * 분석 화면 (v17 전면 개편).
 * - 카테고리 탭: 🚶 걷기/달리기 · 🚴 자전거 · 🚗 운전(오토바이+자동차)
 * - 기간 선택: 하루별 / 주별 / 월별
 * - 운동 카테고리: 운동량(거리·시간·횟수) 차트 + 추세/추천
 * - 운전 카테고리: 안전점수 추이 차트 + 주행량 + 안전운전 조언
 */
@Composable
fun WorkoutAnalyticsScreen(records: List<ActivityRecord>) {
    var category by remember { mutableStateOf(0) } // 0=걷기/달리기, 1=자전거, 2=운전
    var period by remember { mutableStateOf(WorkoutAnalyzer.Period.DAILY) }

    // ✅ 매크로/토글로 무효 처리된 세션(isRankingValid=false)은 점수·통계 평균에서 완전히 제외
    //    (개인 히스토리에는 남아있지만, 안전점수·운동량 집계를 부풀릴 수 없음)
    val categoryRecords = remember(records, category) {
        val valid = records.filter { it.isRankingValid }
        when (category) {
            0 -> valid.filter { it.mode == TravelMode.WALK }
            1 -> valid.filter { it.mode == TravelMode.BIKE }
            else -> valid.filter { !it.mode.isWorkoutMode }
        }
    }
    val series = remember(categoryRecords, period) {
        WorkoutAnalyzer.buildPeriodSeries(categoryRecords, period)
    }
    val isDriving = category == 2

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(LocalStrings.current.myWorkoutAnalytics, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(10.dp))

        // ===== 카테고리 탭 =====
        val cats = listOf("🚶 걷기/달리기", "🚴 자전거", "🚗 운전")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(cats.indices.toList()) { i ->
                val sel = category == i
                Box(
                    Modifier.background(if (sel) Color(0xFF8B9FFF) else Color(0xFF2A2635), RoundedCornerShape(18.dp))
                        .clickable { category = i }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) { Text(cats[i], fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (sel) Color.White else Color(0xFFEDEAF4)) }
            }
        }
        Spacer(Modifier.height(8.dp))

        // ===== 기간 선택 =====
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            WorkoutAnalyzer.Period.entries.forEach { p ->
                val sel = period == p
                Box(
                    Modifier.background(if (sel) Color(0xFF7EDDB8) else Color(0xFF2A2635), RoundedCornerShape(14.dp))
                        .clickable { period = p }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) { Text(p.label, fontSize = 12.sp, color = if (sel) Color.White else Color.Gray, fontWeight = FontWeight.Bold) }
            }
        }
        Spacer(Modifier.height(14.dp))

        if (categoryRecords.isEmpty()) {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(24.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (isDriving) "🚗" else "🏃", fontSize = 36.sp)
                    Text("아직 기록이 없어요", fontWeight = FontWeight.Bold)
                    Text(if (isDriving) "첫 주행을 시작하면 안전점수 분석이 시작돼요" else "첫 운동을 시작해보세요!", fontSize = 12.sp, color = Color.Gray)
                }
            }
            return@Column
        }

        if (isDriving) {
            // ===== 운전 분석: 안전점수 중심 =====
            WorkoutAnalyzer.analyzeDriving(categoryRecords)?.let { d ->
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("🛡️ 안전운전 리포트", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            BigStat("평균 안전점수", "${d.avgSafetyScore}점",
                                color = when { d.avgSafetyScore >= 90 -> Color(0xFF5BBD8B); d.avgSafetyScore >= 70 -> Color(0xFFE8B34B); else -> Color(0xFFFF8FA3) })
                            BigStat("최고 점수", "${d.bestSafetyScore}점")
                            BigStat("이번 주 주행", "${d.weeklyTrips}회")
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            BigStat("총 주행거리", "%.1fkm".format(d.totalDistanceKm))
                            BigStat("최고 속도", "%.0fkm/h".format(d.maxSpeedKmh))
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(d.safetyTrend, fontSize = 12.sp, color = Color(0xFF6E85F0))
                        Text(d.advice, fontSize = 12.sp, color = Color.Gray)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("${period.label} 안전점수 추이", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            BarChartCard(
                labels = series.map { it.label },
                values = series.map { it.avgSafetyScore.toFloat() },
                valueFormatter = { if (it <= 0f) "-" else "%.0f".format(it) },
                maxValue = 100f, barColor = Color(0xFF7EDDB8)
            )
            Spacer(Modifier.height(14.dp))
            Text("${period.label} 주행거리(km)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            BarChartCard(
                labels = series.map { it.label },
                values = series.map { it.totalDistanceKm.toFloat() },
                valueFormatter = { "%.1f".format(it) },
                barColor = Color(0xFF8B9FFF)
            )
        } else {
            // ===== 운동 분석 (걷기/달리기, 자전거) =====
            val mode = if (category == 0) TravelMode.WALK else TravelMode.BIKE
            WorkoutAnalyzer.analyze(mode, categoryRecords)?.let { insight ->
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("이번 주 요약", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            BigStat("횟수", "주 ${insight.weeklyFrequency}회")
                            BigStat("평균 거리", "%.2fkm".format(insight.avgDistanceKm))
                            BigStat("평균 속도", "%.1fkm/h".format(insight.avgSpeedKmh))
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(insight.trendMessage, fontSize = 12.sp, color = Color(0xFF6E85F0))
                        Text(insight.recommendation, fontSize = 12.sp, color = Color.Gray)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("${period.label} 운동량 - 거리(km)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            BarChartCard(
                labels = series.map { it.label },
                values = series.map { it.totalDistanceKm.toFloat() },
                valueFormatter = { "%.1f".format(it) },
                barColor = Color(0xFF8B9FFF)
            )
            Spacer(Modifier.height(14.dp))
            Text("${period.label} 운동량 - 시간(분)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            BarChartCard(
                labels = series.map { it.label },
                values = series.map { it.totalMinutes.toFloat() },
                valueFormatter = { "%.0f".format(it) },
                barColor = Color(0xFFC9A5F5)
            )
        }
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun BigStat(label: String, value: String, color: Color = Color(0xFFEDEAF4)) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = color)
        Text(label, fontSize = 10.sp, color = Color.Gray)
    }
}

/**
 * 외부 차트 라이브러리 없이 Compose만으로 그리는 가벼운 막대 차트.
 * (버전 충돌 걱정 없이 어디서나 동일하게 렌더링)
 */
@Composable
private fun BarChartCard(
    labels: List<String>,
    values: List<Float>,
    valueFormatter: (Float) -> String,
    maxValue: Float? = null,
    barColor: Color
) {
    val peak = maxValue ?: values.maxOrNull()?.takeIf { it > 0f } ?: 1f
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 14.dp).fillMaxWidth().height(170.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Bottom
        ) {
            values.forEachIndexed { i, v ->
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom, modifier = Modifier.weight(1f)) {
                    Text(valueFormatter(v), fontSize = 8.sp, color = Color.Gray, maxLines = 1)
                    Spacer(Modifier.height(2.dp))
                    val h = ((v / peak) * 120f).coerceIn(2f, 120f)
                    Box(
                        Modifier.width(14.dp).height(h.dp)
                            .background(if (v > 0f) barColor else Color(0xFFEDEAF4), RoundedCornerShape(topStart = 5.dp, topEnd = 5.dp))
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(labels.getOrElse(i) { "" }, fontSize = 8.sp, color = Color.Gray, maxLines = 1)
                }
            }
        }
    }
}
