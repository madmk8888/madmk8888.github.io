package com.navifit.tracking

/**
 * 안전운전 점수 (오토바이/자동차 모드 전용) - v25 정밀화.
 *
 * 보험사/티맵식으로 "억울한 감점"이 없도록 판정을 정교화:
 *  ① GPS 신호가 끊겼다 다시 잡히면 속도가 순간적으로 튀는데, 예전엔 이걸 급가속으로
 *     오판했음 -> 샘플 간 시간 간격이 5초를 넘으면(신호 공백) 그 샘플은 판정에서 제외
 *  ② 급가속: "순간 델타"가 아니라 초당 가속도(km/h/s) 기준으로 판정.
 *     실측 기준 초당 +8km/h 이상(제로백 12초급 풀가속)을 2초 이상 지속해야 1회로 침.
 *     살짝 엑셀 밟는 정도(초당 +3~5km/h)는 절대 감점되지 않음.
 *  ③ 과속: 1샘플 튄 값이 아니라 연속 3샘플(약 6초) 이상 80km/h를 유지해야 1회.
 *  ④ 같은 종류 이벤트는 최소 20초 간격으로만 카운트 (연속 감점 폭탄 방지)
 */
class SafetyScoreTracker {
    var speedingCount = 0
        private set
    var suddenAccelCount = 0
        private set
    var maxSpeedKmh = 0.0
        private set

    private var lastSpeedKmh = 0.0
    private var lastSampleAtMillis = 0L
    private var speedingStreak = 0
    private var accelStreakMillis = 0L
    private var lastSpeedingPenaltyAt = 0L
    private var lastAccelPenaltyAt = 0L
    // ═══ v27 추가 ═══
    var suddenBrakeCount = 0; private set          // 급정거
    var cameraViolationCount = 0; private set      // 단속카메라 앞 과속 (제한속도 초과 상태로 통과)
    var signalViolationCount = 0; private set      // 신호위반 의심 (신호카메라를 감속 없이 고속 통과)
    private var brakeStreakMillis = 0L
    private var lastBrakePenaltyAt = 0L
    private var lastCameraPenaltyAt = 0L
    private var lastSignalPenaltyAt = 0L

    companion object {
        const val SPEEDING_THRESHOLD_KMH = 80.0
        const val SPEEDING_STREAK_REQUIRED = 3          // 연속 3샘플 이상 유지돼야 과속 1회
        const val ACCEL_PER_SECOND_THRESHOLD = 8.0       // 초당 +8km/h 이상 = 진짜 풀가속
        const val ACCEL_SUSTAIN_MILLIS = 2000L           // 2초 이상 지속돼야 급가속 1회
        const val BRAKE_PER_SECOND_THRESHOLD = -10.0     // 초당 -10km/h 이상 감속 = 급정거 (일반 제동은 -5 안팎)
        const val BRAKE_SUSTAIN_MILLIS = 1500L
        const val SIGNAL_GAP_MILLIS = 5000L              // 샘플 간격이 이보다 크면 신호 공백 -> 판정 제외
        const val PENALTY_COOLDOWN_MILLIS = 20_000L      // 같은 종류 감점 최소 간격
        const val SPEEDING_PENALTY = 5
        const val ACCEL_PENALTY = 3
        const val BRAKE_PENALTY = 3
        const val CAMERA_PENALTY = 7
        const val SIGNAL_PENALTY = 10
    }

    /** ✅ v27: 단속카메라 제한속도 초과 상태로 통과 (SafetyAlertEngine에서 호출) */
    fun onCameraViolation() {
        val now = System.currentTimeMillis()
        if (now - lastCameraPenaltyAt >= PENALTY_COOLDOWN_MILLIS) {
            cameraViolationCount++
            lastCameraPenaltyAt = now
        }
    }

    /**
     * ✅ v27: 신호카메라를 40km/h 이상으로 감속 없이 통과 -> 신호위반 의심.
     * (실시간 신호등 상태 데이터가 없어 휴리스틱 - 정지/서행 후 통과는 감점 안 됨)
     */
    fun onSignalCameraPass(speedKmh: Double) {
        val now = System.currentTimeMillis()
        if (speedKmh > 40 && now - lastSignalPenaltyAt >= PENALTY_COOLDOWN_MILLIS) {
            signalViolationCount++
            lastSignalPenaltyAt = now
        }
    }

    /** ✅ v31: 현재 도로 제한속도 힌트 (카메라 구간/고속도로에서 갱신). null이면 기본 80 기준 */
    @Volatile var speedLimitHintKmh: Int? = null

    fun onSpeedUpdate(speedKmh: Double) {
        val now = System.currentTimeMillis()
        val dtMillis = if (lastSampleAtMillis == 0L) 0L else now - lastSampleAtMillis

        if (speedKmh > maxSpeedKmh && speedKmh < 220) maxSpeedKmh = speedKmh

        // ① 신호 공백 직후 샘플: 속도가 튈 수 있으므로 이번 샘플은 기준만 갱신하고 판정 없음
        if (lastSampleAtMillis == 0L || dtMillis > SIGNAL_GAP_MILLIS) {
            lastSpeedKmh = speedKmh
            lastSampleAtMillis = now
            speedingStreak = 0
            accelStreakMillis = 0L
            brakeStreakMillis = 0L
            return
        }

        // ✅ v31 GPS 스파이크 필터: 물리적으로 불가능한 가속(초당 ±25km/h 초과)이나
        //    0.5초 미만 샘플은 GPS 노이즈로 보고 판정에서 제외 (억울한 감점의 주범이었음)
        val dtSecRaw = dtMillis / 1000.0
        val accelRaw = if (dtSecRaw > 0) (speedKmh - lastSpeedKmh) / dtSecRaw else 0.0
        if (dtSecRaw < 0.5 || kotlin.math.abs(accelRaw) > 25.0) {
            lastSpeedKmh = speedKmh
            lastSampleAtMillis = now
            return
        }

        // ③ 과속: 도로 제한속도 기준 (제한 + 10km/h 초과가 연속 유지될 때만 - 시중 내비 방식)
        val limit = (speedLimitHintKmh ?: 80) + 10
        if (speedKmh > limit) {
            speedingStreak++
            if (speedingStreak >= SPEEDING_STREAK_REQUIRED && now - lastSpeedingPenaltyAt >= PENALTY_COOLDOWN_MILLIS) {
                speedingCount++
                lastSpeedingPenaltyAt = now
                speedingStreak = 0
            }
        } else speedingStreak = 0

        // ② 급가속: 초당 가속도 기준 + 지속시간 필요
        val dtSec = dtMillis / 1000.0
        val accelPerSec = if (dtSec > 0) (speedKmh - lastSpeedKmh) / dtSec else 0.0
        if (accelPerSec >= ACCEL_PER_SECOND_THRESHOLD) {
            accelStreakMillis += dtMillis
            if (accelStreakMillis >= ACCEL_SUSTAIN_MILLIS && now - lastAccelPenaltyAt >= PENALTY_COOLDOWN_MILLIS) {
                suddenAccelCount++
                lastAccelPenaltyAt = now
                accelStreakMillis = 0L
            }
        } else accelStreakMillis = 0L

        // ✅ v27 급정거: 초당 -10km/h 이상 감속이 1.5초 이상 지속 (일반 제동·서행은 감점 안 됨)
        //    또한 20km/h 이하 저속에선 판정 안 함 (주차·정차 마무리 브레이크 오탐 방지)
        if (accelPerSec <= BRAKE_PER_SECOND_THRESHOLD && lastSpeedKmh > 20) {
            brakeStreakMillis += dtMillis
            if (brakeStreakMillis >= BRAKE_SUSTAIN_MILLIS && now - lastBrakePenaltyAt >= PENALTY_COOLDOWN_MILLIS) {
                suddenBrakeCount++
                lastBrakePenaltyAt = now
                brakeStreakMillis = 0L
            }
        } else brakeStreakMillis = 0L

        lastSpeedKmh = speedKmh
        lastSampleAtMillis = now
    }

    fun currentScore(): Int =
        (100 - speedingCount * SPEEDING_PENALTY - suddenAccelCount * ACCEL_PENALTY
            - suddenBrakeCount * BRAKE_PENALTY - cameraViolationCount * CAMERA_PENALTY
            - signalViolationCount * SIGNAL_PENALTY).coerceAtLeast(0)

    fun reset() {
        speedingCount = 0
        suddenAccelCount = 0
        maxSpeedKmh = 0.0
        lastSpeedKmh = 0.0
        lastSampleAtMillis = 0L
        speedingStreak = 0
        accelStreakMillis = 0L
        lastSpeedingPenaltyAt = 0L
        lastAccelPenaltyAt = 0L
        suddenBrakeCount = 0
        cameraViolationCount = 0
        signalViolationCount = 0
        brakeStreakMillis = 0L
        lastBrakePenaltyAt = 0L
        lastCameraPenaltyAt = 0L
        lastSignalPenaltyAt = 0L
    }
}
