package com.navifit.ui.map

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Matrix
import com.google.android.gms.maps.model.BitmapDescriptor
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.navifit.gacha.BorderDef
import com.navifit.gacha.BorderTier
import com.navifit.gacha.DrawnMarker

/**
 * 지도 위 "내 위치" 마커를 앱에서 직접 그려서 만드는 팩토리.
 *
 * 구성 (위에서 아래로):
 *  ┌──────────────┐
 *  │  닉네임 티커   │   <- 둥근 말풍선(티커)에 닉네임 표시
 *  └──────┬───────┘
 *      ⭕ 이모지      <- 장착한 마커(뽑기에서 획득) + 장착한 테두리 링
 *        ▼           <- 지도 좌표를 가리키는 꼬리
 */
object MyLocationMarkerFactory {

    fun build(
        nickname: String,
        marker: DrawnMarker?,
        border: BorderDef?,
        density: Float,
        rotationDegrees: Float = 0f // ✅ 애니메이션 테두리(회오리)용 - 매 프레임 값을 바꿔서 넘기면 실제로 돌아감
    ): BitmapDescriptor {
        fun dp(v: Float) = v * density

        val circleRadius = dp(26f)
        val ringWidth = dp(4f)
        val tailHeight = dp(10f)
        val tickerPaddingH = dp(10f)
        val tickerPaddingV = dp(5f)
        val gap = dp(4f)

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = dp(12f)
            color = Color.WHITE
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val tickerTextWidth = textPaint.measureText(nickname)
        val tickerWidth = tickerTextWidth + tickerPaddingH * 2
        val tickerHeight = textPaint.textSize + tickerPaddingV * 2
        val tierOrdinalForSize = marker?.effectiveTierOrdinal ?: -1
        val topMargin = dp(5f) // 레전더리/유니크 티커가 위아래로 살짝 움직여도 안 잘리도록 여유 공간 확보
        val sideExtra = if (tierOrdinalForSize >= 3) dp(20f) else 0f // 반짝임 아이콘이 옆에 붙을 공간

        val width = (maxOf(circleRadius * 2 + ringWidth * 2, tickerWidth) + sideExtra).toInt() + dp(8f).toInt()
        val height = (topMargin + tickerHeight + gap + circleRadius * 2 + ringWidth * 2 + tailHeight).toInt() + dp(4f).toInt()

        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val cx = width / 2f - sideExtra / 2f // 반짝임 공간만큼 살짝 왼쪽으로 중심을 당겨서 전체가 안 잘리게

        // --- 1. 닉네임 티커 (둥근 말풍선) ---
        // ✅ 배경색이 마커 등급에 따라 달라짐 (예전엔 항상 같은 보라색 고정) + 등급별 애니메이션:
        //    일반/레어: 가만히 있음 · 에픽: 반짝임(flash) · 유니크: 반짝임+살짝 움직임 · 레전더리: 반짝임+크게 움직임
        val tierOrdinal = marker?.effectiveTierOrdinal ?: -1
        val phaseRad = Math.toRadians((rotationDegrees * 3).toDouble())
        val bounceY = when {
            tierOrdinal >= 4 -> (Math.sin(phaseRad) * dp(3f)).toFloat()       // 레전더리: 크게 움직임
            tierOrdinal == 3 -> (Math.sin(phaseRad) * dp(1.2f)).toFloat()    // 유니크: 살짝 움직임
            else -> 0f
        }
        val flashAlpha = if (tierOrdinal >= 2) (200 + 55 * Math.sin(phaseRad)).toInt().coerceIn(180, 255) else 255

        val tickerRect = RectF(cx - tickerWidth / 2, topMargin + bounceY, cx + tickerWidth / 2, topMargin + tickerHeight + bounceY)
        val tickerColors = tickerColorsForTier(tierOrdinal)
        val tickerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(tickerRect.left, 0f, tickerRect.right, 0f, tickerColors, null, Shader.TileMode.CLAMP)
            alpha = flashAlpha
        }
        canvas.drawRoundRect(tickerRect, tickerHeight / 2, tickerHeight / 2, tickerPaint)
        val textY = tickerRect.centerY() - (textPaint.descent() + textPaint.ascent()) / 2
        canvas.drawText(nickname, cx, textY, textPaint)
        // 유니크/레전더리는 티커 옆에 작은 반짝임 표시도 추가
        if (tierOrdinal >= 3) {
            val sparkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; textSize = dp(10f); alpha = flashAlpha }
            canvas.drawText("✨", tickerRect.right + dp(8f), textY, sparkPaint)
        }

        // --- 2. 마커 원 + 장착 테두리 링 ---
        val circleCy = topMargin + tickerHeight + gap + ringWidth + circleRadius
        val ringShader = borderShader(border, cx, circleCy)
        // ✅ 회전 테두리: 그라데이션 자체를 매 프레임 회전시켜서 실제로 "테두리가" 도는 것처럼 보이게 함
        //    (가운데 이모지는 그대로 두고 링만 회전 - 이모지까지 같이 돌면 어지러워 보임)
        if (border?.isAnimated == true && rotationDegrees != 0f) {
            ringShader.setLocalMatrix(Matrix().apply { setRotate(rotationDegrees, cx, circleCy) })
        }
        val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = ringWidth
            shader = ringShader
        }
        canvas.drawCircle(cx, circleCy, circleRadius + ringWidth / 2, ringPaint)

        // ✅ 파티클: 이모지 대신 빛 점(작은 원)이 링 둘레를 돌며 깜빡임 (v26)
        if (border?.hasSparkle == true) {
            val accent = borderSolidColor(border) ?: 0xFFFFFFFF.toInt()
            val sparkleRadius = circleRadius + ringWidth * 1.8f
            val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent; style = Paint.Style.FILL }
            listOf(0f, 120f, 240f).forEachIndexed { i, baseAngle ->
                val angle = Math.toRadians((baseAngle + rotationDegrees * 1.6 + i * 17).toDouble())
                val px = cx + Math.cos(angle).toFloat() * sparkleRadius
                val py = circleCy + Math.sin(angle).toFloat() * sparkleRadius
                val twinklePhase = ((rotationDegrees * 2 + i * 90) % 360)
                dotPaint.alpha = (128 + 127 * Math.sin(Math.toRadians(twinklePhase.toDouble()))).toInt().coerceIn(40, 255)
                canvas.drawCircle(px, py, dp(2.2f), dotPaint)
            }
        }

        // ✅ v26: 이모지 대신 벡터 배경 + 벡터 심볼로 그림
        MarkerSymbolRenderer.drawBackground(canvas, marker?.color, cx, circleCy, circleRadius, rotationDegrees)
        MarkerSymbolRenderer.drawSymbol(canvas, marker?.shape?.symbol, cx, circleCy, circleRadius * 1.25f)

        // --- 3. 좌표를 가리키는 꼬리 ---
        val tailTop = circleCy + circleRadius + ringWidth - dp(2f)
        val tailPath = android.graphics.Path().apply {
            moveTo(cx - dp(7f), tailTop)
            lineTo(cx + dp(7f), tailTop)
            lineTo(cx, height.toFloat() - dp(1f))
            close()
        }
        canvas.drawPath(tailPath, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = borderSolidColor(border) ?: 0xFF8B9FFF.toInt()
        })

        return BitmapDescriptorFactory.fromBitmap(bmp)
    }

    /** 마커 등급에 따른 티커 배경색 - 예전엔 항상 같은 보라색이었지만 이제 등급이 색으로도 드러남 */
    private fun tickerColorsForTier(tierOrdinal: Int): IntArray = when (tierOrdinal) {
        4 -> intArrayOf(0xFFFFD700.toInt(), 0xFFFFF3B0.toInt())      // 레전더리: 골드
        3 -> intArrayOf(0xFFC0C0C0.toInt(), 0xFFE8E8E8.toInt())      // 유니크: 실버
        2 -> intArrayOf(0xFF8B5CF6.toInt(), 0xFFC9A5F5.toInt())      // 에픽: 퍼플
        1 -> intArrayOf(0xFF60A5FA.toInt(), 0xFF93C5FD.toInt())      // 레어: 블루
        0 -> intArrayOf(0xFF9CA3AF.toInt(), 0xFFD1D5DB.toInt())      // 일반: 그레이
        else -> intArrayOf(0xFF8B9FFF.toInt(), 0xFFC9A5F5.toInt())   // 마커 미장착: 기본 보라색
    }

    private fun markerFillShader(marker: DrawnMarker?, cx: Float, cy: Float, r: Float): Shader {
        val hex = marker?.color?.hex
        return if (hex == "RAINBOW") {
            SweepGradient(cx, cy, intArrayOf(
                0xFFFFD700.toInt(), 0xFFFF3CAC.toInt(), 0xFF5B7FFF.toInt(), 0xFF39FF88.toInt(), 0xFFFFD700.toInt()
            ), null)
        } else {
            val c = try { Color.parseColor(hex ?: "#8B9FFF") } catch (e: Exception) { 0xFF8B9FFF.toInt() }
            LinearGradient(cx - r, cy - r, cx + r, cy + r, c, c, Shader.TileMode.CLAMP)
        }
    }

    private fun borderShader(border: BorderDef?, cx: Float, cy: Float): Shader {
        val colors = when (border?.tier) {
            BorderTier.RING_GOLD -> intArrayOf(0xFFFFD700.toInt(), 0xFFFFF3B0.toInt(), 0xFFFFD700.toInt())
            BorderTier.RING_SILVER -> intArrayOf(0xFFE0E0E0.toInt(), 0xFFFFFFFF.toInt(), 0xFFC0C0C0.toInt())
            BorderTier.RING_BRONZE -> intArrayOf(0xFFCD7F32.toInt(), 0xFFE8A868.toInt(), 0xFFCD7F32.toInt())
            BorderTier.RING_GREEN -> intArrayOf(0xFF7EDDB8.toInt(), 0xFF7EDDB8.toInt())
            BorderTier.RING_PURPLE -> intArrayOf(0xFF8B9FFF.toInt(), 0xFFC9A5F5.toInt(), 0xFF8B9FFF.toInt())
            BorderTier.RING_RAINBOW -> intArrayOf(0xFFFFD700.toInt(), 0xFFFF3CAC.toInt(), 0xFF5B7FFF.toInt(), 0xFF39FF88.toInt(), 0xFFFFD700.toInt())
            BorderTier.RING_FIRE -> intArrayOf(0xFFFF3D00.toInt(), 0xFFFF9100.toInt(), 0xFFFFD600.toInt(), 0xFFFF3D00.toInt())
            BorderTier.RING_ICE -> intArrayOf(0xFFB3E5FC.toInt(), 0xFFFFFFFF.toInt(), 0xFF81D4FA.toInt(), 0xFFB3E5FC.toInt())
            BorderTier.RING_COSMIC -> intArrayOf(0xFF1A0B3D.toInt(), 0xFF8B5CF6.toInt(), 0xFFEC4899.toInt(), 0xFF1A0B3D.toInt())
            // ✅ 무지개는 RING_RAINBOW 하나만 - 홀로그램은 진주빛(펄) 톤
            BorderTier.RING_HOLOGRAPHIC -> intArrayOf(0xFFF8E7FF.toInt(), 0xFFD6F0FF.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFE3F1.toInt(), 0xFFF8E7FF.toInt())
            BorderTier.RING_EMERALD -> intArrayOf(0xFF10B981.toInt(), 0xFF6EE7B7.toInt(), 0xFF10B981.toInt())
            BorderTier.RING_NEON -> intArrayOf(0xFF00F5FF.toInt(), 0xFFFF00E5.toInt(), 0xFF00F5FF.toInt())
            BorderTier.RING_PLATINUM -> intArrayOf(0xFFE5E4E2.toInt(), 0xFFFFFFFF.toInt(), 0xFFB8B8B8.toInt(), 0xFFE5E4E2.toInt())
            BorderTier.RING_OBSIDIAN -> intArrayOf(0xFF0D0D0D.toInt(), 0xFF6B21A8.toInt(), 0xFF0D0D0D.toInt(), 0xFF1E1B4B.toInt())
            BorderTier.RING_AMETHYST -> intArrayOf(0xFF6B21A8.toInt(), 0xFFC084FC.toInt(), 0xFF6B21A8.toInt())
            BorderTier.RING_SAPPHIRE -> intArrayOf(0xFF1E3A8A.toInt(), 0xFF60A5FA.toInt(), 0xFF1E3A8A.toInt())
            null -> intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt())
        }
        return SweepGradient(cx, cy, colors, null)
    }

    private fun borderSolidColor(border: BorderDef?): Int? = when (border?.tier) {
        BorderTier.RING_GOLD -> 0xFFFFD700.toInt()
        BorderTier.RING_SILVER -> 0xFFC0C0C0.toInt()
        BorderTier.RING_BRONZE -> 0xFFCD7F32.toInt()
        BorderTier.RING_GREEN -> 0xFF7EDDB8.toInt()
        BorderTier.RING_PURPLE -> 0xFF8B9FFF.toInt()
        BorderTier.RING_RAINBOW -> 0xFFFF3CAC.toInt()
        BorderTier.RING_FIRE -> 0xFFFF3D00.toInt()
        BorderTier.RING_ICE -> 0xFF81D4FA.toInt()
        BorderTier.RING_COSMIC -> 0xFF8B5CF6.toInt()
        BorderTier.RING_HOLOGRAPHIC -> 0xFFFF3CAC.toInt()
        BorderTier.RING_EMERALD -> 0xFF10B981.toInt()
        BorderTier.RING_NEON -> 0xFF00F5FF.toInt()
        BorderTier.RING_PLATINUM -> 0xFFE5E4E2.toInt()
        BorderTier.RING_OBSIDIAN -> 0xFF6B21A8.toInt()
        BorderTier.RING_AMETHYST -> 0xFFC084FC.toInt()
        BorderTier.RING_SAPPHIRE -> 0xFF60A5FA.toInt()
        null -> null
    }
}
