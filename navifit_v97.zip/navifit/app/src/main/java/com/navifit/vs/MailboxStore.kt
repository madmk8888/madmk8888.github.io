package com.navifit.vs

import android.content.Context

/**
 * ✅ 우편함 시스템 (뽑기 화면에 위치).
 *  · VS 포인트 랭킹 유지 보상, 이벤트 선물 등을 우편으로 받음.
 *  · 매월 1일 정각에 포인트 랭킹 상위 5명에게 지급(서버 연동 시).
 *  · 지금은 테스트용 데모 우편 10개를 미리 넣어둠.
 *
 * 우편 종류: POINT(포인트) / TICKET(뽑기권) / SYSTEM(공지)
 */
object MailboxStore {
    private const val PREFS = "mailbox"
    private const val KEY = "mails"
    private const val KEY_SEEDED = "demo_seeded"

    data class Mail(
        val id: String,
        val type: String,       // "point" | "ticket" | "system"
        val title: String,
        val body: String,
        val rewardAmount: Int,  // 포인트 수 또는 뽑기권 수
        val receivedAt: Long,
        val claimed: Boolean
    )

    fun list(c: Context): List<Mail> {
        seedDemoIfNeeded(c)
        return try {
            val arr = org.json.JSONArray(c.getSharedPreferences(PREFS, 0).getString(KEY, "[]") ?: "[]")
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Mail(o.getString("id"), o.getString("type"), o.getString("title"), o.getString("body"),
                    o.optInt("rewardAmount", 0), o.optLong("receivedAt", 0L), o.optBoolean("claimed", false))
            }.sortedByDescending { it.receivedAt }
        } catch (_: Exception) { emptyList() }
    }

    fun unclaimedCount(c: Context): Int = list(c).count { !it.claimed }

    private fun save(c: Context, mails: List<Mail>) {
        val arr = org.json.JSONArray()
        mails.forEach {
            arr.put(org.json.JSONObject().apply {
                put("id", it.id); put("type", it.type); put("title", it.title); put("body", it.body)
                put("rewardAmount", it.rewardAmount); put("receivedAt", it.receivedAt); put("claimed", it.claimed)
            })
        }
        c.getSharedPreferences(PREFS, 0).edit().putString(KEY, arr.toString()).apply()
    }

    /** 우편 수령 → 보상 지급 후 claimed 처리. 반환: (타입, 수량) */
    fun claim(c: Context, id: String): Pair<String, Int>? {
        val mails = list(c).toMutableList()
        val idx = mails.indexOfFirst { it.id == id }
        if (idx < 0 || mails[idx].claimed) return null
        val m = mails[idx]
        mails[idx] = m.copy(claimed = true)
        save(c, mails)
        return m.type to m.rewardAmount
    }

    /** ✅ v81 이미 수령(확인)한 우편 전체 삭제 */
    fun deleteClaimed(c: Context) {
        save(c, list(c).filter { !it.claimed })
    }

    fun add(c: Context, mail: Mail) {
        val mails = list(c).toMutableList()
        mails.add(mail)
        save(c, mails)
    }

    private fun seedDemoIfNeeded(c: Context) {
        val p = c.getSharedPreferences(PREFS, 0)
        if (p.getBoolean(KEY_SEEDED, false)) return
        val now = System.currentTimeMillis()
        val d = 24L * 3600 * 1000
        val demo = listOf(
            Mail("m1", "point", "🏆 포인트 랭킹 1위 보상", "지난달 포인트 랭킹 1위! 축하합니다.", 10000, now - 1 * d, false),
            Mail("m2", "point", "🥈 포인트 랭킹 2위 보상", "2위 달성 보상이에요.", 5000, now - 2 * d, false),
            Mail("m3", "ticket", "🎁 뽑기권 선물", "출석 이벤트 뽑기권입니다.", 6, now - 3 * d, false),
            Mail("m4", "point", "🔥 7일 연속 유지 보상", "포인트 랭킹 7일 유지!", 1000, now - 4 * d, false),
            Mail("m5", "ticket", "🎟️ 주말 보너스", "주말 특별 뽑기권.", 3, now - 5 * d, false),
            Mail("m6", "system", "📢 VS 모드 오픈", "실시간 대결 VS가 열렸어요. 도전해보세요!", 0, now - 6 * d, false),
            Mail("m7", "point", "🎉 첫 대결 보상", "첫 VS 참가 축하 포인트.", 500, now - 7 * d, false),
            Mail("m8", "ticket", "🏃 100km 달성 선물", "누적 100km 돌파 뽑기권.", 5, now - 8 * d, false),
            Mail("m9", "point", "🌙 야간 러너 보상", "밤 10시 이후 러닝 보너스.", 300, now - 9 * d, false),
            Mail("m10", "ticket", "🎂 가입 축하 선물", "NaviFit 오신 걸 환영해요!", 10, now - 10 * d, false)
        )
        save(c, demo)
        p.edit().putBoolean(KEY_SEEDED, true).apply()
    }
}
