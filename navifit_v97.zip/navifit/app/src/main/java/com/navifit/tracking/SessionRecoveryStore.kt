package com.navifit.tracking

import android.content.Context
import com.navifit.navigation.TravelMode

/**
 * ✅ v34 세션 복구.
 *
 * 문제: 장거리 주행·러닝 중 안드로이드가 메모리 부족으로 앱 프로세스를 죽이면
 *       그때까지 달린 기록이 통째로 날아갔음 (배터리 최적화가 센 기기에서 특히).
 *
 * 해결: 주행/운동 중 30초마다 진행상황을 디스크에 저장.
 *       앱이 다시 켜졌을 때 "완료되지 않은 세션"이 있으면 복구해서 저장할지 물어봄.
 */
object SessionRecoveryStore {
    private const val PREF = "session_recovery"
    private const val MAX_AGE_MS = 12 * 60 * 60 * 1000L // 12시간 지난 세션은 폐기

    data class Snapshot(
        val mode: TravelMode,
        val startTimeMillis: Long,
        val distanceMeters: Double,
        val elapsedSeconds: Long,
        val movingSeconds: Long,
        val maxRestSeconds: Long,
        val maxSpeedKmh: Double,
        val safetyScore: Int,
        val pathPolyline: String?,
        val originName: String?,
        val destName: String?,
        val savedAtMillis: Long
    )

    fun save(
        context: Context,
        mode: TravelMode,
        startTimeMillis: Long,
        distanceMeters: Double,
        elapsedSeconds: Long,
        movingSeconds: Long,
        maxRestSeconds: Long,
        maxSpeedKmh: Double,
        safetyScore: Int,
        pathPolyline: String?,
        originName: String?,
        destName: String?
    ) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString("mode", mode.name)
            .putLong("start", startTimeMillis)
            .putFloat("dist", distanceMeters.toFloat())
            .putLong("elapsed", elapsedSeconds)
            .putLong("moving", movingSeconds)
            .putLong("maxRest", maxRestSeconds)
            .putFloat("maxSpeed", maxSpeedKmh.toFloat())
            .putInt("safety", safetyScore)
            .putString("path", pathPolyline)
            .putString("origin", originName)
            .putString("dest", destName)
            .putLong("savedAt", System.currentTimeMillis())
            .putBoolean("active", true)
            .apply()
    }

    /** 정상 종료 시 호출 - 복구 대상에서 제거 */
    fun clear(context: Context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply()
    }

    /** 앱 시작 시 호출 - 비정상 종료된 세션이 있으면 반환 */
    fun loadPending(context: Context): Snapshot? {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        if (!p.getBoolean("active", false)) return null
        val savedAt = p.getLong("savedAt", 0)
        if (savedAt == 0L || System.currentTimeMillis() - savedAt > MAX_AGE_MS) {
            clear(context); return null
        }
        val dist = p.getFloat("dist", 0f).toDouble()
        if (dist < 100) { clear(context); return null } // 100m 미만은 복구 의미 없음
        val mode = try { TravelMode.valueOf(p.getString("mode", "") ?: "") } catch (_: Exception) {
            clear(context); return null
        }
        return Snapshot(
            mode = mode,
            startTimeMillis = p.getLong("start", 0),
            distanceMeters = dist,
            elapsedSeconds = p.getLong("elapsed", 0),
            movingSeconds = p.getLong("moving", 0),
            maxRestSeconds = p.getLong("maxRest", 0),
            maxSpeedKmh = p.getFloat("maxSpeed", 0f).toDouble(),
            safetyScore = p.getInt("safety", 100),
            pathPolyline = p.getString("path", null),
            originName = p.getString("origin", null),
            destName = p.getString("dest", null),
            savedAtMillis = savedAt
        )
    }
}
