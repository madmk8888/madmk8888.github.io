package com.navifit.social

import android.content.Context

/**
 * 운동장(구 커뮤니티) 랭킹 + 별 배지 시스템 (v25 신규).
 *
 * ── 별 배지 ──
 * 받은 좋아요 총합 기준으로 "그 나라 안에서" 상위 10%에게만 별이 붙음:
 *   1위: 👑 왕별 5개 / 2위: 왕별 4개 / 3위: 왕별 3개 / 4위: 왕별 2개 / 5위: 왕별 1개
 *   6위~: 큰별 1개 + 작은별 10개에서 시작해 순위가 내려갈수록 줄어듦
 *   그 밖: 상위 1%면 ⭐ 2개, 상위 2%면 ⭐ 1개 ... 상위 10%까지만 표시
 * 글을 쓸 때마다 아이디 밑에 이 별이 빛남 (티커/테두리와는 별개 장식).
 *
 * ── 운동장 랭킹 ──
 * 나라별로 1등부터 상위 10%까지 목록으로 보여주고, 내가 어디쯤인지 % + 등수로 표시.
 *
 * ⚠️ 지금은 로컬 데모 데이터 기준 - 실서버 연동 시 좋아요 집계를 서버에서 받아오면 됨.
 */
object PlaygroundRank {

    /**
     * ✅ 무지개 티어 별 배지 (전면 개편):
     *  - 상위 10%까지만 별이 붙음, 별은 항상 최대 5개
     *  - 1~5등: 🔴 빨간별 (1등 5개 → 5등 1개)
     *  - 그 아래는 백분위로 색이 내려감: 주황 → 노랑 → 초록 → 파랑 → 남색 → 보라
     *    각 색 구간 안에서도 상위일수록 별이 많음 (5개 → 1개)
     *  - 글 아이디 밑에 빛나는(글로우) 별로 렌더링됨 (GlowingStars 컴포저블)
     */
    data class StarBadge(val color: androidx.compose.ui.graphics.Color, val count: Int, val tierName: String) {
        val isEmpty: Boolean get() = count <= 0
        /** 이모지 폴백 (알림/텍스트 전용 위치에서 사용) */
        fun render(): String = if (isEmpty) "" else "★".repeat(count.coerceAtMost(5))
        fun renderCompact(): String = if (isEmpty) "" else "$tierName ★x$count"
    }

    /**
     * ✅ v82 무지개 순서(빨·주·노·초·파·남·보) 고정.
     *  위(1등)일수록 빨강, 아래(상위 10% 경계)로 갈수록 보라.
     *  가장 낮은 등급 = 보라 별 1개.
     */
    val TIER_COLORS = listOf(
        androidx.compose.ui.graphics.Color(0xFFFF2D3F) to "빨강",   // 빨 (1~5등)
        androidx.compose.ui.graphics.Color(0xFFFF8A2A) to "주황",   // 주
        androidx.compose.ui.graphics.Color(0xFFFFD22E) to "노랑",   // 노
        androidx.compose.ui.graphics.Color(0xFF2ECC71) to "초록",   // 초
        androidx.compose.ui.graphics.Color(0xFF2F86FF) to "파랑",   // 파
        androidx.compose.ui.graphics.Color(0xFF3F4EA8) to "남색",   // 남
        androidx.compose.ui.graphics.Color(0xFF9B51E0) to "보라"    // 보 (최하위)
    )

    data class RankedUser(val nickname: String, val flag: String, val totalLikes: Int, val rank: Int, val percentile: Double, val isMe: Boolean)

    /**
     * ✅ v81 별 배지 전면 재작성 (버그 수정 + 요청 스펙).
     *
     * ⚠️ 기존 버그: 등수만 보고 별을 줬기 때문에 전체 21명 중 21등(= 상위 100%)인 사람도
     *    "그린 별 5개"를 달고 있었다. 이제 반드시 **상위 10% 이내**여야 별이 붙는다.
     *
     * 규칙:
     *  ① 상위 10% 밖 → 별 없음 (무조건)
     *  ② 1~5등 → 🔴 빨강 (1등 5개 · 2등 4개 · 3등 3개 · 4등 2개 · 5등 1개)
     *  ③ 6등부터 상위 10% 끝까지 → 오렌지→옐로→그린→블루→네이비→바이올렛 순으로 색이 내려가고,
     *     각 색 구간 안에서도 위쪽일수록 별이 많다 (5개 → 1개).
     *  ④ 가장 낮은 등급은 바이올렛(보라) 별 1개.
     *  ⑤ 인원이 적을 때(100명 미만)는 상위 10%가 몇 명 안 되므로 자연스럽게 등수 기준으로 동작하고,
     *     인원이 늘어나면 같은 공식이 그대로 %(비율) 기준으로 확장된다. (별도 분기 불필요 = 버그 없음)
     */
    fun badgeFor(rank: Int, totalUsers: Int): StarBadge {
        val none = StarBadge(androidx.compose.ui.graphics.Color.Transparent, 0, "")
        if (rank <= 0 || totalUsers <= 0) return none

        // ① 상위 10% 이내만 별을 받는다 (최소 1명은 보장 - 1등)
        val eligible = kotlin.math.ceil(totalUsers * 0.10).toInt().coerceAtLeast(1)
        if (rank > eligible) return none

        // ② 1~5등은 빨강 고정
        if (rank <= 5) {
            val (c, n) = TIER_COLORS[0]
            return StarBadge(c, 6 - rank, n)
        }

        // ③ 6등 ~ eligible 구간을 6색(오렌지~바이올렛)으로 균등 분할
        val bandCount = 6                                   // TIER_COLORS[1..6]
        val restTotal = (eligible - 5).coerceAtLeast(1)     // 6등부터 남은 인원 수
        val posInRest = (rank - 6).coerceAtLeast(0)         // 0부터
        val colorIdx = 1 + ((posInRest.toDouble() / restTotal) * bandCount).toInt().coerceIn(0, bandCount - 1)

        // 각 색 구간 안에서 상위일수록 별이 많음 (5 → 1)
        val bandSize = (restTotal.toDouble() / bandCount).coerceAtLeast(1.0)
        val bandStart = 6 + ((colorIdx - 1) * bandSize).toInt()
        val posInBand = ((rank - bandStart).toDouble() / bandSize).coerceIn(0.0, 0.999)
        val stars = (5 - (posInBand * 5).toInt()).coerceIn(1, 5)

        val (c, n) = TIER_COLORS[colorIdx]
        return StarBadge(c, stars, n)
    }

    /** ✅ v81 전세계 랭킹용 식별자 */
    const val GLOBAL = "🌍"

    /** 시연용: 나라별 좋아요 랭킹 (내 좋아요 총합을 넣어 내 위치 계산) */
    fun buildCountryRanking(countryFlag: String, myNickname: String, myTotalLikes: Int): List<RankedUser> {
        val names = listOf("RunnerJane", "SwiftFox", "김달림", "새벽러너", "한강매니아", "박질주", "빠른바람", "서울라이더",
            "NightOwl", "정속주행", "GoGoGo", "안전제일", "Cruiser", "ThunderLegs", "Ana Corre", "MikeSpeed",
            "달빛산책", "바람돌이", "느긋걷기", "출근런")

        // ✅ v81 전세계 랭킹: 여러 나라 인원을 합쳐 훨씬 큰 모집단을 만든다.
        //    (인원이 많아지면 상위 10% 컷이 자연스럽게 %기준으로 확장됨)
        if (countryFlag == GLOBAL) {
            val flags = listOf("🇰🇷", "🇺🇸", "🇯🇵", "🇬🇧", "🇩🇪", "🇫🇷", "🇧🇷")
            val all = ArrayList<Pair<String, Pair<String, Int>>>()   // nickname to (flag, likes)
            flags.forEach { f ->
                val rnd = kotlin.random.Random(f.hashCode())
                names.forEachIndexed { i, n ->
                    val label = if (f == "🇰🇷") n else "$n${rnd.nextInt(10, 99)}"
                    all.add(label to (f to (rnd.nextInt(5, 800) + (names.size - i) * 12)))
                    // ✅ v88 나라마다 파생 유저를 추가해 전세계 모집단을 크게 (약 1,000명)
                    repeat(6) {
                        all.add("$n${rnd.nextInt(100, 999)}" to (f to rnd.nextInt(1, 700)))
                    }
                }
            }
            all.add(myNickname to ("🌍" to myTotalLikes))
            val sorted = all.sortedByDescending { it.second.second }
            val total = sorted.size
            return sorted.mapIndexed { idx, (n, fl) ->
                RankedUser(n, fl.first, fl.second, idx + 1, (idx + 1).toDouble() / total * 100, n == myNickname)
            }
        }

        // ✅ v88 나라별 모집단 확대 (기존 21명 → 약 200명).
        //   21명뿐이면 상위 10% 컷이 2명밖에 안 돼서 등수·비율이 비현실적이었다.
        //   이름 뒤에 번호를 붙여 파생 유저를 만들어 모집단을 키운다.
        val seed = countryFlag.hashCode()
        val rnd = kotlin.random.Random(seed)
        val fakeUsers = ArrayList<Pair<String, Int>>()
        names.forEachIndexed { i, n ->
            // 원본 1명 + 파생 9명 = 이름당 10명
            fakeUsers.add(n to (rnd.nextInt(5, 800) + (names.size - i) * 12))
            repeat(9) { k ->
                fakeUsers.add("$n${rnd.nextInt(10, 99)}" to rnd.nextInt(1, 700))
            }
        }
        val all = (fakeUsers + (myNickname to myTotalLikes))
            .sortedByDescending { it.second }
        val total = all.size
        return all.mapIndexed { idx, (n, likes) ->
            RankedUser(n, countryFlag, likes, idx + 1, (idx + 1).toDouble() / total * 100, n == myNickname)
        }
    }
}

/**
 * ✅ GPS 국가 자동 배정: 현재 위치를 역지오코딩해서 가장 가까운(=현재 있는) 나라로 랭킹 소속을 정함.
 * 실패 시(오프라인·권한 없음) 기기 언어 국가 → 그것도 없으면 🇰🇷 폴백.
 */
object CountryLocator {
    fun flagFromCode(code: String): String {
        val cc = code.uppercase()
        if (cc.length != 2 || !cc.all { it in 'A'..'Z' }) return "🇰🇷"
        val a = Character.codePointAt(cc, 0) - 'A'.code + 0x1F1E6
        val b = Character.codePointAt(cc, 1) - 'A'.code + 0x1F1E6
        return String(Character.toChars(a)) + String(Character.toChars(b))
    }

    /** GPS 좌표 → 국기 이모지 (블로킹 지오코딩이라 코루틴 IO에서 호출 권장) */
    fun flagFor(context: Context, lat: Double?, lng: Double?): String {
        if (lat != null && lng != null) {
            try {
                @Suppress("DEPRECATION")
                val cc = android.location.Geocoder(context, java.util.Locale.US)
                    .getFromLocation(lat, lng, 1)?.firstOrNull()?.countryCode
                if (!cc.isNullOrBlank()) return flagFromCode(cc)
            } catch (_: Exception) { }
        }
        val deviceCc = java.util.Locale.getDefault().country
        return if (deviceCc.isNotBlank()) flagFromCode(deviceCc) else "🇰🇷"
    }
}

/**
 * 운동장 관리자 시스템 (v25 신규).
 * - 관리자(마스터): 앱 소유자 본인 - 모든 권한
 * - 부관리자: 최대 10명 - 글 삭제/가리기, 유저 글쓰기 정지
 * 권한: 글 삭제 · 글 가리기 · 유저 글쓰기 정지(뮤트) · 계정 정지 · 부정랭킹 무효 처리
 * (로컬 저장 - 실서버 연동 시 Firestore roles 컬렉션으로 교체)
 */
object PlaygroundAdmin {
    private const val PREFS = "playground_admin"

    /** ⚠️ 마스터 관리자 고유코드: 내정보의 내 고유코드를 여기 적으면 그 계정이 마스터가 됨 */
    var masterUid: String = "" // 첫 실행 시 아래 claimMaster()로 내 uid가 자동 등록됨

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** 최초 1회: 마스터가 비어있으면 지금 로그인한 계정(=개발자 본인)을 마스터로 등록 */
    fun claimMasterIfEmpty(context: Context, myUid: String) {
        if (myUid.isBlank()) return
        val saved = prefs(context).getString("master", null)
        if (saved.isNullOrBlank()) prefs(context).edit().putString("master", myUid).apply()
        masterUid = prefs(context).getString("master", "") ?: ""
    }

    fun isMaster(context: Context, uid: String): Boolean =
        uid.isNotBlank() && uid == (prefs(context).getString("master", "") ?: "")

    fun isSubAdmin(context: Context, uid: String): Boolean =
        uid.isNotBlank() && subAdmins(context).contains(uid)

    fun isAdmin(context: Context, uid: String): Boolean = isMaster(context, uid) || isSubAdmin(context, uid)

    fun subAdmins(context: Context): Set<String> =
        prefs(context).getStringSet("sub_admins", emptySet()) ?: emptySet()

    /** 부관리자 임명 (마스터만 가능, 최대 10명) */
    fun appointSubAdmin(context: Context, byUid: String, targetUid: String): Boolean {
        if (!isMaster(context, byUid)) return false
        val cur = subAdmins(context).toMutableSet()
        if (cur.size >= 10 && targetUid !in cur) return false
        cur.add(targetUid)
        prefs(context).edit().putStringSet("sub_admins", cur).apply()
        return true
    }

    fun dismissSubAdmin(context: Context, byUid: String, targetUid: String): Boolean {
        if (!isMaster(context, byUid)) return false
        val cur = subAdmins(context).toMutableSet()
        cur.remove(targetUid)
        prefs(context).edit().putStringSet("sub_admins", cur).apply()
        return true
    }

    // ===== 글 가리기 =====
    fun hiddenPosts(context: Context): Set<Long> =
        (prefs(context).getStringSet("hidden_posts", emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet()

    fun hidePost(context: Context, postId: Long) {
        val cur = (prefs(context).getStringSet("hidden_posts", emptySet()) ?: emptySet()).toMutableSet()
        cur.add(postId.toString())
        prefs(context).edit().putStringSet("hidden_posts", cur).apply()
    }

    fun unhidePost(context: Context, postId: Long) {
        val cur = (prefs(context).getStringSet("hidden_posts", emptySet()) ?: emptySet()).toMutableSet()
        cur.remove(postId.toString())
        prefs(context).edit().putStringSet("hidden_posts", cur).apply()
    }

    // ===== 유저 글쓰기 정지 (뮤트) =====
    fun mutedUsers(context: Context): Set<String> =
        prefs(context).getStringSet("muted_users", emptySet()) ?: emptySet()

    fun isMuted(context: Context, uid: String): Boolean = uid.isNotBlank() && mutedUsers(context).contains(uid)

    fun muteUser(context: Context, targetUid: String) {
        val cur = mutedUsers(context).toMutableSet(); cur.add(targetUid)
        prefs(context).edit().putStringSet("muted_users", cur).apply()
    }

    fun unmuteUser(context: Context, targetUid: String) {
        val cur = mutedUsers(context).toMutableSet(); cur.remove(targetUid)
        prefs(context).edit().putStringSet("muted_users", cur).apply()
    }

    // ===== 계정 정지 =====
    fun suspendedUsers(context: Context): Set<String> =
        prefs(context).getStringSet("suspended_users", emptySet()) ?: emptySet()

    fun isSuspended(context: Context, uid: String): Boolean = uid.isNotBlank() && suspendedUsers(context).contains(uid)

    fun suspendUser(context: Context, targetUid: String) {
        val cur = suspendedUsers(context).toMutableSet(); cur.add(targetUid)
        prefs(context).edit().putStringSet("suspended_users", cur).apply()
    }

    fun unsuspendUser(context: Context, targetUid: String) {
        val cur = suspendedUsers(context).toMutableSet(); cur.remove(targetUid)
        prefs(context).edit().putStringSet("suspended_users", cur).apply()
    }
}
