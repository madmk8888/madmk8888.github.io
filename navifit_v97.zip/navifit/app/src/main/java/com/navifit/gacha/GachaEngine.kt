package com.navifit.gacha

import kotlin.random.Random

object GachaEngine {

    // 만보기 30만보 달성마다 쌓이는 확률 부스트 - 최대 5단계
    // ✅ 에픽/유니크만 부스트됨. 레전더리는 절대 부스트 안 됨 (항상 0.0001% 극악 확률 유지)
    const val EPIC_BOOST_PER_LEVEL = 1.0
    const val UNIQUE_BOOST_PER_LEVEL = 0.5
    const val MAX_BOOST_LEVEL = 5

    /**
     * @param premium 교환권 프리미엄 뽑기 여부 (에픽/유니크만 소폭 추가 부스트, 레전더리는 절대 안 오름)
     * @param stepBoostLevel 만보기 누적 부스트 단계 (0~5)
     */
    fun drawOne(premium: Boolean = false, stepBoostLevel: Int = 0): DrawnMarker {
        val shapeTier = pickTier(premium, stepBoostLevel)
        val colorTier = pickTier(premium, stepBoostLevel)
        val shape = MarkerCatalog.shapesByTier(shapeTier).random()

        val color = MarkerCatalog.colorsByTier(colorTier).random()

        return DrawnMarker(shape, color)
    }

    /** 최종 확률표 계산 (뽑기 화면에 그대로 고시하기 위한 함수) */
    fun computeRates(premium: Boolean, stepBoostLevel: Int): Map<GachaTier, Double> {
        val level = stepBoostLevel.coerceIn(0, MAX_BOOST_LEVEL)
        val epicBoost = EPIC_BOOST_PER_LEVEL * level + if (premium) 5.0 else 0.0
        val uniqueBoost = UNIQUE_BOOST_PER_LEVEL * level + if (premium) 1.0 else 0.0
        // ✅ 레전더리는 부스트 대상에서 완전히 제외 - 항상 기본 확률(0.0001%) 그대로
        val commonDelta = (if (premium) 10.0 else 0.0) + epicBoost + uniqueBoost
        val rates = mutableMapOf(
            GachaTier.COMMON to (GachaTier.COMMON.ratePercent - commonDelta).coerceAtLeast(0.0),
            GachaTier.RARE to GachaTier.RARE.ratePercent,
            GachaTier.EPIC to GachaTier.EPIC.ratePercent + epicBoost,
            GachaTier.UNIQUE to GachaTier.UNIQUE.ratePercent + uniqueBoost,
            GachaTier.LEGENDARY to GachaTier.LEGENDARY.ratePercent, // 절대 안 바뀜
        )
        val total = rates.values.sum()
        return rates.mapValues { it.value / total * 100 } // 100% 기준으로 정규화
    }

    private fun pickTier(premium: Boolean, stepBoostLevel: Int): GachaTier {
        val rates = computeRates(premium, stepBoostLevel)
        val roll = Random.nextDouble(0.0, 100.0)
        var cum = 0.0
        for (tier in GachaTier.entries) {
            cum += rates[tier] ?: 0.0
            if (roll <= cum) return tier
        }
        return GachaTier.COMMON
    }

    /**
     * 합성 확률표 (고시용):
     * - 1단계(COMMON 소재) 합성: 승급 80% / 본전(제자리) 20% / 하락 없음 (더 내려갈 곳이 없어서)
     * - 그 외(RARE 이상) 합성: 승급 20% / 본전 70% / 하락 10%
     */
    fun fuse(source: DrawnMarker): FusionResult {
        val shapeResult = fuseOneAxis(source.shape.tier)
        val colorResult = fuseOneAxis(source.color.tier)

        val shape = MarkerCatalog.shapesByTier(shapeResult.newTier).random()
        val color = MarkerCatalog.colorsByTier(colorResult.newTier).random()

        return FusionResult(
            marker = DrawnMarker(shape, color),
            shapeOutcome = shapeResult.outcome,
            colorOutcome = colorResult.outcome
        )
    }

    enum class FuseOutcome { UPGRADE, SAME, DOWNGRADE }
    data class AxisResult(val newTier: GachaTier, val outcome: FuseOutcome)
    data class FusionResult(val marker: DrawnMarker, val shapeOutcome: FuseOutcome, val colorOutcome: FuseOutcome)

    private fun fuseOneAxis(currentTier: GachaTier): AxisResult {
        val roll = Random.nextDouble(0.0, 100.0)
        return if (currentTier == GachaTier.COMMON) {
            // 1단계: 승급 80% / 본전 20% (하락 없음)
            if (roll <= 80.0) AxisResult(nextTier(currentTier), FuseOutcome.UPGRADE)
            else AxisResult(currentTier, FuseOutcome.SAME)
        } else {
            // 그 외: 승급 20% / 본전 70% / 하락 10%
            when {
                roll <= 20.0 -> AxisResult(nextTier(currentTier), FuseOutcome.UPGRADE)
                roll <= 90.0 -> AxisResult(currentTier, FuseOutcome.SAME)
                else -> AxisResult(prevTier(currentTier), FuseOutcome.DOWNGRADE)
            }
        }
    }

    private fun nextTier(tier: GachaTier): GachaTier {
        val idx = GachaTier.entries.indexOf(tier)
        return GachaTier.entries[(idx + 1).coerceAtMost(GachaTier.entries.size - 1)]
    }
    private fun prevTier(tier: GachaTier): GachaTier {
        val idx = GachaTier.entries.indexOf(tier)
        return GachaTier.entries[(idx - 1).coerceAtLeast(0)]
    }
}
