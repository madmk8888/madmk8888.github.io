package com.navifit.social

import android.content.Context

/**
 * ✅ v86 "이 사람 글 안 보기" 저장소.
 *  차단(신고)과 달리 조용히 내 피드에서만 숨긴다. 상대는 알 수 없다.
 */
object BlockStore {
    private const val PREFS = "blocked_authors"
    private const val KEY = "list"

    fun all(c: Context): Set<String> =
        c.getSharedPreferences(PREFS, 0).getStringSet(KEY, emptySet()) ?: emptySet()

    fun isBlocked(c: Context, author: String): Boolean = author in all(c)

    fun block(c: Context, author: String) {
        val cur = all(c).toMutableSet()
        cur.add(author)
        c.getSharedPreferences(PREFS, 0).edit().putStringSet(KEY, cur).apply()
    }

    fun unblock(c: Context, author: String) {
        val cur = all(c).toMutableSet()
        cur.remove(author)
        c.getSharedPreferences(PREFS, 0).edit().putStringSet(KEY, cur).apply()
    }
}
