package com.navifit.tracking

import android.annotation.SuppressLint
import android.content.Context
import android.location.GnssStatus
import android.location.LocationManager
import android.location.OnNmeaMessageListener
import android.os.Build
import android.os.Handler
import android.os.Looper

/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  GnssQualityMonitor — 위성 신호를 "직접" 읽어서 하늘이 보이는지 판정 (v84 전면 개편)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * 왜 만들었나 (기존 문제):
 *   기존엔 "위치 업데이트가 15초 안 오면 터널"이라고 **추측**했다.
 *   그런데 배터리 최적화(Doze)·앱 절전·기기 스로틀링으로 업데이트가 늦어져도
 *   똑같이 15초가 지나므로, 하늘이 훤히 보이는 야외에서도 "터널"이라고 오판했다.
 *
 * 어떻게 고쳤나:
 *   안드로이드 7.0(API 24)부터 제공되는 GnssStatus 콜백으로 **실제 위성 상태**를 읽는다.
 *   전부 무료·오프라인·추가 권한 불필요(이미 있는 위치 권한만 사용).
 *
 *   · satellitesVisible : 하늘에서 보이는 위성 총 개수
 *   · satellitesUsed    : 실제 측위에 사용된 위성 개수  ← 이게 핵심
 *   · avgCn0            : 사용 위성들의 평균 신호세기(dB-Hz)
 *
 * 판정 기준 (업계 통용):
 *   · C/N0 ≥ 35 dB-Hz  : 아주 강한 신호 (탁 트인 하늘)
 *   · C/N0 30~35       : 양호
 *   · C/N0 25~30       : 보통 (건물 근처)
 *   · C/N0 < 25        : 약함 (실내·터널·깊은 도심)
 *   · 측위 사용 위성 4개 미만 = 정상 측위 불가 → 진짜 신호 두절
 *
 * 이제 "터널"은 추측이 아니라 **위성이 실제로 안 잡힐 때만** 표시된다.
 */
class GnssQualityMonitor(private val context: Context) {

    /** 하늘 개방 상태 */
    enum class SkyState {
        OPEN,      // 탁 트임: 위성 다수 + 신호 강함 → GPS 신뢰도 높음
        PARTIAL,   // 부분 가림: 도심/나무 아래 → 필터를 조금 더 강하게
        BLOCKED,   // 실제 차단: 터널·실내 → 추측항법(dead-reckoning)으로 전환
        UNKNOWN    // 아직 위성 정보 수신 전 (또는 API 미지원 기기)
    }

    @Volatile var satellitesVisible: Int = 0; private set
    @Volatile var satellitesUsed: Int = 0; private set
    @Volatile var avgCn0: Float = 0f; private set
    @Volatile var maxCn0: Float = 0f; private set
    @Volatile var skyState: SkyState = SkyState.UNKNOWN; private set
    /** 마지막으로 위성 상태를 받은 시각 (elapsedRealtime 기준, 시스템 시계 변경에 영향 없음) */
    @Volatile var lastStatusAtElapsed: Long = 0L; private set
    /** NMEA에서 뽑은 수평 정밀도 저하율(HDOP). 낮을수록 좋음(1~2=우수, 5+=나쁨). 0이면 미수신 */
    @Volatile var hdop: Float = 0f; private set

    private val lm by lazy { context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager }
    private val handler = Handler(Looper.getMainLooper())
    private var registered = false

    private val gnssCallback = object : GnssStatus.Callback() {
        override fun onSatelliteStatusChanged(status: GnssStatus) {
            var visible = 0
            var used = 0
            var sumCn0 = 0f
            var peak = 0f
            for (i in 0 until status.satelliteCount) {
                visible++
                val cn0 = status.getCn0DbHz(i)
                if (cn0 > peak) peak = cn0
                if (status.usedInFix(i)) {
                    used++
                    sumCn0 += cn0
                }
            }
            satellitesVisible = visible
            satellitesUsed = used
            avgCn0 = if (used > 0) sumCn0 / used else 0f
            maxCn0 = peak
            lastStatusAtElapsed = android.os.SystemClock.elapsedRealtime()
            skyState = judge(used, avgCn0)
        }

        override fun onStopped() {
            skyState = SkyState.UNKNOWN
            satellitesUsed = 0
        }
    }

    /**
     * 하늘 상태 판정.
     *  · 측위 사용 위성 6개 이상 + 평균 30dB-Hz 이상 → 완전 개방 (신뢰)
     *  · 4개 이상이면 측위는 가능 → 부분 가림
     *  · 4개 미만 → 실제 차단 (여기서만 "터널"로 본다)
     */
    private fun judge(used: Int, cn0: Float): SkyState = when {
        used >= 6 && cn0 >= 30f -> SkyState.OPEN
        used >= 5 && cn0 >= 25f -> SkyState.OPEN
        used >= 4 -> SkyState.PARTIAL
        used >= 1 -> SkyState.BLOCKED
        else -> SkyState.BLOCKED
    }

    private val nmeaListener = OnNmeaMessageListener { message, _ ->
        // $GPGGA 문장의 8번째 필드가 HDOP
        try {
            if (message.startsWith("\$GPGGA") || message.startsWith("\$GNGGA")) {
                val parts = message.split(",")
                if (parts.size > 8) parts[8].toFloatOrNull()?.let { hdop = it }
            }
        } catch (_: Exception) { }
    }

    @SuppressLint("MissingPermission")
    fun start() {
        if (registered) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return  // GnssStatus는 API 24+
        try {
            lm?.registerGnssStatusCallback(gnssCallback, handler)
            lm?.addNmeaListener(nmeaListener, handler)
            registered = true
        } catch (_: SecurityException) {
        } catch (_: Exception) { }
    }

    fun stop() {
        if (!registered) return
        try {
            lm?.unregisterGnssStatusCallback(gnssCallback)
            lm?.removeNmeaListener(nmeaListener)
        } catch (_: Exception) { }
        registered = false
        skyState = SkyState.UNKNOWN
        satellitesUsed = 0; satellitesVisible = 0; avgCn0 = 0f; hdop = 0f
    }

    /**
     * ✅ 진짜 신호 두절인지 판정 (터널 표시용).
     * 위성 정보를 받고 있고, 측위 위성이 4개 미만일 때만 true.
     * 위성 정보 자체를 못 받는 기기(API 미지원)면 false를 반환해서
     * 기존처럼 시간 기반으로만 판단하도록 넘긴다.
     */
    fun isTrulyBlocked(): Boolean {
        if (skyState == SkyState.UNKNOWN) return false
        val fresh = android.os.SystemClock.elapsedRealtime() - lastStatusAtElapsed < 10_000L
        return fresh && skyState == SkyState.BLOCKED
    }

    /** 위성 정보를 실제로 받고 있는지 (지원 기기 + 콜백 동작 중) */
    fun hasSatelliteInfo(): Boolean =
        skyState != SkyState.UNKNOWN &&
        android.os.SystemClock.elapsedRealtime() - lastStatusAtElapsed < 10_000L

    /**
     * ✅ 하늘 상태에 따른 위치 신뢰 반경(m).
     * 개방된 하늘에선 관대하게, 가려진 곳에선 엄격하게 필터링하도록 상위에 알려준다.
     */
    fun trustRadiusMeters(): Float = when (skyState) {
        SkyState.OPEN -> 50f      // 하늘 트임 → 웬만한 fix는 믿는다
        SkyState.PARTIAL -> 35f   // 도심 → 조금 엄격
        SkyState.BLOCKED -> 20f   // 차단 → 매우 엄격
        SkyState.UNKNOWN -> 40f
    }

    /** 사용자에게 보여줄 짧은 상태 문구 */
    fun statusText(): String = when (skyState) {
        SkyState.OPEN -> "GPS 양호 (위성 ${satellitesUsed}개)"
        SkyState.PARTIAL -> "GPS 보통 (위성 ${satellitesUsed}개)"
        SkyState.BLOCKED -> "GPS 약함 (위성 ${satellitesUsed}개)"
        SkyState.UNKNOWN -> "GPS 확인 중"
    }
}
