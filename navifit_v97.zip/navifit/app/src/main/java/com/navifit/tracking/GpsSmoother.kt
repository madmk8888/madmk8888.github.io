package com.navifit.tracking

import com.navifit.navigation.LatLngPoint
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sqrt

/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  GpsSmoother — v81 GPS 지그재그 완전 개조
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * 문제: GPS는 정확도가 나쁠 때 좌우로 5~20m씩 튀어서 경로가 톱니처럼 지그재그로 그려짐.
 *       (실시간 화면에서도, 저장된 경로에서도)
 *
 * 해결 (3단계):
 *  1) 칼만 유사 필터(1차원 적응형): 정확도(accuracy)를 신뢰도로 써서
 *     "정확도 좋은 점은 크게 반영, 나쁜 점은 조금만 반영" → 튐이 부드럽게 흡수됨.
 *  2) 이상치 제거: 직전 위치에서 물리적으로 불가능한 점프는 아예 버림.
 *  3) 최소 이동 임계: 정지 상태에서 GPS가 제자리를 맴돌며 생기는 미세 지그재그 차단.
 *
 * 이 필터는 화면 표시·거리 누적·경로 저장에 모두 같은 결과를 쓰므로
 * "실시간은 괜찮은데 저장하면 지그재그" 같은 불일치가 사라진다.
 */
class GpsSmoother {

    private var estLat = 0.0
    private var estLng = 0.0
    /** 추정 오차 분산(미터^2). 클수록 새 관측을 더 믿는다. */
    private var variance = -1.0

    /** 정지 판정용: 이 거리 미만 이동은 노이즈로 간주 */
    private val stillThresholdM = 1.5

    fun reset() { variance = -1.0; estLat = 0.0; estLng = 0.0 }

    /**
     * 새 GPS 관측을 넣고 부드럽게 보정된 좌표를 반환.
     * @param accuracyM 관측 정확도(m). 알 수 없으면 30f 정도를 넣는다.
     * @param dtSeconds 직전 관측과의 시간 간격(초)
     * @param speedMps 현재 속도(m/s) - 이동 중이면 필터를 덜 걸어 반응성을 유지
     * @return 보정 좌표, 또는 이상치라 버려야 하면 null
     */
    fun process(lat: Double, lng: Double, accuracyM: Float, dtSeconds: Double, speedMps: Double): LatLngPoint? {
        val acc = if (accuracyM > 0f) accuracyM.toDouble() else 30.0

        if (variance < 0) {
            estLat = lat; estLng = lng; variance = acc * acc
            return LatLngPoint(estLat, estLng)
        }

        // ── ② 이상치 제거: 물리적으로 불가능한 점프 ──
        val jump = distanceMeters(estLat, estLng, lat, lng)
        // 허용 이동량 = (현재속도 + 여유 3m/s) × 경과시간 × 2배 마진, 최소 25m
        val allowed = ((speedMps + 3.0) * dtSeconds.coerceIn(0.5, 10.0) * 2.0).coerceAtLeast(25.0)
        if (jump > allowed) return null   // 버림 (지도 튐 차단)

        // ── ③ 정지 상태 미세 지그재그 차단 ──
        if (speedMps < 0.5 && jump < stillThresholdM) {
            return LatLngPoint(estLat, estLng)   // 이전 위치 유지
        }

        // ── ① 칼만 유사 갱신 ──
        // 프로세스 노이즈: 이동 중일수록 크게(=새 관측을 더 신뢰) → 반응성 유지
        val processNoise = (speedMps.coerceAtLeast(0.3) * dtSeconds.coerceIn(0.2, 5.0)) * 1.4
        variance += processNoise * processNoise

        val k = variance / (variance + acc * acc)   // 칼만 게인 (0~1)
        estLat += k * (lat - estLat)
        estLng += k * (lng - estLng)
        variance *= (1 - k)

        return LatLngPoint(estLat, estLng)
    }

    companion object {
        fun distanceMeters(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
            val latRad = Math.toRadians((lat1 + lat2) / 2)
            val dx = (lng2 - lng1) * cos(latRad) * 111_320.0
            val dy = (lat2 - lat1) * 110_540.0
            return sqrt(dx * dx + dy * dy)
        }

        /**
         * ✅ 저장용 경로 후처리: 남은 각진 부분을 부드럽게 편다.
         *  · 1차: 이상치(급격한 꺾임) 제거
         *  · 2차: 가중 이동평균(5점, 중앙 가중)으로 완만화
         * MapMatcher(도로 스냅) 이전에 적용하면 결과가 훨씬 깔끔하다.
         */
        fun polishTrack(points: List<LatLngPoint>): List<LatLngPoint> {
            if (points.size < 5) return points

            // 1차: 앞뒤 점을 잇는 직선에서 과도하게 벗어난 점 제거 (스파이크 컷)
            val cleaned = ArrayList<LatLngPoint>(points.size)
            cleaned.add(points.first())
            for (i in 1 until points.size - 1) {
                val prev = cleaned.last()
                val cur = points[i]
                val next = points[i + 1]
                val direct = distanceMeters(prev.latitude, prev.longitude, next.latitude, next.longitude)
                val viaCur = distanceMeters(prev.latitude, prev.longitude, cur.latitude, cur.longitude) +
                        distanceMeters(cur.latitude, cur.longitude, next.latitude, next.longitude)
                // 우회 거리가 직선의 2.5배를 넘고 실제로 8m 이상 튀면 스파이크로 판단
                if (direct > 1.0 && viaCur > direct * 2.5 && (viaCur - direct) > 8.0) continue
                cleaned.add(cur)
            }
            cleaned.add(points.last())
            if (cleaned.size < 5) return cleaned

            // 2차: 5점 가중 이동평균 (가중치 1-2-3-2-1)
            val w = doubleArrayOf(1.0, 2.0, 3.0, 2.0, 1.0)
            val out = ArrayList<LatLngPoint>(cleaned.size)
            out.add(cleaned[0]); out.add(cleaned[1])
            for (i in 2 until cleaned.size - 2) {
                var sLat = 0.0; var sLng = 0.0; var sw = 0.0
                for (j in -2..2) {
                    val p = cleaned[i + j]; val ww = w[j + 2]
                    sLat += p.latitude * ww; sLng += p.longitude * ww; sw += ww
                }
                out.add(LatLngPoint(sLat / sw, sLng / sw))
            }
            out.add(cleaned[cleaned.size - 2]); out.add(cleaned.last())
            return out
        }
    }
}
