package com.navifit.safety

import android.content.Context
import com.navifit.navigation.LatLngPoint
import com.navifit.navigation.NavigationProgressCalculator
import org.json.JSONArray

/**
 * 도로 안전 POI (과속카메라 / 신호카메라 / 구간단속 / 방지턱) 저장소 + 실시간 경보 엔진 (v27).
 *
 * ✅ 800m 전 사전 안내 → 통과할 때까지 위반(속도 초과) 감시 → 위반 중이면 지속 경보
 * ✅ 데이터: assets/safety_cameras.json 또는 다운로드 파일에서 로드
 *    (공공데이터포털 '무인교통단속카메라' CSV/JSON을 변환해 넣으면 전국 커버 -
 *     무료 API가 실시간 제공을 안 해서 파일 동봉 방식. 형식은 아래 fromJson 참고)
 */
enum class RoadHazardType(val label: String, val icon: String) {
    SPEED_CAMERA("과속 단속 카메라", "📸"),
    SIGNAL_CAMERA("신호 단속 카메라", "🚦"),
    SECTION_START("구간단속 시작", "📏"),
    SECTION_END("구간단속 끝", "📏"),
    SPEED_BUMP("과속 방지턱", "⛰️"),
    SCHOOL_ZONE("어린이 보호구역", "🏫"),
    ACCIDENT_BLACKSPOT("사고 다발 구간", "⚠️")
}

data class RoadHazard(
    val type: RoadHazardType,
    val location: LatLngPoint,
    val limitKmh: Int? = null   // 제한속도 (카메라/스쿨존)
)

/** 현재 활성화된 경보 상태 (UI가 이걸 보고 패널/빨간 프레임/사운드를 처리) */
data class HazardAlert(
    val hazard: RoadHazard,
    val distanceMeters: Int,
    val isViolating: Boolean,      // 지금 제한속도를 넘고 있는가 (넘는 동안 지속 경보)
    val phase: AlertPhase
)

enum class AlertPhase { APPROACH_800, APPROACH_300, PASSING, CLEARED }

object SafetyCameraStore {
    private val hazards = mutableListOf<RoadHazard>()
    @Volatile private var loaded = false
    private const val CACHE_FILE = "safety_cameras_cache.json"

    /** 캐시(공공API 동기화본) → 없으면 assets/safety_cameras.json 순으로 로드 */
    fun ensureLoaded(context: Context) {
        if (loaded) return
        synchronized(this) {
            if (loaded) return
            try {
                val cache = java.io.File(context.filesDir, CACHE_FILE)
                val json = if (cache.exists()) cache.readText()
                else context.assets.open("safety_cameras.json").bufferedReader().readText()
                hazards.addAll(fromJson(json))
            } catch (_: Exception) { /* 파일 없으면 무시 */ }
            loaded = true
        }
    }

    /**
     * ✅ v52: 파이어베이스(Firestore)에서 전국 단속카메라를 받아와 캐시. (1순위 소스)
     *
     * data.go.kr의 단속카메라 오픈API가 찾기 어려워진 것에 대한 대체 방식:
     *   ① data.go.kr에서 "전국무인교통단속카메라표준데이터" CSV 파일을 다운로드 (파일데이터는 계속 제공됨, 무료)
     *   ② 프로젝트의 tools/upload_safety_cameras.py 스크립트로 내 Firebase에 1회 업로드
     *   ③ 앱은 여기서 Firestore를 읽음 - API 키·활용신청 전부 불필요, 완전 무료
     *
     * 저장 구조(읽기 비용 최소화): safety_camera_chunks/{chunk_N} 문서의 "json" 필드에
     * 카메라 수천 개를 JSON 배열 문자열로 압축 저장 → 전국 3만대 = 문서 3~4개 = Firestore 읽기 3~4회.
     * (카메라를 문서 1개당 1대로 저장하면 3만 읽기가 되어 무료 한도를 낭비함)
     */
    suspend fun syncFromFirebase(context: Context): Boolean = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        // ✅ google-services.json이 없으면 즉시 건너뜀 (기존엔 여기서 타임아웃까지 멈춰있었음)
        if (!com.navifit.social.FirebaseGuard.available(context)) return@withContext false
        val cache = java.io.File(context.filesDir, CACHE_FILE)
        // 7일 이내 캐시면 재동기화 생략
        if (cache.exists() && System.currentTimeMillis() - cache.lastModified() < 7L * 24 * 3600 * 1000) return@withContext true
        try {
            // ✅ 8초 타임아웃: 서버가 늦어도 앱 시작이 늘어지지 않게
            val snap = kotlinx.coroutines.withTimeoutOrNull(8_000) {
                kotlinx.coroutines.suspendCancellableCoroutine<com.google.firebase.firestore.QuerySnapshot?> { cont ->
                    com.google.firebase.firestore.FirebaseFirestore.getInstance()
                        .collection("safety_camera_chunks").get()
                        .addOnSuccessListener { cont.resume(it) {} }
                        .addOnFailureListener { cont.resume(null) {} }
                }
            } ?: return@withContext false
            val all = mutableListOf<RoadHazard>()
            // chunk_0, chunk_1 ... 순서 보장 위해 문서 id로 정렬
            snap.documents.sortedBy { it.id }.forEach { d ->
                d.getString("json")?.let { all.addAll(fromJson(it)) }
            }
            if (all.size >= 100) {
                // 캐시 교체 (기존 공공API 동기화와 동일 포맷이라 그대로 호환)
                val sb = StringBuilder("[")
                all.forEachIndexed { i, h ->
                    if (i > 0) sb.append(",")
                    sb.append("{\"type\":\"${h.type.name}\",\"lat\":${h.location.latitude},\"lng\":${h.location.longitude}")
                    h.limitKmh?.let { sb.append(",\"limit\":$it") }
                    sb.append("}")
                }
                sb.append("]")
                cache.writeText(sb.toString())
                synchronized(this@SafetyCameraStore) { hazards.clear(); hazards.addAll(all) }
                android.util.Log.i("NaviFit-Camera", "✅ Firebase에서 단속카메라 ${all.size}건 동기화 완료")
                true
            } else {
                android.util.Log.w("NaviFit-Camera",
                    "Firebase safety_camera_chunks가 비어있어요. tools/upload_safety_cameras.py로 업로드하세요")
                false
            }
        } catch (e: Exception) {
            android.util.Log.e("NaviFit-Camera", "Firebase 카메라 동기화 실패: ${e.message}")
            false
        }
    }

    /**
     * ✅ v29: 공공데이터포털 "전국무인교통단속카메라표준데이터" 오픈API에서 전국 카메라를 받아와 캐시.
     * ⚠️ v52부터는 Firebase가 1순위이고, 이 API는 data_go_kr_key가 있을 때만 예비로 시도됨.
     * 무료 - data.go.kr에서 활용신청 후 인증키(Decoding)를 assets/api_keys.properties의
     * data_go_kr_key 에 넣으면 앱 시작 시 자동 동기화 (7일마다 갱신, 실패해도 기존 캐시/내장파일로 동작).
     */
    suspend fun syncFromPublicApi(context: Context) = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val key = com.navifit.navigation.NavApiKeys.dataGoKrKey(context) ?: return@withContext
        val cache = java.io.File(context.filesDir, CACHE_FILE)
        // 7일 이내 캐시면 재동기화 생략
        if (cache.exists() && System.currentTimeMillis() - cache.lastModified() < 7L * 24 * 3600 * 1000) return@withContext
        try {
            val client = okhttp3.OkHttpClient.Builder()
                .connectTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
                .build()   // ✅ 타임아웃: 서버 무응답 시 앱이 멈춰있지 않게
            val all = mutableListOf<RoadHazard>()
            var page = 1
            while (page <= 60) { // 최대 60페이지 × 1000건 = 6만건 안전상한
                // ✅ v47 버그 수정: 공공데이터포털은 인증키를 두 종류로 줌.
                //    · Decoding 키: 원본 (예: abc+def/ghi==)   → URL 인코딩이 필요함
                //    · Encoding 키: 이미 인코딩됨 (예: abc%2Bdef%2Fghi%3D%3D) → 다시 인코딩하면 %가 %25로 깨짐
                //    기존 코드는 무조건 인코딩해서, Encoding 키를 넣으면 100% 실패했음 (카메라가 안 나오던 원인)
                val alreadyEncoded = key.contains("%2B") || key.contains("%2F") || key.contains("%3D")
                val serviceKey = if (alreadyEncoded) key else java.net.URLEncoder.encode(key, "UTF-8")
                val url = "https://api.data.go.kr/openapi/tn_pubr_public_unmanned_traffic_camera_api" +
                    "?serviceKey=$serviceKey&pageNo=$page&numOfRows=1000&type=json"
                val body = client.newCall(okhttp3.Request.Builder().url(url).build())
                    .execute().use { it.body?.string() } ?: break
                val items = try {
                    org.json.JSONObject(body).getJSONObject("response")
                        .getJSONObject("body").getJSONArray("items")
                } catch (e: Exception) {
                    // ✅ v47: 왜 실패했는지 로그로 남김 (기존엔 조용히 실패해서 원인을 알 수 없었음)
                    android.util.Log.e("NaviFit-Camera",
                        "단속카메라 API 실패. 키/활용신청 상태를 확인하세요. 응답: ${body.take(300)}")
                    break
                }
                if (items.length() == 0) break
                for (i in 0 until items.length()) {
                    val o = items.getJSONObject(i)
                    val lat = o.optString("latitude").toDoubleOrNull() ?: continue
                    val lng = o.optString("longitude").toDoubleOrNull() ?: continue
                    val se = o.optString("regltSe") + o.optString("regltSeNm") // 단속구분 코드+이름 합쳐서 판별
                    val limit = o.optString("lmttVe").toDoubleOrNull()?.toInt()
                    val type = when {
                        se.contains("신호") || se.contains("02") -> RoadHazardType.SIGNAL_CAMERA
                        se.contains("구간") -> RoadHazardType.SECTION_START
                        else -> RoadHazardType.SPEED_CAMERA
                    }
                    all.add(RoadHazard(type, LatLngPoint(lat, lng), limit?.takeIf { it in 10..130 }))
                }
                if (items.length() < 1000) break
                page++
            }
            if (all.size >= 100) { // 정상 응답으로 판단될 때만 캐시 교체
                val sb = StringBuilder("[")
                all.forEachIndexed { i, h ->
                    if (i > 0) sb.append(",")
                    sb.append("{\"type\":\"${h.type.name}\",\"lat\":${h.location.latitude},\"lng\":${h.location.longitude}")
                    h.limitKmh?.let { sb.append(",\"limit\":$it") }
                    sb.append("}")
                }
                sb.append("]")
                cache.writeText(sb.toString())
                synchronized(this@SafetyCameraStore) {
                    hazards.clear(); hazards.addAll(all)
                }
            }
        } catch (_: Exception) { /* 실패 시 기존 데이터 유지 */ }
    }

    /**
     * JSON 형식:
     * [{"type":"SPEED_CAMERA","lat":37.5,"lng":126.9,"limit":60}, ...]
     * type: RoadHazardType 이름 · limit 생략 가능
     */
    fun fromJson(json: String): List<RoadHazard> = try {
        val arr = JSONArray(json)
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val t = try { RoadHazardType.valueOf(o.getString("type")) } catch (_: Exception) { return@mapNotNull null }
            RoadHazard(t, LatLngPoint(o.getDouble("lat"), o.getDouble("lng")),
                if (o.has("limit")) o.getInt("limit") else null)
        }
    } catch (_: Exception) { emptyList() }

    /** 테스트/수동 추가용 */
    fun addAll(list: List<RoadHazard>) { hazards.addAll(list) }

    /** 내 위치 반경 radius 내 POI (지도 마커 표시용) */
    fun near(loc: LatLngPoint, radiusMeters: Double = 3000.0): List<RoadHazard> =
        hazards.filter { NavigationProgressCalculator.fastDistanceMeters(loc, it.location) <= radiusMeters }
}

/**
 * 경보 엔진: 매 위치 업데이트마다 feed()를 호출하면
 * "800m 전 안내 → 300m 전 재안내 → 통과 감시(위반 시 지속경보) → 해제" 상태머신을 굴림.
 */
class SafetyAlertEngine(
    private val onAnnounce: (text: String) -> Unit,          // 음성/토스트 안내 콜백
    private val onViolationChanged: (violating: Boolean) -> Unit // 화면 빨간 프레임 on/off
) {
    private data class Tracking(var announced800: Boolean = false, var announced300: Boolean = false, var passed: Boolean = false)
    private val trackingMap = mutableMapOf<RoadHazard, Tracking>()

    var currentAlert: HazardAlert? = null
        private set
    private var wasViolating = false

    fun feed(loc: LatLngPoint, speedKmh: Double, headingDeg: Float?) {
        // 1) 진행방향 앞쪽(±75도) 1km 내 가장 가까운 위험 POI 선정
        val candidates = SafetyCameraStore.near(loc, 1000.0)
            .map { it to NavigationProgressCalculator.fastDistanceMeters(loc, it.location) }
            .filter { (h, d) ->
                if (headingDeg == null || d < 60) true
                else {
                    val bearingTo = bearing(loc, h.location)
                    val diff = angleDiff(headingDeg, bearingTo)
                    diff <= 75f // 뒤에 있는 카메라는 무시
                }
            }
            .sortedBy { it.second }

        val nearest = candidates.firstOrNull()
        if (nearest == null) { clear(); return }
        val (hazard, dist) = nearest
        val tr = trackingMap.getOrPut(hazard) { Tracking() }

        // 통과 판정: 60m 이내로 접근했다가 다시 멀어지기 시작
        if (dist < 60) tr.passed = false // 접근 중
        val phase = when {
            dist <= 60 -> AlertPhase.PASSING
            dist <= 300 -> AlertPhase.APPROACH_300
            dist <= 800 -> AlertPhase.APPROACH_800
            else -> AlertPhase.CLEARED
        }

        // 800m/300m 1회 안내
        if (phase == AlertPhase.APPROACH_800 && !tr.announced800) {
            tr.announced800 = true
            val limitTxt = hazard.limitKmh?.let { " 제한속도 ${it}km" } ?: ""
            onAnnounce("${(dist / 100).toInt() * 100}m 앞 ${hazard.type.label}$limitTxt")
        }
        if (phase == AlertPhase.APPROACH_300 && !tr.announced300) {
            tr.announced300 = true
            onAnnounce("잠시 후 ${hazard.type.label}입니다")
        }

        // 위반 감시: 제한속도 있는 POI에 800m 이내로 접근 중 + 속도 초과 -> 지속 경보
        val violating = hazard.limitKmh != null && dist <= 800 && speedKmh > hazard.limitKmh + 2
        if (violating != wasViolating) {
            wasViolating = violating
            onViolationChanged(violating)
            if (violating) onAnnounce("제한속도를 초과했어요. ${hazard.limitKmh}km로 줄여주세요")
        }

        currentAlert = HazardAlert(hazard, dist.toInt(), violating, phase)

        // 800m 밖으로 완전히 벗어난 지난 POI들의 추적 상태 정리
        trackingMap.keys.retainAll { h ->
            NavigationProgressCalculator.fastDistanceMeters(loc, h.location) <= 1200
        }
    }

    private fun clear() {
        if (wasViolating) { wasViolating = false; onViolationChanged(false) }
        currentAlert = null
    }

    private fun bearing(a: LatLngPoint, b: LatLngPoint): Float {
        val dLng = Math.toRadians(b.longitude - a.longitude)
        val lat1 = Math.toRadians(a.latitude); val lat2 = Math.toRadians(b.latitude)
        val y = Math.sin(dLng) * Math.cos(lat2)
        val x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng)
        return ((Math.toDegrees(Math.atan2(y, x)) + 360) % 360).toFloat()
    }

    private fun angleDiff(a: Float, b: Float): Float {
        val d = Math.abs(a - b) % 360
        return if (d > 180) 360 - d else d
    }
}
