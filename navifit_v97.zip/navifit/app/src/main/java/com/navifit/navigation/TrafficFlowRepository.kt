package com.navifit.navigation

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

/**
 * ✅ v32 실시간 정체 구간 (무료).
 * 국토교통부 ITS 교통소통정보 오픈API - 고속도로·국도 구간별 실시간 평균속도 (5분 갱신, 무료).
 * data.go.kr "국토교통부_교통소통정보" 활용신청 → 같은 data_go_kr_key 사용.
 *
 * 경로 폴리라인의 각 구간을 근처 소통정보 링크와 매칭해서
 * 원활(초록) / 서행(노랑) / 정체(빨강) 으로 색칠한다.
 */
class TrafficFlowRepository(private val context: Context) {

    private val client = OkHttpClient()

    enum class Level { FREE, SLOW, JAM, UNKNOWN }

    data class FlowPoint(val point: LatLngPoint, val speedKmh: Double, val level: Level)

    private var cache: List<FlowPoint> = emptyList()
    private var cachedAtMs = 0L

    // ✅ v47 버그 수정: ITS 국가교통정보센터(openapi.its.go.kr)는 공공데이터포털(data.go.kr)과
    //    완전히 별개의 키를 씁니다. 기존엔 data.go.kr 키를 넣어서 정체구간이 항상 실패했음.
    //    its.go.kr/opendata 에서 별도 발급받은 키를 its_key 에 넣으세요.
    fun hasKey() = NavApiKeys.itsKey(context) != null

    /**
     * 지도 영역(내 위치 반경) 소통정보 조회. 5분 캐시 (API 갱신주기와 동일).
     * 호출량: 5분에 1건 = 하루 최대 288건. 공공API 무료 한도(개발계정 1만/일) 대비 여유.
     */
    suspend fun fetchNear(center: LatLngPoint, radiusKm: Double = 15.0): List<FlowPoint> = withContext(Dispatchers.IO) {
        val key = NavApiKeys.itsKey(context) ?: return@withContext emptyList()
        if (System.currentTimeMillis() - cachedAtMs < 5 * 60_000L && cache.isNotEmpty()) return@withContext cache
        try {
            val d = radiusKm / 111.0
            val url = "https://openapi.its.go.kr:9443/trafficInfo" +
                "?apiKey=$key&type=all&drcType=all&getType=json" +
                "&minX=${center.longitude - d}&maxX=${center.longitude + d}" +
                "&minY=${center.latitude - d}&maxY=${center.latitude + d}"
            val body = client.newCall(Request.Builder().url(url).build())
                .execute().use { it.body?.string() } ?: return@withContext cache
            val items = JSONObject(body).optJSONObject("body")?.optJSONArray("items")
                ?: return@withContext cache
            val list = mutableListOf<FlowPoint>()
            for (i in 0 until items.length()) {
                val o = items.getJSONObject(i)
                val spd = o.optString("speed").toDoubleOrNull() ?: continue
                // 링크 시작좌표 (제공 필드명이 버전에 따라 달라 여러 후보 시도)
                val lat = (o.optString("startNodeY").toDoubleOrNull()
                    ?: o.optString("y").toDoubleOrNull()) ?: continue
                val lng = (o.optString("startNodeX").toDoubleOrNull()
                    ?: o.optString("x").toDoubleOrNull()) ?: continue
                list.add(FlowPoint(LatLngPoint(lat, lng), spd, levelOf(spd)))
            }
            if (list.isNotEmpty()) { cache = list; cachedAtMs = System.currentTimeMillis() }
            cache
        } catch (_: Exception) { cache }
    }

    /** 속도 → 혼잡도 (도심/고속 공통 근사: 30 미만 정체, 60 미만 서행) */
    private fun levelOf(speedKmh: Double): Level = when {
        speedKmh < 30 -> Level.JAM
        speedKmh < 60 -> Level.SLOW
        else -> Level.FREE
    }

    /**
     * 경로 폴리라인을 소통정보에 맞춰 구간별로 색칠할 수 있게 분할.
     * 각 경로점에서 가장 가까운 소통 링크(500m 내)의 혼잡도를 부여, 없으면 UNKNOWN.
     */
    fun colorizeRoute(routePoints: List<LatLngPoint>, flows: List<FlowPoint>): List<Pair<List<LatLngPoint>, Level>> {
        if (routePoints.size < 2 || flows.isEmpty()) return emptyList()
        val levels = routePoints.map { p ->
            var best: FlowPoint? = null
            var bestD = 500.0
            for (f in flows) {
                val d = NavigationProgressCalculator.fastDistanceMeters(p, f.point)
                if (d < bestD) { bestD = d; best = f }
            }
            best?.level ?: Level.UNKNOWN
        }
        // 같은 혼잡도가 이어지는 구간끼리 묶기
        val segments = mutableListOf<Pair<List<LatLngPoint>, Level>>()
        var startIdx = 0
        for (i in 1 until routePoints.size) {
            if (levels[i] != levels[startIdx] || i == routePoints.size - 1) {
                if (i - startIdx >= 1) {
                    segments.add(routePoints.subList(startIdx, (i + 1).coerceAtMost(routePoints.size)) to levels[startIdx])
                }
                startIdx = i
            }
        }
        // 정체/서행 구간만 반환 (원활은 기존 경로색 그대로 두면 됨)
        return segments.filter { it.second == Level.JAM || it.second == Level.SLOW }
    }
}
