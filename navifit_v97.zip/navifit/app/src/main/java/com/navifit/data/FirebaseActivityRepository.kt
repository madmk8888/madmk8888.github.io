package com.navifit.data

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.navifit.navigation.TravelMode
import kotlinx.coroutines.tasks.await

/**
 * Firebase Firestore 기반 기록 저장소.
 * Firestore 무료(Spark) 요금제 기준:
 * - 일 50,000 읽기 / 20,000 쓰기 / 20,000 삭제 무료
 * - 저장용량 1GiB 무료
 * 개인용/초기 서비스 단계에서는 충분히 무료 범위 안에서 운영 가능.
 *
 * 인증은 Firebase Anonymous Auth를 붙이면 사용자별 데이터 분리 가능 (여기서는 uid 파라미터로 단순화).
 */
class FirebaseActivityRepository {

    private val db = FirebaseFirestore.getInstance()
    private fun collection(uid: String) = db.collection("users").document(uid).collection("activity_records")

    suspend fun save(uid: String, record: FirestoreActivityRecord): Result<String> {
        return try {
            val docRef = collection(uid).document()
            docRef.set(record.copy(id = docRef.id)).await()
            Result.success(docRef.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getByMode(uid: String, mode: TravelMode): Result<List<FirestoreActivityRecord>> {
        return try {
            val snapshot = collection(uid)
                .whereEqualTo("mode", mode.name)
                .orderBy("startTimeMillis", Query.Direction.DESCENDING)
                .get()
                .await()
            Result.success(snapshot.toObjects(FirestoreActivityRecord::class.java))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getAll(uid: String): Result<List<FirestoreActivityRecord>> {
        return try {
            val snapshot = collection(uid)
                .orderBy("startTimeMillis", Query.Direction.DESCENDING)
                .get()
                .await()
            Result.success(snapshot.toObjects(FirestoreActivityRecord::class.java))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** 보유 마커도 같은 방식으로 Firestore에 저장 */
    suspend fun saveOwnedMarker(uid: String, markerId: String): Result<Unit> {
        return try {
            db.collection("users").document(uid)
                .collection("owned_markers").document(markerId)
                .set(mapOf("markerId" to markerId, "obtainedAt" to System.currentTimeMillis()))
                .await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getOwnedMarkerIds(uid: String): Result<List<String>> {
        return try {
            val snapshot = db.collection("users").document(uid)
                .collection("owned_markers").get().await()
            Result.success(snapshot.documents.map { it.id })
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

/** Firestore 저장용 데이터 클래스 (Room의 ActivityRecord와 별도로, no-arg 생성자 필요해서 기본값 지정) */
data class FirestoreActivityRecord(
    val id: String = "",
    val mode: String = "",
    val startTimeMillis: Long = 0,
    val durationSeconds: Long = 0,
    val distanceMeters: Double = 0.0,
    val avgSpeedKmh: Double = 0.0,
    val maxSpeedKmh: Double = 0.0,
    val destinationName: String? = null
)
