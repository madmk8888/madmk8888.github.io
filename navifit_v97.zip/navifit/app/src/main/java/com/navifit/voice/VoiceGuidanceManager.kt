package com.navifit.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import com.navifit.navigation.RouteStep
import java.util.Locale

/**
 * 오토바이/자동차 모드 음성 안내 (v38 전면 재작성).
 *
 * ── 기존 문제 ──
 *  ① 회전 안내를 300m 지점에서 딱 1번만 함 → 100km/h면 10초 만에 지나침.
 *  ② announceArrival()이 매 위치 업데이트마다 호출돼 "도착했습니다"가 무한 반복됐음.
 *  ③ 회전교차로 몇 번째 출구인지 안내 안 함.
 *  ④ QUEUE_FLUSH라 카메라 경보가 회전 안내를 끊어먹음.
 *
 * ── v38 ──
 *  · 단계별 안내: (고속 시)2km / 1km / 500m / 200m / 직전
 *  · 도착·이탈 안내 1회만
 *  · 회전교차로 출구 번호 + 방면 정보 안내
 *  · QUEUE_ADD로 안내가 서로 끊지 않음
 */
class VoiceGuidanceManager(context: Context) {

    private var tts: TextToSpeech? = null
    private var isReady = false
    // ✅ v41 앱에서 선택한 언어로 안내 (한국어 고정이었음)
    private val lang: String = com.navifit.i18n.LanguageStore.current(context).code
    private val appLocale: Locale = com.navifit.i18n.LanguageStore.locale(context)

    /**
     * ✅ v42 실제 음성이 나갈 언어.
     * 안내 문구를 직접 작성해둔 언어는 ko/en/ja/zh/es 5개.
     * 그 외 언어(베트남어 등)를 고르면 TTS는 그 나라 말로 설정되는데 문구는 영어라
     * 발음이 깨졌음 → 이제 문구가 있는 언어로 TTS도 맞춤 (영어로 통일).
     */
    private val ttsLang: String = if (lang in setOf("ko", "en", "ja", "zh", "es")) lang else "en"
    private val ttsLocale: Locale = when (ttsLang) {
        "ko" -> Locale.KOREAN
        "ja" -> Locale.JAPANESE
        "zh" -> Locale.CHINESE
        "es" -> Locale("es")
        else -> Locale.ENGLISH
    }

    private val announcedStages = mutableMapOf<String, MutableSet<Stage>>()
    private var arrivalAnnounced = false
    private var lastOffRouteAtMs = 0L

    private enum class Stage { FAR_2KM, KM1, M500, M200, IMMINENT }

    init {
        initTts(context, retryOnFail = true)
    }

    private fun initTts(context: Context, retryOnFail: Boolean) {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                // 선택 언어 지원 안 하면 영어 → 그것도 안 되면 한국어로 폴백
                // ✅ v42 문구와 같은 언어로 TTS 설정 (텍스트/발음 불일치 제거)
                val r = tts?.setLanguage(ttsLocale)
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    val e = tts?.setLanguage(Locale.ENGLISH)
                    if (e == TextToSpeech.LANG_MISSING_DATA || e == TextToSpeech.LANG_NOT_SUPPORTED) {
                        tts?.setLanguage(Locale.KOREAN)
                    }
                }
                tts?.setSpeechRate(1.05f)
                // ✅ 내비 안내 전용 오디오 속성: 미디어 볼륨이 0이어도 안내가 나가고,
                //    음악 재생 중이면 시스템이 자동으로 오디오 포커스(덕킹)를 처리
                try {
                    tts?.setAudioAttributes(
                        android.media.AudioAttributes.Builder()
                            .setUsage(android.media.AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                } catch (_: Exception) {}
                isReady = true
                flushPending()   // ✅ 준비 전에 쌓인 안내를 순서대로 재생
            } else if (retryOnFail) {
                // ✅ 기기에 따라 첫 초기화가 간헐적으로 실패 → 1회 재시도 (기존엔 영원히 무음)
                try { tts?.shutdown() } catch (_: Exception) {}
                initTts(context, retryOnFail = false)
            }
        }
    }

    /**
     * 다음 회전까지 거리를 보고 단계별 안내.
     * @param stepKey 스텝 고유키 (인덱스보다 안전 - 재탐색 시 인덱스가 바뀌어도 정확)
     * @param speedKmh 현재 속도 (고속일수록 더 일찍 안내)
     */
    fun announceIfNeeded(
        step: RouteStep,
        stepKey: String,
        remainingDistanceMeters: Int,
        speedKmh: Double = 0.0
    ) {
        if (!isReady || muted) return
        if (remainingDistanceMeters <= 0) return

        val stages = announcedStages.getOrPut(stepKey) { mutableSetOf() }
        val maneuver = maneuverPhrase(step.maneuver, step.instruction)

        val isSilentStraight = step.maneuver == "straight" &&
            !step.instruction.contains("고속도로") && !step.instruction.contains("진입")

        val fast = speedKmh >= 80
        val imm = immediateThreshold(speedKmh)

        val stage: Stage = when {
            remainingDistanceMeters <= imm && Stage.IMMINENT !in stages -> Stage.IMMINENT
            remainingDistanceMeters in (imm + 1)..250 && Stage.M200 !in stages -> Stage.M200
            remainingDistanceMeters in 251..600 && Stage.M500 !in stages -> Stage.M500
            remainingDistanceMeters in 601..1200 && Stage.KM1 !in stages -> Stage.KM1
            fast && remainingDistanceMeters in 1201..2200 && Stage.FAR_2KM !in stages -> Stage.FAR_2KM
            else -> return
        }

        if (isSilentStraight && stage != Stage.IMMINENT) {
            stages.add(stage); return
        }
        stages.add(stage)

        // ✅ v41 선택 언어로 안내
        val text = when (ttsLang) {
            "en" -> when (stage) {
                Stage.IMMINENT -> "Now, $maneuver"
                Stage.M200 -> "In 200 meters, $maneuver"
                Stage.M500 -> "In 500 meters, $maneuver"
                Stage.KM1 -> "In 1 kilometer, $maneuver"
                Stage.FAR_2KM -> "In 2 kilometers, $maneuver"
            }
            "ja" -> when (stage) {
                Stage.IMMINENT -> "まもなく、$maneuver"
                Stage.M200 -> "200メートル先、$maneuver"
                Stage.M500 -> "500メートル先、$maneuver"
                Stage.KM1 -> "1キロメートル先、$maneuver"
                Stage.FAR_2KM -> "2キロメートル先、$maneuver"
            }
            "zh" -> when (stage) {
                Stage.IMMINENT -> "即将$maneuver"
                Stage.M200 -> "前方200米，$maneuver"
                Stage.M500 -> "前方500米，$maneuver"
                Stage.KM1 -> "前方1公里，$maneuver"
                Stage.FAR_2KM -> "前方2公里，$maneuver"
            }
            "es" -> when (stage) {
                Stage.IMMINENT -> "Ahora, $maneuver"
                Stage.M200 -> "En 200 metros, $maneuver"
                Stage.M500 -> "En 500 metros, $maneuver"
                Stage.KM1 -> "En 1 kilómetro, $maneuver"
                Stage.FAR_2KM -> "En 2 kilómetros, $maneuver"
            }
            else -> when (stage) {
                Stage.IMMINENT -> "잠시 후 $maneuver"
                Stage.M200 -> "200미터 앞 $maneuver"
                Stage.M500 -> "500미터 앞 $maneuver"
                Stage.KM1 -> "1킬로미터 앞 $maneuver"
                Stage.FAR_2KM -> "2킬로미터 앞 $maneuver"
            }
        }
        speak(text)
    }

    /** 속도 기준 "직전 안내" 거리 (3초 전, 50~150m) */
    private fun immediateThreshold(speedKmh: Double): Int =
        (speedKmh / 3.6 * 3).toInt().coerceIn(50, 150)

    fun announceRouteStart(totalDistanceMeters: Int, totalDurationSeconds: Int) {
        announcedStages.clear()
        arrivalAnnounced = false
        val distanceKm = totalDistanceMeters / 1000.0
        val minutes = totalDurationSeconds / 60
        speak(when (ttsLang) {
            "en" -> "Starting navigation. Total distance %.1f kilometers, estimated time %d minutes.".format(distanceKm, minutes)
            "ja" -> "案内を開始します。総距離%.1fキロメートル、所要時間約%d分です。".format(distanceKm, minutes)
            "zh" -> "开始导航。全程%.1f公里，预计%d分钟。".format(distanceKm, minutes)
            "es" -> "Iniciando navegación. Distancia total %.1f kilómetros, tiempo estimado %d minutos.".format(distanceKm, minutes)
            else -> "경로 안내를 시작합니다. 총 거리 %.1f킬로미터, 예상 소요시간 %d분입니다.".format(distanceKm, minutes)
        })
    }

    /** ✅ 도착 안내는 1회만 */
    fun announceArrival() {
        if (arrivalAnnounced) return
        arrivalAnnounced = true
        speak(when (ttsLang) {
            "en" -> "You have arrived at your destination. Navigation ended."
            "ja" -> "目的地に到着しました。案内を終了します。"
            "zh" -> "已到达目的地，导航结束。"
            "es" -> "Ha llegado a su destino. Navegación finalizada."
            else -> "목적지 부근에 도착했습니다. 안내를 종료합니다."
        })
    }

    /** 이탈 안내: 15초 내 중복 방지 */
    fun announceOffRoute() {
        val now = System.currentTimeMillis()
        if (now - lastOffRouteAtMs < 15_000L) return
        lastOffRouteAtMs = now
        announcedStages.clear()
        speak(when (ttsLang) {
            "en" -> "Off route. Recalculating."
            "ja" -> "ルートを外れました。再検索します。"
            "zh" -> "已偏离路线，正在重新规划。"
            "es" -> "Fuera de ruta. Recalculando."
            else -> "경로를 이탈했습니다. 새 경로를 안내합니다."
        })
    }

    /** 새 경로로 교체 시 안내 상태 초기화 */
    fun resetForNewRoute() {
        announcedStages.clear()
        arrivalAnnounced = false
    }

    /**
     * ✅ v42 회전 안내 문구 생성 (언어별).
     *
     * 기존 버그:
     *  ① 회전교차로 분기가 언어 체크보다 먼저 return 되어 영어 설정에서도 한국어가 나왔음
     *  ② 한국어 "서울 방면" 접두사를 영어 안내에도 붙여서 "서울 방면 turn right"처럼 섞였음
     *  ③ 미지원 언어는 TTS는 그 나라 말로 설정됐는데 텍스트는 영어라 발음이 깨졌음
     *     → 이제 TTS가 실제로 지원하는 언어(ttsLang)에 맞춰 문구를 고름
     */
    private fun maneuverPhrase(maneuver: String?, instruction: String): String {
        val m = maneuver ?: "straight"
        val isLeft = m.contains("left")
        val isRight = m.contains("right")

        // 출구 번호 (회전교차로)
        val exit = Regex("(\\d+)\\s*(?:번째|번)\\s*출구").find(instruction)?.groupValues?.get(1)
            ?: Regex("exit\\s*(\\d+)", RegexOption.IGNORE_CASE).find(instruction)?.groupValues?.get(1)

        // 방면 정보는 한국어 안내일 때만 사용 (다른 언어에 한글을 섞지 않음)
        val viaSuffix = if (ttsLang == "ko") {
            Regex("([가-힣]+)\\s*방면").find(instruction)?.groupValues?.get(1)?.let { "$it 방면 " } ?: ""
        } else ""

        val phrase = when (ttsLang) {
            "en" -> when {
                m == "arrive" -> "you will arrive at your destination"
                m == "depart" -> "start driving"
                m.contains("roundabout") ->
                    if (exit != null) "at the roundabout, take exit number $exit" else "enter the roundabout"
                m.contains("uturn") -> "make a U-turn"
                m == "merge" -> "merge onto the main road"
                m.contains("ramp") || m.contains("fork") ->
                    if (isLeft) "take the left exit" else "take the right exit"
                isLeft -> if (m.contains("sharp")) "turn sharply left"
                          else if (m.contains("slight") || m.contains("keep")) "keep left" else "turn left"
                isRight -> if (m.contains("sharp")) "turn sharply right"
                           else if (m.contains("slight") || m.contains("keep")) "keep right" else "turn right"
                else -> "go straight"
            }
            "ja" -> when {
                m == "arrive" -> "目的地に到着します"
                m == "depart" -> "出発します"
                m.contains("roundabout") ->
                    if (exit != null) "ラウンドアバウトで${exit}番目の出口です" else "ラウンドアバウトです"
                m.contains("uturn") -> "Uターンします"
                m == "merge" -> "本線に合流します"
                m.contains("ramp") || m.contains("fork") -> if (isLeft) "左の出口です" else "右の出口です"
                isLeft -> "左折です"
                isRight -> "右折です"
                else -> "直進です"
            }
            "zh" -> when {
                m == "arrive" -> "即将到达目的地"
                m == "depart" -> "开始出发"
                m.contains("roundabout") ->
                    if (exit != null) "在环岛走第${exit}个出口" else "进入环岛"
                m.contains("uturn") -> "掉头"
                m == "merge" -> "汇入主路"
                m.contains("ramp") || m.contains("fork") -> if (isLeft) "从左侧出口驶出" else "从右侧出口驶出"
                isLeft -> "左转"
                isRight -> "右转"
                else -> "直行"
            }
            "es" -> when {
                m == "arrive" -> "llegará a su destino"
                m == "depart" -> "comience a conducir"
                m.contains("roundabout") ->
                    if (exit != null) "en la rotonda, tome la salida número $exit" else "entre en la rotonda"
                m.contains("uturn") -> "haga un cambio de sentido"
                m == "merge" -> "incorpórese a la vía principal"
                m.contains("ramp") || m.contains("fork") ->
                    if (isLeft) "tome la salida izquierda" else "tome la salida derecha"
                isLeft -> "gire a la izquierda"
                isRight -> "gire a la derecha"
                else -> "siga recto"
            }
            else -> when {   // 한국어
                m == "arrive" -> "목적지에 도착합니다"
                m == "depart" -> "출발합니다"
                m.contains("roundabout") ->
                    if (exit != null) "회전교차로에서 ${exit}번째 출구로 나가세요" else "회전교차로입니다"
                m.contains("uturn") -> "유턴입니다"
                m == "merge" -> "합류 구간입니다. 본선에 합류하세요"
                m.contains("ramp") || m.contains("fork") ->
                    if (isLeft) "좌측 진출로로 나가세요" else "우측 진출로로 나가세요"
                isLeft -> if (m.contains("sharp")) "좌측으로 크게 도세요"
                          else if (m.contains("slight") || m.contains("keep")) "좌측 방향입니다" else "좌회전입니다"
                isRight -> if (m.contains("sharp")) "우측으로 크게 도세요"
                           else if (m.contains("slight") || m.contains("keep")) "우측 방향입니다" else "우회전입니다"
                else -> if (instruction.contains("고속도로")) "고속도로에 진입합니다" else "직진입니다"
            }
        }
        return viaSuffix + phrase
    }

    /** 내정보 설정에서 끈 경우 모든 음성 무시 */
    var muted: Boolean = false

    fun speakFreeform(text: String) = speak(text)

    // ✅ TTS 소리 안 나오던 버그 수정 3종:
    //  ① TTS 엔진 초기화(비동기)가 끝나기 전에 온 안내는 조용히 버려졌음 → 준비될 때까지 대기열에 보관
    //  ② 오디오 스트림 미지정으로 '미디어 볼륨'을 따라갔음 (미디어 볼륨 0이면 내비도 무음)
    //     → 내비 안내 전용 오디오 속성(ASSISTANCE_NAVIGATION_GUIDANCE)으로 재생
    //  ③ 초기화 실패 시 재시도 없이 영원히 무음이었음 → 1회 재초기화
    private val pendingUtterances = ArrayDeque<String>()

    /** QUEUE_ADD: 카메라 경보가 회전 안내를 끊지 않도록 */
    private fun speak(text: String) {
        if (muted) return
        if (!isReady) {
            if (pendingUtterances.size < 5) pendingUtterances.addLast(text)
            return
        }
        val mode = if (tts?.isSpeaking == true) TextToSpeech.QUEUE_ADD else TextToSpeech.QUEUE_FLUSH
        tts?.speak(text, mode, speechParams(), "navifit_${System.currentTimeMillis()}")
    }

    private fun speechParams(): android.os.Bundle = android.os.Bundle().apply {
        putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, android.media.AudioManager.STREAM_MUSIC)
    }

    private fun flushPending() {
        while (pendingUtterances.isNotEmpty()) {
            val t = pendingUtterances.removeFirst()
            tts?.speak(t, TextToSpeech.QUEUE_ADD, speechParams(), "navifit_${System.currentTimeMillis()}")
        }
    }

    fun release() {
        tts?.stop()
        tts?.shutdown()
    }
}
