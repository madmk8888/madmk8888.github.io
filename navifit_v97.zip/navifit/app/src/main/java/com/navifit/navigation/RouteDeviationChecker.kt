package com.navifit.navigation

import kotlin.math.*

/**
 * 현재 위치가 경로(폴리라인)에서 얼마나 벗어났는지 계산하고,
 * 임계값 이상 벗어나면 재탐색이 필요하다고 판단하는 로직.
 */
object RouteDeviationChecker {

    // 이동수단별 이탈 허용 거리 (미터) - 너무 좁으면 API 호출이 잦아져서 비용/배터리 낭비됨
    private val DEVIATION_THRESHOLDS = mapOf(
        TravelMode.WALK to 30.0,
        TravelMode.BIKE to 40.0,
        TravelMode.MOTORCYCLE to 50.0,
        TravelMode.CAR to 50.0
    )

    /**
     * 현재 위치와 경로 스텝들의 선분들 중 가장 가까운 거리를 계산해서
     * 임계값을 넘으면 true (재탐색 필요) 반환
     */
    fun isOffRoute(
        current: LatLngPoint,
        routeSteps: List<RouteStep>,
        mode: TravelMode
    ): Boolean {
        if (routeSteps.isEmpty()) return false

        val threshold = DEVIATION_THRESHOLDS[mode] ?: 40.0

        val minDistance = routeSteps.minOf { step ->
            distanceToSegmentMeters(
                point = current,
                segmentStart = step.startLocation,
                segmentEnd = step.endLocation
            )
        }

        return minDistance > threshold
    }

    /** 점과 선분 사이의 최단 거리 (하버사인 근사 + 평면 투영으로 충분히 정확함, 단거리이므로) */
    private fun distanceToSegmentMeters(
        point: LatLngPoint,
        segmentStart: LatLngPoint,
        segmentEnd: LatLngPoint
    ): Double {
        val x = point.longitude
        val y = point.latitude
        val x1 = segmentStart.longitude
        val y1 = segmentStart.latitude
        val x2 = segmentEnd.longitude
        val y2 = segmentEnd.latitude

        val dx = x2 - x1
        val dy = y2 - y1

        val t = if (dx == 0.0 && dy == 0.0) {
            0.0
        } else {
            (((x - x1) * dx + (y - y1) * dy) / (dx * dx + dy * dy)).coerceIn(0.0, 1.0)
        }

        val closestLng = x1 + t * dx
        val closestLat = y1 + t * dy

        return haversineMeters(y, x, closestLat, closestLng)
    }

    private fun haversineMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371000.0 // 지구 반지름(m)
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }
}
