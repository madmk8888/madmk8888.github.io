package com.navifit.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.withStyle
import kotlinx.coroutines.launch
import kotlinx.coroutines.async
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.pullrefresh.PullRefreshIndicator
import androidx.compose.material.pullrefresh.pullRefresh
import androidx.compose.material.pullrefresh.rememberPullRefreshState
import androidx.compose.material.ExperimentalMaterialApi
import androidx.compose.runtime.snapshotFlow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.navifit.i18n.tr
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.animateFloat
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import java.io.File
import java.io.FileOutputStream

/**
 * 커뮤니티 피드 (기기 로컬 저장 - 서버 없이 동작).
 * 사진/동영상은 앱 내부 저장소(filesDir/community_media)에 복사해서 보관.
 * ⚠️ 다른 사람과 실제로 공유되는 커뮤니티는 서버+계정+모더레이션이 필요함 (지금은 로컬 검증용).
 */
data class Post(
    val id: Long,
    val author: String,
    val authorUid: String = "", // RM 발신 대상 지정용 (빈 값이면 RM 대상 아님 - 예: 데모 게시물)
    val title: String = "",
    var text: String,
    var likes: Int = 0,
    var dislikes: Int = 0,
    var liked: Boolean = false,
    var disliked: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val comments: MutableList<Pair<String, String>> = mutableListOf(), // (구버전 호환용 - 신규는 commentList 사용)
    val commentList: MutableList<CommentData> = mutableListOf(),        // ✅ v37 대댓글·멘션 지원 댓글
    val isMine: Boolean = false,
    val mediaPath: String? = null,          // 구버전 호환 (첫 장)
    val mediaPaths: List<String> = emptyList(), // ✅ v37 사진 여러 장 (최대 10장)
    val mediaType: String? = null, // "image" | "video"
    val theme: String? = null, // 도보/자전거/오토바이/자동차 태그
    val lat: Double? = null, // ✅ 작성 당시 위치 (거리순 정렬용 - 정확한 좌표는 공개하지 않고 반올림 거리만 표시)
    val lng: Double? = null,
    var commentsLocked: Boolean = false, // ✅ v35 작성자가 이 글의 댓글을 막음
    val lang: String? = null             // ✅ v41 작성 언어 (원문은 이 언어로 보임, 번역 보기로 전환)
)

/**
 * ✅ v37 댓글 (대댓글·멘션 지원).
 * parentId가 null이면 최상위 댓글, 값이 있으면 그 댓글에 달린 답글.
 */
data class CommentData(
    val id: Long = System.currentTimeMillis(),
    val author: String,
    val authorUid: String = "",
    val text: String,
    val parentId: Long? = null,      // 답글이면 부모 댓글 id
    val at: Long = System.currentTimeMillis(),
    val lang: String? = null         // ✅ v41 작성 언어
)

/** 본문·댓글에서 @닉네임 멘션 추출 */
/**
 * ✅ 빛나는 3D 티어 별 (운동장 랭킹 배지).
 * Canvas로 5각 별을 그리고: 바깥 글로우(방사형 그라데이션) + 본체(위→아래 밝기 그라데이션) +
 * 좌상단 하이라이트로 입체감. 티어 색(빨~보) × 개수(1~5)로 표시.
 */
@Composable
fun GlowingStars(color: Color, count: Int, size: androidx.compose.ui.unit.Dp = 14.dp, modifier: Modifier = Modifier) {
    if (count <= 0) return
    // ✅ v58 반짝임 특수효과: 별마다 위상이 다른 무한 트윙클(글로우 강약) + 은은한 크기 맥동 + 스파클(✦) 회전
    val twinkle = androidx.compose.animation.core.rememberInfiniteTransition(label = "starTwinkle")
    val phase by twinkle.animateFloat(
        initialValue = 0f, targetValue = 2f * Math.PI.toFloat(),
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            androidx.compose.animation.core.tween(2600, easing = androidx.compose.animation.core.LinearEasing)
        ), label = "phase"
    )
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        repeat(count.coerceAtMost(5)) { starIdx ->
            // 별마다 다른 위상 → 파도치듯 순서대로 반짝임
            val local = kotlin.math.sin(phase + starIdx * 1.1f) * 0.5f + 0.5f   // 0~1
            val glowBoost = 0.45f + local * 0.45f                                // 글로우 알파 0.45~0.9
            val pulse = 1f + local * 0.12f                                       // 크기 1.0~1.12
            androidx.compose.foundation.Canvas(
                Modifier.size(size).graphicsLayer(scaleX = pulse, scaleY = pulse)
            ) {
                val r = this.size.minDimension / 2f
                val cx = this.size.width / 2f; val cy = this.size.height / 2f
                // 별 꼭짓점 path
                val path = androidx.compose.ui.graphics.Path()
                val outer = r * 0.92f; val inner = r * 0.42f
                for (i in 0 until 10) {
                    val ang = Math.PI / 2 + i * Math.PI / 5
                    val rad = if (i % 2 == 0) outer else inner
                    val x = cx + (rad * kotlin.math.cos(ang)).toFloat()
                    val y = cy - (rad * kotlin.math.sin(ang)).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                // 1) 글로우 (별 뒤 은은한 빛무리)
                drawCircle(
                    brush = androidx.compose.ui.graphics.Brush.radialGradient(
                        listOf(color.copy(alpha = glowBoost), color.copy(alpha = 0f)),   // ✅ 숨쉬는 글로우
                        center = androidx.compose.ui.geometry.Offset(cx, cy), radius = r * (1.05f + local * 0.35f)
                    ),
                    radius = r * 1.15f, center = androidx.compose.ui.geometry.Offset(cx, cy)
                )
                // 2) 본체 (위쪽이 밝은 수직 그라데이션 → 3D 볼륨감)
                drawPath(path, brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                    listOf(
                        androidx.compose.ui.graphics.lerp(color, Color.White, 0.45f),
                        color,
                        androidx.compose.ui.graphics.lerp(color, Color.Black, 0.25f)
                    )
                ))
                // 3) 좌상단 하이라이트 점
                drawCircle(Color.White.copy(alpha = 0.75f), radius = r * 0.14f,
                    center = androidx.compose.ui.geometry.Offset(cx - r * 0.25f, cy - r * 0.35f))
            }
            Spacer(Modifier.width(1.dp))
        }
    }
}

/** ✅ v58 나라 필터 표시용 국기 */
fun countryFilterFlag(code: String?): String = when (code) {
    null -> "🌍"; "ko" -> "🇰🇷"; "en" -> "🇺🇸"; "ja" -> "🇯🇵"
    "zh" -> "🇨🇳"; "es" -> "🇪🇸"; "fr" -> "🇫🇷"; else -> "🌍"
}

fun extractMentions(text: String): List<String> =
    Regex("@([\\w가-힣]{2,20})").findAll(text).map { it.groupValues[1] }.distinct().toList()

/** 본문에서 #해시태그 추출 */
fun extractHashtags(text: String): List<String> =
    Regex("#([\\w가-힣]{1,20})").findAll(text).map { it.groupValues[1] }.distinct().toList()

// ✅ v41: 한국어 욕설 6개만 걸리던 약한 필터를 다국어 필터로 전면 교체
//    (욕설·19금·스팸·사기/도박·개인정보를 한/영/일/중/스/러 등에서 차단 + 우회 시도 정규화)
fun isCleanText(text: String) = com.navifit.moderation.ContentFilter.isClean(text)
fun violationOf(text: String) = com.navifit.moderation.ContentFilter.check(text)

/** 정확한 거리를 노출하지 않기 위해 실제 km 값만 내부 계산용으로 리턴 (표시는 roundedDistanceLabel 사용) */
private fun distanceKmOrNull(p: Post, myLoc: com.navifit.navigation.LatLngPoint): Double? {
    val lat = p.lat ?: return null
    val lng = p.lng ?: return null
    return com.navifit.navigation.NavigationProgressCalculator.fastDistanceMeters(
        myLoc, com.navifit.navigation.LatLngPoint(lat, lng)
    ) / 1000.0
}

/** ✅ 1km/500m처럼 정확히 보여주지 않고, 5km 단위로 대략적으로만 표시 (프라이버시 보호) */
private fun roundedDistanceLabel(p: Post, myLoc: com.navifit.navigation.LatLngPoint?): String? {
    if (myLoc == null) return null
    val km = distanceKmOrNull(p, myLoc) ?: return null
    val bucket = (Math.ceil(km / 5.0) * 5).toInt().coerceAtLeast(5)
    return "약 ${bucket}km 이내"
}

private enum class SortMode(val label: String) {
    LATEST("🕐 최신순"), FOLLOWING("👤 런친"), HOT("🔥 인기글"), POPULAR("❤️ 누적인기"), THEME("🏷️ 테마별"), NEARBY("📍 거리순")
}

/**
 * ✅ 인기글 점수: "시간대별로 반응 터진 글"을 골라내는 점수.
 * 좋아요x2 + 댓글x3 을 (경과시간+2h)^1.4 로 나눔 - 방금 올라와서 반응 터진 글이
 * 오래된 누적 인기글보다 위로 올라옴 (해커뉴스 방식).
 */
private fun hotScore(p: Post): Double {
    val hours = (System.currentTimeMillis() - p.createdAt) / 3_600_000.0
    val engagement = p.likes * 2.0 + p.comments.size * 3.0
    return engagement / Math.pow(hours + 2.0, 1.4)
}

@OptIn(ExperimentalMaterialApi::class)  // pullRefresh (당겨서 새로고침)
@Composable
fun CommunityScreen(
    myNickname: String,
    isAnonymous: Boolean = false,
    myUid: String = "",
    myLocation: com.navifit.navigation.LatLngPoint? = null, // ✅ 거리순 정렬/표시용 (정확한 좌표는 노출하지 않고 반올림 거리만 보여줌)
    onOpenDm: (otherUid: String, otherNickname: String) -> Unit = { _, _ -> },
    onOpenInbox: () -> Unit = {},
    onOpenFriends: () -> Unit = {}, // ✅ 작성 버튼 자리로 이동한 친구 목록 열기
    onFollowSharedRoute: (com.navifit.navigation.RouteShare.SharedRoute) -> Unit = {}, // ✅ v33 "이 경로대로 안내"
    notifUnreadCount: Int = 0,                    // ✅ v36 알림 뱃지
    dmUnreadCount: Int = 0,                       // ✅ v62 RM 안 읽음 개수
    onOpenProfile: (String, String) -> Unit = { _, _ -> },   // ✅ v64 인스타식 프로필 열기 (nickname, uid)
    onRequestRm: (String, String) -> Unit = { _, _ -> },      // ✅ v86 RM 요청 (nickname, uid)
    onRequestRunFriend: (String, String) -> Unit = { _, _ -> }, // ✅ v86 런친 요청 (nickname, uid)
    onOpenNotifications: () -> Unit = {},
    friendNicknames: Set<String> = emptySet(),    // ✅ @멘션은 친구 목록에 있는 닉네임만 허용
    focusPostId: String? = null,                 // ✅ v81 알림 딥링크로 열 글 id
    onFocusConsumed: () -> Unit = {}
) {
    val context = LocalContext.current
    // 앱을 껐다 켜도, 탭을 옮겨도 글이 유지되도록 디스크에서 로드
    LaunchedEffect(Unit) { CommunityStore.load(context) }
    var posts by remember { mutableStateOf(CommunityStore.posts) }
    fun syncPosts(newList: List<Post>) { CommunityStore.save(context, newList); posts = newList }

    var showDialog by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") }
    var countryFilter by remember { mutableStateOf<String?>(null) }   // ✅ v58 나라별 운동장 (null=전체, 글 작성 언어 기준)
    var globalTranslating by remember { mutableStateOf(false) }   // ✅ v60 번역 중 로딩 오버레이
    var pendingMediaPath by remember { mutableStateOf<String?>(null) }
    var pendingMediaPaths by remember { mutableStateOf<List<String>>(emptyList()) }  // ✅ v37 여러 장
    var pendingMediaType by remember { mutableStateOf<String?>(null) }
    /** ✅ v42 검사 통과 후 실제 게시 (게시 후 회수하지 않고, 통과했을 때만 올림) */
    fun postApproved(newPostId: Long, langCode: String, title: String, body: String) {
        syncPosts(listOf(Post(
            id = newPostId, author = myNickname, authorUid = myUid,
            title = "", text = body, isMine = true,   // ✅ v92 제목 개념 제거 - 내용만
            mediaPath = pendingMediaPath,
            mediaPaths = pendingMediaPaths,
            mediaType = pendingMediaType,
            lat = myLocation?.latitude, lng = myLocation?.longitude,
            lang = langCode
        )) + posts)
        draft = ""
        pendingMediaPath = null; pendingMediaPaths = emptyList(); pendingMediaType = null
    }
    var snack by remember { mutableStateOf<String?>(null) }
    var sortMode by remember { mutableStateOf(SortMode.LATEST) }

    /**
     * ✅ v45 이미지 압축 저장 (성능·용량).
     * 기존엔 원본 그대로 복사해서 12MP 사진이면 4MB+가 그대로 저장되고,
     * 피드에서 여러 장을 띄우면 메모리를 크게 먹어 스크롤이 버벅였음.
     * → 긴 변 1600px로 축소 + JPEG 85% 압축 (화질은 유지, 용량은 1/10 수준)
     */
    fun copyToInternal(uri: Uri, ext: String): String? {
        return try {
            val dir = File(context.filesDir, "community_media").apply { mkdirs() }
            val outFile = File(dir, "media_${System.currentTimeMillis()}.$ext")

            if (ext == "jpg" || ext == "png") {
                // 1) 원본 크기만 먼저 읽기 (메모리에 안 올림)
                val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                context.contentResolver.openInputStream(uri)?.use {
                    android.graphics.BitmapFactory.decodeStream(it, null, bounds)
                }
                val maxSide = 1600
                var sample = 1
                var w = bounds.outWidth; var h = bounds.outHeight
                while (w / sample > maxSide || h / sample > maxSide) sample *= 2

                // 2) 축소해서 디코드
                val opts = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = context.contentResolver.openInputStream(uri)?.use {
                    android.graphics.BitmapFactory.decodeStream(it, null, opts)
                } ?: return null

                // 3) JPEG 85%로 저장
                FileOutputStream(outFile).use { out ->
                    bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, out)
                }
                bmp.recycle()
            } else {
                // 동영상 등은 원본 복사
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(outFile).use { output -> input.copyTo(output) }
                }
            }
            outFile.absolutePath
        } catch (e: Exception) { null }
    }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            pendingMediaPath = copyToInternal(it, "jpg")
            pendingMediaType = "image"
        }
    }

    /** ✅ 작성 중이던 내용 전체 리셋 (취소하면 이전 초안이 남지 않도록) */
    fun resetDraft() {
        draft = ""
        pendingMediaPath = null; pendingMediaPaths = emptyList(); pendingMediaType = null
    }

    // ✅ v61 사진 최대 10장 (기존 + 새로 고른 것 합쳐 10장까지, 순서 유지)
    val pickImages = rememberLauncherForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        val newPhotos = uris.mapNotNull { copyToInternal(it, "jpg") }
        if (newPhotos.isNotEmpty()) {
            val existingPhotos = pendingMediaPaths.filter { !it.endsWith(".mp4") }
            val videos = pendingMediaPaths.filter { it.endsWith(".mp4") }
            val merged = (existingPhotos + newPhotos).take(10) + videos   // 사진 10장 + 동영상 유지
            pendingMediaPaths = merged
            pendingMediaPath = merged.firstOrNull()
            pendingMediaType = "image"
        }
    }

    // ✅ v61 동영상은 1개만 (여러 개 고르면 첫 번째만)
    val pickVideo = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        val path = uri?.let { copyToInternal(it, "mp4") }
        if (path != null) {
            val photos = pendingMediaPaths.filter { !it.endsWith(".mp4") }
            pendingMediaPaths = photos + path   // 기존 동영상 대체, 사진 뒤에 붙임
            if (pendingMediaPath == null) pendingMediaPath = pendingMediaPaths.first()
            pendingMediaType = "video"
        }
    }

    val scope = rememberCoroutineScope()
    // ✅ GPS 기준 내 국가 국기 (랭킹 소속 자동 배정)
    var myCountryFlag by remember { mutableStateOf("🇰🇷") }
    LaunchedEffect(myLocation) {
        myCountryFlag = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            com.navifit.social.CountryLocator.flagFor(context, myLocation?.latitude, myLocation?.longitude)
        }
    }
    var commentTarget by remember { mutableStateOf<Post?>(null) }   // ✅ v35 댓글창 대상 글
    var reportTarget by remember { mutableStateOf<Post?>(null) }    // ✅ v36 신고 대상 글
    var editTarget by remember { mutableStateOf<Post?>(null) }      // ✅ v36 수정 대상 글
    var showBookmarksOnly by remember { mutableStateOf(false) }     // ✅ v36 저장한 글만 보기
    var autoHidden by remember { mutableStateOf<Set<Long>>(emptySet()) }
    // ✅ 내가 숨긴 작성자 목록 (그 사람 글은 블러 카드로 표시)
    var mutedAuthors by remember { mutableStateOf(MutedAuthors.all(context)) }
    var followingUids by remember { mutableStateOf<Set<String>>(emptySet()) }   // ✅ v37 팔로우
    var adminTick by remember { mutableStateOf(0) } // ✅ 글 가리기 등 관리자 조치 후 목록 갱신 트리거

    // ✅ v45 성능: 기본은 최근 7일치만 렌더 (글이 쌓여도 목록이 가벼움).
    //    "더 보기"를 누르면 7일씩 더 불러오고, 검색할 때는 기간 제한 없이 전체에서 찾음.
    var weeksLoaded by remember { mutableStateOf(1) }

    LaunchedEffect(Unit) { autoHidden = com.navifit.social.ReportSystem.autoHiddenPostIds() }
    LaunchedEffect(myUid) { if (myUid.isNotBlank()) followingUids = com.navifit.social.FollowSystem.followingUids(myUid) }

    val hiddenIds = com.navifit.social.PlaygroundAdmin.hiddenPosts(context)
    val sortedPosts = remember(posts, sortMode, myLocation, adminTick, hiddenIds, followingUids, friendNicknames) {
        // ✅ 관리자가 가린 글은 목록에서 제외
        val visible = posts.filter { it.id !in hiddenIds || com.navifit.social.PlaygroundAdmin.isAdmin(context, myUid) }
        val base = when (sortMode) {
            SortMode.FOLLOWING -> visible.filter { it.authorUid in followingUids || it.isMine }.sortedByDescending { it.createdAt }
            SortMode.HOT -> visible.filter { it.likes + it.comments.size > 0 }.sortedByDescending { hotScore(it) }
            SortMode.POPULAR -> visible.sortedByDescending { it.likes + it.comments.size }
            SortMode.THEME -> visible.sortedBy { it.theme ?: "zzz" }
            SortMode.NEARBY -> if (myLocation == null) visible.sortedByDescending { it.createdAt }
                else visible.sortedBy { distanceKmOrNull(it, myLocation) ?: Double.MAX_VALUE }
            // ✅ v64 인스타식: 최신 정렬에서 "친구/런친가 최근 올린 글"을 맨 위로 끌어올림.
            //   24시간 이내 친구 글은 최상단, 그 외는 최신순. (봤으면 내려가는 건 UI 스크롤로 자연 처리)
            SortMode.LATEST -> {
                val now = System.currentTimeMillis()
                val dayMs = 24L * 3600 * 1000
                visible.sortedWith(compareByDescending<Post> { p ->
                    val isFriendish = p.authorUid in followingUids || p.author in friendNicknames
                    if (isFriendish && (now - p.createdAt) < dayMs) 1 else 0   // 친구 최근글 우선
                }.thenByDescending { it.createdAt })
            }
        }
        base
    }
    // ✅ 제목·내용·작성자 3개 필드로 검색
    val visiblePosts = remember(sortedPosts, searchQuery, autoHidden, showBookmarksOnly, weeksLoaded, countryFilter, adminTick) {
        var base = sortedPosts
        // ✅ v85 신고 100건 이상 누적 → 글쓴이 본인에게만 보임 (운영진 검토 대기)
        base = base.filter { it.id !in autoHidden || it.isMine }
        // ✅ v86 "이 사람 글 안 보기"로 숨긴 작성자 제외
        val blockedAuthors = com.navifit.social.BlockStore.all(context)
        if (blockedAuthors.isNotEmpty()) base = base.filter { it.author !in blockedAuthors || it.isMine }
        // ✅ v88 "이 글 가리기"로 숨긴 개별 글 제외
        val hiddenLocal = com.navifit.social.HiddenStore.all(context)
        if (hiddenLocal.isNotEmpty()) base = base.filter { it.id.toString() !in hiddenLocal || it.isMine }
        // ✅ v58 나라별 운동장: 글 작성 언어로 필터 (전체/한국/영어권/일본/중국/...)
        countryFilter?.let { cf -> base = base.filter { (it.lang ?: "ko") == cf } }
        // ✅ v36 저장한 글만 보기
        if (showBookmarksOnly) {
            val marks = com.navifit.social.BookmarkStore.all(context)
            base = base.filter { it.id in marks }
        }
        if (searchQuery.isNotBlank()) {
            // ✅ v45 검색은 기간 제한 없이 전체에서 (오래된 글도 검색으로 찾을 수 있음)
            base.filter {
                it.text.contains(searchQuery, true) ||
                it.author.contains(searchQuery, true)
            }
        } else {
            // ✅ v45 기본은 최근 7일치만 (글이 수천 개여도 목록이 가벼움)
            //    "더 보기"를 누를 때마다 7일씩 확장
            val cutoff = System.currentTimeMillis() - weeksLoaded * 7L * 24 * 3600 * 1000
            val recent = base.filter { it.createdAt >= cutoff }
            // 최근 7일에 글이 하나도 없으면(신규 앱·비활성 커뮤니티) 최신 20개는 보여줌
            if (recent.isEmpty() && weeksLoaded == 1) base.take(20) else recent
        }
    }
    // 더 불러올 오래된 글이 있는지
    val hasOlderPosts = remember(sortedPosts, visiblePosts, searchQuery) {
        searchQuery.isBlank() && sortedPosts.size > visiblePosts.size
    }

    // ✅ v48 점진 로딩(무한스크롤): 7일치라도 글이 많으면 한 번에 다 그리지 않고
    //    30개씩 끊어서 렌더하고, 스크롤이 끝에 닿으면 자동으로 30개 더 붙임.
    //    (서버·기기 양쪽 부담을 줄이고 첫 렌더가 즉시 뜸)
    val listState = rememberLazyListState()
    var renderLimit by remember(visiblePosts.size, searchQuery, sortMode) { mutableStateOf(30) }
    val renderedPosts = remember(visiblePosts, renderLimit) { visiblePosts.take(renderLimit) }
    // ✅ v81 알림 딥링크: 지정된 글이 있으면 렌더 범위를 늘리고 그 글로 스크롤 + 잠시 하이라이트
    var highlightedPostId by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(focusPostId, visiblePosts.size) {
        val target = focusPostId ?: return@LaunchedEffect
        val idx = visiblePosts.indexOfFirst { it.id.toString() == target }
        if (idx >= 0) {
            if (idx >= renderLimit) renderLimit = (idx + 5).coerceAtMost(visiblePosts.size)
            kotlinx.coroutines.delay(120)
            runCatching { listState.animateScrollToItem(idx) }
            highlightedPostId = target
            kotlinx.coroutines.delay(2200)
            highlightedPostId = null
        }
        onFocusConsumed()
    }
    LaunchedEffect(listState, visiblePosts.size) {
        snapshotFlow { listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0 }
            .collect { lastVisible ->
                // 끝에서 5개 남았을 때 미리 더 로드
                if (lastVisible >= renderedPosts.size - 5 && renderLimit < visiblePosts.size) {
                    renderLimit = (renderLimit + 30).coerceAtMost(visiblePosts.size)
                }
            }
    }

    // ✅ v45 성능: 작성자별 좋아요 합계를 한 번만 계산.
    //    기존엔 글 카드마다 posts.filter{}로 전체를 훑어서 O(n²)였음
    //    (글 500개면 스크롤 프레임마다 25만 번 연산 → 심한 렉의 주범)
    val authorLikesMap = remember(posts) {
        posts.groupBy { it.author }.mapValues { (_, list) -> list.sumOf { it.likes } }
    }

    var showPlaygroundRanking by remember { mutableStateOf(false) }
    val isAdmin = com.navifit.social.PlaygroundAdmin.isAdmin(context, myUid)
    LaunchedEffect(myUid) { com.navifit.social.PlaygroundAdmin.claimMasterIfEmpty(context, myUid) }
    // 내가 받은 좋아요 총합 (별 배지·운동장 랭킹용)
    val myTotalLikes = remember(posts) { posts.filter { it.isMine }.sumOf { it.likes } }

    Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        // ✅ v57 인스타식 상단 바: 왼쪽 로고형 타이틀 + 오른쪽 아이콘 줄 (버튼 배경 없음)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(com.navifit.i18n.LocalStrings.current.community,
                fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onBackground)
            // ✅ v61 모든 버튼에 라벨 표시: RANK · FR(친구) · RM · 히스토리 · 알림
            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                // ✅ v78 내 운동장 (내 프로필/꾸미기로 이동)
                Column(horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable { onOpenProfile(myNickname, myUid) }) {
                    Text("🏟️", fontSize = 19.sp)
                    Text(tr("내운동장"), fontSize = 7.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF7CC7FF))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable { showPlaygroundRanking = true }) {
                    Text("⭐", fontSize = 19.sp)
                    Text("RANK", fontSize = 7.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFFFD22E))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable(onClick = onOpenFriends)) {
                    Text("👤", fontSize = 19.sp)
                    Text(tr("FR친구"), fontSize = 7.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF34D399))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable(onClick = onOpenInbox)) {
                    Box {
                        Text("✉️", fontSize = 19.sp)
                        if (dmUnreadCount > 0) {
                            Text("$dmUnreadCount", fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.Bold,
                                modifier = Modifier.align(Alignment.TopEnd).offset(x = 8.dp, y = (-5).dp)
                                    .background(Color(0xFFFF3040), CircleShape)
                                    .padding(horizontal = 4.dp, vertical = 1.dp))
                        }
                    }
                    Text("RM", fontSize = 7.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF0095F6))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable { showBookmarksOnly = !showBookmarksOnly }) {
                    Text(if (showBookmarksOnly) "🔖" else "📑", fontSize = 19.sp)
                    Text(tr("히스토리"), fontSize = 7.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFAAB0BD))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box {
                        Text("🔔", fontSize = 19.sp, modifier = Modifier.clickable(onClick = onOpenNotifications))
                        if (notifUnreadCount > 0) {
                            Text("$notifUnreadCount", fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.Bold,
                                modifier = Modifier.align(Alignment.TopEnd).offset(x = 7.dp, y = (-5).dp)
                                    .background(Color(0xFFFF3040), CircleShape)
                                    .padding(horizontal = 4.dp, vertical = 1.dp))
                        }
                    }
                    Text(tr("알림"), fontSize = 7.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFFF6B6B))
                }
            }
        }
        snack?.let { Text(it, color = Color(0xFFFF8FA3), fontSize = 12.sp) }
        Spacer(Modifier.height(8.dp))

        // ✅ 제목·내용·작성자 검색 (v58: 검색 버튼 + 나라 선택 추가)
        var pendingQuery by remember { mutableStateOf("") }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = pendingQuery, onValueChange = { pendingQuery = it },
                placeholder = { Text(tr("제목, 내용, 작성자 검색"), fontSize = 13.sp) },
                singleLine = true, modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(14.dp),
                trailingIcon = { if (pendingQuery.isNotBlank()) Text("✕", Modifier.clickable { pendingQuery = ""; searchQuery = "" }.padding(8.dp)) }
            )
            Spacer(Modifier.width(7.dp))
            Button(onClick = { searchQuery = pendingQuery.trim() },
                shape = RoundedCornerShape(14.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp)
            ) { Text(tr("검색"), fontSize = 13.sp, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.width(7.dp))
            // ✅ 나라별 운동장 선택 (글 작성 언어 기준 필터)
            var showCountryMenu by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { showCountryMenu = true },
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 12.dp)
                ) { Text(countryFilterFlag(countryFilter), fontSize = 15.sp) }
                DropdownMenu(expanded = showCountryMenu, onDismissRequest = { showCountryMenu = false }) {
                    listOf(null to "🌍 전체", "ko" to "🇰🇷 한국", "en" to "🇺🇸 영어권", "ja" to "🇯🇵 일본",
                        "zh" to "🇨🇳 중국", "es" to "🇪🇸 스페인어권", "fr" to "🇫🇷 프랑스").forEach { (code, label) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = { countryFilter = code; showCountryMenu = false })
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(SortMode.entries) { s ->
                val sel = sortMode == s
                Box(
                    Modifier.background(if (sel) Color(0xFF8B9FFF) else Color(0xFF2A2635), RoundedCornerShape(16.dp))
                        .clickable { sortMode = s }
                        .padding(horizontal = 12.dp, vertical = 7.dp)
                ) { Text(s.label, fontSize = 12.sp, color = if (sel) Color.White else Color(0xFFEDEAF4)) }
            }
        }
        if (sortMode == SortMode.NEARBY && myLocation == null) {
            Text(tr("⚠️ 내 위치를 확인할 수 없어서 지금은 최신순으로 보여요 (위치 권한을 확인해주세요)"),
                fontSize = 10.sp, color = Color.Gray, modifier = Modifier.padding(top = 4.dp))
        }
        Spacer(Modifier.height(8.dp))

        // ✅ 아래로 끌어내리면 새로고침: 저장소를 다시 읽고 기간을 최신 7일로 리셋 → 최신 글이 맨 위에
        var refreshing by remember { mutableStateOf(false) }
        val pullState = androidx.compose.material.pullrefresh.rememberPullRefreshState(
            refreshing = refreshing,
            onRefresh = {
                refreshing = true
                scope.launch {
                    CommunityStore.reload(context)
                    posts = CommunityStore.posts
                    weeksLoaded = 1
                    sortMode = SortMode.LATEST
                    autoHidden = com.navifit.social.ReportSystem.autoHiddenPostIds()
                    kotlinx.coroutines.delay(350)
                    refreshing = false
                }
            }
        )
        Box(Modifier.weight(1f).pullRefresh(pullState)) {
        LazyColumn(Modifier.fillMaxSize(), state = listState) {
            items(renderedPosts, key = { it.id }) { p ->
                // ✅ 숨긴 작성자의 글: 내용 대신 블러 처리된 안내 카드 (다시 보기로 해제)
                if (p.author in mutedAuthors && !p.isMine) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp)
                            // ✅ v81 은은한 그림자 박스 (화이트=옅은 그림자, 다크=어두운 카드)
                            .then(com.navifit.ui.theme.NaviTheme.subtleCard(12.dp))
                            // 알림에서 넘어온 글은 잠시 강조 테두리
                            .then(
                                if (highlightedPostId == p.id.toString())
                                    Modifier.border(2.dp, Color(0xFF3B82F6), RoundedCornerShape(12.dp))
                                else Modifier
                            )
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🚫", fontSize = 14.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(tr("숨긴 작성자(%s)의 글이에요").format(p.author), fontSize = 12.sp,
                            color = Color(0xFF6B7188), modifier = Modifier.weight(1f))
                        Text(tr("다시 보기"), fontSize = 12.sp, color = Color(0xFF7C93F5), fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable {
                                MutedAuthors.unmute(context, p.author)
                                mutedAuthors = MutedAuthors.all(context)
                            }.padding(4.dp))
                    }
                    HorizontalDivider(color = Color(0xFF1F1F1F), thickness = 0.7.dp)
                    return@items
                }
                // ✅ v57 인스타그램식 플랫 피드: 카드 대신 전폭 아이템 + 하단 얇은 구분선
                Column(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                            // ✅ 인스타식 그라데이션 링 아바타
                            Box(
                                Modifier.size(36.dp).clip(CircleShape)
                                    .background(Brush.sweepGradient(listOf(
                                        Color(0xFFFEDA75), Color(0xFFFA7E1E), Color(0xFFD62976),
                                        Color(0xFF962FBF), Color(0xFF4F5BD5), Color(0xFFFEDA75))))
                                    .padding(2.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(Modifier.fillMaxSize().clip(CircleShape).background(Color(0xFF0A0A0A)),
                                    contentAlignment = Alignment.Center) {
                                    Text(if (p.isMine) "🙋" else "🏃", fontSize = 15.sp)
                                }
                            }
                            Spacer(Modifier.width(9.dp))
                            // ✅ v86 아이디 탭 → 바로 프로필이 아니라 "행동 메뉴"를 띄운다
                            //   (운동장 보기 / RM 요청 / 런친 요청 / 이 사람 글 안 보기 / 스팸 신고)
                            var showAuthorMenu by remember(p.id) { mutableStateOf(false) }
                            Column(Modifier.clickable { showAuthorMenu = true }) {
                                Text(p.author, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                // ✅ 별 배지: 좋아요 상위 10%만 아이디 밑에 별이 빛남 (티커/테두리와 별개)
                                val authorLikes = authorLikesMap[p.author] ?: 0
                                val countryRanking = remember(p.author, authorLikes) {
                                    com.navifit.social.PlaygroundRank.buildCountryRanking(myCountryFlag, p.author, authorLikes)
                                }
                                val myRankEntry = countryRanking.firstOrNull { it.isMe }
                                val badge = myRankEntry?.let { com.navifit.social.PlaygroundRank.badgeFor(it.rank, countryRanking.size) }
                                if (badge != null && !badge.isEmpty) {
                                    // ✅ 빛나는 티어 별 (상위 10%만, 최대 5개)
                                    GlowingStars(color = badge.color, count = badge.count, size = 13.dp)
                                }
                                Text(timeAgo(p.createdAt), fontSize = 11.sp, color = Color.Gray)
                            }
                            // ✅ v86 작성자 행동 메뉴
                            if (showAuthorMenu) {
                                AlertDialog(
                                    onDismissRequest = { showAuthorMenu = false },
                                    title = { Text(p.author, fontWeight = FontWeight.ExtraBold) },
                                    text = {
                                        Column {
                                            AuthorMenuRow("🏟️ 운동장 구경하기") {
                                                showAuthorMenu = false; onOpenProfile(p.author, p.authorUid)
                                            }
                                            if (!p.isMine) {
                                                AuthorMenuRow("✉️ RM 요청하기") {
                                                    showAuthorMenu = false; onRequestRm(p.author, p.authorUid)
                                                }
                                                AuthorMenuRow("🏃 런친 요청하기") {
                                                    showAuthorMenu = false; onRequestRunFriend(p.author, p.authorUid)
                                                }
                                                AuthorMenuRow("🚫 이 사람 글 안 보기") {
                                                    showAuthorMenu = false
                                                    com.navifit.social.BlockStore.block(context, p.author)
                                                    adminTick++
                                                    snack = "${p.author} 님의 글을 숨겼어요"
                                                }
                                                AuthorMenuRow("📛 스팸 신고") {
                                                    showAuthorMenu = false
                                                    scope.launch {
                                                        snack = com.navifit.social.ReportSystem.reportPost(
                                                            p.id, p.authorUid, myUid,
                                                            com.navifit.social.ReportSystem.Reason.SPAM)
                                                    }
                                                }
                                            }
                                        }
                                    },
                                    confirmButton = {
                                        TextButton(onClick = { showAuthorMenu = false }) { Text(tr("닫기")) }
                                    }
                                )
                            }
                            } // 아바타+아이디 Row 끝
                            if (p.isMine) {
                                // ✅ v86 헤더의 중복 🗑️ 제거 — 삭제는 글 설정(⚙️) 메뉴 한 곳에서만
                            } else {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    // ✅ v37 팔로우 버튼 (단방향 구독)
                                    if (p.authorUid.isNotBlank() && !isAnonymous && p.authorUid != myUid) {
                                        val isFollowing = p.authorUid in followingUids
                                        Text(
                                            if (isFollowing) "런친" else "+ 런친",
                                            fontSize = 11.sp, fontWeight = FontWeight.Bold,
                                            color = if (isFollowing) Color.Gray else Color(0xFF7EDDB8),
                                            modifier = Modifier.clickable {
                                                scope.launch {
                                                    snack = if (isFollowing)
                                                        com.navifit.social.FollowSystem.unfollow(myUid, p.authorUid)
                                                    else
                                                        com.navifit.social.FollowSystem.follow(myUid, myNickname, p.authorUid, p.author)
                                                    followingUids = com.navifit.social.FollowSystem.followingUids(myUid)
                                                }
                                            }.padding(horizontal = 6.dp)
                                        )
                                    }
                                    if (p.authorUid.isNotBlank() && !isAnonymous) {
                                        Text("💬 RM", fontSize = 11.sp, color = Color(0xFF8B9FFF), fontWeight = FontWeight.Bold,
                                            modifier = Modifier.clickable { onOpenDm(p.authorUid, p.author) }.padding(horizontal = 6.dp))
                                    }
                                    Text("🚨", Modifier.clickable { reportTarget = p }.padding(4.dp))   // ✅ 신고 = 사이렌
                                    // ✅ 이 작성자 글 숨기기 (개인 차단 - 인스타 '숨기기'처럼 내 피드에서만 블러)
                                    if (!p.isMine && p.authorUid != myUid) {
                                        Text("🚫", fontSize = 13.sp, modifier = Modifier.clickable {
                                            MutedAuthors.mute(context, p.author)
                                            mutedAuthors = MutedAuthors.all(context)
                                            snack = "${p.author}님의 글을 숨겼어요 (글 카드에서 '다시 보기'로 해제)"
                                        }.padding(4.dp))
                                    }
                                    // ✅ 관리자(마스터/부관리자) 전용 관리 메뉴: 글 삭제·가리기·글쓰기 정지·계정 정지
                                    if (isAdmin) {
                                        var showAdminMenu by remember { mutableStateOf(false) }
                                        var confirmAdminDel by remember(p.id) { mutableStateOf(false) }
                                        Box {
                                            Text("⚙️", Modifier.clickable { showAdminMenu = true }.padding(4.dp))
                                            DropdownMenu(expanded = showAdminMenu, onDismissRequest = { showAdminMenu = false }) {
                                                DropdownMenuItem(text = { Text(tr("🗑️ 글 삭제 (관리)")) }, onClick = {
                                                    showAdminMenu = false; confirmAdminDel = true   // ✅ 삭제 전 확인
                                                })
                                                DropdownMenuItem(text = { Text(tr("🚫 글 가리기")) }, onClick = {
                                                    showAdminMenu = false
                                                    com.navifit.social.PlaygroundAdmin.hidePost(context, p.id)
                                                    adminTick++ // 목록 갱신
                                                })
                                                DropdownMenuItem(text = { Text(tr("🔇 글쓰기 정지")) }, onClick = {
                                                    showAdminMenu = false
                                                    if (p.authorUid.isNotBlank()) com.navifit.social.PlaygroundAdmin.muteUser(context, p.authorUid)
                                                    snack = "${p.author}님 글쓰기 정지 처리됨"
                                                })
                                                DropdownMenuItem(text = { Text(tr("⛔ 계정 정지"), color = Color(0xFFFF8FA3)) }, onClick = {
                                                    showAdminMenu = false
                                                    if (p.authorUid.isNotBlank()) com.navifit.social.PlaygroundAdmin.suspendUser(context, p.authorUid)
                                                    snack = "${p.author}님 계정 정지 처리됨"
                                                })
                                            }
                                            // ✅ 삭제 전 확인 창 (메뉴 밖에 배치해야 메뉴가 닫혀도 떠 있음)
                                            if (confirmAdminDel) {
                                                AlertDialog(
                                                    onDismissRequest = { confirmAdminDel = false },
                                                    title = { Text(tr("글 삭제 (관리)")) },
                                                    text = { Text(tr("이 글을 삭제하시겠습니까?"), fontSize = 13.sp) },
                                                    confirmButton = {
                                                        TextButton(onClick = {
                                                            confirmAdminDel = false
                                                            syncPosts(posts.filter { it.id != p.id })
                                                        }) { Text(tr("삭제"), color = Color(0xFFFF8FA3)) }
                                                    },
                                                    dismissButton = { TextButton(onClick = { confirmAdminDel = false }) { Text(tr("취소")) } }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(6.dp))

                        var translated by remember(p.id) { mutableStateOf<String?>(null) }
                        var translating by remember(p.id) { mutableStateOf(false) }

                        roundedDistanceLabel(p, myLocation)?.let { label ->
                            Text("📍 $label", fontSize = 10.sp, color = Color(0xFF6E85F0), modifier = Modifier.padding(top = 2.dp, bottom = 2.dp))
                        }

                        // ✅ 첨부 여러 개(사진+동영상 혼합): 올린 순서 그대로 가로 스와이프로 표시
                        val photos = if (p.mediaPaths.isNotEmpty()) p.mediaPaths
                                     else listOfNotNull(p.mediaPath.takeIf { p.mediaType == "image" })
                        fun playVideo(path: String) {
                            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", File(path))
                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(uri, "video/*")
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            try { context.startActivity(intent) } catch (_: Exception) {}
                        }
                        if (photos.size > 1) {
                            Box {
                                LazyRow(
                                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    items(photos) { ph ->
                                        if (ph.endsWith(".mp4")) {
                                            Box(
                                                Modifier.width(260.dp).height(180.dp)
                                                    .clip(RoundedCornerShape(12.dp))
                                                    .background(Color(0xFF2A2635))
                                                    .clickable { playVideo(ph) },
                                                contentAlignment = Alignment.Center
                                            ) { Text("▶️", fontSize = 30.sp) }
                                        } else {
                                            AsyncImage(
                                                model = File(ph), contentDescription = null,
                                                modifier = Modifier.width(260.dp).height(180.dp)
                                                    .clip(RoundedCornerShape(12.dp)),
                                                contentScale = ContentScale.Crop
                                            )
                                        }
                                    }
                                }
                                Text(
                                    "1/${photos.size}", fontSize = 10.sp, color = Color.White,
                                    modifier = Modifier.align(Alignment.TopEnd).padding(10.dp)
                                        .background(Color(0xAA000000), RoundedCornerShape(10.dp))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                        p.mediaPath?.let { path ->
                            if (p.mediaType == "image" && photos.size <= 1) {
                                AsyncImage(
                                    model = File(path), contentDescription = null,
                                    modifier = Modifier.fillMaxWidth().height(180.dp).padding(vertical = 6.dp),
                                    contentScale = ContentScale.Crop
                                )
                            } else if (p.mediaType == "video") {
                                Box(
                                    Modifier.fillMaxWidth().height(80.dp)
                                        .background(Color(0xFF2A2635), RoundedCornerShape(12.dp))
                                        .clickable {
                                            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", File(path))
                                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                                setDataAndType(uri, "video/*")
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(intent)
                                        },
                                    contentAlignment = Alignment.Center
                                ) { Text(tr("▶️ 동영상 재생 (탭)"), fontSize = 13.sp) }
                            }
                        }

                        // ✅ v33: 공유 경로가 포함된 글이면 원문 코드는 숨기고 "이 경로대로 안내" 버튼 표시
                        val sharedRoute = remember(p.text) { com.navifit.navigation.RouteShare.parse(p.text) }
                        // ✅ 글에 담긴 경로를 내 기기 키 저장소에 자동 등록 → 발급된 키로도 언제든 따라가기 가능
                        LaunchedEffect(sharedRoute) {
                            sharedRoute?.let {
                                com.navifit.navigation.RouteKeyStore.issueKey(context, it.mode, it.polyline)
                            }
                        }
                        val displayText = remember(p.text) {
                            p.text.replace(Regex("NAVIFIT_ROUTE:[A-Z_]+:[^\\s]+"), "").trim()
                        }
                        // ✅ v41 번역: 기본은 작성자 언어 원문. 다른 언어 사용자는 [🌐 번역 보기]로 내 언어 전환
                        val myLang = com.navifit.i18n.LanguageStore.current(context).code
                        // ✅ v42: lang이 없는 글(기존 글·데모 글)은 본문에서 언어를 자동 감지.
                        //    기존엔 lang == null이면 번역 버튼이 아예 안 떠서 "번역이 안 되는" 상태였음.
                        var detectedLang by remember(p.id) { mutableStateOf(p.lang) }
                        LaunchedEffect(p.id, displayText) {
                            if (detectedLang == null && displayText.isNotBlank()) {
                                detectedLang = com.navifit.i18n.TranslationService.detectLanguage(displayText)
                            }
                        }
                        val srcLang = detectedLang
                        if (displayText.isNotBlank()) {
                            Text(translated ?: displayText, fontSize = 14.sp, lineHeight = 20.sp)
                            // 작성 언어가 내 언어와 다를 때만 번역 버튼 노출
                            if (srcLang != null && srcLang != myLang) {
                                Text(
                                    when {
                                        translating -> "🌐 ..."
                                        translated != null -> com.navifit.i18n.UiText.get("translate_original", myLang)
                                        else -> com.navifit.i18n.UiText.get("translate_show", myLang)
                                    },
                                    fontSize = 11.sp, color = Color(0xFF64B5FF), fontWeight = FontWeight.Bold,
                                    modifier = Modifier.clickable(enabled = !translating) {
                                        if (translated != null) { translated = null; return@clickable }
                                        translating = true
                                        globalTranslating = true   // ✅ 전체 화면 번역 중 오버레이
                                        scope.launch {
                                            // ✅ v92 제목 개념 제거 → 본문만 번역
                                            val bodyJob = async { com.navifit.i18n.TranslationService.translate(displayText, srcLang, myLang) }

                                            var r = bodyJob.await()
                                            // ✅ 번역 결과도 검열 (욕설/금칙어가 번역으로 뚫리지 않게)
                                            if (r != null && violationOf(r) != null) r = "⚠️ 번역 결과가 운영 정책에 걸려 가려졌어요"
                                            translated = r
                                            translating = false
                                            globalTranslating = false
                                            if (r == null) snack = "번역할 수 없어요 (언어팩 다운로드가 필요할 수 있어요)"
                                        }
                                    }.padding(top = 4.dp)
                                )
                            }
                        }
                        sharedRoute?.let { sr ->
                            Spacer(Modifier.height(8.dp))
                            Button(
                                onClick = { onFollowSharedRoute(sr) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6E85F0)),
                                contentPadding = PaddingValues(vertical = 8.dp)
                            ) { Text(tr("👣 이 경로대로 안내 (%s)").format(sr.mode.displayName), fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                        }
                        Spacer(Modifier.height(8.dp))
                        // ✅ v57 인스타식 액션 줄: 큰 하트/말풍선, 숫자는 옆에 굵게
                        Row(verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                            Text(if (p.liked) "❤️ ${p.likes}" else "🤍 ${p.likes}", fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (p.liked) Color(0xFFFF3040) else Color(0xFFF5F5F5),
                                modifier = Modifier.clickable {
                                    val nowLiked = !p.liked
                                    syncPosts(posts.map { if (it.id == p.id) it.copy(liked = !it.liked, likes = it.likes + if (it.liked) -1 else 1) else it })
                                    // ✅ v36 좋아요 알림 (누를 때만, 취소는 알림 없음)
                                    if (nowLiked && p.authorUid.isNotBlank() && p.authorUid != myUid) {
                                        scope.launch {
                                            com.navifit.social.NotificationCenter.push(
                                                p.authorUid, com.navifit.social.NotificationCenter.Type.LIKE,
                                                myNickname, "회원님의 글을 좋아합니다"
                                            )
                                        }
                                    }
                                })
                            Text("👎 ${p.dislikes}", fontSize = 15.sp,
                                color = if (p.disliked) Color(0xFFF5F5F5) else Color(0xFF737373),
                                modifier = Modifier.clickable {
                                    syncPosts(posts.map { if (it.id == p.id) it.copy(disliked = !it.disliked, dislikes = it.dislikes + if (it.disliked) -1 else 1) else it })
                                })
                            Text(
                                if (p.commentsLocked) "🔒" else "💬 ${p.comments.size}",
                                fontSize = 17.sp, fontWeight = FontWeight.Bold,
                                color = if (p.commentsLocked) Color(0xFF737373) else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.clickable { commentTarget = p }.padding(4.dp)
                            )
                            Spacer(Modifier.weight(1f))
                            // ═══ ✅ v88 나머지 액션은 ⚙️ 하나로 묶음 (인스타처럼 깔끔하게) ═══
                            var showPostMenu by remember(p.id) { mutableStateOf(false) }
                            var confirmPostDel by remember(p.id) { mutableStateOf(false) }
                            var marked by remember(p.id) { mutableStateOf(com.navifit.social.BookmarkStore.has(context, p.id)) }
                            Text("⚙️", fontSize = 15.sp,
                                modifier = Modifier.clickable { showPostMenu = true }.padding(4.dp))
                            if (showPostMenu) {
                                AlertDialog(
                                    onDismissRequest = { showPostMenu = false },
                                    title = { Text(tr("글 설정")) },
                                    text = {
                                        Column {
                                            AuthorMenuRow(if (marked) "📑 저장 해제" else "🔖 이 글 저장") {
                                                marked = com.navifit.social.BookmarkStore.toggle(context, p.id)
                                                snack = if (marked) "저장했어요" else "저장을 해제했어요"
                                                showPostMenu = false
                                            }
                                            AuthorMenuRow("📤 공유하기") {
                                                showPostMenu = false
                                                val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                                    type = "text/plain"
                                                    putExtra(android.content.Intent.EXTRA_TEXT,
                                                        p.text)
                                                }
                                                context.startActivity(android.content.Intent.createChooser(send, "글 공유"))
                                            }
                                            if (p.isMine || p.authorUid == myUid) {
                                                // ✅ v88 댓글 잠금을 "글마다" 설정 (설정 화면이 아니라 여기서)
                                                AuthorMenuRow(if (p.commentsLocked) "🔓 댓글 허용하기" else "🔒 이 글 댓글 막기") {
                                                    syncPosts(posts.map {
                                                        if (it.id == p.id) it.copy(commentsLocked = !it.commentsLocked) else it
                                                    })
                                                    snack = if (p.commentsLocked) "댓글을 허용했어요" else "이 글의 댓글을 막았어요"
                                                    showPostMenu = false
                                                }
                                                AuthorMenuRow("✏️ 글 수정") {
                                                    editTarget = p; draft = p.text
                                                    showPostMenu = false
                                                }
                                                AuthorMenuRow("🗑️ 글 삭제") {
                                                    showPostMenu = false; confirmPostDel = true
                                                }
                                            } else {
                                                AuthorMenuRow("📛 이 글 신고") {
                                                    showPostMenu = false
                                                    scope.launch {
                                                        snack = com.navifit.social.ReportSystem.reportPost(
                                                            p.id, p.authorUid, myUid,
                                                            com.navifit.social.ReportSystem.Reason.OTHER)
                                                    }
                                                }
                                                AuthorMenuRow("🚫 이 글 가리기") {
                                                    showPostMenu = false
                                                    com.navifit.social.HiddenStore.hide(context, p.id.toString())
                                                    adminTick++
                                                    snack = "이 글을 가렸어요"
                                                }
                                            }
                                        }
                                    },
                                    confirmButton = { TextButton(onClick = { showPostMenu = false }) { Text(tr("닫기")) } }
                                )
                            }
                            if (confirmPostDel) {
                                AlertDialog(
                                    onDismissRequest = { confirmPostDel = false },
                                    title = { Text(tr("글 삭제")) },
                                    text = { Text(tr("이 글을 삭제하시겠습니까? 댓글과 첨부도 함께 사라져요."), fontSize = 13.sp) },
                                    confirmButton = {
                                        TextButton(onClick = {
                                            confirmPostDel = false
                                            syncPosts(posts.filter { it.id != p.id })
                                            snack = "글을 삭제했어요"
                                        }) { Text(tr("삭제"), color = Color(0xFFFF8FA3)) }
                                    },
                                    dismissButton = { TextButton(onClick = { confirmPostDel = false }) { Text(tr("취소")) } }
                                )
                            }
                        }
                    }
                    // ✅ 인스타식 아이템 구분선 (얇은 #262626)
                    HorizontalDivider(color = Color(0xFF1F1F1F), thickness = 0.7.dp)
                }
            }
            // ✅ v45 "더 보기": 기본 7일치만 보여주고, 누를 때마다 7일씩 확장
            if (renderLimit < visiblePosts.size) {
                item {
                    Text(
                        tr("불러오는 중..."), fontSize = 11.sp, color = Color.Gray,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            } else if (hasOlderPosts) {
                item {
                    // ✅ v58: 누르면 기간 선택으로 (1주씩 넘기던 방식 대신)
                    var showPeriodPicker by remember { mutableStateOf(false) }
                    if (showPeriodPicker) {
                        AlertDialog(
                            onDismissRequest = { showPeriodPicker = false },
                            title = { Text(tr("기간 선택")) },
                            text = {
                                Column {
                                    listOf("최근 1주" to 1, "최근 1개월" to 5, "최근 3개월" to 13, "전체 보기" to 5200).forEach { (label, w) ->
                                        Text(label, fontSize = 15.sp, modifier = Modifier.fillMaxWidth()
                                            .clickable { weeksLoaded = w; showPeriodPicker = false }
                                            .padding(vertical = 11.dp))
                                    }
                                }
                            },
                            confirmButton = {},
                            dismissButton = { TextButton(onClick = { showPeriodPicker = false }) { Text(tr("취소")) } }
                        )
                    }
                    OutlinedButton(
                        onClick = { showPeriodPicker = true },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)
                    ) {
                        Text(tr("🗓 이전 글 보기 (기간 선택)"), fontSize = 13.sp)
                    }
                }
            } else if (searchQuery.isBlank() && visiblePosts.isNotEmpty()) {
                item {
                    Text(
                        tr("오래된 글은 검색으로 찾을 수 있어요"),
                        fontSize = 11.sp, color = Color.Gray,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        }
        // ✅ 당겨서 새로고침 스피너
        PullRefreshIndicator(
            refreshing = refreshing, state = pullState,
            modifier = Modifier.align(Alignment.TopCenter),
            backgroundColor = Color(0xFF2A2635), contentColor = Color(0xFF8B9FFF)
        )
        } // pullRefresh Box 끝
        // ✅ 하단 소형 배너 광고 자리 (운동장 아래 한 칸만 작게)
        Box(
            Modifier.fillMaxWidth().height(50.dp).padding(top = 6.dp)
                .background(Color(0xFF2A2635), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            // 실서비스에선 AdMob AndroidView(AdView) 로 교체 - 지금은 자리 표시
            Text(tr("AD · 배너 광고 자리 (320x50)"), fontSize = 11.sp, color = Color(0xFF8A8496))
        }
    }

    // ✅ 글 작성 버튼: 연필 아이콘 + "글쓰기" 라벨 (오른쪽 아래 플로팅)
    ExtendedFloatingActionButton(
        onClick = {
            if (com.navifit.social.PlaygroundAdmin.isMuted(context, myUid) || com.navifit.social.PlaygroundAdmin.isSuspended(context, myUid)) {
                snack = "운영 정책 위반으로 글쓰기가 제한된 상태예요"
            } else showDialog = true
        },
        modifier = Modifier.align(Alignment.BottomEnd).padding(end = 18.dp, bottom = 70.dp),
        containerColor = Color(0xFF7C93F5),
        contentColor = Color.White
    ) { Text(tr("📝 글쓰기"), fontSize = 14.sp, fontWeight = FontWeight.Bold) }

    // ✅ v60 번역 중 로딩 오버레이 (번역 국기/버튼 누르면 잠깐 떴다가 완료되면 사라짐)
    if (globalTranslating) {
        Box(Modifier.fillMaxSize().background(Color(0xCC0E1013)), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = Color(0xFF3B82F6))
                Spacer(Modifier.height(14.dp))
                Text(tr("🌐 번역 중..."), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(tr("잠시만 기다려주세요"), color = Color(0xFF8B93AC), fontSize = 12.sp)
            }
        }
    }
    } // Box 끝

    // ✅ 운동장 랭킹 (나라별 · 1등부터 상위 10%까지 + 내 위치 %와 등수)
    if (showPlaygroundRanking) {
        PlaygroundRankingDialog(myNickname = myNickname, myTotalLikes = myTotalLikes, myLocation = myLocation,
            onDismiss = { showPlaygroundRanking = false })
    }

    if (showDialog) {
        Dialog(onDismissRequest = { showDialog = false; resetDraft() }) {
            Surface(shape = RoundedCornerShape(24.dp), color = Color(0xFF1E1B27), tonalElevation = 4.dp) {
                Column(Modifier.padding(20.dp).fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(38.dp).clip(CircleShape)
                                .background(Brush.sweepGradient(listOf(Color(0xFFFF8FA3), Color(0xFFC9A5F5), Color(0xFF8B9FFF), Color(0xFF7EDDB8), Color(0xFFFF8FA3))))
                                .padding(2.dp),
                        ) {
                            Box(Modifier.fillMaxSize().clip(CircleShape).background(Color(0xFF1E1B27)), contentAlignment = Alignment.Center) {
                                Text("🙋", fontSize = 16.sp)
                            }
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(myNickname, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Spacer(Modifier.height(14.dp))
                    // ✅ v61 제목란 제거 - 내용란만
                    OutlinedTextField(
                        value = draft, onValueChange = { if (it.length <= 2000) draft = it },   // ✅ 본문 2000자
                        placeholder = { Text(tr("오늘의 기록 소감을 남겨보세요... (@로 친구 언급)")) },
                        modifier = Modifier.fillMaxWidth().height(120.dp),
                        shape = RoundedCornerShape(14.dp)
                    )
                    // ✅ v81 @멘션 자동완성 - 마지막 @뒤 글자와 친구 닉네임을 매칭해 후보를 띄움
                    val mentionQuery = remember(draft) {
                        val at = draft.lastIndexOf('@')
                        if (at < 0) null
                        else {
                            val after = draft.substring(at + 1)
                            // 공백/줄바꿈이 들어가면 멘션 입력이 끝난 것으로 봄
                            if (after.contains(' ') || after.contains('\n')) null else after
                        }
                    }
                    val mentionCandidates = remember(mentionQuery, friendNicknames) {
                        val q = mentionQuery
                        if (q == null) emptyList()
                        else friendNicknames.filter { it.startsWith(q, ignoreCase = true) }.take(5)
                    }
                    if (mentionCandidates.isNotEmpty()) {
                        Column(
                            Modifier.fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                                .padding(vertical = 4.dp)
                        ) {
                            Text(tr("친구 언급"), fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp))
                            mentionCandidates.forEach { nick ->
                                Text(
                                    "@$nick", fontSize = 14.sp, fontWeight = FontWeight.Medium,
                                    color = Color(0xFF3B82F6),
                                    modifier = Modifier.fillMaxWidth()
                                        .clickable {
                                            val at = draft.lastIndexOf('@')
                                            if (at >= 0) draft = draft.substring(0, at) + "@" + nick + " "
                                        }
                                        .padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                    Text("${draft.length}/2000", fontSize = 10.sp,
                        color = if (draft.length >= 2000) Color(0xFFFF6B6B) else Color(0xFF8B93AC),
                        modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.End)
                    Spacer(Modifier.height(10.dp))

                    // ✅ 첨부 목록: 고른 순서대로 번호가 붙고, 그 순서 그대로 게시됨.
                    //    ✕로 한 개씩 삭제, "전체 삭제"로 한 번에 비우기 가능.
                    val attached = if (pendingMediaPaths.isNotEmpty()) pendingMediaPaths
                                   else listOfNotNull(pendingMediaPath)
                    if (attached.isNotEmpty()) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(tr("첨부 %s/10 · 번호 순서대로 게시돼요").format(attached.size), fontSize = 11.sp, color = Color.Gray,
                                modifier = Modifier.weight(1f))
                            TextButton(onClick = {
                                pendingMediaPath = null; pendingMediaPaths = emptyList(); pendingMediaType = null
                            }) { Text(tr("🗑 전체 삭제"), fontSize = 11.sp, color = Color(0xFFFF8FA3)) }
                        }
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(attached.size) { idx ->
                                val path = attached[idx]
                                val isVideo = path.endsWith(".mp4")
                                Box(Modifier.size(96.dp)) {
                                    if (isVideo) {
                                        Box(Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp))
                                            .background(Color(0xFF2A2635)), contentAlignment = Alignment.Center) {
                                            Text("🎬", fontSize = 26.sp)
                                        }
                                    } else {
                                        AsyncImage(model = File(path), contentDescription = null,
                                            modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp)),
                                            contentScale = ContentScale.Crop)
                                    }
                                    // 순서 번호 배지
                                    Text("${idx + 1}", fontSize = 10.sp, color = Color.White,
                                        modifier = Modifier.align(Alignment.TopStart).padding(4.dp)
                                            .background(Color(0xCC000000), CircleShape)
                                            .padding(horizontal = 6.dp, vertical = 1.dp))
                                    // ✕ 한 개 삭제
                                    Text("✕", fontSize = 11.sp, color = Color.White,
                                        modifier = Modifier.align(Alignment.TopEnd).padding(4.dp)
                                            .background(Color(0xCC000000), CircleShape)
                                            .clickable {
                                                val newList = attached.toMutableList().also { it.removeAt(idx) }
                                                pendingMediaPaths = newList
                                                pendingMediaPath = newList.firstOrNull()
                                                if (newList.isEmpty()) pendingMediaType = null
                                            }
                                            .padding(horizontal = 6.dp, vertical = 1.dp))
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { pickImages.launch("image/*") }, shape = RoundedCornerShape(20.dp)) {
                            Text(tr("📷 사진 추가"), fontSize = 12.sp)  // 여러 장 선택 가능, 고른 순서대로 추가
                        }
                        OutlinedButton(onClick = { pickVideo.launch("video/*") }, shape = RoundedCornerShape(20.dp)) { Text(tr("🎬 동영상 추가"), fontSize = 12.sp) }  // 여러 개 선택 가능
                    }

                    Spacer(Modifier.height(16.dp))
                    // ✅ v58: 게시가 막힌 이유를 작성 창 안에 바로 표시 (기존엔 다이얼로그 뒤에 가려져 "버튼이 안 먹는" 것처럼 보였음)
                    snack?.let {
                        Text("⚠️ $it", color = Color(0xFFFF6B6B), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 6.dp))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { showDialog = false; resetDraft() }) { Text(tr("취소"), color = Color.Gray) }
                        Spacer(Modifier.width(4.dp))
                        Button(
                            onClick = {
                                val hasMedia = pendingMediaPath != null || pendingMediaPaths.isNotEmpty()
                                // ✅ 버그 수정: 사진/동영상만 첨부하면 게시가 안 되던 문제
                                //    (기존엔 본문이 비어있으면 조용히 아무 일도 안 일어났음)
                                if (draft.isBlank() && !hasMedia) {
                                    snack = "내용을 쓰거나 사진/동영상을 첨부해주세요"; return@Button
                                }
                                // ✅ v36 글쓰기 검증 (기존엔 길이·도배 제한이 전혀 없었음)
                                if (draft.length > 2000) { snack = "본문은 2000자까지 쓸 수 있어요 (현재 ${draft.length}자)"; return@Button }
                                // ✅ 멘션은 친구 목록에 있는 사람만 가능
                                val badMentions = extractMentions(draft)
                                    .filter { it !in friendNicknames && it != myNickname }
                                if (badMentions.isNotEmpty()) {
                                    snack = "@멘션은 친구만 할 수 있어요: @${badMentions.first()} 님은 친구 목록에 없어요"; return@Button
                                }
                                val lastPostAt = posts.filter { it.isMine }.maxOfOrNull { it.createdAt } ?: 0L
                                if (System.currentTimeMillis() - lastPostAt < 30_000L) {
                                    snack = "도배 방지: 30초 후에 다시 올릴 수 있어요"; return@Button
                                }
                                // 1단계 로컬 필터 (즉시 차단)
                                if (draft.isNotBlank()) violationOf(draft)?.let { v -> snack = v.reason; return@Button }

                                // ✅ 관리자에게 글쓰기 정지/계정 정지 당한 유저는 게시 불가
                                if (com.navifit.social.PlaygroundAdmin.isMuted(context, myUid) || com.navifit.social.PlaygroundAdmin.isSuspended(context, myUid)) {
                                    snack = "운영 정책 위반으로 글쓰기가 제한된 상태예요"; showDialog = false; return@Button
                                }
                                if (isAnonymous) {
                                    val today = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.KOREA).format(java.util.Date())
                                    val todayCount = posts.count { it.isMine && java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.KOREA).format(java.util.Date(it.createdAt)) == today }
                                    if (todayCount >= com.navifit.auth.AnonymousLimits.MAX_POSTS_PER_DAY) {
                                        snack = "게스트는 하루 ${com.navifit.auth.AnonymousLimits.MAX_POSTS_PER_DAY}개까지만 글을 쓸 수 있어요 (구글 연결 시 무제한)"; return@Button
                                    }
                                    // ✅ v58: 게스트도 사진/동영상 게시 허용 (막혀 있어서 "게시가 안 된다"고 느껴지던 원인)
                                }
                                // ✅ v42 2단계 검사 통과 후에만 게시 (게시 후 회수 X - 그 사이 남들이 봄)
                                val bodyForCheck = draft
                                val titleForCheck = ""
                                val myLangCode = com.navifit.i18n.LanguageStore.current(context).code
                                val newPostId = System.currentTimeMillis()
                                val mediaForCheck = if (pendingMediaPaths.isNotEmpty()) pendingMediaPaths
                                                    else listOfNotNull(pendingMediaPath)
                                scope.launch {
                                    // 본문이 비어있으면(사진만 게시) 텍스트 검사는 건너뜀
                                    if (bodyForCheck.isNotBlank()) {
                                        val reason = com.navifit.moderation.ModerationGate.check(context, bodyForCheck)
                                        if (reason != null) { snack = reason; return@launch }
                                    }
                                    // ✅ 첨부 사진·동영상 검열 (성인물·잔혹물 등 자동 차단, 동영상은 대표 프레임 3장)
                                    if (mediaForCheck.isNotEmpty()) {
                                        val mReason = com.navifit.moderation.ModerationGate.checkMedia(context, mediaForCheck)
                                        if (mReason != null) { snack = "🚫 $mReason"; return@launch }
                                    }
                                    postApproved(newPostId, myLangCode, titleForCheck, bodyForCheck)
                                }
                                showDialog = false; snack = null
                            },
                            shape = RoundedCornerShape(20.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B9FFF))
                        ) { Text(tr("게시하기")) }
                    }
                }
            }
        }
    }

    // ═══════════ ✅ v37 댓글창 (대댓글 · 멘션 · 삭제 · 금지) ═══════════
    commentTarget?.let { target ->
        var newComment by remember(target.id) { mutableStateOf("") }
        var replyTo by remember(target.id) { mutableStateOf<CommentData?>(null) }
        val isMyPost = target.isMine || target.authorUid == myUid
        // 구버전 댓글(Pair)도 함께 보여주기 위해 병합
        val allComments = remember(target) {
            val legacy = target.comments.map { (a, t) -> CommentData(author = a, text = t) }
            (legacy + target.commentList).sortedBy { it.at }
        }
        val roots = allComments.filter { it.parentId == null }

        AlertDialog(
            onDismissRequest = { commentTarget = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("댓글 %s").format(allComments.size), fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    if (isMyPost) {
                        TextButton(onClick = {
                            syncPosts(posts.map {
                                if (it.id == target.id) it.copy(commentsLocked = !it.commentsLocked) else it
                            })
                            commentTarget = posts.find { it.id == target.id }
                        }) {
                            Text(if (target.commentsLocked) "🔓 댓글 허용" else "🔒 댓글 금지", fontSize = 12.sp)
                        }
                    }
                }
            },
            text = {
                Column(Modifier.heightIn(max = 400.dp)) {
                    // ✅ 어떤 글의 댓글창인지 원문 미리보기 (제목 + 본문 일부)
                    Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFF232030)) {
                        Column(Modifier.fillMaxWidth().padding(10.dp)) {
                            Text(tr("📄 %s님의 글").format(target.author), fontSize = 10.sp, color = Color(0xFF8B9FFF), fontWeight = FontWeight.Bold)

                            val previewBody = target.text.replace(Regex("NAVIFIT_ROUTE:[A-Z_]+:[^\\s]+"), "").trim()
                            if (previewBody.isNotBlank())
                                Text(previewBody, fontSize = 11.sp, color = Color(0xFFB9B3C6), maxLines = 2)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    if (allComments.isEmpty()) {
                        Text(tr("아직 댓글이 없어요"), color = Color.Gray, fontSize = 13.sp,
                            modifier = Modifier.padding(vertical = 12.dp))
                    } else {
                        Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())) {
                            roots.forEach { c ->
                                CommentRow(
                                    c = c, indent = 0, myNickname = myNickname, canDelete = c.author == myNickname || isMyPost,
                                    onReply = { replyTo = c },
                                    onDelete = {
                                        syncPosts(posts.map { pp ->
                                            if (pp.id == target.id) {
                                                // 답글까지 함께 삭제
                                                val kept = pp.commentList.filter { it.id != c.id && it.parentId != c.id }
                                                val keptLegacy = pp.comments.filterNot { it.first == c.author && it.second == c.text }
                                                pp.copy(
                                                    commentList = kept.toMutableList(),
                                                    comments = keptLegacy.toMutableList()
                                                )
                                            } else pp
                                        })
                                        commentTarget = posts.find { it.id == target.id }
                                    }
                                )
                                // 답글들
                                allComments.filter { it.parentId == c.id }.forEach { r ->
                                    CommentRow(
                                        c = r, indent = 1, myNickname = myNickname,
                                        canDelete = r.author == myNickname || isMyPost,
                                        onReply = { replyTo = c },   // 답글의 답글도 같은 부모로 (2단계까지만)
                                        onDelete = {
                                            syncPosts(posts.map { pp ->
                                                if (pp.id == target.id)
                                                    pp.copy(commentList = pp.commentList.filter { it.id != r.id }.toMutableList())
                                                else pp
                                            })
                                            commentTarget = posts.find { it.id == target.id }
                                        }
                                    )
                                }
                                Divider(color = Color(0x22FFFFFF))
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    if (target.commentsLocked) {
                        Text(tr("🔒 작성자가 댓글을 막았어요"), color = Color(0xFFFF8FA3), fontSize = 12.sp)
                    } else {
                        replyTo?.let { rt ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(tr("↳ %s님에게 답글").format(rt.author), fontSize = 11.sp, color = Color(0xFF8B9FFF))
                                Spacer(Modifier.weight(1f))
                                Text("✕", fontSize = 12.sp, modifier = Modifier.clickable { replyTo = null }.padding(4.dp))
                            }
                        }
                        OutlinedTextField(
                            value = newComment, onValueChange = { if (it.length <= 300) newComment = it },
                            placeholder = { Text(tr("댓글 입력 (@닉네임으로 멘션)"), fontSize = 13.sp) },
                            modifier = Modifier.fillMaxWidth(), maxLines = 3,
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp)
                        )
                        // ✅ v86 댓글에도 @멘션 자동완성 (친구 목록 + 비슷한 닉네임)
                        val cQuery = remember(newComment) {
                            val at = newComment.lastIndexOf('@')
                            if (at < 0) null else {
                                val after = newComment.substring(at + 1)
                                if (after.contains(' ') || after.contains('\n')) null else after
                            }
                        }
                        val cCandidates = remember(cQuery, friendNicknames) {
                            val q = cQuery
                            when {
                                q == null -> emptyList()
                                q.isBlank() -> friendNicknames.take(5)          // @만 쳐도 친구 목록이 뜸
                                else -> friendNicknames
                                    .filter { it.startsWith(q, true) || it.contains(q, true) }  // 비슷한 닉네임까지
                                    .sortedBy { if (it.startsWith(q, true)) 0 else 1 }
                                    .take(5)
                            }
                        }
                        if (cCandidates.isNotEmpty()) {
                            Column(
                                Modifier.fillMaxWidth().padding(top = 4.dp)
                                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                                    .padding(vertical = 4.dp)
                            ) {
                                cCandidates.forEach { nick ->
                                    Text(
                                        "@$nick", fontSize = 13.sp, fontWeight = FontWeight.Medium,
                                        color = Color(0xFF3B82F6),
                                        modifier = Modifier.fillMaxWidth()
                                            .clickable {
                                                val at = newComment.lastIndexOf('@')
                                                if (at >= 0) newComment = newComment.substring(0, at) + "@" + nick + " "
                                            }
                                            .padding(horizontal = 12.dp, vertical = 7.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                if (!target.commentsLocked) {
                    TextButton(onClick = {
                        val txt = newComment.trim()
                        if (txt.isBlank()) return@TextButton
                        violationOf(txt)?.let { v -> snack = v.reason; return@TextButton }
                        // ✅ @멘션은 친구 목록에 있는 사람만 가능
                        val badM = extractMentions(txt).filter { it !in friendNicknames && it != myNickname }
                        if (badM.isNotEmpty()) { snack = "@멘션은 친구만 할 수 있어요: @${badM.first()} 님은 친구 목록에 없어요"; return@TextButton }
                        val cd = CommentData(
                            author = myNickname, authorUid = myUid, text = txt, parentId = replyTo?.id,
                            lang = com.navifit.i18n.LanguageStore.current(context).code  // ✅ v41
                        )
                        syncPosts(posts.map { pp ->
                            if (pp.id == target.id)
                                pp.copy(commentList = (pp.commentList + cd).toMutableList())
                            else pp
                        })
                        scope.launch {
                            // 글쓴이 알림
                            if (target.authorUid.isNotBlank() && target.authorUid != myUid) {
                                com.navifit.social.NotificationCenter.push(
                                    target.authorUid, com.navifit.social.NotificationCenter.Type.COMMENT,
                                    myNickname, "회원님의 글에 댓글을 남겼어요: ${txt.take(30)}"
                                )
                            }
                            // ✅ v37 답글 알림 (부모 댓글 작성자에게)
                            replyTo?.let { rt ->
                                if (rt.authorUid.isNotBlank() && rt.authorUid != myUid) {
                                    com.navifit.social.NotificationCenter.push(
                                        rt.authorUid, com.navifit.social.NotificationCenter.Type.COMMENT,
                                        myNickname, "회원님의 댓글에 답글을 남겼어요: ${txt.take(30)}"
                                    )
                                }
                            }
                            // ✅ v37 멘션 알림 (@닉네임)
                            extractMentions(txt).forEach { nick ->
                                val uid = posts.firstOrNull { it.author == nick }?.authorUid
                                if (!uid.isNullOrBlank() && uid != myUid) {
                                    com.navifit.social.NotificationCenter.push(
                                        uid, com.navifit.social.NotificationCenter.Type.COMMENT,
                                        myNickname, "댓글에서 회원님을 언급했어요: ${txt.take(30)}"
                                    )
                                }
                            }
                        }
                        newComment = ""; replyTo = null
                        commentTarget = posts.find { it.id == target.id }
                    }) { Text(tr("등록")) }
                }
            },
            dismissButton = { TextButton(onClick = { commentTarget = null }) { Text(tr("닫기")) } }
        )
    }

    // ═══════════ ✅ v36 신고 다이얼로그 (실제 서버 접수) ═══════════
    reportTarget?.let { target ->
        var reason by remember(target.id) { mutableStateOf(com.navifit.social.ReportSystem.Reason.SPAM) }
        var detail by remember(target.id) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { reportTarget = null },
            title = { Text(tr("글 신고하기"), fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(tr("신고 사유를 선택해주세요"), fontSize = 13.sp, color = Color.Gray)
                    Spacer(Modifier.height(8.dp))
                    com.navifit.social.ReportSystem.Reason.values().forEach { r ->
                        Row(
                            Modifier.fillMaxWidth().clickable { reason = r }.padding(vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = reason == r, onClick = { reason = r })
                            Text(r.label, fontSize = 13.sp)
                        }
                    }
                    OutlinedTextField(
                        value = detail, onValueChange = { if (it.length <= 300) detail = it },
                        placeholder = { Text(tr("상세 내용 (선택)"), fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(), maxLines = 3,
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp)
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(tr("※ 3건 이상 신고가 쌓이면 자동으로 숨김 처리되고 운영진이 검토합니다"),
                        fontSize = 10.sp, color = Color(0xFFFF8FA3))
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val t = target
                    scope.launch {
                        snack = com.navifit.social.ReportSystem.reportPost(
                            t.id, t.authorUid, myUid, reason, detail
                        )
                        autoHidden = com.navifit.social.ReportSystem.autoHiddenPostIds()
                    }
                    reportTarget = null
                }) { Text(tr("신고하기"), color = Color(0xFFFF8FA3)) }
            },
            dismissButton = { TextButton(onClick = { reportTarget = null }) { Text(tr("취소")) } }
        )
    }

    // ═══════════ ✅ v36 글 수정 다이얼로그 ═══════════
    editTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { editTarget = null; draft = "" },
            title = { Text(tr("글 수정"), fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    OutlinedTextField(
                        value = draft, onValueChange = { if (it.length <= 2000) draft = it },
                        label = { Text(tr("내용 (%s/2000)").format(draft.length)) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp), maxLines = 8
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (draft.isBlank()) return@TextButton
                    violationOf(draft)?.let { v -> snack = v.reason; return@TextButton }
                    syncPosts(posts.map {
                        if (it.id == target.id) it.copy(title = "", text = draft) else it
                    })
                    editTarget = null; draft = ""
                    snack = "글을 수정했어요"
                }) { Text(tr("저장")) }
            },
            dismissButton = {
                TextButton(onClick = { editTarget = null; draft = "" }) { Text(tr("취소")) }
            }
        )
    }
}

/** ✅ v37 댓글 한 줄 (답글은 들여쓰기 + 멘션 하이라이트) */
@Composable
private fun CommentRow(
    c: CommentData, indent: Int, myNickname: String, canDelete: Boolean,
    onReply: () -> Unit, onDelete: () -> Unit
) {
    // ✅ v41 댓글 번역: 원문은 작성자 언어, [🌐] 누르면 내 언어로
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val myLang = com.navifit.i18n.LanguageStore.current(ctx).code
    val cScope = rememberCoroutineScope()
    var cTranslated by remember(c.id) { mutableStateOf<String?>(null) }
    // ✅ v42 lang 없는 옛 댓글도 자동 감지해서 번역 가능하게
    var cLang by remember(c.id) { mutableStateOf(c.lang) }
    LaunchedEffect(c.id) {
        if (cLang == null && c.text.isNotBlank()) {
            cLang = com.navifit.i18n.TranslationService.detectLanguage(c.text)
        }
    }
    Row(
        Modifier.fillMaxWidth()
            .padding(start = (indent * 20).dp, top = 5.dp, bottom = 5.dp)
    ) {
        if (indent > 0) Text("↳ ", fontSize = 12.sp, color = Color.Gray)
        Column(Modifier.weight(1f)) {
            Text(c.author, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF8B9FFF))
            // 멘션(@닉네임)을 파란색으로 강조
            val shownText = cTranslated ?: c.text
            val mentions = extractMentions(shownText)
            if (mentions.isEmpty()) {
                Text(shownText, fontSize = 13.sp, lineHeight = 18.sp)
            } else {
                val annotated = buildAnnotatedString {
                    val regex = Regex("@([\\w가-힣]{2,20})")
                    var last = 0
                    regex.findAll(shownText).forEach { m ->
                        append(shownText.substring(last, m.range.first))
                        withStyle(SpanStyle(color = Color(0xFF64B5FF), fontWeight = FontWeight.Bold)) {
                            append(m.value)
                        }
                        last = m.range.last + 1
                    }
                    if (last < shownText.length) append(shownText.substring(last))
                }
                Text(annotated, fontSize = 13.sp, lineHeight = 18.sp)
            }
            Row {
                Text(tr("답글"), fontSize = 10.sp, color = Color.Gray,
                    modifier = Modifier.clickable(onClick = onReply).padding(top = 2.dp, end = 8.dp))
                if (cLang != null && cLang != myLang) {
                    Text(
                        if (cTranslated != null) "🌐 원문" else "🌐 번역",
                        fontSize = 10.sp, color = Color(0xFF64B5FF), fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable {
                            if (cTranslated != null) { cTranslated = null }
                            else cScope.launch {
                                cTranslated = com.navifit.i18n.TranslationService.translate(c.text, cLang, myLang)
                            }
                        }.padding(top = 2.dp)
                    )
                }
            }
        }
        if (canDelete) {
            // ✅ 삭제 전 확인 창 ("삭제하시겠습니까?")
            var confirmDel by remember(c.id) { mutableStateOf(false) }
            Text("🗑️", fontSize = 13.sp, modifier = Modifier.clickable { confirmDel = true }.padding(4.dp))
            if (confirmDel) {
                AlertDialog(
                    onDismissRequest = { confirmDel = false },
                    title = { Text(tr("댓글 삭제")) },
                    text = { Text(tr("이 댓글을 삭제하시겠습니까? 답글도 함께 삭제될 수 있어요."), fontSize = 13.sp) },
                    confirmButton = { TextButton(onClick = { confirmDel = false; onDelete() }) { Text(tr("삭제"), color = Color(0xFFFF8FA3)) } },
                    dismissButton = { TextButton(onClick = { confirmDel = false }) { Text(tr("취소")) } }
                )
            }
        }
    }
}

/**
 * 커뮤니티 글 저장소.
 * - 메모리 싱글톤: 탭 전환/화면 재구성에도 유지
 * - 디스크(SharedPreferences JSON): 앱 종료·프로세스 재시작에도 유지
 * => "글 쓰고 다른 탭 갔다 오면 글이 사라지는" 문제 완전 해결
 */
/**
 * ✅ 작성자 숨기기(개인 차단): 특정 작성자가 계속 거슬리면 그 사람 글을 내 피드에서 블러 처리.
 * 기기 로컬 저장 - "다시 보기"로 언제든 해제 가능. (신고·관리자 숨김과는 별개의 개인 설정)
 */
object MutedAuthors {
    private const val PREFS = "muted_authors"
    private fun p(c: android.content.Context) = c.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
    fun all(c: android.content.Context): Set<String> = p(c).getStringSet("names", emptySet()) ?: emptySet()
    fun mute(c: android.content.Context, author: String) {
        p(c).edit().putStringSet("names", all(c) + author).apply()
    }
    fun unmute(c: android.content.Context, author: String) {
        p(c).edit().putStringSet("names", all(c) - author).apply()
    }
}

object CommunityStore {
    private const val PREFS = "community_store"
    private const val KEY = "posts_json"
    private var loaded = false

    var posts: List<Post> = emptyList()
        private set

    /** ✅ v64 인스타 프로필에서 작성자별 게시물 필터용 */
    fun currentPosts(): List<Post> = posts

    /** ✅ v65 운동 결과 → 운동장 게시물로 바로 추가 */
    fun addPost(context: android.content.Context, author: String, authorUid: String, text: String, theme: String? = null) {
        load(context)
        val newPost = Post(
            id = System.currentTimeMillis(),
            author = author, authorUid = authorUid, text = text,
            isMine = true, theme = theme, createdAt = System.currentTimeMillis()
        )
        save(context, listOf(newPost) + posts)
    }

    fun load(context: android.content.Context) {
        if (loaded) return
        loaded = true
        val json = context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).getString(KEY, null)
        posts = if (json == null) defaultPosts() else try { fromJson(json) } catch (e: Exception) { defaultPosts() }
    }

    /** ✅ 당겨서 새로고침용: 디스크에서 강제로 다시 읽음 (서버 연동 시 여기서 서버 fetch로 교체) */
    fun reload(context: android.content.Context) {
        loaded = false
        load(context)
    }

    /**
     * ✅ v45 성능 수정 (심각한 렉의 주원인이었음).
     *
     * 기존: 좋아요 한 번 누를 때마다 "전체 글 목록"을 JSON으로 직렬화해서 저장했음.
     *      글이 1,000개면 좋아요 1번에 1,000개를 다시 쓰는 셈 → 메인 스레드가 멈춤(ANR).
     *
     * 이제:
     *  ① 메모리 목록은 즉시 갱신 (UI는 바로 반응)
     *  ② 디스크 저장은 백그라운드 + 500ms 디바운스 (연속 탭해도 마지막 1번만 저장)
     *  ③ 저장 상한: 최근 500개만 보관 (그 이상은 오래된 순으로 정리 - 무한 증가 방지)
     */
    private var saveJob: kotlinx.coroutines.Job? = null
    private val saveScope = kotlinx.coroutines.CoroutineScope(
        kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.IO
    )

    fun save(context: android.content.Context, newList: List<Post>) {
        posts = newList   // 메모리 즉시 반영 (UI 즉각 반응)
        val appCtx = context.applicationContext
        saveJob?.cancel()
        saveJob = saveScope.launch {
            kotlinx.coroutines.delay(500)   // 디바운스: 연속 조작 시 마지막 것만 저장
            val trimmed = newList.sortedByDescending { it.createdAt }.take(500)
            val json = toJson(trimmed)      // 무거운 직렬화를 백그라운드에서
            appCtx.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
                .edit().putString(KEY, json).apply()
        }
    }

    private fun defaultPosts(): List<Post> {
        val now = System.currentTimeMillis()
        val h = 3_600_000L
        // ✅ v61 정렬 테스트용 다양한 데모 글 (인기/누적인기/테마/거리순)
        return listOf(
            Post(id = 1, author = "RunnerJane", authorUid = "demo_u1",
                text = "오늘 한강 5km 완주! 날씨 최고 ☀️ 다들 오늘 러닝 어때요?", likes = 12, dislikes = 0,
                createdAt = now - 1 * h, theme = "run", lat = 37.5297, lng = 126.9327, lang = "ko"),
            Post(id = 2, author = "속도광김씨", authorUid = "demo_u2",
                text = "자전거로 남산 한 바퀴 🚴 오르막 지옥이지만 내리막 천국. 인기글 각?", likes = 88, dislikes = 3,
                createdAt = now - 5 * h, theme = "bike", lat = 37.5512, lng = 126.9882, lang = "ko"),
            Post(id = 3, author = "새벽러너", authorUid = "demo_u3",
                text = "누적 좋아요 1위 도전! 벌써 300일째 매일 달리는 중 🔥 꾸준함이 답이다", likes = 245, dislikes = 5,
                createdAt = now - 30 * h, theme = "run", lat = 37.5665, lng = 126.9780, lang = "ko"),
            Post(id = 4, author = "TokyoRunner", authorUid = "demo_u4",
                text = "皇居ランニング最高！5km 22分 🇯🇵 (황궁 러닝 최고!)", likes = 34, dislikes = 1,
                createdAt = now - 12 * h, theme = "run", lat = 35.6852, lng = 139.7528, lang = "ja"),
            Post(id = 5, author = "동네한바퀴", authorUid = "demo_u5",
                text = "집 앞 공원 산책로 추천합니다 🌳 거리순으로 보면 제일 가까울걸요?", likes = 7, dislikes = 0,
                createdAt = now - 2 * h, theme = "walk", lat = 37.5700, lng = 126.9760, lang = "ko"),
            Post(id = 6, author = "BikePacker", authorUid = "demo_u6",
                text = "Century ride done! 100km in one go 🚴‍♂️💪", likes = 156, dislikes = 2,
                createdAt = now - 48 * h, theme = "bike", lat = 37.4979, lng = 127.0276, lang = "en")
        )
    }

    private fun toJson(list: List<Post>): String {
        val arr = org.json.JSONArray()
        list.forEach { p ->
            val o = org.json.JSONObject()
            o.put("id", p.id); o.put("author", p.author); o.put("authorUid", p.authorUid); o.put("title", p.title); o.put("text", p.text)
            o.put("likes", p.likes); o.put("dislikes", p.dislikes)
            o.put("liked", p.liked); o.put("disliked", p.disliked)
            o.put("createdAt", p.createdAt); o.put("isMine", p.isMine)
            p.mediaPath?.let { o.put("mediaPath", it) }
            p.mediaType?.let { o.put("mediaType", it) }
            p.theme?.let { o.put("theme", it) }
            p.lat?.let { o.put("lat", it) }
            p.lng?.let { o.put("lng", it) }
            val cArr = org.json.JSONArray()
            p.comments.forEach { (a, t) -> cArr.put(org.json.JSONObject().put("a", a).put("t", t)) }
            o.put("comments", cArr)
            o.put("commentsLocked", p.commentsLocked)
            p.lang?.let { o.put("lang", it) }
            // ✅ v37 대댓글 구조 저장
            val clArr = org.json.JSONArray()
            p.commentList.forEach { c ->
                clArr.put(org.json.JSONObject()
                    .put("id", c.id).put("a", c.author).put("uid", c.authorUid)
                    .put("t", c.text).put("parent", c.parentId ?: -1L).put("at", c.at)
                    .put("lang", c.lang ?: ""))
            }
            o.put("commentList", clArr)
            // ✅ v37 사진 여러 장
            o.put("mediaPaths", org.json.JSONArray(p.mediaPaths))
            arr.put(o)
        }
        return arr.toString()
    }

    private fun fromJson(json: String): List<Post> {
        val arr = org.json.JSONArray(json)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val comments = mutableListOf<Pair<String, String>>()
            val cArr = o.optJSONArray("comments")
            if (cArr != null) for (j in 0 until cArr.length()) {
                val c = cArr.getJSONObject(j)
                comments.add(c.optString("a") to c.optString("t"))
            }
            Post(
                id = o.getLong("id"), author = o.getString("author"), authorUid = o.optString("authorUid", ""),
                title = o.optString("title", ""), text = o.getString("text"),
                likes = o.optInt("likes"), dislikes = o.optInt("dislikes"),
                liked = o.optBoolean("liked"), disliked = o.optBoolean("disliked"),
                createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                comments = comments, isMine = o.optBoolean("isMine"),
                commentsLocked = o.optBoolean("commentsLocked", false),
                lang = o.optString("lang", "").ifBlank { null },
                commentList = run {
                    val out = mutableListOf<CommentData>()
                    val cl = o.optJSONArray("commentList")
                    if (cl != null) for (j in 0 until cl.length()) {
                        val c = cl.getJSONObject(j)
                        val parent = c.optLong("parent", -1L)
                        out.add(CommentData(
                            id = c.optLong("id", System.currentTimeMillis() + j),
                            author = c.optString("a"), authorUid = c.optString("uid"),
                            text = c.optString("t"),
                            parentId = if (parent > 0) parent else null,
                            at = c.optLong("at", 0L),
                            lang = c.optString("lang", "").ifBlank { null }
                        ))
                    }
                    out
                },
                mediaPaths = run {
                    val out = mutableListOf<String>()
                    val mp = o.optJSONArray("mediaPaths")
                    if (mp != null) for (j in 0 until mp.length()) out.add(mp.getString(j))
                    out
                },
                mediaPath = o.optString("mediaPath", "").ifBlank { null },
                mediaType = o.optString("mediaType", "").ifBlank { null },
                theme = o.optString("theme", "").ifBlank { null },
                lat = if (o.has("lat")) o.getDouble("lat") else null,
                lng = if (o.has("lng")) o.getDouble("lng") else null
            )
        }
    }
}

/**
 * ✅ 운동장 랭킹 다이얼로그: 나라별로 좋아요 랭킹 1등부터 상위 10%까지 표시 + 내 등수/% 카드.
 */
@Composable
private fun PlaygroundRankingDialog(
    myNickname: String, myTotalLikes: Int, onDismiss: () -> Unit,
    myLocation: com.navifit.navigation.LatLngPoint? = null
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    // ✅ v81 기본은 전세계(🌍), 드롭다운으로 나라 선택
    var countryFlag by remember { mutableStateOf(com.navifit.social.PlaygroundRank.GLOBAL) }
    var myCountry by remember { mutableStateOf("🇰🇷") }
    var dropdownOpen by remember { mutableStateOf(false) }
    LaunchedEffect(myLocation) {
        myCountry = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            com.navifit.social.CountryLocator.flagFor(ctx, myLocation?.latitude, myLocation?.longitude)
        }
    }
    val countryOptions = listOf(
        com.navifit.social.PlaygroundRank.GLOBAL to "전세계",
        "🇰🇷" to "대한민국", "🇺🇸" to "미국", "🇯🇵" to "일본", "🇬🇧" to "영국",
        "🇩🇪" to "독일", "🇫🇷" to "프랑스", "🇧🇷" to "브라질"
    )
    val ranking = remember(countryFlag, myTotalLikes) {
        com.navifit.social.PlaygroundRank.buildCountryRanking(countryFlag, myNickname, myTotalLikes)
    }
    // ✅ v81 별은 상위 10%까지만 → 목록도 상위 10%만 노출 (최소 5명은 보이게)
    val starCut = remember(ranking) {
        kotlin.math.ceil(ranking.size * 0.10).toInt().coerceAtLeast(1)
    }
    val top10pct = remember(ranking, starCut) {
        ranking.take(starCut.coerceAtLeast(5).coerceAtMost(ranking.size))
    }
    val me = ranking.firstOrNull { it.isMe }

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(24.dp), tonalElevation = 4.dp) {
            Column(Modifier.padding(18.dp).fillMaxWidth()) {
                Text(tr("🏆 운동장 랭킹"), fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                Text(tr("좋아요 랭킹 · 상위 10%만 별을 받아요"), fontSize = 11.sp, color = Color.Gray)
                Spacer(Modifier.height(10.dp))
                // ✅ v81 나라 드롭다운 (기본 전세계)
                Box {
                    Row(
                        Modifier.fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                            .clickable { dropdownOpen = true }
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val label = countryOptions.firstOrNull { it.first == countryFlag }?.second ?: "전세계"
                        Text(countryFlag, fontSize = 17.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(label, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                        Text("▼", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    DropdownMenu(expanded = dropdownOpen, onDismissRequest = { dropdownOpen = false }) {
                        countryOptions.forEach { (flag, label) ->
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(flag, fontSize = 16.sp)
                                        Spacer(Modifier.width(8.dp))
                                        Text(label + if (flag == myCountry) " (내 나라)" else "", fontSize = 14.sp)
                                    }
                                },
                                onClick = { countryFlag = flag; dropdownOpen = false }
                            )
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                // 내 위치 카드
                me?.let {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF2E3A5C)), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.padding(12.dp).fillMaxWidth()) {
                            Text(tr("🙋 내 운동장 순위: %s등 / %s명").format(it.rank, ranking.size), fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = Color.White)
                            Text(tr("상위 %.1f%% · 받은 좋아요 %s개").format(it.percentile, it.totalLikes), fontSize = 11.sp, color = Color(0xFFB8C4F0))
                            val badge = com.navifit.social.PlaygroundRank.badgeFor(it.rank, ranking.size)
                            if (!badge.isEmpty) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(tr("내 별: "), fontSize = 12.sp, color = Color(0xFFB8C4F0))
                                    GlowingStars(color = badge.color, count = badge.count, size = 14.dp)
                                    Text(tr("  %s 티어").format(badge.tierName), fontSize = 11.sp, color = badge.color, fontWeight = FontWeight.Bold)
                                }
                            } else {
                                // ✅ v81 상위 10% 밖이면 별이 없다는 걸 명확히 안내 (예전엔 하위권도 별이 붙는 버그)
                                Text(tr("⭐ 별은 상위 10%%부터 받아요 (상위 %s등까지)").format(starCut),
                                    fontSize = 11.sp, color = Color(0xFFB8C4F0))
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(top10pct, key = { it.rank }) { u ->
                        val badge = com.navifit.social.PlaygroundRank.badgeFor(u.rank, ranking.size)
                        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("${u.rank}", fontWeight = FontWeight.Bold, fontSize = 13.sp,
                                color = if (u.rank <= 3) Color(0xFFFFD700) else Color.Gray, modifier = Modifier.width(28.dp))
                            Column(Modifier.weight(1f)) {
                                Text((if (u.isMe) "🙋 " else "") + u.nickname, fontSize = 13.sp,
                                    fontWeight = if (u.isMe) FontWeight.ExtraBold else FontWeight.Normal)
                                if (!badge.isEmpty) GlowingStars(color = badge.color, count = badge.count, size = 11.dp)
                            }
                            Text("❤️ ${u.totalLikes}", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B9FFF))) { Text(tr("닫기")) }
            }
        }
    }
}

private fun timeAgo(ts: Long): String {
    val diff = (System.currentTimeMillis() - ts) / 1000
    return when {
        diff < 60 -> "방금 전"
        diff < 3600 -> "${diff / 60}분 전"
        diff < 86400 -> "${diff / 3600}시간 전"
        else -> "${diff / 86400}일 전"
    }
}

/** ✅ v86 작성자 행동 메뉴 한 줄 */
@androidx.compose.runtime.Composable
private fun AuthorMenuRow(label: String, onClick: () -> Unit) {
    androidx.compose.material3.Text(
        label,
        fontSize = 15.sp,
        fontWeight = androidx.compose.ui.text.font.FontWeight.Medium,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
        modifier = androidx.compose.ui.Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 12.dp)
    )
}
