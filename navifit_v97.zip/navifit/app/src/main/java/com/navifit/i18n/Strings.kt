package com.navifit.i18n

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.staticCompositionLocalOf

/**
 * 앱 언어 설정.
 * 내정보 > 언어 설정에서 고르면 SharedPreferences에 저장되고,
 * 아래 AppStrings 테이블을 통해 하단 탭바 + 각 화면 상단 헤더까지 즉시 그 언어로 바뀜.
 *
 * ⚠️ 화면 곳곳의 세부 문구(예: 커뮤니티 글 작성 다이얼로그 안내문 하나하나)까지 전부 이 시스템으로
 *    옮기려면 각 화면의 하드코딩된 Text(...)를 LocalStrings.current.xxx 로 계속 바꿔주는 작업이
 *    필요함 - 구조 자체는 전 화면에서 재사용 가능하게 만들어져 있어 점진적으로 확장 가능.
 */
enum class AppLanguage(val code: String, val nativeName: String, val flag: String) {
    KOREAN("ko", "한국어", "🇰🇷"),
    ENGLISH("en", "English", "🇺🇸"),
    JAPANESE("ja", "日本語", "🇯🇵"),
    CHINESE("zh", "中文", "🇨🇳"),
    SPANISH("es", "Español", "🇪🇸"),
    FRENCH("fr", "Français", "🇫🇷"),
    GERMAN("de", "Deutsch", "🇩🇪"),
    PORTUGUESE("pt", "Português", "🇧🇷"),
    VIETNAMESE("vi", "Tiếng Việt", "🇻🇳"),
    THAI("th", "ภาษาไทย", "🇹🇭"),
    INDONESIAN("id", "Bahasa Indonesia", "🇮🇩"),
    RUSSIAN("ru", "Русский", "🇷🇺"),
    ITALIAN("it", "Italiano", "🇮🇹"),
    ARABIC("ar", "العربية", "🇸🇦"),
    HINDI("hi", "हिन्दी", "🇮🇳")
}

data class AppStrings(
    val navNavigate: String, val navGacha: String, val navAnalytics: String,
    val navRanking: String, val navCommunity: String, val navProfile: String,
    val whereToGo: String, val destinationInput: String, val startNavigation: String,
    val myWorkoutAnalytics: String, val ranking: String, val community: String,
    val myInfo: String, val logout: String, val logoutConfirm: String,
    val nicknameChange: String, val googleLink: String
)

val koStrings = AppStrings(
    navNavigate = "길찾기", navGacha = "뽑기", navAnalytics = "분석", navRanking = "랭킹",
    navCommunity = "운동장", navProfile = "내정보",
    whereToGo = "어디로 떠날까요?", destinationInput = "목적지 입력", startNavigation = "길찾기 시작",
    myWorkoutAnalytics = "나의 분석", ranking = "🏆 랭킹", community = "운동장",
    myInfo = "내정보", logout = "로그아웃", logoutConfirm = "로그아웃 할까요?",
    nicknameChange = "닉네임 변경", googleLink = "Google 계정 연결하기"
)
val enStrings = AppStrings(
    navNavigate = "Navigate", navGacha = "Gacha", navAnalytics = "Stats", navRanking = "Ranking",
    navCommunity = "Playground", navProfile = "Profile",
    whereToGo = "Where to?", destinationInput = "Enter destination", startNavigation = "Start navigation",
    myWorkoutAnalytics = "My Stats", ranking = "🏆 Ranking", community = "Playground",
    myInfo = "Profile", logout = "Log out", logoutConfirm = "Log out?",
    nicknameChange = "Change nickname", googleLink = "Connect Google account"
)
val jaStrings = AppStrings(
    navNavigate = "ナビ", navGacha = "ガチャ", navAnalytics = "分析", navRanking = "ランキング",
    navCommunity = "うんどう場", navProfile = "マイページ",
    whereToGo = "どこへ行きますか?", destinationInput = "目的地を入力", startNavigation = "案内開始",
    myWorkoutAnalytics = "私の分析", ranking = "🏆 ランキング", community = "運動場",
    myInfo = "マイページ", logout = "ログアウト", logoutConfirm = "ログアウトしますか?",
    nicknameChange = "ニックネーム変更", googleLink = "Googleアカウントを連携"
)
val zhStrings = AppStrings(
    navNavigate = "导航", navGacha = "扭蛋", navAnalytics = "分析", navRanking = "排行榜",
    navCommunity = "运动场", navProfile = "我的",
    whereToGo = "要去哪里?", destinationInput = "输入目的地", startNavigation = "开始导航",
    myWorkoutAnalytics = "我的分析", ranking = "🏆 排行榜", community = "运动场",
    myInfo = "我的", logout = "退出登录", logoutConfirm = "确定要退出登录吗?",
    nicknameChange = "修改昵称", googleLink = "关联 Google 账号"
)
val esStrings = AppStrings(
    navNavigate = "Navegar", navGacha = "Gacha", navAnalytics = "Estadísticas", navRanking = "Ranking",
    navCommunity = "Patio", navProfile = "Perfil",
    whereToGo = "¿A dónde vamos?", destinationInput = "Ingresa destino", startNavigation = "Iniciar navegación",
    myWorkoutAnalytics = "Mis estadísticas", ranking = "🏆 Ranking", community = "Patio deportivo",
    myInfo = "Perfil", logout = "Cerrar sesión", logoutConfirm = "¿Cerrar sesión?",
    nicknameChange = "Cambiar apodo", googleLink = "Conectar cuenta de Google"
)
val frStrings = AppStrings(
    navNavigate = "Itinéraire", navGacha = "Gacha", navAnalytics = "Stats", navRanking = "Classement",
    navCommunity = "Terrain", navProfile = "Profil",
    whereToGo = "Où allons-nous ?", destinationInput = "Entrer une destination", startNavigation = "Démarrer",
    myWorkoutAnalytics = "Mes statistiques", ranking = "🏆 Classement", community = "Terrain de sport",
    myInfo = "Profil", logout = "Déconnexion", logoutConfirm = "Se déconnecter ?",
    nicknameChange = "Changer de pseudo", googleLink = "Connecter un compte Google"
)
val deStrings = AppStrings(
    navNavigate = "Navigation", navGacha = "Gacha", navAnalytics = "Statistik", navRanking = "Rangliste",
    navCommunity = "Sportplatz", navProfile = "Profil",
    whereToGo = "Wohin geht's?", destinationInput = "Ziel eingeben", startNavigation = "Navigation starten",
    myWorkoutAnalytics = "Meine Statistik", ranking = "🏆 Rangliste", community = "Sportplatz",
    myInfo = "Profil", logout = "Abmelden", logoutConfirm = "Abmelden?",
    nicknameChange = "Nickname ändern", googleLink = "Google-Konto verbinden"
)
val ptStrings = AppStrings(
    navNavigate = "Navegar", navGacha = "Gacha", navAnalytics = "Estatísticas", navRanking = "Ranking",
    navCommunity = "Quadra", navProfile = "Perfil",
    whereToGo = "Para onde vamos?", destinationInput = "Digite o destino", startNavigation = "Iniciar navegação",
    myWorkoutAnalytics = "Minhas estatísticas", ranking = "🏆 Ranking", community = "Quadra esportiva",
    myInfo = "Perfil", logout = "Sair", logoutConfirm = "Deseja sair?",
    nicknameChange = "Alterar apelido", googleLink = "Conectar conta do Google"
)
val viStrings = AppStrings(
    navNavigate = "Chỉ đường", navGacha = "Gacha", navAnalytics = "Thống kê", navRanking = "Bảng xếp hạng",
    navCommunity = "Sân chơi", navProfile = "Hồ sơ",
    whereToGo = "Bạn muốn đi đâu?", destinationInput = "Nhập điểm đến", startNavigation = "Bắt đầu chỉ đường",
    myWorkoutAnalytics = "Thống kê của tôi", ranking = "🏆 Bảng xếp hạng", community = "Sân vận động",
    myInfo = "Hồ sơ", logout = "Đăng xuất", logoutConfirm = "Đăng xuất?",
    nicknameChange = "Đổi biệt danh", googleLink = "Liên kết tài khoản Google"
)
val thStrings = AppStrings(
    navNavigate = "นำทาง", navGacha = "กาชา", navAnalytics = "สถิติ", navRanking = "อันดับ",
    navCommunity = "สนามกีฬา", navProfile = "โปรไฟล์",
    whereToGo = "จะไปไหนดี?", destinationInput = "ป้อนจุดหมาย", startNavigation = "เริ่มนำทาง",
    myWorkoutAnalytics = "สถิติของฉัน", ranking = "🏆 อันดับ", community = "สนามกีฬา",
    myInfo = "โปรไฟล์", logout = "ออกจากระบบ", logoutConfirm = "ออกจากระบบ?",
    nicknameChange = "เปลี่ยนชื่อเล่น", googleLink = "เชื่อมต่อบัญชี Google"
)
val idStrings = AppStrings(
    navNavigate = "Navigasi", navGacha = "Gacha", navAnalytics = "Statistik", navRanking = "Peringkat",
    navCommunity = "Lapangan", navProfile = "Profil",
    whereToGo = "Mau ke mana?", destinationInput = "Masukkan tujuan", startNavigation = "Mulai navigasi",
    myWorkoutAnalytics = "Statistik saya", ranking = "🏆 Peringkat", community = "Lapangan olahraga",
    myInfo = "Profil", logout = "Keluar", logoutConfirm = "Keluar?",
    nicknameChange = "Ubah nama panggilan", googleLink = "Hubungkan akun Google"
)
val ruStrings = AppStrings(
    navNavigate = "Навигация", navGacha = "Гача", navAnalytics = "Статистика", navRanking = "Рейтинг",
    navCommunity = "Площадка", navProfile = "Профиль",
    whereToGo = "Куда направляемся?", destinationInput = "Введите пункт назначения", startNavigation = "Начать навигацию",
    myWorkoutAnalytics = "Моя статистика", ranking = "🏆 Рейтинг", community = "Спортплощадка",
    myInfo = "Профиль", logout = "Выйти", logoutConfirm = "Выйти из аккаунта?",
    nicknameChange = "Изменить никнейм", googleLink = "Подключить аккаунт Google"
)
val itStrings = AppStrings(
    navNavigate = "Naviga", navGacha = "Gacha", navAnalytics = "Statistiche", navRanking = "Classifica",
    navCommunity = "Campo", navProfile = "Profilo",
    whereToGo = "Dove andiamo?", destinationInput = "Inserisci destinazione", startNavigation = "Avvia navigazione",
    myWorkoutAnalytics = "Le mie statistiche", ranking = "🏆 Classifica", community = "Campo sportivo",
    myInfo = "Profilo", logout = "Disconnetti", logoutConfirm = "Disconnettersi?",
    nicknameChange = "Cambia nickname", googleLink = "Collega account Google"
)
val arStrings = AppStrings(
    navNavigate = "الملاحة", navGacha = "غاتشا", navAnalytics = "الإحصائيات", navRanking = "الترتيب",
    navCommunity = "الملعب", navProfile = "الملف الشخصي",
    whereToGo = "إلى أين نذهب؟", destinationInput = "أدخل الوجهة", startNavigation = "بدء الملاحة",
    myWorkoutAnalytics = "إحصائياتي", ranking = "🏆 الترتيب", community = "الملعب",
    myInfo = "الملف الشخصي", logout = "تسجيل الخروج", logoutConfirm = "هل تريد تسجيل الخروج؟",
    nicknameChange = "تغيير الاسم المستعار", googleLink = "ربط حساب Google"
)
val hiStrings = AppStrings(
    navNavigate = "नेविगेट", navGacha = "गाचा", navAnalytics = "आंकड़े", navRanking = "रैंकिंग",
    navCommunity = "मैदान", navProfile = "प्रोफ़ाइल",
    whereToGo = "कहाँ चलना है?", destinationInput = "गंतव्य दर्ज करें", startNavigation = "नेविगेशन शुरू करें",
    myWorkoutAnalytics = "मेरे आंकड़े", ranking = "🏆 रैंकिंग", community = "खेल का मैदान",
    myInfo = "प्रोफ़ाइल", logout = "लॉग आउट", logoutConfirm = "लॉग आउट करें?",
    nicknameChange = "उपनाम बदलें", googleLink = "Google खाता कनेक्ट करें"
)

fun stringsFor(lang: AppLanguage): AppStrings = when (lang) {
    AppLanguage.KOREAN -> koStrings
    AppLanguage.ENGLISH -> enStrings
    AppLanguage.JAPANESE -> jaStrings
    AppLanguage.CHINESE -> zhStrings
    AppLanguage.SPANISH -> esStrings
    AppLanguage.FRENCH -> frStrings
    AppLanguage.GERMAN -> deStrings
    AppLanguage.PORTUGUESE -> ptStrings
    AppLanguage.VIETNAMESE -> viStrings
    AppLanguage.THAI -> thStrings
    AppLanguage.INDONESIAN -> idStrings
    AppLanguage.RUSSIAN -> ruStrings
    AppLanguage.ITALIAN -> itStrings
    AppLanguage.ARABIC -> arStrings
    AppLanguage.HINDI -> hiStrings
}

val LocalAppLanguage = compositionLocalOf { AppLanguage.KOREAN }
val LocalStrings = staticCompositionLocalOf { koStrings }

/**
 * ✅ v41 언어 저장소.
 * MainActivity가 settings/lang 에 저장하는 값을 어디서든 읽을 수 있게 함
 * (번역 대상 언어 판단, TTS 언어 설정 등에 사용).
 */
object LanguageStore {
    fun current(c: android.content.Context): AppLanguage {
        val code = c.getSharedPreferences("settings", android.content.Context.MODE_PRIVATE)
            .getString("lang", "ko") ?: "ko"
        return AppLanguage.entries.firstOrNull { it.code == code } ?: AppLanguage.KOREAN
    }

    /** TTS·시스템 로케일용 */
    fun locale(c: android.content.Context): java.util.Locale = when (current(c)) {
        AppLanguage.KOREAN -> java.util.Locale.KOREAN
        AppLanguage.ENGLISH -> java.util.Locale.ENGLISH
        AppLanguage.JAPANESE -> java.util.Locale.JAPANESE
        AppLanguage.CHINESE -> java.util.Locale.CHINESE
        AppLanguage.FRENCH -> java.util.Locale.FRENCH
        AppLanguage.GERMAN -> java.util.Locale.GERMAN
        AppLanguage.ITALIAN -> java.util.Locale.ITALIAN
        else -> java.util.Locale(current(c).code)
    }
}

/**
 * ✅ v41 뽑기·내비 화면 문구 다국어 테이블.
 *
 * 기존 AppStrings는 탭/헤더 17개만 있어서 뽑기·내비 화면이 전부 한국어로 고정돼 있었음.
 * 여기서 확장 (한/영/일/중/스 완비, 그 외 언어는 영어로 폴백 - 최소한 읽을 수는 있게).
 */
object UiText {
    private val table: Map<String, Map<String, String>> = mapOf(
        // ── 뽑기 ──
        "gacha_draw" to mapOf(
            "ko" to "뽑기", "en" to "Draw", "ja" to "ガチャ", "zh" to "抽奖", "es" to "Sorteo"),
        "gacha_owned" to mapOf(
            "ko" to "보유", "en" to "Owned", "ja" to "所持", "zh" to "拥有", "es" to "Poseídos"),
        "gacha_border" to mapOf(
            "ko" to "테두리", "en" to "Borders", "ja" to "フレーム", "zh" to "边框", "es" to "Bordes"),
        "gacha_rates" to mapOf(
            "ko" to "확률 고시", "en" to "Drop Rates", "ja" to "確率表記", "zh" to "概率公示", "es" to "Probabilidades"),
        "gacha_draw_btn" to mapOf(
            "ko" to "뽑기 (1회)", "en" to "Draw (1x)", "ja" to "ガチャを引く", "zh" to "抽一次", "es" to "Sortear (1x)"),
        "gacha_fusion" to mapOf(
            "ko" to "합성", "en" to "Fuse", "ja" to "合成", "zh" to "合成", "es" to "Fusionar"),
        "gacha_equip" to mapOf(
            "ko" to "장착", "en" to "Equip", "ja" to "装備", "zh" to "装备", "es" to "Equipar"),
        "gacha_equipped" to mapOf(
            "ko" to "장착 중", "en" to "Equipped", "ja" to "装備中", "zh" to "已装备", "es" to "Equipado"),
        "gacha_locked" to mapOf(
            "ko" to "잠김", "en" to "Locked", "ja" to "ロック", "zh" to "未解锁", "es" to "Bloqueado"),
        // ── 내비 ──
        "nav_start" to mapOf(
            "ko" to "안내 시작", "en" to "Start", "ja" to "案内開始", "zh" to "开始导航", "es" to "Iniciar"),
        "nav_finish" to mapOf(
            "ko" to "도착 종료", "en" to "End", "ja" to "終了", "zh" to "结束", "es" to "Finalizar"),
        "nav_arrive" to mapOf(
            "ko" to "도착", "en" to "Arrival", "ja" to "到着", "zh" to "到达", "es" to "Llegada"),
        "nav_remaining" to mapOf(
            "ko" to "남음", "en" to "left", "ja" to "残り", "zh" to "剩余", "es" to "restante"),
        "nav_rerouting" to mapOf(
            "ko" to "경로 재탐색 중...", "en" to "Rerouting...", "ja" to "再検索中...", "zh" to "重新规划中...", "es" to "Recalculando..."),
        "nav_offroute" to mapOf(
            "ko" to "경로 이탈", "en" to "Off route", "ja" to "ルート外れ", "zh" to "偏离路线", "es" to "Fuera de ruta"),
        "nav_tunnel" to mapOf(
            "ko" to "터널 구간 · 위치 추정 중", "en" to "Tunnel · estimating position",
            "ja" to "トンネル・位置推定中", "zh" to "隧道·位置推算中", "es" to "Túnel · estimando posición"),
        "nav_gps_weak" to mapOf(
            "ko" to "GPS 약함", "en" to "Weak GPS", "ja" to "GPS弱い", "zh" to "GPS信号弱", "es" to "GPS débil"),
        "nav_faster" to mapOf(
            "ko" to "더 빠른 길이 있어요", "en" to "A faster route is available",
            "ja" to "より速いルートがあります", "zh" to "有更快的路线", "es" to "Hay una ruta más rápida"),
        "nav_camera" to mapOf(
            "ko" to "단속 카메라", "en" to "Speed camera", "ja" to "取締りカメラ", "zh" to "测速摄像头", "es" to "Radar"),
        "nav_no_network" to mapOf(
            "ko" to "인터넷 연결이 없어요", "en" to "No internet connection",
            "ja" to "インターネット接続がありません", "zh" to "无网络连接", "es" to "Sin conexión a internet"),
        // ── 번역 ──
        "nav_follow_route" to mapOf(
            "ko" to "경로를 따라 진행하세요", "en" to "Follow the route", "ja" to "ルートに沿って進んでください",
            "zh" to "请沿路线行驶", "es" to "Siga la ruta"),
        "nav_arrive_in" to mapOf(
            "ko" to "도착", "en" to "arrival", "ja" to "到着", "zh" to "到达", "es" to "llegada"),
        "translate_show" to mapOf(
            "ko" to "🌐 번역 보기", "en" to "🌐 See translation", "ja" to "🌐 翻訳を見る",
            "zh" to "🌐 查看翻译", "es" to "🌐 Ver traducción"),
        "translate_original" to mapOf(
            "ko" to "🌐 원문 보기", "en" to "🌐 See original", "ja" to "🌐 原文を見る",
            "zh" to "🌐 查看原文", "es" to "🌐 Ver original")
    )

    /** 키 + 언어코드 → 문구 (없으면 영어, 그것도 없으면 키 그대로) */
    fun get(key: String, langCode: String): String {
        val row = table[key] ?: return key
        return row[langCode] ?: row["en"] ?: key
    }

    fun get(key: String, c: android.content.Context): String =
        get(key, LanguageStore.current(c).code)
}
