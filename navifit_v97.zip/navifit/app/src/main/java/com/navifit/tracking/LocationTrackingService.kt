package com.navifit.tracking

import android.app.*
import android.content.Context
import android.content.Intent
import android.location.Location
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import com.navifit.navigation.LatLngPoint
import com.navifit.navigation.TravelMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * 실시간 위치추적 포그라운드 서비스
 *
 * 배터리 최적화 핵심 포인트:
 * 1. 이동수단별로 위치 갱신 주기를 다르게 설정 (도보는 느슨하게, 오토바이/자동차는 촘촘하게)
 * 2. 포그라운드 서비스 + 알림으로 안드로이드가 백그라운드에서 죽이지 않도록 함
 * 3. 화면 꺼져있을 때는 PRIORITY_BALANCED_POWER_ACCURACY로 낮춰서 배터리 절약
 */
class LocationTrackingService : Service() {

    companion object {
        const val CHANNEL_ID = "navifit_tracking_channel"
        const val NOTIFICATION_ID = 1001

        // 이동수단별 위치 업데이트 간격 (밀리초) - 화면 켜짐 기준, 배터리 최적화 핵심
        private val UPDATE_INTERVALS = mapOf(
            // ✅ v68 실시간 추종: 모든 모드 1초 (카카오/네이버 내비 수준). 화면 켜짐 기준.
            TravelMode.WALK to 1000L,
            TravelMode.BIKE to 1000L,
            TravelMode.MOTORCYCLE to 1000L,
            TravelMode.CAR to 1000L
        )
        // 화면이 꺼져있거나 딴 앱을 보고 있을 때: 간격을 늘리고 정확도를 낮춰서 발열/배터리 절약
        private val BACKGROUND_UPDATE_INTERVALS = mapOf(
            TravelMode.WALK to 3000L,
            TravelMode.BIKE to 2000L,
            TravelMode.MOTORCYCLE to 2000L,
            TravelMode.CAR to 2000L
        )
        // 이 거리(m) 이상 움직였을 때만 갱신 - 정지 상태에서 GPS가 계속 깨어나며 발열나는 것을 방지
        // ✅ v68 실시간 추종 위해 0으로 (필터는 앱단에서). 정지 시 발열은 도플러 속도 게이트로 방지.
        private val MIN_DISPLACEMENT_METERS = mapOf(
            TravelMode.WALK to 0f,
            TravelMode.BIKE to 0f,
            TravelMode.MOTORCYCLE to 0f,
            TravelMode.CAR to 0f
        )

        private val _trackingState = MutableStateFlow(TrackingSnapshot())
        val trackingState: StateFlow<TrackingSnapshot> = _trackingState

        fun startWithMode(context: android.content.Context, mode: TravelMode) {
            val intent = Intent(context, LocationTrackingService::class.java).apply {
                putExtra("mode", mode.name)
            }
            context.startForegroundService(intent)
        }

        fun stop(context: android.content.Context) {
            context.stopService(Intent(context, LocationTrackingService::class.java))
        }

        // ✅ v61 긴급 안내(화장실 경유) 중 운동 일시정지: 거리·시간 누적 동결
        @Volatile var paused = false
    }

    data class TrackingSnapshot(
        val currentLocation: LatLngPoint? = null,
        val speedKmh: Double = 0.0,
        val totalDistanceMeters: Double = 0.0,
        val elapsedSeconds: Long = 0,
        val startTimeMillis: Long = 0L,        // ✅ v63 매끄러운 1초 타이머용 (UI에서 직접 계산)
        val bearingDegrees: Float = 0f, // GPS가 제공하는 진행 방향 (오토바이/자동차 리닝 판정 등에 사용)
        val isAfterSignalGap: Boolean = false, // ✅ 터널 등으로 GPS 신호가 끊겼다 이 위치에서 다시 잡힌 경우 true
        val accuracyMeters: Float = 0f,        // ✅ v33 현재 GPS 오차 (UI에 신호 품질 표시)
        val satellitesUsed: Int = 0,           // ✅ v84 측위에 사용된 위성 개수 (하늘 상태 실측)
        val elevationGainMeters: Double = 0.0, // ✅ v90 누적 상승고도 (기압계 기반)
        val elevationLossMeters: Double = 0.0, // ✅ v90 누적 하강고도
        val gpsStatusText: String = "",        // ✅ v84 "GPS 양호 (위성 9개)" 같은 안내 문구
        val movingSeconds: Long = 0L,          // ✅ v33 실제 이동시간 (정지·신호대기 제외 - 운동 페이스 계산용)
        val maxRestSeconds: Long = 0L          // ✅ v34 한 번에 가장 오래 쉰 시간 ("한 번에 달성" 테두리 검증)
    )

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var locationCallback: LocationCallback? = null
    private var currentMode: TravelMode = TravelMode.default()
    private var lastLocation: Location? = null
    private val smoother = GpsSmoother()   // ✅ v81 지그재그 제거 필터
    // ✅ v84 위성 상태 직접 판독 (터널 오판 제거 + 하늘 상태별 필터 강도 조절)
    private val gnss by lazy { GnssQualityMonitor(this) }
    // ✅ v90 기압계 고도 측정 (누적 상승고도 - 러닝·자전거 핵심 지표)
    private val elevation by lazy { ElevationTracker(this) }
    // ✅ v90 CPU 유지용 부분 웨이크락.
    //   포그라운드 서비스만으로는 화면이 꺼졌을 때 일부 기기가 CPU를 재워
    //   위치 콜백이 끊기는 사례가 있어, 운동 중에만 부분 웨이크락을 잡는다.
    private var wakeLock: android.os.PowerManager.WakeLock? = null
    private var lastReceivedAtMillis: Long = 0L
    // ✅ v67 터널 오탐 완화: 신호단절 기준을 8s→15s로 (도심에서 잠깐 오차 커진 걸 터널로 오판하던 문제)
    private val GAP_THRESHOLD_MS = 15000L
    private var totalDistance = 0.0
    private var movingSeconds = 0.0   // ✅ v33 실제 이동시간 누적(초)
    private var currentRestSeconds = 0.0  // ✅ v34 지금 연속으로 쉬고 있는 시간
    private var maxRestSeconds = 0.0      // ✅ v34 한 번에 가장 오래 쉰 시간
    private var startTimeMillis = 0L
    private var isScreenOn = true

    /** ✅ 화면 꺼짐/켜짐 감지 -> 꺼지면 자동으로 저전력 모드(간격 늘리고 정확도 낮춤)로 전환해서 발열·배터리 절약 */
    private val screenStateReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> { isScreenOn = false; restartLocationUpdates() }
                Intent.ACTION_SCREEN_ON -> { isScreenOn = true; restartLocationUpdates() }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        createNotificationChannel()
        androidx.core.content.ContextCompat.registerReceiver(
            this, screenStateReceiver,
            android.content.IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
            },
            androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // ✅ 유령 추적 수정: intent가 null이면 사용자가 시작한 게 아니라 시스템이 멋대로 재시작한 것.
        //    (예전엔 이때 기본모드(도보)로 추적을 시작해서 "운동 시작도 안 눌렀는데
        //     NaviFit 추적 중 · 400m 걸음" 알림이 뜨는 문제가 있었음)
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val modeName = intent.getStringExtra("mode") ?: TravelMode.default().name
        currentMode = TravelMode.valueOf(modeName)
        startTimeMillis = System.currentTimeMillis()
        totalDistance = 0.0
        smoother.reset()
        movingSeconds = 0.0
        currentRestSeconds = 0.0
        maxRestSeconds = 0.0
        lastLocation = null
        lastReceivedAtMillis = 0L
        // ✅ v85 UI가 구독하는 스냅샷도 즉시 0으로 초기화.
        //   (기존 버그: 내부 변수만 리셋하고 _trackingState는 이전 운동 값을 들고 있어서,
        //    따라뛰기 시작 직후 종료하면 지난 운동의 거리·시간이 그대로 불려나왔음)
        elevation.reset()   // ✅ v90 새 운동 시작 시 고도 누적 초기화
        _trackingState.value = TrackingSnapshot(startTimeMillis = startTimeMillis)

        startForeground(NOTIFICATION_ID, buildNotification(
            if (currentMode.isWorkoutMode) "운동 안내 시작..." else "주행 안내 시작..."
        ))
        startLocationUpdates()

        return START_NOT_STICKY // ✅ 사용자가 시작한 안내 중에만 동작 - 시스템 자동 재시작 금지
    }

    /** ✅ 앱을 최근앱에서 스와이프해 완전히 끄면 추적도 함께 종료 (배터리 보호) */
    override fun onTaskRemoved(rootIntent: Intent?) {
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    private fun startLocationUpdates() {
        // ✅ 화면 꺼짐 여부에 따라 간격/정확도를 동적으로 조정 (배터리·발열 절약 핵심)
        // ✅ v63: 운동(WALK/BIKE) 중에는 화면이 꺼져도 고정밀 유지 - 주머니에 넣고 뛰는 경우가 많아서.
        //   (자동차/오토바이 주행은 기존대로 화면 off 시 절전)
        val activeWorkout = currentMode.isWorkoutMode
        val effectiveHighAccuracy = isScreenOn || activeWorkout
        val intervalMs = if (effectiveHighAccuracy) UPDATE_INTERVALS[currentMode] ?: 3000L
                          else BACKGROUND_UPDATE_INTERVALS[currentMode] ?: 6000L
        val priority = if (effectiveHighAccuracy) Priority.PRIORITY_HIGH_ACCURACY else Priority.PRIORITY_BALANCED_POWER_ACCURACY
        val displacement = MIN_DISPLACEMENT_METERS[currentMode] ?: 4f

        // ✅ v62~63 위치 정확도 향상: GNSS(GPS/글로나스/갈릴레오/베이더우) + 기지국 + Wi-Fi를 fused가 융합
        //   - 운동 중이면 화면이 꺼져 있어도 waitForAccurateLocation=true로 튐 좌표 감소
        //   - 최소 이동거리 0으로 촘촘히 받고, 필터는 앱단(MainActivity 궤적 필터)에서 처리
        val request = LocationRequest.Builder(priority, intervalMs)
            .setMinUpdateIntervalMillis(if (effectiveHighAccuracy) 1000L else intervalMs / 2)
            .setWaitForAccurateLocation(effectiveHighAccuracy)
            .setMinUpdateDistanceMeters(if (effectiveHighAccuracy) 0f else displacement)
            .setMaxUpdateDelayMillis(intervalMs * 2)
            .build()

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val location = result.lastLocation ?: return
                handleNewLocation(location)
            }
        }

        try {
            fusedLocationClient.requestLocationUpdates(
                request,
                locationCallback as LocationCallback,
                mainLooper
            )
            gnss.start()   // ✅ v84 위성 상태 판독 시작
            elevation.start()  // ✅ v90 기압계 고도 측정 시작
            // ✅ v90 부분 웨이크락 (화면 꺼져도 위치 콜백 유지)
            try {
                if (wakeLock == null) {
                    val pm = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                    wakeLock = pm.newWakeLock(
                        android.os.PowerManager.PARTIAL_WAKE_LOCK, "NaviFit::TrackingLock")
                }
                if (wakeLock?.isHeld != true) wakeLock?.acquire(6 * 60 * 60 * 1000L) // 최대 6시간
            } catch (_: Exception) { }
        } catch (e: SecurityException) {
            // 권한 없음 - 실제 앱에서는 사용자에게 권한 요청 화면으로 유도해야 함
            stopSelf()
        }
    }

    /** 화면 on/off 전환 시 기존 구독을 갈아끼움 (간격/정확도 재조정) */
    private fun restartLocationUpdates() {
        locationCallback?.let { fusedLocationClient.removeLocationUpdates(it) }
        startLocationUpdates()
    }

    private fun handleNewLocation(location: Location) {
        val previous = lastLocation
        val now = System.currentTimeMillis()

        // ✅ v90 기압계가 없는 기기: GPS 고도로 상승고도 폴백 계산
        if (!elevation.hasBarometer && location.hasAltitude()) {
            elevation.onGpsAltitude(location.altitude)
        }

        // ✅ v61 긴급 안내로 일시정지 중: 위치는 갱신(지도 따라감)하되 거리·시간은 누적하지 않음
        if (paused) {
            lastLocation = location
            _trackingState.value = _trackingState.value.copy(
                currentLocation = LatLngPoint(location.latitude, location.longitude)
            )
            return
        }

        // ═══════════ v40: 정확도 게이트 (치명적 버그 수정) ═══════════
        // ⚠️ 기존 버그: 오차 큰 fix를 버리면서 lastReceivedAtMillis를 갱신했음.
        //    → 터널에서 약한 신호(오차 60m)가 2초마다 계속 들어오면 전부 버려지는데 타이머는 매번 리셋되어
        //      "15초 이상 못 받으면 받아들인다"는 예외가 영원히 발동하지 않음 → GPS가 영구히 멈춰 보였음.
        //    이제 거절된 샘플은 타이머를 건드리지 않아, 진짜 데이터 공백이 정확히 측정됨.
        val acc = if (location.hasAccuracy()) location.accuracy else 999f
        val staleMs = if (lastReceivedAtMillis > 0) now - lastReceivedAtMillis else 0L
        val dtForJump = if (lastReceivedAtMillis > 0) (now - lastReceivedAtMillis) / 1000.0 else 1.0

        // ✅ v84 하늘 상태(위성 실측)에 따라 필터 강도를 다르게.
        //   하늘이 트인 곳(위성 6개+, 신호 강함)에선 관대하게 → 정상 fix를 안 버림
        //   가려진 곳에선 엄격하게 → 반사파(멀티패스)로 인한 튐을 차단
        val skyOpen = gnss.skyState == GnssQualityMonitor.SkyState.OPEN
        val skyBlocked = gnss.isTrulyBlocked()
        val jumpTolerance = if (skyOpen) 3.0 else if (skyBlocked) 1.3 else 2.0

        // ✅ v70 순간이동(텔레포트) 방어: 물리적으로 불가능한 점프는 화면에 반영하지 않음.
        val maxJumpM = when (currentMode) {
            TravelMode.WALK -> 12.0; TravelMode.BIKE -> 30.0
            TravelMode.MOTORCYCLE -> 80.0; else -> 90.0
        } * dtForJump.coerceIn(1.0, 10.0) * jumpTolerance
        val jumpDist = previous?.distanceTo(location)?.toDouble() ?: 0.0
        if (previous != null && jumpDist > maxJumpM && jumpDist > 60.0 && staleMs < 12_000L) {
            return
        }

        // ✅ v84 정확도 한계도 하늘 상태에 맞춰 동적으로.
        //   (기존 고정 45m는 도심에서 정상 fix까지 버려서 "위치가 안 따라옴" 원인이 됐음)
        val accLimit = if (gnss.hasSatelliteInfo()) {
            gnss.trustRadiusMeters().coerceAtLeast(if (currentMode.isWorkoutMode) 30f else 40f)
        } else {
            if (currentMode.isWorkoutMode) 45f else 60f
        }
        val poorAccuracy = acc > accLimit && staleMs < 15_000L && previous != null
        if (poorAccuracy) {
            lastReceivedAtMillis = now
            // ✅ v81 정확도 나쁜 점도 스무더를 통과시켜 부드럽게만 반영 (지그재그 차단)
            val sp = smoother.process(
                location.latitude, location.longitude, acc, dtForJump,
                if (location.hasSpeed()) location.speed.toDouble() else _trackingState.value.speedKmh / 3.6
            )
            if (sp != null) {
                lastLocation = location
                _trackingState.value = _trackingState.value.copy(
                    currentLocation = sp,
                    bearingDegrees = if (location.hasBearing() && location.speed > 1.0f) location.bearing
                                     else _trackingState.value.bearingDegrees,
                    accuracyMeters = acc,
                    satellitesUsed = gnss.satellitesUsed,
                    gpsStatusText = gnss.statusText(),
                    isAfterSignalGap = false
                )
            }
            return
        }

        val gapMs = if (lastReceivedAtMillis > 0) now - lastReceivedAtMillis else 0L
        // ✅ v84 "신호 두절(터널)" 판정을 위성 실측 기준으로 교체.
        //   기존: 15초간 위치 업데이트가 없으면 무조건 터널 → 배터리 절전·Doze로 업데이트가
        //         늦어져도 터널로 오판해서, 하늘이 훤히 보이는 야외에서 "터널" 문구가 떴다.
        //   변경: 위성 정보를 받을 수 있는 기기면 "측위 위성 4개 미만"일 때만 두절로 본다.
        //         위성 정보를 못 받는 구형 기기에서만 기존 시간 기준을 폴백으로 사용.
        val afterGap = if (gnss.hasSatelliteInfo()) {
            gnss.isTrulyBlocked() && gapMs > GAP_THRESHOLD_MS
        } else {
            gapMs > GAP_THRESHOLD_MS
        }

        // ② 속도 산출: provider가 speed를 안 주는 기기 대비 위치차 기반 계산으로 폴백
        val providerSpeed = if (location.hasSpeed() && location.speed > 0f) location.speed * 3.6 else -1.0
        val rawDelta = previous?.distanceTo(location)?.toDouble() ?: 0.0
        val dtSec = (gapMs / 1000.0).coerceAtLeast(0.001)
        val computedSpeed = if (previous != null && gapMs in 1..30_000) (rawDelta / dtSec) * 3.6 else 0.0
        var speedKmh = (if (providerSpeed >= 0) providerSpeed else computedSpeed).coerceAtLeast(0.0)

        // ③ 물리적 상한: 모드별 불가능한 속도는 노이즈로 간주 (거리 폭증·부정행위 오판 방지)
        val maxPlausible = when (currentMode) {
            TravelMode.WALK -> 32.0      // 세계기록 스프린트도 45km/h, 지속 32 넘으면 GPS 오류
            TravelMode.BIKE -> 90.0
            TravelMode.MOTORCYCLE -> 200.0
            TravelMode.CAR -> 220.0
        }
        if (speedKmh > maxPlausible) speedKmh = _trackingState.value.speedKmh  // 직전 값 유지

        // ④ 거리 누적 방어
        var accepted = 0.0
        if (previous != null) {
            val plausibleMax = (maxPlausible / 3.6) * dtSec * 1.3   // 이 시간에 물리적으로 갈 수 있는 최대거리
            // ✅ v55: "가만히 있는데 km가 올라가는" 버그 수정 2종
            //  ⑴ GPS 칩이 직접 재는 속도(도플러 기반)가 0.7m/s(2.5km/h) 미만이면 정지로 확정.
            //     위치 좌표는 오차로 흔들려도(지터) 도플러 속도는 정지 시 거의 0이라 훨씬 신뢰도 높음.
            //  ⑵ 노이즈 게이트 강화: 이동거리가 max(오차×0.8, 8m) 미만이면 지터로 보고 버림.
            //     (기존 acc×0.5는 오차 10m 실내에서 8m 지터가 계속 누적되는 걸 못 막았음)
            val dopplerStationary = location.hasSpeed() && location.speed < 0.7f
            val noiseFloor = maxOf(acc.toDouble() * 0.8, 8.0)   // ✅ 타입 통일 (Float×Double 혼합 컴파일 에러 수정)
            accepted = when {
                // 터널 등 신호 공백 후 첫 fix: 순간이동처럼 큰 점프 -> 추측항법 거리로 보정
                //   (그냥 더하면 터널 통과 시 실제보다 훨씬 긴 거리가 잡히거나, GPS 튐이면 몇백m가 그대로 들어감)
                afterGap -> {
                    val drSpeed = (_trackingState.value.speedKmh / 3.6)     // 끊기기 직전 속도
                    val estimate = drSpeed * (gapMs / 1000.0)               // 등속 가정 추정 이동거리
                    minOf(rawDelta, estimate * 1.2)                          // 둘 중 작은 값 (과대계상 방지)
                }
                // ⑴ 도플러 속도상 정지 → 좌표가 흔들려도 거리 반영 안 함 (신호대기·실내 벤치 등)
                dopplerStationary && rawDelta < 25.0 -> 0.0
                // GPS 지터: 정지 상태(2km/h 미만)인데 위치만 흔들리는 경우 -> 거리 반영 안 함
                //   (달리기 기록에서 신호 대기 중에 몇십 m씩 쌓이던 문제의 원인)
                speedKmh < 2.0 && rawDelta < 12.0 -> 0.0
                // ⑵ 정확도·최소이동 기준 미달은 노이즈
                rawDelta < noiseFloor -> 0.0
                // 물리적으로 불가능한 점프는 버림
                rawDelta > plausibleMax -> 0.0
                else -> rawDelta
            }
            totalDistance += accepted
        }

        // ⑤ 이동/휴식 시간 분리 집계 (운동 페이스 정확도 + "한 번에 달성" 테두리 검증)
        //    운전은 정체·신호대기가 잦으므로 이동 판정 기준을 낮게(1km/h), 도보/자전거는 2km/h
        val movingThreshold = if (currentMode.isWorkoutMode) 2.0 else 1.0
        val dtSecStep = (gapMs / 1000.0).coerceIn(0.0, 30.0)  // 큰 공백은 30초까지만 인정 (앱 절전 대비)
        if (speedKmh >= movingThreshold) {
            movingSeconds += dtSecStep
            currentRestSeconds = 0.0                       // 다시 움직이면 연속 휴식 리셋
        } else {
            currentRestSeconds += dtSecStep
            if (currentRestSeconds > maxRestSeconds) maxRestSeconds = currentRestSeconds
        }

        lastLocation = location
        lastReceivedAtMillis = now

        val elapsedSeconds = (now - startTimeMillis) / 1000

        // ✅ v81 화면·기록에 쓰이는 좌표를 스무더로 통일 (실시간/저장 경로 불일치 제거)
        val smoothed = smoother.process(
            location.latitude, location.longitude, acc, dtSec, speedKmh / 3.6
        ) ?: LatLngPoint(location.latitude, location.longitude)

        _trackingState.value = TrackingSnapshot(
            currentLocation = smoothed,
            speedKmh = speedKmh,
            totalDistanceMeters = totalDistance,
            elapsedSeconds = elapsedSeconds,
            startTimeMillis = startTimeMillis,
            bearingDegrees = if (location.hasBearing() && speedKmh > 3.0) location.bearing
                             else _trackingState.value.bearingDegrees,  // 정지 시 방위 튐 방지
            isAfterSignalGap = afterGap,
            accuracyMeters = acc,
            satellitesUsed = gnss.satellitesUsed,
            gpsStatusText = gnss.statusText(),
            elevationGainMeters = elevation.gainMeters,
            elevationLossMeters = elevation.lossMeters,
            movingSeconds = movingSeconds.toLong(),
            maxRestSeconds = maxRestSeconds.toLong()
        )

        updateNotification(
            if (currentMode.isWorkoutMode)
                "🏃 운동 중 · %.2fkm · %.1fkm/h".format(totalDistance / 1000, speedKmh)
            else
                "🚗 주행 안내 중 · %.2fkm 이동 · %.1fkm/h".format(totalDistance / 1000, speedKmh)
        )
    }

    /** 운동/주행 완료 버튼 눌렀을 때 호출 - 최종 기록 반환 후 서비스 종료 */
    fun stopTrackingAndGetResult(): TrackingSnapshot {
        val finalState = _trackingState.value
        locationCallback?.let { fusedLocationClient.removeLocationUpdates(it) }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        return finalState
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        try { unregisterReceiver(screenStateReceiver) } catch (_: Exception) {}
        locationCallback?.let { fusedLocationClient.removeLocationUpdates(it) }
        gnss.stop()   // ✅ v84
        elevation.stop()  // ✅ v90
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) { }
        wakeLock = null
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "실시간 추적",
                NotificationManager.IMPORTANCE_LOW // 소리/진동 없이 조용히
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(content: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(if (currentMode.isWorkoutMode) "NaviFit 운동 기록" else "NaviFit 길안내")
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(content: String) {
        val notification = buildNotification(content)
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, notification)
    }
}
