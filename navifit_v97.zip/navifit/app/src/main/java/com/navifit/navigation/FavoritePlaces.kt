package com.navifit.navigation

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * ✅ v39 즐겨찾기 (집 / 회사 / 사용자 지정).
 * 시중 내비의 기본 기능인데 없어서, 매번 주소를 검색해야 했음.
 */
object FavoritePlaces {
    private const val PREF = "favorite_places"

    data class Favorite(
        val id: String,          // "home", "work", 또는 uuid
        val label: String,       // "집", "회사", 사용자 지정 이름
        val icon: String,        // 🏠 🏢 ⭐
        val name: String,        // 장소명/주소
        val lat: Double,
        val lng: Double
    )

    fun all(c: Context): List<Favorite> = try {
        val raw = prefs(c).getString("list", "[]") ?: "[]"
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Favorite(
                id = o.getString("id"), label = o.getString("label"),
                icon = o.optString("icon", "⭐"), name = o.getString("name"),
                lat = o.getDouble("lat"), lng = o.getDouble("lng")
            )
        }
    } catch (_: Exception) { emptyList() }

    fun save(c: Context, fav: Favorite) {
        val list = all(c).filter { it.id != fav.id } + fav
        persist(c, list)
    }

    fun remove(c: Context, id: String) = persist(c, all(c).filter { it.id != id })

    fun home(c: Context) = all(c).firstOrNull { it.id == "home" }
    fun work(c: Context) = all(c).firstOrNull { it.id == "work" }

    private fun persist(c: Context, list: List<Favorite>) {
        val arr = JSONArray()
        list.forEach { f ->
            arr.put(JSONObject()
                .put("id", f.id).put("label", f.label).put("icon", f.icon)
                .put("name", f.name).put("lat", f.lat).put("lng", f.lng))
        }
        prefs(c).edit().putString("list", arr.toString()).apply()
    }

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
}

/**
 * ✅ v39 네트워크 상태 확인.
 * 경로 계산은 인터넷이 필요한데, 오프라인이면 "경로를 찾을 수 없어요"라는 모호한 메시지만 떴음.
 * 원인을 정확히 알려줘야 사용자가 대처할 수 있음.
 */
object NetworkCheck {
    fun isOnline(c: Context): Boolean {
        return try {
            val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val net = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(net) ?: return false
            caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (_: Exception) { true }  // 확인 실패 시엔 일단 시도해봄
    }
}
