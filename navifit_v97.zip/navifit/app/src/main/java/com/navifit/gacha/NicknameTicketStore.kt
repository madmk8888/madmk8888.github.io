package com.navifit.gacha

import android.content.Context

/**
 * ✅ v85 닉네임 변경권 보관소.
 *  · 포인트 상점에서 10,000P로 구매 (여러 번 구매 가능 = 누적 보유)
 *  · 설정 > 닉네임 변경에서 1장 소모
 *  · 프리미엄 뽑기권(PremiumTicketStore)과 완전히 분리된 별도 재화
 */
object NicknameTicketStore {
    private const val PREFS = "nickname_tickets"
    private const val KEY = "count"

    fun count(c: Context): Int =
        c.getSharedPreferences(PREFS, 0).getInt(KEY, 0)

    fun add(c: Context, n: Int = 1) {
        val p = c.getSharedPreferences(PREFS, 0)
        p.edit().putInt(KEY, (p.getInt(KEY, 0) + n).coerceAtLeast(0)).apply()
    }

    /** 1장 사용. 보유량이 없으면 false */
    fun consume(c: Context): Boolean {
        val p = c.getSharedPreferences(PREFS, 0)
        val cur = p.getInt(KEY, 0)
        if (cur <= 0) return false
        p.edit().putInt(KEY, cur - 1).apply()
        return true
    }
}
