package com.navifit.navigation

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class SearchHistoryEntry(
    val name: String,
    val address: String?,
    val lat: Double,
    val lng: Double,
    val tapCount: Int,
    val lastUsedAt: Long
)

/**
 * 목적지 검색 기록 관리.
 * - 검색 결과에서 실제로 "탭해서 선택"한 장소만 기록 (그냥 타이핑만 한 건 저장 안 함)
 * - 같은 곳을 또 선택하면 tapCount 증가 + lastUsedAt 갱신 -> "자주 가는 곳" 랭킹에 반영
 */
object SearchHistoryManager {
    private const val PREFS = "search_history_prefs"
    private const val KEY = "history_json"

    fun record(context: Context, name: String, address: String?, lat: Double, lng: Double) {
        val list = loadAll(context).toMutableList()
        val idx = list.indexOfFirst { it.name == name }
        if (idx >= 0) {
            val old = list[idx]
            list[idx] = old.copy(tapCount = old.tapCount + 1, lastUsedAt = System.currentTimeMillis())
        } else {
            list.add(SearchHistoryEntry(name, address, lat, lng, 1, System.currentTimeMillis()))
        }
        // 너무 많이 쌓이지 않게 최근 100개까지만 유지
        val trimmed = list.sortedByDescending { it.lastUsedAt }.take(100)
        save(context, trimmed)
    }

    /** 최근 사용순 전체 목록 (검색 결과 우선순위 판단용) */
    fun loadAll(context: Context): List<SearchHistoryEntry> {
        val json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                SearchHistoryEntry(
                    o.getString("name"), o.optString("address", "").ifBlank { null },
                    o.getDouble("lat"), o.getDouble("lng"),
                    o.optInt("tapCount", 1), o.optLong("lastUsedAt", 0L)
                )
            }
        } catch (e: Exception) { emptyList() }
    }

    /** 자주 가는 곳 상위 5개 (탭 횟수 우선, 동률이면 최근 순) */
    fun topFrequent(context: Context, limit: Int = 5): List<SearchHistoryEntry> =
        loadAll(context).sortedWith(compareByDescending<SearchHistoryEntry> { it.tapCount }.thenByDescending { it.lastUsedAt }).take(limit)

    private fun save(context: Context, list: List<SearchHistoryEntry>) {
        val arr = JSONArray()
        list.forEach { e ->
            arr.put(JSONObject().apply {
                put("name", e.name); put("address", e.address ?: "")
                put("lat", e.lat); put("lng", e.lng)
                put("tapCount", e.tapCount); put("lastUsedAt", e.lastUsedAt)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
