package com.navifit.navigation

/**
 * 이동수단 모드
 * - WALK, BIKE: 운동 기록 대상 (걷기/자전거 전용도로 경로)
 * - MOTORCYCLE, CAR: 음성 안내 내비게이션 대상
 */
enum class TravelMode(
    val displayName: String,
    val directionsApiMode: String, // Google Directions API에 넘길 travel mode 파라미터
    val isWorkoutMode: Boolean,     // 운동 기록 대상인지
    val needsVoiceGuidance: Boolean // 음성 안내가 필요한지
) {
    WALK(
        displayName = "도보/달리기", // ✅ 걷기·달리기는 같은 몸운동이라 하나로 통합 (별도 RUN 모드 없음)
        directionsApiMode = "walking",
        isWorkoutMode = true,
        needsVoiceGuidance = false
    ),
    BIKE(
        displayName = "자전거",
        directionsApiMode = "bicycling", // 자전거 전용도로 우선 경로
        isWorkoutMode = true,
        needsVoiceGuidance = false
    ),
    MOTORCYCLE(
        displayName = "오토바이",
        // Directions API는 오토바이 전용 모드가 없어서 driving 기반 + 후처리로 이륜차 도로 우선순위 조정
        directionsApiMode = "driving",
        isWorkoutMode = false,
        needsVoiceGuidance = true
    ),
    CAR(
        displayName = "자동차",
        directionsApiMode = "driving",
        isWorkoutMode = false,
        needsVoiceGuidance = true
    );

    companion object {
        fun default() = WALK
    }
}

/**
 * ✅ 자동차/오토바이 경로 취향 (v25 신규).
 * 무료 라우팅(ORS)과 구글 폴백에서 지원하는 회피 옵션으로 매핑됨:
 *  - FAST(빠른길): 기본값 - 시간 최단 경로 (유료도로·고속도로 모두 사용)
 *  - FREE(무료도로): 유료도로(톨게이트) 회피
 *  - HIGHWAY(고속도로 위주): 시간 최단 우선 (고속도로가 있으면 자연히 선택됨)
 *  - OPTIMAL(최적 효율): 시간·비용 균형 - 유료도로는 피하되 페리 등도 회피
 */
enum class RoutePreference(val label: String, val emoji: String, val description: String) {
    FAST("빠른길", "⚡", "시간이 가장 짧은 경로"),
    FREE("무료도로", "🆓", "톨게이트 없는 무료 경로"),
    HIGHWAY("고속도로 위주", "🛣️", "고속도로를 우선으로 하는 경로"),
    OPTIMAL("최적 효율", "⚖️", "시간·비용 균형 경로");

    companion object {
        private const val PREFS = "route_pref"
        fun load(context: android.content.Context): RoutePreference =
            entries.find { it.name == context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).getString("pref", null) } ?: FAST
        fun save(context: android.content.Context, p: RoutePreference) {
            context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).edit().putString("pref", p.name).apply()
        }
    }
}

/**
 * ✅ v76 달리기·자전거 전용 경로 옵션 (ORS 파라미터로 매핑).
 *  - SHORTEST_TIME: 최단 시간 (기본, ORS preference=fastest)
 *  - SHORTEST_DIST: 최단 거리 (ORS preference=shortest)
 *  - STRAIGHT: 직진 우선 (회전 최소화 - ORS는 shortest에 가까움 + 회전 페널티)
 *  - AVOID_CROSSING: 횡단보도 최소 (신호 대기 줄이기 - 큰 도로 회피 성향)
 */
enum class WorkoutRoutePreference(val label: String, val emoji: String, val orsPreference: String) {
    SHORTEST_TIME("최단 시간", "⏱️", "fastest"),
    SHORTEST_DIST("최단 거리", "📏", "shortest"),
    STRAIGHT("직진 우선", "➡️", "shortest"),
    AVOID_CROSSING("횡단보도 우회", "🚦", "fastest");

    companion object {
        private const val PREFS = "workout_route_pref"
        fun load(context: android.content.Context): WorkoutRoutePreference =
            entries.find { it.name == context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).getString("wpref", null) } ?: SHORTEST_TIME
        fun save(context: android.content.Context, p: WorkoutRoutePreference) {
            context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).edit().putString("wpref", p.name).apply()
        }
    }
}
