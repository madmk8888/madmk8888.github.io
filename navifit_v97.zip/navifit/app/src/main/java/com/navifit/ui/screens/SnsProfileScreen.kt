package com.navifit.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.border
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.navifit.data.ActivityRecord

/**
 * ✅ v64 인스타식 프로필 화면.
 *  · 상단: 프로필 사진/마커 + 닉네임 + 소개(bio) + 게시물/친구 수
 *  · 탭: 📷 사진 / 🎬 동영상 / 📝 글  (각각 따로 봄)
 *  · 하단: (내 프로필이면) 운동 이력·업적 공개 토글, 소개/사진 편집
 *
 * 게시물은 CommunityScreen의 Post를 그대로 받아 작성자별로 필터링.
 */
@Composable
fun SnsProfileScreen(
    profileNickname: String,
    profileUid: String,
    isMe: Boolean,
    allPosts: List<Any>,          // Post 리스트 (여기선 리플렉션 없이 콜백으로 처리)
    photoPosts: List<PostMediaItem>,
    videoPosts: List<PostMediaItem>,
    textPosts: List<PostTextItem>,
    records: List<ActivityRecord>,
    onBack: () -> Unit,
    onEditProfile: () -> Unit = {},
    onOpenPost: (Long) -> Unit = {}
) {
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf(0) }
    val bio = remember { com.navifit.social.UserProfileStore.bio(ctx) }
    // ✅ v85 프로필 저장소 리비전을 키로 삼아, 사진/아바타 방식을 바꾸면 즉시 반영
    //   (기존: remember{}가 최초 값을 고정해서 화면을 나갔다 와야 적용됐음)
    val profileRev = com.navifit.social.UserProfileStore.revision
    val photoPath = remember(profileRev) { com.navifit.social.UserProfileStore.profilePhotoPath(ctx) }
    val usePhoto = remember(profileRev) { com.navifit.social.UserProfileStore.usePhotoAvatar(ctx) }

    Column(Modifier.fillMaxSize()) {
        // 상단 바
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("←", fontSize = 22.sp, color = Color.White, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.width(14.dp))
            Text(profileNickname, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Color.White, modifier = Modifier.weight(1f))
            if (isMe) Text("⚙️", fontSize = 18.sp, modifier = Modifier.clickable { onEditProfile() })
        }

        // 프로필 헤더
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(78.dp).clip(CircleShape).background(Color(0xFF243247)), contentAlignment = Alignment.Center) {
                if (isMe && usePhoto && photoPath != null) {
                    AsyncImage(model = photoPath, contentDescription = null,
                        modifier = Modifier.fillMaxSize().clip(CircleShape), contentScale = ContentScale.Crop)
                } else {
                    // ✅ v85 사진을 안 쓰면 "내가 장착한 마커 + 테두리"를 실제로 그린다.
                    //   (기존 버그: 무조건 🏃 이모지를 띄워서 마커 설정이 반영 안 됐음)
                    val inv = remember(profileRev) { com.navifit.gacha.GachaInventory(ctx) }
                    val equipped = remember(profileRev) { inv.equippedKey?.let { inv.resolveMarker(it) } }
                    val borderDef = remember(profileRev) {
                        inv.selectedBorderKey?.let { bk ->
                            com.navifit.gacha.BorderCatalog.all.find { it.key == bk }
                        }
                    }
                    if (equipped != null) {
                        // 테두리 링 (장착했다면 등급 색으로)
                        if (borderDef != null) {
                            val ringColors = when (borderDef.tier) {
                                com.navifit.gacha.BorderTier.RING_BRONZE -> listOf(Color(0xFFCD7F32), Color(0xFF8C5A22))
                                com.navifit.gacha.BorderTier.RING_SILVER -> listOf(Color(0xFFE0E0E0), Color(0xFF9E9E9E))
                                com.navifit.gacha.BorderTier.RING_GOLD -> listOf(Color(0xFFFFD700), Color(0xFFB8860B))
                                com.navifit.gacha.BorderTier.RING_GREEN -> listOf(Color(0xFF2ECC71), Color(0xFF14764A))
                                com.navifit.gacha.BorderTier.RING_PURPLE -> listOf(Color(0xFF9B51E0), Color(0xFF5B2E86))
                                com.navifit.gacha.BorderTier.RING_EMERALD -> listOf(Color(0xFF00C9A7), Color(0xFF00695C))
                                com.navifit.gacha.BorderTier.RING_NEON -> listOf(Color(0xFF00E5FF), Color(0xFFFF00E5))
                                com.navifit.gacha.BorderTier.RING_PLATINUM -> listOf(Color(0xFFE5E4E2), Color(0xFFA8A9AD))
                                com.navifit.gacha.BorderTier.RING_OBSIDIAN -> listOf(Color(0xFF1C1C1C), Color(0xFF6A4CA8))
                                com.navifit.gacha.BorderTier.RING_AMETHYST -> listOf(Color(0xFF9966CC), Color(0xFF4B0082))
                                else -> listOf(Color(0xFF7CC7FF), Color(0xFF3B82F6))
                            }
                            Box(
                                Modifier.fillMaxSize()
                                    .border(3.dp, Brush.sweepGradient(ringColors), CircleShape)
                            )
                        }
                        com.navifit.ui.map.MarkerCanvas(marker = equipped, size = 54.dp, animated = true)
                    } else {
                        Text("🏃", fontSize = 34.sp)
                    }
                }
            }
            Spacer(Modifier.width(20.dp))
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceEvenly) {
                ProfileStat("게시물", (photoPosts.size + videoPosts.size + textPosts.size).toString())
                ProfileStat("운동", records.size.toString())
                ProfileStat("거리", "%.0f".format(records.sumOf { it.distanceMeters } / 1000) + "km")
            }
        }
        Spacer(Modifier.height(10.dp))
        // 소개
        Column(Modifier.padding(horizontal = 16.dp)) {
            Text(profileNickname, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
            if (bio.isNotBlank()) Text(bio, fontSize = 13.sp, color = Color(0xFFC7CBD9))
            else if (isMe) Text("소개를 추가해보세요 (⚙️ 프로필 설정)", fontSize = 12.sp, color = Color(0xFF6B7180))
        }
        Spacer(Modifier.height(14.dp))

        // 미디어 탭
        Row(Modifier.fillMaxWidth()) {
            listOf("📷 사진", "🎬 동영상", "📝 글").forEachIndexed { i, label ->
                val sel = tab == i
                Box(Modifier.weight(1f).clickable { tab = i }
                    .padding(vertical = 10.dp)
                    .then(if (sel) Modifier else Modifier), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(label, fontSize = 13.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                            color = if (sel) Color.White else Color(0xFF6B7180))
                        Spacer(Modifier.height(4.dp))
                        Box(Modifier.height(2.dp).fillMaxWidth(0.6f)
                            .background(if (sel) Color(0xFF3B82F6) else Color.Transparent))
                    }
                }
            }
        }
        Divider(color = Color(0x22FFFFFF))

        when (tab) {
            0 -> MediaGrid(photoPosts, "아직 올린 사진이 없어요 📷", onOpenPost)
            1 -> MediaGrid(videoPosts, "아직 올린 동영상이 없어요 🎬", onOpenPost)
            2 -> TextPostList(textPosts, onOpenPost)
        }
    }
}

data class PostMediaItem(val postId: Long, val mediaPath: String, val isVideo: Boolean, val createdAt: Long)
data class PostTextItem(val postId: Long, val text: String, val createdAt: Long, val likes: Int)

@Composable
private fun ProfileStat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = Color.White)
        Text(label, fontSize = 11.sp, color = Color(0xFF8B93AC))
    }
}

@Composable
private fun MediaGrid(items: List<PostMediaItem>, emptyMsg: String, onOpenPost: (Long) -> Unit) {
    if (items.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(emptyMsg, fontSize = 13.sp, color = Color(0xFF6B7180), textAlign = TextAlign.Center)
        }
        return
    }
    LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.fillMaxSize().padding(2.dp)) {
        items(items) { m ->
            Box(Modifier.padding(1.dp).aspectRatio(1f).background(Color(0xFF16181D))
                .clickable { onOpenPost(m.postId) }) {
                AsyncImage(model = m.mediaPath, contentDescription = null,
                    modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                if (m.isVideo) Text("▶", fontSize = 20.sp, color = Color.White,
                    modifier = Modifier.align(Alignment.Center))
            }
        }
    }
}

@Composable
private fun TextPostList(items: List<PostTextItem>, onOpenPost: (Long) -> Unit) {
    if (items.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("아직 글이 없어요 📝", fontSize = 13.sp, color = Color(0xFF6B7180))
        }
        return
    }
    androidx.compose.foundation.lazy.LazyColumn(Modifier.fillMaxSize().padding(12.dp)) {
        items(items.size) { i ->
            val t = items[i]
            Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)
                .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp)).padding(14.dp)
                .clickable { onOpenPost(t.postId) }) {
                Text(t.text, fontSize = 14.sp, color = Color(0xFFECEEF2), maxLines = 3)
                Spacer(Modifier.height(6.dp))
                Text("❤️ ${t.likes} · ${java.text.SimpleDateFormat("MM.dd", java.util.Locale.KOREA).format(java.util.Date(t.createdAt))}",
                    fontSize = 11.sp, color = Color(0xFF8B93AC))
            }
        }
    }
}
