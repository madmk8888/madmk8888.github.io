package com.navifit.workout

import com.navifit.data.ActivityRecord
import com.navifit.navigation.TravelMode
import kotlin.math.max

data class WorkoutInsight(
    val weeklyFrequency: Int,          // 최근 7일간 운동 횟수
    val avgDistanceKm: Double,
    val avgSpeedKmh: Double,
    val avgDurationMinutes: Double,
    val trendMessage: String,          // "지난주보다 페이스가 빨라졌어요" 등
    val recommendation: String         // "주 3회 이상, 회당 30분 이상 추천"
)

/**
 * 운동 기록을 분석해서 개선점/추천 루틴을 만들어주는 로직.
 * 규칙 기반(rule-based)으로 구현 - 외부 AI 호출 없이도 동작하므로 비용이 들지 않음.
 */
object WorkoutAnalyzer {

    // 보건 가이드라인 참고치 (WHO 권장 성인 유산소 운동 기준 근사치)
    private const val RECOMMENDED_WEEKLY_SESSIONS = 3
    private const val RECOMMENDED_SESSION_MINUTES = 30

    fun analyze(mode: TravelMode, records: List<ActivityRecord>): WorkoutInsight? {
        if (records.isEmpty()) return null

        val now = System.currentTimeMillis()
        val oneWeekAgo = now - 7L * 24 * 60 * 60 * 1000
        val twoWeeksAgo = now - 14L * 24 * 60 * 60 * 1000

        val thisWeek = records.filter { it.startTimeMillis >= oneWeekAgo }
        val lastWeek = records.filter { it.startTimeMillis in twoWeeksAgo until oneWeekAgo }

        val avgDistanceKm = thisWeek.map { it.distanceMeters / 1000 }.average().takeIf { !it.isNaN() } ?: 0.0
        val avgSpeed = thisWeek.map { it.avgSpeedKmh }.average().takeIf { !it.isNaN() } ?: 0.0
        val avgDuration = thisWeek.map { it.durationSeconds / 60.0 }.average().takeIf { !it.isNaN() } ?: 0.0

        val trend = buildTrendMessage(thisWeek, lastWeek)
        val recommendation = buildRecommendation(mode, thisWeek.size, avgDuration)

        return WorkoutInsight(
            weeklyFrequency = thisWeek.size,
            avgDistanceKm = avgDistanceKm,
            avgSpeedKmh = avgSpeed,
            avgDurationMinutes = avgDuration,
            trendMessage = trend,
            recommendation = recommendation
        )
    }

    private fun buildTrendMessage(thisWeek: List<ActivityRecord>, lastWeek: List<ActivityRecord>): String {
        if (lastWeek.isEmpty() || thisWeek.isEmpty()) {
            return "아직 비교할 만큼의 기록이 쌓이지 않았어요. 꾸준히 기록해보세요."
        }

        val thisWeekAvgSpeed = thisWeek.map { it.avgSpeedKmh }.average()
        val lastWeekAvgSpeed = lastWeek.map { it.avgSpeedKmh }.average()
        val speedDiffPercent = ((thisWeekAvgSpeed - lastWeekAvgSpeed) / max(lastWeekAvgSpeed, 0.01)) * 100

        val thisWeekAvgDist = thisWeek.map { it.distanceMeters }.average()
        val lastWeekAvgDist = lastWeek.map { it.distanceMeters }.average()
        val distDiffPercent = ((thisWeekAvgDist - lastWeekAvgDist) / max(lastWeekAvgDist, 1.0)) * 100

        return when {
            speedDiffPercent > 5 -> "지난주보다 평균 페이스가 %.0f%% 빨라졌어요. 좋은 흐름이에요!".format(speedDiffPercent)
            speedDiffPercent < -5 -> "지난주보다 페이스가 조금 느려졌어요. 컨디션 관리도 함께 신경 써보세요."
            distDiffPercent > 10 -> "이동 거리가 지난주보다 %.0f%% 늘었어요. 체력이 붙고 있어요.".format(distDiffPercent)
            else -> "지난주와 비슷한 페이스를 유지하고 있어요."
        }
    }

    private fun buildRecommendation(mode: TravelMode, weeklyCount: Int, avgDurationMinutes: Double): String {
        val activityName = if (mode == TravelMode.WALK) "걷기" else "자전거 타기"

        val frequencyAdvice = when {
            weeklyCount < RECOMMENDED_WEEKLY_SESSIONS ->
                "이번 주 ${activityName} 횟수(${weeklyCount}회)가 권장치(주 ${RECOMMENDED_WEEKLY_SESSIONS}회)보다 적어요. " +
                "주 ${RECOMMENDED_WEEKLY_SESSIONS - weeklyCount}회 더 늘려보는 걸 추천해요."
            else ->
                "이번 주 ${weeklyCount}회로 권장 횟수를 잘 채우고 있어요. 이 페이스를 유지해보세요."
        }

        val durationAdvice = if (avgDurationMinutes < RECOMMENDED_SESSION_MINUTES) {
            " 평균 운동시간(%.0f분)도 %d분 이상으로 조금씩 늘려보면 좋아요.".format(
                avgDurationMinutes, RECOMMENDED_SESSION_MINUTES
            )
        } else ""

        return frequencyAdvice + durationAdvice
    }

    /**
     * 그래프용 - 최근 N일간 일별 요약 데이터
     */
    fun buildDailySeries(records: List<ActivityRecord>, days: Int = 14): List<DailyPoint> {
        val now = System.currentTimeMillis()
        val dayMillis = 24 * 60 * 60 * 1000L

        return (0 until days).map { dayOffset ->
            val dayStart = now - (days - dayOffset) * dayMillis
            val dayEnd = dayStart + dayMillis
            val dayRecords = records.filter { it.startTimeMillis in dayStart until dayEnd }

            DailyPoint(
                dayIndex = dayOffset,
                totalDistanceKm = dayRecords.sumOf { it.distanceMeters } / 1000,
                avgSpeedKmh = dayRecords.map { it.avgSpeedKmh }.average().takeIf { !it.isNaN() } ?: 0.0
            )
        }
    }

    data class DailyPoint(
        val dayIndex: Int,
        val totalDistanceKm: Double,
        val avgSpeedKmh: Double
    )

    // ===== 기간별(일/주/월) 집계 =====

    enum class Period(val label: String, val bucketCount: Int) {
        DAILY("하루별", 14),   // 최근 14일
        WEEKLY("주별", 8),     // 최근 8주
        MONTHLY("월별", 6)     // 최근 6개월
    }

    data class PeriodPoint(
        val label: String,           // "7/3", "6월 4주", "5월" 등
        val totalDistanceKm: Double, // 운동량 (거리)
        val totalMinutes: Double,    // 운동량 (시간)
        val sessionCount: Int,
        val avgSafetyScore: Double   // 운전 기록이면 안전점수 평균 (운동이면 0)
    )

    /** 기간 단위로 기록을 묶어서 집계 - 분석 화면의 일/주/월 그래프용 */
    fun buildPeriodSeries(records: List<com.navifit.data.ActivityRecord>, period: Period): List<PeriodPoint> {
        val cal = java.util.Calendar.getInstance()
        val dayMillis = 24 * 60 * 60 * 1000L

        fun bucketRange(offsetFromNow: Int): Pair<Long, Long> = when (period) {
            Period.DAILY -> {
                val end = System.currentTimeMillis() - offsetFromNow * dayMillis
                (end - dayMillis) to end
            }
            Period.WEEKLY -> {
                val end = System.currentTimeMillis() - offsetFromNow * 7 * dayMillis
                (end - 7 * dayMillis) to end
            }
            Period.MONTHLY -> {
                val c = java.util.Calendar.getInstance()
                c.add(java.util.Calendar.MONTH, -offsetFromNow)
                c.set(java.util.Calendar.DAY_OF_MONTH, 1)
                c.set(java.util.Calendar.HOUR_OF_DAY, 0); c.set(java.util.Calendar.MINUTE, 0)
                c.set(java.util.Calendar.SECOND, 0); c.set(java.util.Calendar.MILLISECOND, 0)
                val start = c.timeInMillis
                c.add(java.util.Calendar.MONTH, 1)
                start to c.timeInMillis
            }
        }

        fun bucketLabel(offsetFromNow: Int, startMillis: Long): String {
            cal.timeInMillis = startMillis
            return when (period) {
                Period.DAILY -> "${cal.get(java.util.Calendar.MONTH) + 1}/${cal.get(java.util.Calendar.DAY_OF_MONTH) + 1}"
                Period.WEEKLY -> if (offsetFromNow == 0) "이번주" else "${offsetFromNow}주 전"
                Period.MONTHLY -> "${cal.get(java.util.Calendar.MONTH) + 1}월"
            }
        }

        return (period.bucketCount - 1 downTo 0).map { offset ->
            val (start, end) = bucketRange(offset)
            val bucket = records.filter { it.startTimeMillis in start until end }
            PeriodPoint(
                label = bucketLabel(offset, start),
                totalDistanceKm = bucket.sumOf { it.distanceMeters } / 1000,
                totalMinutes = bucket.sumOf { it.durationSeconds } / 60.0,
                sessionCount = bucket.size,
                avgSafetyScore = bucket.map { it.safetyScore.toDouble() }.average().takeIf { !it.isNaN() } ?: 0.0
            )
        }
    }

    // ===== 운전(오토바이/자동차) 전용 분석 =====

    data class DrivingInsight(
        val weeklyTrips: Int,
        val avgSafetyScore: Int,
        val bestSafetyScore: Int,
        val totalDistanceKm: Double,
        val maxSpeedKmh: Double,
        val safetyTrend: String,
        val advice: String
    )

    fun analyzeDriving(records: List<com.navifit.data.ActivityRecord>): DrivingInsight? {
        if (records.isEmpty()) return null
        val now = System.currentTimeMillis()
        val oneWeekAgo = now - 7L * 24 * 60 * 60 * 1000
        val twoWeeksAgo = now - 14L * 24 * 60 * 60 * 1000
        val thisWeek = records.filter { it.startTimeMillis >= oneWeekAgo }
        val lastWeek = records.filter { it.startTimeMillis in twoWeeksAgo until oneWeekAgo }

        val avgScore = records.map { it.safetyScore }.average().toInt()
        val thisAvg = thisWeek.map { it.safetyScore.toDouble() }.average().takeIf { !it.isNaN() } ?: 0.0
        val lastAvg = lastWeek.map { it.safetyScore.toDouble() }.average().takeIf { !it.isNaN() } ?: 0.0

        val trend = when {
            lastWeek.isEmpty() || thisWeek.isEmpty() -> "비교할 기록이 더 쌓이면 안전점수 추세를 알려드려요."
            thisAvg > lastAvg + 2 -> "지난주보다 안전점수가 %.0f점 올랐어요. 훌륭해요! 🛡️".format(thisAvg - lastAvg)
            thisAvg < lastAvg - 2 -> "지난주보다 안전점수가 %.0f점 내려갔어요. 과속·급가속에 조금만 더 신경 써보세요.".format(lastAvg - thisAvg)
            else -> "지난주와 비슷한 안전운전 수준을 유지하고 있어요."
        }
        val advice = when {
            avgScore >= 95 -> "최상위권 안전운전자예요. 이대로만 유지하세요!"
            avgScore >= 85 -> "안정적인 운전 습관이에요. 과속 구간만 조금 줄이면 만점권이에요."
            avgScore >= 70 -> "과속/급가속이 자주 감지돼요. 여유있는 출발과 규정속도 준수를 추천해요."
            else -> "위험 운전 패턴이 많이 감지됐어요. 안전을 위해 운전 습관 점검이 필요해요."
        }

        return DrivingInsight(
            weeklyTrips = thisWeek.size,
            avgSafetyScore = avgScore,
            bestSafetyScore = records.maxOf { it.safetyScore },
            totalDistanceKm = records.sumOf { it.distanceMeters } / 1000,
            maxSpeedKmh = records.maxOf { it.maxSpeedKmh },
            safetyTrend = trend,
            advice = advice
        )
    }
}
