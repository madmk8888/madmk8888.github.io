package com.navifit.navigation

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * ✅ v48 한국도로공사 도로정보 (data.ex.co.kr).
 *
 * 이 사이트는 "활용신청" 절차 없이 회원가입만 하면 인증키를 바로 줍니다 (API 유형이 LINK).
 * 그리고 키 하나로 여러 API를 다 쓸 수 있어서, 자동차 내비의 차별점을 만들기 좋습니다.
 *
 * 여기서 쓰는 것:
 *  ① 돌발정보 (사고·공사·통제) → "전방 3km 사고 발생, 1차로 통제" 음성 경보
 *     └ 카카오/티맵 대비 확실한 강점. 고속도로 사고를 미리 알면 사고 2차 피해를 막을 수 있음.
 *  ② 실시간 교통량 (TCS 영업소별) → 요금소 정체 예측
 *  ③ 휴게소 (기존 RestAreaRepository)
 */
class ExRoadInfoRepository(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .callTimeout(8, TimeUnit.SECONDS)
        .build()

    fun hasKey() = !NavApiKeys.exKey(context).isNullOrBlank()

    /** 돌발 유형 */
    enum class IncidentType(val label: String, val icon: String) {
        ACCIDENT("사고", "🚨"),
        CONSTRUCTION("공사", "🚧"),
        CLOSURE("통제", "⛔"),
        DISABLED_VEHICLE("고장차", "🚗"),
        WEATHER("기상", "🌧️"),
        OTHER("돌발", "⚠️")
    }

    data class Incident(
        val type: IncidentType,
        val location: LatLngPoint,
        val roadName: String,
        val message: String,
        val lanesBlocked: Int   // 통제 차로 수 (0이면 미상)
    )

    /**
     * 전국 고속도로 돌발상황 조회.
     * 사고·공사·통제 정보를 가져와서, 경로 앞쪽에 있으면 미리 경보합니다.
     */
    suspend fun fetchIncidents(): List<Incident> = withContext(Dispatchers.IO) {
        val out = mutableListOf<Incident>()
        // ✅ v50: 한국도로공사(고속도로) + 국토교통부(고속도로+국도, 예상복구시간·정체길이 포함) 이중화.
        //    도로공사 키가 없어도 국토부 데이터만으로 동작하고, 겹치는 지점은 도로공사 쪽을 우선.
        out += fetchFromEx()
        out += fetchFromMolit().filter { m -> out.none { e -> fastDist(e.location, m.location) < 300 } }
        out
    }

    private fun fastDist(a: LatLngPoint, b: LatLngPoint) =
        NavigationProgressCalculator.fastDistanceMeters(a, b)

    /** 한국도로공사 돌발정보 (고속도로 전용, ex_key 필요) */
    private fun fetchFromEx(): List<Incident> {
        val key = NavApiKeys.exKey(context) ?: return emptyList()
        val out = mutableListOf<Incident>()
        try {
            val url = "https://data.ex.co.kr/openapi/safeDriving/breakdownInfo" +
                "?key=$key&type=json&numOfRows=200&pageNo=1"
            val body = client.newCall(Request.Builder().url(url).build())
                .execute().use { it.body?.string() } ?: return emptyList()

            val arr = JSONObject(body).optJSONArray("list") ?: return emptyList()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val lat = o.optString("yCode").toDoubleOrNull()
                    ?: o.optString("latitude").toDoubleOrNull() ?: continue
                val lng = o.optString("xCode").toDoubleOrNull()
                    ?: o.optString("longitude").toDoubleOrNull() ?: continue

                val raw = (o.optString("incidentTypeName") + o.optString("contents") +
                           o.optString("eventType")).ifBlank { o.toString() }
                val type = classify(raw)
                val lanes = Regex("(\\d+)\\s*차로").find(raw)?.groupValues?.get(1)?.toIntOrNull() ?: 0

                out.add(
                    Incident(
                        type = type,
                        location = LatLngPoint(lat, lng),
                        roadName = o.optString("routeName").ifBlank { "고속도로" },
                        message = o.optString("contents").take(60).ifBlank { type.label },
                        lanesBlocked = lanes
                    )
                )
            }
        } catch (_: Exception) { }
        return out
    }

    /**
     * ✅ v50: 국토교통부 돌발상황/사고정보 (고속도로+국도, LINK형 - 활용신청 없이 사용 가능).
     * 예상 복구시간·정체 길이 등 더 상세한 정보를 담고 있어, 있으면 메시지에 함께 표시.
     */
    private fun fetchFromMolit(): List<Incident> {
        return try {
            val url = "https://api.data.go.kr/openapi/tn_pubr_public_trrsrtinfo_api" +
                "?type=json&numOfRows=200&pageNo=1"
            val body = client.newCall(Request.Builder().url(url).build())
                .execute().use { it.body?.string() } ?: return emptyList()
            val arr = JSONObject(body).optJSONObject("response")
                ?.optJSONObject("body")?.optJSONArray("items") ?: return emptyList()

            val out = mutableListOf<Incident>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val lat = o.optString("yCrdnt").toDoubleOrNull()
                    ?: o.optString("latitude").toDoubleOrNull() ?: continue
                val lng = o.optString("xCrdnt").toDoubleOrNull()
                    ?: o.optString("longitude").toDoubleOrNull() ?: continue

                val raw = (o.optString("eventType") + o.optString("eventDetailType") +
                           o.optString("eventText")).ifBlank { o.toString() }
                val type = classify(raw)
                val recovery = o.optString("expClearTime").takeIf { it.isNotBlank() }
                val congestLen = o.optString("congestLength").toDoubleOrNull()

                val msgParts = mutableListOf(o.optString("eventText").take(50).ifBlank { type.label })
                if (recovery != null) msgParts += "예상복구 $recovery"
                if (congestLen != null && congestLen > 0) msgParts += "정체 ${congestLen.toInt()}m"

                out.add(
                    Incident(
                        type = type,
                        location = LatLngPoint(lat, lng),
                        roadName = o.optString("roadName").ifBlank { "도로" },
                        message = msgParts.joinToString(" · "),
                        lanesBlocked = Regex("(\\d+)\\s*차로").find(raw)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                    )
                )
            }
            out
        } catch (_: Exception) { emptyList() }
    }

    private fun classify(raw: String) = when {
        raw.contains("사고") -> IncidentType.ACCIDENT
        raw.contains("공사") || raw.contains("작업") -> IncidentType.CONSTRUCTION
        raw.contains("통제") || raw.contains("폐쇄") -> IncidentType.CLOSURE
        raw.contains("고장") -> IncidentType.DISABLED_VEHICLE
        raw.contains("결빙") || raw.contains("안개") || raw.contains("폭설") -> IncidentType.WEATHER
        else -> IncidentType.OTHER
    }

    /**
     * 경로 앞쪽에 있는 돌발상황 찾기 (진행 방향 기준).
     * @param routePoints 경로 좌표
     * @param current 현재 위치
     * @param lookAheadKm 몇 km 앞까지 볼지
     */
    fun findAhead(
        incidents: List<Incident>,
        routePoints: List<LatLngPoint>,
        current: LatLngPoint,
        lookAheadKm: Double = 20.0
    ): Pair<Incident, Int>? {
        if (routePoints.isEmpty() || incidents.isEmpty()) return null
        val myIdx = NavigationProgressCalculator.nearestPointIndex(routePoints, current)

        var best: Pair<Incident, Int>? = null
        incidents.forEach { inc ->
            // 돌발 지점이 경로에서 500m 이내인지 (경로와 무관한 사고는 무시)
            val incIdx = NavigationProgressCalculator.nearestPointIndex(routePoints, inc.location)
            val distToRoute = NavigationProgressCalculator.fastDistanceMeters(
                routePoints[incIdx], inc.location
            )
            if (distToRoute > 500) return@forEach
            if (incIdx <= myIdx) return@forEach   // 이미 지나친 지점

            // 경로를 따라 남은 거리 계산
            var d = 0.0
            for (i in (myIdx + 1)..incIdx) {
                d += NavigationProgressCalculator.fastDistanceMeters(routePoints[i - 1], routePoints[i])
                if (d > lookAheadKm * 1000) return@forEach
            }
            val meters = d.toInt()
            if (best == null || meters < best!!.second) best = inc to meters
        }
        return best
    }
}
