package com.navifit.gacha

import android.content.Context
import org.json.JSONObject

/**
 * 보유 마커 / 장착 마커 / 교환권을 기기에 영구 저장.
 * (프로토타입에서는 새로고침하면 사라졌지만 앱에서는 유지됨)
 */
class GachaInventory(context: Context) {

    private val prefs = context.getSharedPreferences("gacha_inventory", Context.MODE_PRIVATE)

    /** key -> count */
    fun getOwned(): MutableMap<String, Int> {
        val json = prefs.getString("owned", "{}") ?: "{}"
        val obj = JSONObject(json)
        val map = mutableMapOf<String, Int>()
        obj.keys().forEach { k -> map[k] = obj.getInt(k) }
        return map
    }

    fun addMarker(marker: DrawnMarker) {
        val owned = getOwned()
        owned[marker.key] = (owned[marker.key] ?: 0) + 1
        saveOwned(owned)
        // key로부터 복원할 수 있도록 메타 저장
        prefs.edit().putString("meta_${marker.key}",
            "${marker.shape.id}|${marker.color.hex}").apply()
    }

    fun removeThree(key: String): Boolean {
        val owned = getOwned()
        val count = owned[key] ?: 0
        if (count < 3) return false
        if (count == 3) owned.remove(key) else owned[key] = count - 3
        saveOwned(owned)
        return true
    }

    fun resolveMarker(key: String): DrawnMarker? {
        val meta = prefs.getString("meta_$key", null) ?: return null
        val (shapeId, colorHex) = meta.split("|").let { it[0] to it[1] }
        val shape = MarkerCatalog.shapes.find { it.id == shapeId } ?: return null
        val color = MarkerCatalog.colors.find { it.hex == colorHex } ?: return null
        return DrawnMarker(shape, color)
    }

    var equippedKey: String?
        get() = prefs.getString("equipped", null)
        set(value) { prefs.edit().putString("equipped", value).apply() }

    var selectedBorderKey: String?
        get() = prefs.getString("selected_border", null)
        set(value) { prefs.edit().putString("selected_border", value).apply() }

    private fun saveOwned(map: Map<String, Int>) {
        val obj = JSONObject()
        map.forEach { (k, v) -> obj.put(k, v) }
        prefs.edit().putString("owned", obj.toString()).apply()
    }
}
