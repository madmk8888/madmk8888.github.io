package com.navifit.tracking

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  HapticFeedback — 진동 피드백 (v90 신규)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * 왜 필요한가:
 *  달리거나 자전거를 탈 때는 화면을 볼 수 없다. 음성도 음악 때문에 못 들을 수 있다.
 *  진동은 주머니·팔에 차고 있어도 확실히 느껴지는 유일한 신호다.
 *
 * 사용처:
 *  · 좌/우 회전 안내 (패턴을 다르게 해서 방향까지 구분)
 *  · 1km 갱신 (스플릿 알림)
 *  · 경로 이탈 경고
 *  · VS 카운트다운·출발·결승
 *
 * 전부 안드로이드 기본 API. 권한은 VIBRATE 하나만 필요(설치 시 자동 허용).
 */
object HapticFeedback {

    private fun vibrator(c: Context): Vibrator? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = c.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vm?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            c.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    } catch (_: Exception) { null }

    private fun play(c: Context, timings: LongArray, amplitudes: IntArray? = null) {
        val v = vibrator(c) ?: return
        if (!v.hasVibrator()) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val effect = if (amplitudes != null && v.hasAmplitudeControl())
                    VibrationEffect.createWaveform(timings, amplitudes, -1)
                else VibrationEffect.createWaveform(timings, -1)
                v.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(timings, -1)
            }
        } catch (_: Exception) { }
    }

    /** 우회전: 짧게 두 번 (오른쪽 = 빠른 두 번) */
    fun turnRight(c: Context) = play(c, longArrayOf(0, 60, 90, 60), intArrayOf(0, 200, 0, 200))

    /** 좌회전: 길게 한 번 (왼쪽 = 한 번 길게) — 방향을 진동만으로 구분 */
    fun turnLeft(c: Context) = play(c, longArrayOf(0, 220), intArrayOf(0, 200))

    /** 직진/유턴 등 일반 안내 */
    fun turnGeneric(c: Context) = play(c, longArrayOf(0, 120), intArrayOf(0, 160))

    /** 1km 갱신 (스플릿) — 톡톡톡 */
    fun kmSplit(c: Context) = play(c, longArrayOf(0, 50, 80, 50, 80, 50), intArrayOf(0, 180, 0, 180, 0, 180))

    /** 경로 이탈 경고 — 강하게 길게 (놓치면 안 되는 신호) */
    fun offRoute(c: Context) = play(c, longArrayOf(0, 300, 150, 300), intArrayOf(0, 255, 0, 255))

    /** VS 카운트다운 (3,2,1) — 짧고 가볍게 */
    fun countdownTick(c: Context) = play(c, longArrayOf(0, 45), intArrayOf(0, 140))

    /** VS 출발! — 강한 한 방 */
    fun raceStart(c: Context) = play(c, longArrayOf(0, 400), intArrayOf(0, 255))

    /** VS 승리 — 리듬감 있게 */
    fun win(c: Context) = play(c, longArrayOf(0, 90, 70, 90, 70, 260), intArrayOf(0, 200, 0, 200, 0, 255))

    /** VS 패배 — 낮고 둔하게 */
    fun lose(c: Context) = play(c, longArrayOf(0, 450), intArrayOf(0, 110))

    /** 목적지 도착 */
    fun arrive(c: Context) = play(c, longArrayOf(0, 150, 100, 150, 100, 350), intArrayOf(0, 220, 0, 220, 0, 255))

    /** 가벼운 탭 (버튼 확인용) */
    fun tick(c: Context) = play(c, longArrayOf(0, 30), intArrayOf(0, 120))
}
