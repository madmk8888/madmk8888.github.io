package com.navifit.tracking

import android.content.Context
import com.navifit.navigation.TravelMode
import org.json.JSONArray
import org.json.JSONObject

/**
 * 세션 단위 매크로/어뷰징 방어 (v25 신규).
 *
 * 기존 AntiCheatMonitor는 "주행 중" 센서/속도 기반 부정을 잡지만,
 * "껐다 켰다"를 반복하는 세션 토글 매크로는 잡지 못했음:
 *  - 안전점수: 아주 짧은 주행을 반복해서 매번 100점을 받아 누적 평균을 부풀리는 수법
 *  - 운동/키로수: 초단위 세션을 반복 저장해서 기록 수·거리를 불리는 수법
 *
 * 방어 규칙 (조합해서 "지능적으로" 판정):
 *  ① 최소 세션 요건 - 이보다 짧으면 점수/랭킹 반영 자체가 안 됨
 *     · 운동(도보/자전거): 거리 300m 이상 AND 3분 이상
 *     · 운전(오토바이/자동차) 안전점수 반영: 거리 1km 이상 AND 3분 이상
 *  ② 토글 패턴 감지 - 최근 30분 내 "짧은 세션"이 3회 이상이면
 *     이후 1시간 동안 시작되는 모든 세션을 점수 미반영 처리 (쿨다운)
 *  ③ 하루 반영 상한 - 점수/랭킹에 반영되는 세션은 하루 최대 20회
 *     (정상 사용자는 도달 불가, 매크로만 걸림)
 *
 * 기록 자체는 항상 저장됨 (개인 히스토리 보존) - "점수 반영"만 차단.
 */
object SessionGuard {
    private const val PREFS = "session_guard_prefs"
    private const val KEY_SESSIONS = "recent_sessions" // [{t: endMillis, d: durationSec, m: meters, ok: bool}]
    private const val KEY_COOLDOWN_UNTIL = "cooldown_until"

    // ① 최소 세션 요건
    const val MIN_WORKOUT_METERS = 300.0
    const val MIN_WORKOUT_SECONDS = 180L
    const val MIN_DRIVING_METERS = 1000.0
    const val MIN_DRIVING_SECONDS = 180L

    // ② 토글 패턴
    private const val SHORT_SESSION_WINDOW_MILLIS = 30 * 60_000L
    private const val SHORT_SESSION_LIMIT = 3
    private const val COOLDOWN_MILLIS = 60 * 60_000L

    // ③ 하루 상한
    private const val MAX_COUNTED_PER_DAY = 20

    data class Verdict(
        val countsForScore: Boolean,  // 안전점수/운동통계 누적에 반영해도 되는가
        val countsForRanking: Boolean, // 랭킹에 반영해도 되는가
        val reason: String?            // 미반영 사유 (사용자에게 그대로 보여줌)
    )

    /**
     * 세션 종료 시 호출. 이 세션이 점수/랭킹에 반영돼도 되는지 판정하고,
     * 판정과 무관하게 세션 이력을 기록해 다음 판정에 사용.
     */
    fun evaluateAndRecord(
        context: Context,
        mode: TravelMode,
        distanceMeters: Double,
        durationSeconds: Long
    ): Verdict {
        val now = System.currentTimeMillis()
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        val (minMeters, minSeconds) =
            if (mode.isWorkoutMode) MIN_WORKOUT_METERS to MIN_WORKOUT_SECONDS
            else MIN_DRIVING_METERS to MIN_DRIVING_SECONDS
        val tooShort = distanceMeters < minMeters || durationSeconds < minSeconds

        // 세션 이력 로드 (24시간 이전 것은 버림)
        val sessions = loadSessions(prefs).filter { now - it.optLong("t") < 24 * 3600_000L }.toMutableList()

        // 판정
        var reason: String? = null
        val cooldownUntil = prefs.getLong(KEY_COOLDOWN_UNTIL, 0L)
        val countedToday = sessions.count { it.optBoolean("ok") }

        if (tooShort) {
            reason = if (mode.isWorkoutMode)
                "세션이 너무 짧아요 (${(minMeters / 1000).let { "%.1f".format(it) }}km·${minSeconds / 60}분 이상부터 점수·랭킹에 반영돼요)"
            else
                "주행이 너무 짧아요 (1km·3분 이상 주행부터 안전점수에 반영돼요)"
        } else if (now < cooldownUntil) {
            reason = "짧은 세션을 반복 시작·종료하는 패턴이 감지되어 잠시 점수 반영이 제한됐어요 (약 ${((cooldownUntil - now) / 60_000L) + 1}분 후 해제)"
        } else if (countedToday >= MAX_COUNTED_PER_DAY) {
            reason = "오늘 점수에 반영되는 세션 수(${MAX_COUNTED_PER_DAY}회)를 초과했어요 - 기록은 저장되지만 점수·랭킹엔 반영되지 않아요"
        }

        val counts = reason == null

        // 이번 세션 기록
        sessions.add(JSONObject().apply {
            put("t", now); put("d", durationSeconds); put("m", distanceMeters); put("ok", counts)
        })

        // ② 토글 패턴: 최근 30분 내 "너무 짧은 세션" 수 집계 -> 쿨다운 발동
        val recentShort = sessions.count {
            now - it.optLong("t") < SHORT_SESSION_WINDOW_MILLIS &&
                (it.optLong("d") < minSeconds || it.optDouble("m") < minMeters)
        }
        if (recentShort >= SHORT_SESSION_LIMIT) {
            prefs.edit().putLong(KEY_COOLDOWN_UNTIL, now + COOLDOWN_MILLIS).apply()
        }

        saveSessions(prefs, sessions)
        return Verdict(countsForScore = counts, countsForRanking = counts, reason = reason)
    }

    private fun loadSessions(prefs: android.content.SharedPreferences): MutableList<JSONObject> {
        val json = prefs.getString(KEY_SESSIONS, null) ?: return mutableListOf()
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { arr.getJSONObject(it) }.toMutableList()
        } catch (e: Exception) { mutableListOf() }
    }

    private fun saveSessions(prefs: android.content.SharedPreferences, list: List<JSONObject>) {
        val arr = JSONArray().apply { list.forEach { put(it) } }
        prefs.edit().putString(KEY_SESSIONS, arr.toString()).apply()
    }
}
