package com.navifit.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.navifit.i18n.tr
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.navifit.data.ActivityRecord
import com.navifit.gacha.*
import com.navifit.monetization.RewardAdManager
import kotlinx.coroutines.delay

// ⚠️ 테스트 단계 플래그: true면 테두리 전부 해금 상태로 보여줌 (배포 전 false로 변경)
private const val TEST_MODE_UNLOCK_ALL_BORDERS = true

private fun tierColor(hex: String): Color =
    if (hex == "RAINBOW") Color(0xFFFFD700) else Color(android.graphics.Color.parseColor(hex))

@Composable
private fun OwnedMarkerCell(
    marker: DrawnMarker,
    count: Int,
    isEquipped: Boolean,
    onToggleEquip: () -> Unit,
    onFuse: () -> Unit
) {
    Box(contentAlignment = Alignment.TopCenter) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = 6.dp)) {
            Box(
                Modifier.size(56.dp).clip(CircleShape)
                    .background(if (isEquipped) Color(0xFF8B9FFF) else Color.Transparent)
                    .padding(if (isEquipped) 3.dp else 0.dp)
            ) {
                Box(
                    Modifier.fillMaxSize().clip(CircleShape).clickable(onClick = onToggleEquip),
                    contentAlignment = Alignment.Center
                ) { com.navifit.ui.map.MarkerCanvas(marker, size = 50.dp) }
            }
            Text(marker.color.nameKo, fontSize = 9.sp, color = Color.Gray)
            if (isEquipped) Text(tr("✅ 장착중"), fontSize = 9.sp, color = Color(0xFF6E85F0), fontWeight = FontWeight.ExtraBold)
            if (count >= 3) {
                Button(
                    onClick = onFuse,
                    modifier = Modifier.height(26.dp).padding(top = 3.dp),
                    contentPadding = PaddingValues(horizontal = 9.dp, vertical = 0.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7EDDB8))
                ) { Text(tr("🔧 합성"), fontSize = 10.sp) }
            }
        }
        if (count > 1) {
            Box(
                Modifier.align(Alignment.TopEnd)
                    .background(Color(0xFF4A4458), RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp, bottomStart = 10.dp, bottomEnd = 2.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) { Text("x$count", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White) }
        }
    }
}

private fun ringBrush(tier: BorderTier): Brush = when (tier) {
    BorderTier.RING_GOLD -> Brush.sweepGradient(listOf(Color(0xFFFFD700), Color(0xFFFFF3B0), Color(0xFFFFD700)))
    BorderTier.RING_SILVER -> Brush.sweepGradient(listOf(Color(0xFFE0E0E0), Color.White, Color(0xFFC0C0C0)))
    BorderTier.RING_BRONZE -> Brush.sweepGradient(listOf(Color(0xFFCD7F32), Color(0xFFE8A868), Color(0xFFCD7F32)))
    BorderTier.RING_GREEN -> Brush.linearGradient(listOf(Color(0xFF7EDDB8), Color(0xFF7EDDB8)))
    BorderTier.RING_PURPLE -> Brush.sweepGradient(listOf(Color(0xFF8B9FFF), Color(0xFFC9A5F5), Color(0xFF8B9FFF)))
    BorderTier.RING_RAINBOW -> Brush.sweepGradient(listOf(Color(0xFFFFD700), Color(0xFFFF3CAC), Color(0xFF5B7FFF), Color(0xFF39FF88), Color(0xFFFFD700)))
    BorderTier.RING_FIRE -> Brush.sweepGradient(listOf(Color(0xFFFF3D00), Color(0xFFFF9100), Color(0xFFFFD600), Color(0xFFFF3D00)))
    BorderTier.RING_ICE -> Brush.sweepGradient(listOf(Color(0xFFB3E5FC), Color(0xFFFFFFFF), Color(0xFF81D4FA), Color(0xFFB3E5FC)))
    BorderTier.RING_COSMIC -> Brush.sweepGradient(listOf(Color(0xFF1A0B3D), Color(0xFF8B5CF6), Color(0xFFEC4899), Color(0xFF1A0B3D)))
    // ✅ 무지개는 RING_RAINBOW 하나만 - 홀로그램은 진주빛(펄) 톤으로 구분
    BorderTier.RING_HOLOGRAPHIC -> Brush.sweepGradient(listOf(Color(0xFFF8E7FF), Color(0xFFD6F0FF), Color(0xFFFFFFFF), Color(0xFFFFE3F1), Color(0xFFF8E7FF)))
    BorderTier.RING_EMERALD -> Brush.sweepGradient(listOf(Color(0xFF10B981), Color(0xFF6EE7B7), Color(0xFF10B981)))
    BorderTier.RING_NEON -> Brush.sweepGradient(listOf(Color(0xFF00F5FF), Color(0xFFFF00E5), Color(0xFF00F5FF)))
    BorderTier.RING_PLATINUM -> Brush.sweepGradient(listOf(Color(0xFFE5E4E2), Color.White, Color(0xFFB8B8B8), Color(0xFFE5E4E2)))
    BorderTier.RING_OBSIDIAN -> Brush.sweepGradient(listOf(Color(0xFF0D0D0D), Color(0xFF6B21A8), Color(0xFF0D0D0D), Color(0xFF1E1B4B)))
    BorderTier.RING_AMETHYST -> Brush.sweepGradient(listOf(Color(0xFF6B21A8), Color(0xFFC084FC), Color(0xFF6B21A8)))
    BorderTier.RING_SAPPHIRE -> Brush.sweepGradient(listOf(Color(0xFF1E3A8A), Color(0xFF60A5FA), Color(0xFF1E3A8A)))
}

/**
 * 갖고 싶어지는 테두리 프리뷰.
 * - animated=true: 천천히 회전 (질감이 살아있는 느낌)
 * - sparkle=true: 주변에 반짝이는 별 파티클이 깜빡깜빡
 * - unlocked=false: 흑백 처리 + 회전/반짝임 없음 (자물쇠 아이콘만)
 */
@Composable
private fun AnimatedBorderRing(
    tier: BorderTier,
    unlocked: Boolean,
    size: androidx.compose.ui.unit.Dp,
    animated: Boolean,
    sparkle: Boolean,
    effect: com.navifit.gacha.BorderEffect = com.navifit.gacha.BorderEffect.NONE,
    motion: com.navifit.gacha.BorderMotion = com.navifit.gacha.BorderMotion.ARC,
    strongGlow: Boolean = false,
    particleColor: Color = Color.White,
    content: @Composable () -> Unit
) {
    val infinite = rememberInfiniteTransition(label = "border")
    val rotation by infinite.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(4200, easing = LinearEasing)), label = "rot"
    )
    val pulse by infinite.animateFloat(
        initialValue = 0.25f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(650), repeatMode = RepeatMode.Reverse), label = "spk"
    )

    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        // 1층: 테두리 링 (모션에 따라 회전/발광)
        val glowMod = if (unlocked && strongGlow)
            Modifier.background(particleColor.copy(alpha = pulse * 0.35f), CircleShape) else Modifier
        Box(
            Modifier.fillMaxSize().then(glowMod).clip(CircleShape)
                .background(
                    if (!unlocked) Brush.linearGradient(listOf(Color(0xFFE4E1EC), Color(0xFFE4E1EC)))
                    else ringBrush(tier)
                )
                .graphicsLayer {
                    if (unlocked && animated && (motion == com.navifit.gacha.BorderMotion.ARC || motion == com.navifit.gacha.BorderMotion.SHIMMER))
                        rotationZ = rotation
                    // BREATHE: 살짝 커졌다 작아짐 / HUE: 밝기 변화로 근사
                    if (unlocked && motion == com.navifit.gacha.BorderMotion.BREATHE) {
                        val sc = 1f + 0.03f * kotlin.math.sin(Math.toRadians((rotation * 3).toDouble())).toFloat()
                        scaleX = sc; scaleY = sc
                    }
                    if (unlocked && motion == com.navifit.gacha.BorderMotion.HUE) {
                        alpha = 0.8f + 0.2f * kotlin.math.sin(Math.toRadians((rotation * 2).toDouble())).toFloat()
                    }
                }
        )
        // 2층: 고정 배경 + 콘텐츠 (회전 안 함)
        Box(
            Modifier.fillMaxSize().padding(3.dp).clip(CircleShape).background(Color(0xFF1E1B27)),
            contentAlignment = Alignment.Center
        ) { content() }

        // 3층: 빛 입자 (이모지 아님) - 종류별로 배치가 다름
        if (unlocked && sparkle && effect != com.navifit.gacha.BorderEffect.NONE) {
            val positions = when (effect) {
                com.navifit.gacha.BorderEffect.JEWEL -> listOf(0f to -1f, -0.85f to 0.5f, 0.85f to 0.5f)      // 링 위 3점
                com.navifit.gacha.BorderEffect.AURA -> listOf(0.7f to -0.7f, -0.9f to 0.3f, 0.4f to 0.9f)
                com.navifit.gacha.BorderEffect.RISE -> listOf(-0.5f to 0.8f, 0.5f to 0.8f, 0f to 0.9f)
                com.navifit.gacha.BorderEffect.FALL -> listOf(-0.3f to -0.9f, 0.5f to -0.8f, -0.6f to -0.7f)
                else -> listOf(-1f to -1f, 1f to -1f, -1f to 1f, 1f to 1f)
            }
            val dotSize = size.value * 0.10f
            positions.forEachIndexed { i, (dx, dy) ->
                Box(
                    Modifier.align(Alignment.Center)
                        .graphicsLayer {
                            translationX = dx * size.toPx() * 0.42f
                            translationY = dy * size.toPx() * 0.42f
                            alpha = if (i % 2 == 0) pulse else 1f - pulse
                        }
                        .size(dotSize.dp).clip(CircleShape).background(particleColor)
                )
            }
        }
    }
}

/** BorderTier → 파티클/발광 대표색 */
private fun borderAccentColor(tier: BorderTier): Color = when (tier) {
    BorderTier.RING_GOLD -> Color(0xFFFFD700)
    BorderTier.RING_SILVER -> Color(0xFFE8E8E8)
    BorderTier.RING_BRONZE -> Color(0xFFE8A868)
    BorderTier.RING_GREEN -> Color(0xFF8BC34A)
    BorderTier.RING_PURPLE -> Color(0xFFC084FC)
    BorderTier.RING_EMERALD -> Color(0xFF6EE7B7)
    BorderTier.RING_NEON -> Color(0xFFC6FF00)
    BorderTier.RING_PLATINUM -> Color(0xFFFFFFFF)
    BorderTier.RING_OBSIDIAN -> Color(0xFFFF3D3D)
    BorderTier.RING_AMETHYST -> Color(0xFFF3C4FB)
    BorderTier.RING_SAPPHIRE -> Color(0xFF40C4FF)
    BorderTier.RING_RAINBOW -> Color(0xFFFFFFFF)
    BorderTier.RING_FIRE -> Color(0xFFFFAB40)
    BorderTier.RING_ICE -> Color(0xFFE1F5FE)
    BorderTier.RING_COSMIC -> Color(0xFFEA80FC)
    BorderTier.RING_HOLOGRAPHIC -> Color(0xFFFFFFFF)
}

@Composable
fun MarkerGachaScreen(
    inventory: GachaInventory,
    exchangeTickets: Int,
    stepBoostLevel: Int = 0,
    onConsumeTicket: () -> Unit,
    myRecords: List<ActivityRecord> = emptyList(),
    questContent: @Composable () -> Unit = {}   // ✅ v61 만보 퀘스트 탭 내용 (MainActivity의 StepCounterPanel 주입)
) {
    var lastDrawn by remember { mutableStateOf<DrawnMarker?>(null) }
    var ownedMap by remember { mutableStateOf(inventory.getOwned()) }
    var equippedKey by remember { mutableStateOf(inventory.equippedKey) }
    var selectedBorder by remember { mutableStateOf(inventory.selectedBorderKey) }
    var isDrawing by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(0) } // 0=뽑기, 1=보유, 2=테두리, 3=확률고시
    var fusionOverlay by remember { mutableStateOf<DrawnMarker?>(null) } // 합성 연출용
    var drawOverlay by remember { mutableStateOf<DrawnMarker?>(null) }   // 뽑기 연출용 (캡슐 흔들림 -> 팡! 공개)
    var lastDrawWasPremium by remember { mutableStateOf(false) }         // ✅ v86 연출 분기용
    val gachaCtx = androidx.compose.ui.platform.LocalContext.current
    // ✅ v41 선택한 언어로 표시 (기존엔 한국어 하드코딩)
    val langCode = com.navifit.i18n.LanguageStore.current(gachaCtx).code
    val T: (String) -> String = { key -> com.navifit.i18n.UiText.get(key, langCode) }

    fun refresh() {
        ownedMap = inventory.getOwned()
        equippedKey = inventory.equippedKey
        selectedBorder = inventory.selectedBorderKey
    }

    val scale by animateFloatAsState(
        targetValue = if (lastDrawn != null) 1f else 0.5f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "scale"
    )

    val progress = remember(myRecords, ownedMap) {
        BorderProgress(
            // ✅ 매크로로 무효 처리된 세션은 테두리 해금 조건(누적km 등)에서도 제외
            cumulativeKm = myRecords.filter { it.isRankingValid }.sumOf { it.distanceMeters } / 1000,
            recordCount = myRecords.count { it.isRankingValid },
            hasUniqueMarker = ownedMap.keys.any { inventory.resolveMarker(it)?.isUnique == true },
            epicOrAboveCount = ownedMap.keys.count { key ->
                val m = inventory.resolveMarker(key)
                m != null && (m.shape.tier == GachaTier.EPIC || m.shape.tier == GachaTier.UNIQUE || m.shape.tier == GachaTier.LEGENDARY ||
                    m.color.tier == GachaTier.EPIC || m.color.tier == GachaTier.UNIQUE || m.color.tier == GachaTier.LEGENDARY)
            },
            modesUsedCount = myRecords.filter { it.isRankingValid }.map { it.mode.name }.distinct().size,
            longestWalkKm = (myRecords.filter { it.isRankingValid && it.mode == com.navifit.navigation.TravelMode.WALK }.maxOfOrNull { it.distanceMeters } ?: 0.0) / 1000,
            longestBikeKm = (myRecords.filter { it.isRankingValid && it.mode == com.navifit.navigation.TravelMode.BIKE }.maxOfOrNull { it.distanceMeters } ?: 0.0) / 1000,
            longestCarKm = (myRecords.filter { it.isRankingValid && !it.mode.isWorkoutMode }.maxOfOrNull { it.distanceMeters } ?: 0.0) / 1000,
            bestSafetyScore = myRecords.filter { it.isRankingValid && !it.mode.isWorkoutMode }.maxOfOrNull { it.safetyScore } ?: 0,
            // ── v26: 이동수단별 누적거리 ──
            walkCumKm = myRecords.filter { it.isRankingValid && it.mode == com.navifit.navigation.TravelMode.WALK }.sumOf { it.distanceMeters } / 1000,
            bikeCumKm = myRecords.filter { it.isRankingValid && it.mode == com.navifit.navigation.TravelMode.BIKE }.sumOf { it.distanceMeters } / 1000,
            carCumKm = myRecords.filter { it.isRankingValid && !it.mode.isWorkoutMode }.sumOf { it.distanceMeters } / 1000,
            // ── v26: 한 번에 긴 거리 달성 횟수 ──
            // ✅ v34: "한 번에 달성" 테두리는 쉬는 시간이 많으면 인정 안 됨
            //    (이동시간 70% 이상 + 한 번에 30분 이상 쉬지 않았을 것)
            fullCourseCount = myRecords.count { it.isRankingValid && it.isSingleSessionValid && it.mode == com.navifit.navigation.TravelMode.WALK && it.distanceMeters >= 42195 },
            walkLongCount = myRecords.count { it.isRankingValid && it.isSingleSessionValid && it.mode == com.navifit.navigation.TravelMode.WALK && it.distanceMeters >= 30000 },
            bike100Count = myRecords.count { it.isRankingValid && it.isSingleSessionValid && it.mode == com.navifit.navigation.TravelMode.BIKE && it.distanceMeters >= 100000 },
            car500Count = myRecords.count { it.isRankingValid && it.isSingleSessionValid && !it.mode.isWorkoutMode && it.distanceMeters >= 500000 },
            // ── v26: 레전더리 보유 종수 (모양 또는 색이 레전더리) ──
            legendaryMarkerCount = ownedMap.keys.count { key ->
                val m = inventory.resolveMarker(key)
                m != null && (m.shape.tier == GachaTier.LEGENDARY || m.color.tier == GachaTier.LEGENDARY)
            },
            // ── v26: 전체 컬렉션(일반~유니크 모든 등급 마커 하나씩 이상 보유) ──
            hasFullCollection = run {
                val ownedTiers = ownedMap.keys.mapNotNull { inventory.resolveMarker(it) }
                    .flatMap { listOf(it.shape.tier, it.color.tier) }.toSet()
                listOf(GachaTier.COMMON, GachaTier.RARE, GachaTier.EPIC, GachaTier.UNIQUE).all { it in ownedTiers }
            },
            safety100Days = com.navifit.tracking.SafetyStreakStore.currentStreakDays(gachaCtx),
            currentRankLabels = com.navifit.gacha.LiveRankTracker.currentRankLabels()
        )
    }
    val unlockedBorders = remember(progress) {
        if (TEST_MODE_UNLOCK_ALL_BORDERS) BorderCatalog.all.map { it.key }.toSet()
        else BorderCatalog.unlockedKeys(progress)
    }

    // ✅ v89 테스트 모드: 모든 마커(모양 × 색 전 조합)를 보유함에 자동 지급.
    //   테두리처럼 마커도 전부 보고 고를 수 있게 데모 상태를 만든다.
    //   (한 번만 실행되도록 플래그 저장 - 매번 돌면 느려짐)
    val demoCtx = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(Unit) {
        if (!TEST_MODE_UNLOCK_ALL_BORDERS) return@LaunchedEffect
        val flagPrefs = demoCtx.getSharedPreferences("gacha_inventory", 0)
        if (flagPrefs.getBoolean("demo_all_markers_granted", false)) return@LaunchedEffect
        try {
            MarkerCatalog.shapes.forEach { shape ->
                MarkerCatalog.colors.forEach { color ->
                    inventory.addMarker(DrawnMarker(shape, color))
                }
            }
            flagPrefs.edit().putBoolean("demo_all_markers_granted", true).apply()
            refresh()
        } catch (_: Exception) { }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Text(tr("마커 뽑기"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            if (TEST_MODE_UNLOCK_ALL_BORDERS) Text(tr("🧪 테스트 모드: 마커·테두리 전체 보유 상태"), fontSize = 10.sp, color = Color(0xFFFF8FA3))
            Spacer(Modifier.height(8.dp))

            ScrollableTabRow(selectedTabIndex = tab, edgePadding = 0.dp) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text(T("gacha_draw")) })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("${T("gacha_owned")}(${ownedMap.size})") })
                Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text(T("gacha_border")) })
                Tab(selected = tab == 3, onClick = { tab = 3 }, text = { Text("📋 " + T("gacha_rates")) })
                Tab(selected = tab == 4, onClick = { tab = 4 }, text = { Text(tr("🎯 만보 퀘스트")) })   // ✅ v61
                Tab(selected = tab == 5, onClick = { tab = 5 }, text = { Text(tr("📬 우편함")) })         // ✅ v63
                Tab(selected = tab == 6, onClick = { tab = 6 }, text = { Text(tr("🛒 상점")) })           // ✅ v63
            }
            Spacer(Modifier.height(12.dp))

            when (tab) {
                0 -> Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    // 뽑기 탭 전체를 화면 정중앙에 정렬
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(150.dp), contentAlignment = Alignment.Center) {
                            lastDrawn?.let { Box(Modifier.scale(scale)) { GachaResultCircle(it) } }
                                ?: Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("🎰", fontSize = 44.sp)
                                    Text(tr("아직 뽑은 마커가 없어요"), fontSize = 12.sp, color = Color.Gray)
                                }
                        }
                        lastDrawn?.let {
                            Spacer(Modifier.height(8.dp))
                            Text(it.displayName, fontWeight = FontWeight.Bold)
                            if (it.isUnique) Text(tr("✨ 완전 유니크 ✨"), color = Color(0xFFFFB300), fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(24.dp))
                        Button(
                            onClick = {
                                // ✅ 연타 버그 수정: 뽑는 중이거나 결과 연출이 아직 떠 있으면 무시
                                if (isDrawing || drawOverlay != null) return@Button
                                isDrawing = true
                                RewardAdManager.showRewardedAd(onRewardEarned = {
                                    val m = GachaEngine.drawOne(premium = false, stepBoostLevel = stepBoostLevel)
                                    inventory.addMarker(m)
                                    lastDrawWasPremium = false
                                    drawOverlay = m // 연출 오버레이로 공개 (닫힐 때 isDrawing 해제)
                                    refresh()
                                }, onAdFailedOrSkipped = { isDrawing = false })
                            },
                            modifier = Modifier.fillMaxWidth(0.85f), enabled = !isDrawing
                        ) { Text(if (isDrawing) "광고 재생 중..." else "📺 광고보고 뽑기") }
                        Spacer(Modifier.height(8.dp))
                        // ✅ v81 ① 만보 퀘스트 뽑기권 (일반 확률) — VS 프리미엄과 완전 분리
                        Button(
                            onClick = {
                                if (exchangeTickets <= 0 || isDrawing || drawOverlay != null) return@Button
                                isDrawing = true
                                onConsumeTicket()
                                val m = GachaEngine.drawOne(premium = false, stepBoostLevel = stepBoostLevel)
                                inventory.addMarker(m)
                                lastDrawWasPremium = false
                                drawOverlay = m
                                refresh()
                            },
                            modifier = Modifier.fillMaxWidth(0.85f), enabled = exchangeTickets > 0,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF34C77B))
                        ) { Text(tr("🎟️ 만보 뽑기권 (%s장)").format(exchangeTickets), color = Color.White, fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.height(8.dp))
                        // ✅ v81 ② VS 포인트 상점 프리미엄 뽑기권 (레전더리 1%)
                        val premCtx = androidx.compose.ui.platform.LocalContext.current
                        var premCount by remember { mutableStateOf(com.navifit.gacha.PremiumTicketStore.count(premCtx)) }
                        LaunchedEffect(drawOverlay, tab) { premCount = com.navifit.gacha.PremiumTicketStore.count(premCtx) }
                        Button(
                            onClick = {
                                if (premCount <= 0 || isDrawing || drawOverlay != null) return@Button
                                if (!com.navifit.gacha.PremiumTicketStore.consume(premCtx)) return@Button
                                premCount = com.navifit.gacha.PremiumTicketStore.count(premCtx)
                                isDrawing = true
                                val m = GachaEngine.drawOne(premium = true, stepBoostLevel = stepBoostLevel)
                                inventory.addMarker(m)
                                lastDrawWasPremium = true
                                drawOverlay = m
                                refresh()
                            },
                            modifier = Modifier.fillMaxWidth(0.85f), enabled = premCount > 0,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B5CF6))
                        ) { Text(tr("🎫 프리미엄 뽑기 (%s장)").format(premCount), color = Color.White, fontWeight = FontWeight.Bold) }
                        Spacer(Modifier.height(8.dp))
                        Text(tr("🎟️ 만보 뽑기권 = 만보 퀘스트 보상 (일반 확률)\n🎫 프리미엄 뽑기권 = VS 포인트 상점·우편함 (레전더리 1%)"),
                            fontSize = 10.sp, lineHeight = 15.sp, textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 2.dp))
                    }
                }

                1 -> {
                    // ✅ 같은 이모티콘(모양)끼리 한 줄로 묶고, 그 줄 안에서는 색 등급이 높은 순으로 정렬
                    val grouped = remember(ownedMap) {
                        ownedMap.keys.mapNotNull { key -> inventory.resolveMarker(key)?.let { key to it } }
                            .groupBy { it.second.shape.id }
                            .toList()
                            // 그룹(모양) 자체도 희귀도 높은 모양이 위로
                            .sortedByDescending { (_, entries) -> entries.first().second.shape.tier.ordinal }
                            .map { (shapeId, entries) ->
                                shapeId to entries.sortedByDescending { it.second.color.tier.ordinal }
                            }
                    }
                    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                        items(grouped, key = { it.first }) { (shapeId, entries) ->
                            val shapeName = entries.first().second.shape.nameKo
                            Text(shapeName, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                                modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
                            Row(
                                Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                entries.forEach { (key, marker) ->
                                    val count = ownedMap[key] ?: 0
                                    val isEquipped = key == equippedKey
                                    OwnedMarkerCell(
                                        marker = marker, count = count, isEquipped = isEquipped,
                                        onToggleEquip = { inventory.equippedKey = if (isEquipped) null else key; refresh() },
                                        onFuse = {
                                            if (count >= 3 && inventory.removeThree(key)) {
                                                val result = GachaEngine.fuse(marker)
                                                inventory.addMarker(result.marker)
                                                fusionOverlay = result.marker
                                                refresh()
                                            }
                                        }
                                    )
                                }
                            }
                        }
                        item { Spacer(Modifier.height(20.dp)) }
                    }
                }

                2 -> LazyVerticalGrid(columns = GridCells.Fixed(1), modifier = Modifier.weight(1f)) {
                    items(BorderCatalog.all) { def ->
                        val unlocked = unlockedBorders.contains(def.key)
                        val isSelected = selectedBorder == def.key
                        // ✅ v89 구간별 랭킹 테두리 — 키에서 등수를 뽑아 배지 표시
                        //   예: rank_RUN_3.0_1 → 이름이 이미 "러닝 3km 1등"이라 그대로 씀
                        val rankIdx = if (def.key.startsWith("rank_"))
                            def.key.substringAfterLast('_').toIntOrNull()?.minus(1) else null
                        val rankSmallLabel = if (rankIdx != null && unlocked)
                            "${def.icon} 현재 유지 중" else null
                        Card(
                            Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                .clickable(enabled = unlocked) {
                                    inventory.selectedBorderKey = if (isSelected) null else def.key; refresh()
                                },
                            colors = CardDefaults.cardColors(containerColor = if (isSelected) Color(0xFF2E3A5C) else MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                AnimatedBorderRing(
                                    tier = def.tier, unlocked = unlocked, size = 40.dp,
                                    animated = def.isAnimated, sparkle = def.hasSparkle,
                                    effect = def.effect, motion = def.motion, strongGlow = def.strongGlow,
                                    particleColor = borderAccentColor(def.tier)
                                ) {
                                    Text(if (unlocked) def.icon else "🔒", fontSize = 15.sp)
                                }
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(def.name + (if (unlocked) " ✅" else ""), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    }
                                    // ✅ v87 금·은·동 테두리: 어느 구간에서 몇 등인지 배지로 명확히 표시
                                    if (unlocked && rankSmallLabel != null) {
                                        val badgeBg = when (rankIdx) {
                                            0 -> Color(0xFFFFE082)   // 금
                                            1 -> Color(0xFFE0E0E0)   // 은
                                            else -> Color(0xFFE8C39E) // 동
                                        }
                                        val badgeFg = when (rankIdx) {
                                            0 -> Color(0xFF6E4E00)
                                            1 -> Color(0xFF44464A)
                                            else -> Color(0xFF5C3A1E)
                                        }
                                        Box(
                                            Modifier.padding(top = 3.dp)
                                                .background(badgeBg, RoundedCornerShape(8.dp))
                                                .padding(horizontal = 7.dp, vertical = 2.dp)
                                        ) {
                                            Text(rankSmallLabel, fontSize = 10.sp,
                                                fontWeight = FontWeight.ExtraBold, color = badgeFg)
                                        }
                                    } else if (rankIdx != null && !unlocked) {
                                        // 아직 그 등수가 아닐 때 안내
                                        Text("아직 ${when(rankIdx){0->"1등";1->"2등";else->"3등"}} 구간이 없어요",
                                            fontSize = 10.sp, color = Color(0xFF8B93AC),
                                            modifier = Modifier.padding(top = 2.dp))
                                    }
                                    Text(
                                        if (!unlocked && def.isHidden) "❓ 히든 퀘스트 - 조건을 채우면 공개돼요" else def.description,
                                        fontSize = 11.sp, color = Color.Gray
                                    )
                                    // ✅ v86 테두리에 내 누적 키로수 표시 (달성 진행도를 바로 알 수 있게)
                                    run {
                                        val km = when {
                                            def.description.contains("자전거") || def.key.contains("bike") -> progress.bikeCumKm
                                            else -> progress.walkCumKm
                                        }
                                        val label = if (def.description.contains("자전거") || def.key.contains("bike"))
                                            "🚴 내 자전거 누적" else "🏃 내 러닝 누적"
                                        Text("$label %.1fkm".format(km),
                                            fontSize = 10.sp,
                                            color = if (unlocked) Color(0xFF34D399) else Color(0xFF8B93AC))
                                    }
                                    if (def.isRankBorder && unlocked) {
                                        Text(tr("⚠️ 등수가 4등 밖으로 밀리면 자동으로 사라져요"), fontSize = 9.sp, color = Color(0xFFE8B34B))
                                    }
                                }
                                if (isSelected) Text(tr("착용중"), fontSize = 11.sp, color = Color(0xFF6E85F0), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                3 -> OddsDisclosurePanel(stepBoostLevel)

                4 -> Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
                    // ✅ v61 만보 퀘스트: 뽑기 화면 탭 안에서, 누르면 내용이 아래로 주르륵 펼쳐짐
                    questContent()
                }
                5 -> Box(Modifier.weight(1f).fillMaxWidth()) { MailboxPanel() }        // ✅ v63 우편함
                6 -> Box(Modifier.weight(1f).fillMaxWidth()) { PointShopPanel() }      // ✅ v63 포인트 상점
            }
        }

        // 합성 연출: 화면 암전 -> 중앙에 결과 마커 밝게 등장
        fusionOverlay?.let { marker ->
            FusionRevealOverlay(marker) { fusionOverlay = null }
        }
        // 뽑기 연출: 캡슐 흔들림 -> 팡! -> 등급별 이펙트와 함께 공개
        drawOverlay?.let { marker ->
            DrawRevealOverlay(marker, isPremium = lastDrawWasPremium) {
                lastDrawn = marker
                drawOverlay = null
                isDrawing = false   // ✅ 연출이 완전히 끝난 뒤에만 다음 뽑기 허용
            }
        }
    }
}

@Composable
private fun FusionRevealOverlay(marker: DrawnMarker, onDone: () -> Unit) {
    var phase by remember { mutableStateOf(0) } // 0=암전, 1=밝아지며 등장, 2=유지
    val bgAlpha by animateFloatAsState(
        targetValue = if (phase >= 1) 0.75f else 1f,
        animationSpec = tween(500), label = "bg"
    )
    val revealScale by animateFloatAsState(
        targetValue = if (phase >= 1) 1f else 0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "reveal"
    )

    LaunchedEffect(Unit) {
        delay(400) // 암전 유지
        phase = 1
        delay(2200) // 결과 보여주는 시간
        onDone()
    }

    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = bgAlpha)),
        contentAlignment = Alignment.Center
    ) {
        if (phase >= 1) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.scale(revealScale)) {
                Text(tr("🔧 합성 완료!"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
                GachaResultCircle(marker)
                Spacer(Modifier.height(10.dp))
                Text(marker.displayName, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                if (marker.isUnique) Text(tr("✨ 완전 유니크 ✨"), color = Color(0xFFFFD700), fontSize = 12.sp)
            }
        }
    }
}

/**
 * 뽑기 연출 오버레이.
 * 1단계: 캡슐(🎰)이 좌우로 흔들림 (두근두근)
 * 2단계: 화면 플래시(팡!)
 * 3단계: 결과 마커가 튀어나오면서 등급별 색의 컨페티가 사방으로 퍼짐
 */
@Composable
private fun DrawRevealOverlay(marker: DrawnMarker, isPremium: Boolean = false, onDone: () -> Unit) {
    var phase by remember { mutableStateOf(0) } // 0=흔들림, 1=플래시, 2=공개

    // 캡슐 흔들림 (좌우 진동)
    val shakeTransition = rememberInfiniteTransition(label = "shake")
    val shakeAngle by shakeTransition.animateFloat(
        initialValue = -14f, targetValue = 14f,
        animationSpec = infiniteRepeatable(tween(if (isPremium) 70 else 90), RepeatMode.Reverse), label = "sa"
    )
    // ✅ v86 프리미엄 전용: 캡슐이 커졌다 작아지는 맥동
    val pulse by shakeTransition.animateFloat(
        0.92f, 1.12f, infiniteRepeatable(tween(420), RepeatMode.Reverse), label = "pl")
    // ✅ v86 오로라 회전 (유니크/레전더리 뒤 배경)
    val auroraSpin by shakeTransition.animateFloat(
        0f, 360f, infiniteRepeatable(tween(6000, easing = LinearEasing)), label = "au")
    val auroraBreath by shakeTransition.animateFloat(
        0.55f, 1f, infiniteRepeatable(tween(1300), RepeatMode.Reverse), label = "ab")

    val flashAlpha by animateFloatAsState(
        targetValue = if (phase == 1) 1f else 0f,
        animationSpec = tween(150), label = "flash"
    )
    val revealScale by animateFloatAsState(
        targetValue = if (phase >= 2) 1f else 0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "rv"
    )
    // 컨페티 퍼짐 진행도
    val confettiProgress by animateFloatAsState(
        targetValue = if (phase >= 2) 1f else 0f,
        animationSpec = tween(1100), label = "cf"
    )

    LaunchedEffect(Unit) {
        delay(if (isPremium) 1600 else 1200) // 프리미엄은 더 길게 긴장감
        phase = 1
        delay(180)  // 플래시
        phase = 2
        delay(2400) // 결과 감상
        onDone()
    }

    val isLegendaryish = marker.isUnique || marker.hasGlow
    val confettiEmojis = if (isLegendaryish)
        listOf("✨", "🌟", "💛", "💫", "⭐", "🎉", "✨", "🌟")
    else listOf("🎉", "🎊", "✨", "💥", "🎉", "🎊", "✨", "💥")

    Box(
        Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.85f)),
        contentAlignment = Alignment.Center
    ) {
        // ═══ ✅ v86 유니크/레전더리 오로라 배경 (마커 뒤에서 회전하며 반짝임) ═══
        if (phase >= 2 && isLegendaryish) {
            Box(
                Modifier.size(300.dp)
                    .graphicsLayer {
                        rotationZ = auroraSpin
                        alpha = auroraBreath * 0.85f
                    }
                    .background(
                        Brush.sweepGradient(
                            listOf(
                                Color(0x00FFFFFF), Color(0x8800E5FF), Color(0x00FFFFFF),
                                Color(0x88FF00E5), Color(0x00FFFFFF), Color(0x88FFD700),
                                Color(0x00FFFFFF), Color(0x8834D399), Color(0x00FFFFFF)
                            )
                        ),
                        androidx.compose.foundation.shape.CircleShape
                    )
            )
            // 안쪽 부드러운 광원
            Box(
                Modifier.size(190.dp)
                    .graphicsLayer { alpha = auroraBreath * 0.7f }
                    .background(
                        Brush.radialGradient(
                            listOf(
                                if (marker.isUnique) Color(0x99FFD700) else Color(0x8800E5FF),
                                Color(0x00000000)
                            )
                        ),
                        androidx.compose.foundation.shape.CircleShape
                    )
            )
        }
        when {
            phase == 0 -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // ✅ v86 뽑기권 종류별로 다른 연출
                //   만보 뽑기권 = 🎰 슬롯머신 흔들림 / 프리미엄 = 🎁 선물상자 맥동 + 보라 후광
                if (isPremium) {
                    Box(contentAlignment = Alignment.Center) {
                        Box(
                            Modifier.size(150.dp)
                                .graphicsLayer { alpha = (pulse - 0.92f) * 4f }
                                .background(
                                    Brush.radialGradient(listOf(Color(0x99C9A5F5), Color(0x00000000))),
                                    androidx.compose.foundation.shape.CircleShape
                                )
                        )
                        Text("🎁", fontSize = 88.sp,
                            modifier = Modifier.graphicsLayer {
                                rotationZ = shakeAngle * 0.6f
                                scaleX = pulse; scaleY = pulse
                            })
                    }
                    Spacer(Modifier.height(16.dp))
                    Text(tr("프리미엄 뽑기 중..."), color = Color(0xFFE3D0FF), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                } else {
                    Text("🎰", fontSize = 84.sp,
                        modifier = Modifier.graphicsLayer { rotationZ = shakeAngle })
                    Spacer(Modifier.height(16.dp))
                    Text(tr("두근두근..."), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }
            }
            phase >= 2 -> {
                // 컨페티: 중앙에서 8방향으로 퍼져나가며 점점 투명해짐
                confettiEmojis.forEachIndexed { i, emoji ->
                    val angle = Math.toRadians((i * 45.0) + 20)
                    val dist = 150f * confettiProgress
                    Text(
                        emoji, fontSize = 24.sp,
                        modifier = Modifier.graphicsLayer {
                            translationX = (Math.cos(angle) * dist * density).toFloat()
                            translationY = ((Math.sin(angle) * dist * density) - 40f * confettiProgress * density).toFloat()
                            alpha = (1f - confettiProgress).coerceIn(0f, 1f)
                            rotationZ = confettiProgress * 360f
                        }
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.scale(revealScale)) {
                    Text(if (marker.isUnique) "🎊 대박!! 🎊" else "🎉 뽑기 성공!",
                        color = if (marker.isUnique) Color(0xFFFFD700) else Color.White,
                        fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    Spacer(Modifier.height(14.dp))
                    GachaResultCircle(marker)
                    Spacer(Modifier.height(12.dp))
                    Text(marker.displayName, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                    if (marker.isUnique) Text(tr("✨ 완전 유니크 ✨"), color = Color(0xFFFFD700), fontSize = 13.sp)
                    Spacer(Modifier.height(18.dp))
                    Text(tr("탭해서 닫기"), color = Color.Gray, fontSize = 11.sp,
                        modifier = Modifier.clickable { onDone() })
                }
            }
        }
        // 플래시
        if (flashAlpha > 0f) Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = flashAlpha)))
    }
}

@Composable
private fun OddsDisclosurePanel(stepBoostLevel: Int) {
    val normalRates = remember(stepBoostLevel) { GachaEngine.computeRates(false, stepBoostLevel) }
    val premiumRates = remember(stepBoostLevel) { GachaEngine.computeRates(true, stepBoostLevel) }
    val legendaryNormal = normalRates[GachaTier.LEGENDARY] ?: 0.0
    val legendaryPremium = premiumRates[GachaTier.LEGENDARY] ?: 0.0

    // ✅ 예전엔 Text들이 Column 없이 그리드 셀 안에 그대로 나열돼서 서로 겹쳐 보였던 문제 수정
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp)
    ) {
        // ✅ v81 확률 고시 재작성 - 뽑기권 종류를 명확히 구분
        Text(tr("📋 확률 고시"), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp,
            color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(4.dp))
        Text(tr("뽑기권 종류에 따라 확률이 다릅니다."), fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(14.dp))

        Text(tr("📺 광고 뽑기 · 🎟️ 만보 뽑기권 (일반 확률)"), fontWeight = FontWeight.Bold, fontSize = 13.sp,
            color = Color(0xFF34C77B))
        Text(tr("만보 퀘스트 보상으로 받는 뽑기권이에요. 부스트 %s단계 반영됨").format(stepBoostLevel),
            fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(6.dp))
        GachaTier.entries.forEach { t ->
            Text("${t.label}: %.4f%%".format(normalRates[t] ?: 0.0), fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 2.dp))
        }

        Spacer(Modifier.height(14.dp))
        Text(tr("🎫 프리미엄 뽑기권 (VS 포인트 상점·우편함)"), fontWeight = FontWeight.Bold, fontSize = 13.sp,
            color = Color(0xFF8B5CF6))
        Text(tr("VS 대결 포인트로 구매하거나 우편함에서 받는 뽑기권이에요. 레전더리 확률이 더 높아요"),
            fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(6.dp))
        GachaTier.entries.forEach { t ->
            Text("${t.label}: %.4f%%".format(premiumRates[t] ?: 0.0), fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 2.dp))
        }

        Spacer(Modifier.height(14.dp))
        Text(tr("완전 유니크(모양·색 둘 다 레전더리) 확률"), fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        Text(tr("· 일반 뽑기: %.6f%% (레전더리 %.4f%% × 레전더리 %.4f%%)").format(legendaryNormal / 100 * legendaryNormal, legendaryNormal, legendaryNormal),
            fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 2.dp))
        Text(tr("· 프리미엄 뽑기: %.6f%% (레전더리 %.4f%% × 레전더리 %.4f%%)").format(legendaryPremium / 100 * legendaryPremium, legendaryPremium, legendaryPremium),
            fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 2.dp))
        Spacer(Modifier.height(6.dp))
        Text(tr("모양과 색은 각각 독립적으로 뽑혀 조합돼요."), fontSize = 11.sp, color = Color(0xFF6E85F0))

        Spacer(Modifier.height(20.dp))
        Text(tr("합성 확률"), fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        Text(tr("· 소재 등급이 일반(COMMON)일 때: 승급 80% / 본전(제자리) 20% (더 내려갈 등급이 없어서 하락 없음)"),
            fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 2.dp))
        Text(tr("· 소재 등급이 레어 이상일 때: 승급 20% / 본전 70% / 하락 10%"),
            fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 2.dp))
        Text(tr("· 모양/색 각각 독립적으로 이 확률이 적용돼요"), fontSize = 11.sp, color = Color(0xFF6E85F0))

        Spacer(Modifier.height(20.dp))
        Text(tr("레전더리 색 세부 확률"), fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        Text(tr("· 골드: 95% · 레인보우: 5% (전체 기준 레인보우 ≈ 레전더리% × 5%)"),
            fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 2.dp))

        Spacer(Modifier.height(20.dp))
        Text(tr("만보기 부스트"), fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        Text(tr("· 30만보 달성마다 에픽 확률 +1%p, 유니크 확률 +0.5%p (일반에서 차감)"),
            fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 2.dp))
        Text(tr("· 최대 5단계까지 누적 (에픽 +5%p, 유니크 +2.5%p), 그 이상은 상승하지 않음"),
            fontSize = 12.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 2.dp))
        Text(tr("· ⚠️ 레전더리는 부스트 대상이 아니에요 - 항상 0.0001% 그대로 유지돼요"),
            fontSize = 12.sp, color = Color(0xFFE05A78), fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 2.dp))

        Spacer(Modifier.height(16.dp))
        Text(tr("💡 게임산업법상 확률형 아이템 정보공개 의무에 따라 모든 확률을 투명하게 공개해요."),
            fontSize = 10.sp, color = Color.Gray, lineHeight = 14.sp)
    }
}

@Composable
private fun GachaResultCircle(marker: DrawnMarker) {
    val transition = rememberInfiniteTransition(label = "glow")
    val glowAlpha by transition.animateFloat(
        initialValue = 0.3f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "a"
    )
    val bg = if (marker.color.isRainbow) ringBrush(BorderTier.RING_RAINBOW)
    else Brush.linearGradient(listOf(tierColor(marker.color.hex), tierColor(marker.color.hex)))

    Box(
        modifier = Modifier.size(130.dp)
            .then(if (marker.hasGlow) Modifier.background(
                tierColor(if (marker.color.isRainbow) "#FFD700" else marker.color.hex).copy(alpha = glowAlpha * 0.4f), CircleShape
            ) else Modifier)
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) { com.navifit.ui.map.MarkerCanvas(marker, size = 114.dp) }
}

/** ✅ v63 우편함 패널 (뽑기 화면 내). VS 랭킹 보상·이벤트 선물 수령. */
@Composable
private fun MailboxPanel() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var mails by remember { mutableStateOf(com.navifit.vs.MailboxStore.list(ctx)) }
    var toast by remember { mutableStateOf<String?>(null) }
    var showDeleteAll by remember { mutableStateOf(false) }   // ✅ v81 수령완료 전체삭제 확인

    if (showDeleteAll) {
        AlertDialog(
            onDismissRequest = { showDeleteAll = false },
            title = { Text(tr("수령완료 우편 삭제")) },
            text = { Text(tr("이미 수령(확인)한 우편을 모두 삭제할까요? 아직 안 받은 우편은 그대로 남아요.")) },
            confirmButton = {
                TextButton(onClick = {
                    com.navifit.vs.MailboxStore.deleteClaimed(ctx)
                    mails = com.navifit.vs.MailboxStore.list(ctx)
                    toast = "🗑 수령완료 우편을 정리했어요"
                    showDeleteAll = false
                }) { Text(tr("삭제"), color = Color(0xFFFF6B6B)) }
            },
            dismissButton = { TextButton(onClick = { showDeleteAll = false }) { Text(tr("취소")) } }
        )
    }
    androidx.compose.foundation.lazy.LazyColumn(Modifier.fillMaxSize().padding(14.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr("📬 우편함"), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface)
                    Text(tr("VS 랭킹 보상과 이벤트 선물을 받아요"), fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                // ✅ v81 수령완료(읽은) 우편 전체 삭제
                val claimedCount = mails.count { it.claimed }
                if (claimedCount > 0) {
                    Box(
                        Modifier.background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                            .clickable { showDeleteAll = true }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(tr("🗑 수령완료 삭제 (%s)").format(claimedCount), fontSize = 10.sp, fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            toast?.let { Text(it, color = Color(0xFF34D399), fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp)) }
        }
        items(mails.size) { i ->
            val m = mails[i]
            val icon = when (m.type) { "point" -> "💠"; "ticket" -> "🎟️"; else -> "📢" }
            androidx.compose.material3.Card(
                Modifier.fillMaxWidth().padding(vertical = 5.dp),
                shape = RoundedCornerShape(14.dp),
                colors = androidx.compose.material3.CardDefaults.cardColors(
                    containerColor = if (m.claimed) Color(0xFF16181D) else Color(0xFF20242E))
            ) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(icon, fontSize = 22.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(m.title, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                            color = if (m.claimed) Color(0xFF6B7180) else MaterialTheme.colorScheme.onSurface)
                        Text(m.body, fontSize = 11.sp, color = Color(0xFF8B93AC))
                        if (m.rewardAmount > 0)
                            Text("보상: ${m.rewardAmount}${if (m.type == "ticket") "장" else "P"}",
                                fontSize = 11.sp, color = Color(0xFF7CC7FF))
                    }
                    if (m.claimed) {
                        Text(tr("수령완료"), fontSize = 11.sp, color = Color(0xFF6B7180))
                    } else {
                        Button(onClick = {
                            val r = com.navifit.vs.MailboxStore.claim(ctx, m.id)
                            if (r != null) {
                                // ✅ v81 뽑기권 수령이 실제로 프리미엄 뽑기권에 반영되도록 수정
                                when (r.first) {
                                    "point" -> com.navifit.vs.VsMatchSystem.setMyPoints(ctx,
                                        com.navifit.vs.VsMatchSystem.myPoints(ctx) + r.second)
                                    "ticket" -> com.navifit.gacha.PremiumTicketStore.add(ctx, r.second)
                                }
                                toast = if (r.first == "ticket")
                                    "✅ 프리미엄 뽑기권 ${r.second}장 수령! (뽑기 탭에서 사용)"
                                else "✅ ${m.title} 수령! (${r.second}P)"
                                mails = com.navifit.vs.MailboxStore.list(ctx)
                            }
                        }, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6))) {
                            Text(tr("받기"), fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

/** ✅ v63 포인트 상점 패널. VS 포인트로 프리미엄 뽑기권 구매. */
@Composable
private fun PointShopPanel() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var points by remember { mutableStateOf(com.navifit.vs.VsMatchSystem.myPoints(ctx)) }
    var toast by remember { mutableStateOf<String?>(null) }
    var confirmPurchase by remember { mutableStateOf<Triple<Int, Int, String>?>(null) }   // ✅ v77 구매 확인
    var confirmSlotBuy by remember { mutableStateOf(false) }                              // ✅ v82 폴더 슬롯 구매
    var confirmNickBuy by remember { mutableStateOf(false) }                              // ✅ v85 닉네임 변경권 구매
    var folderMax by remember { mutableStateOf(com.navifit.ui.screens.RouteVaultStore.maxFolders(ctx)) }
    // (뽑기권 수, 가격) - 요청: 1장 1000P / 6장 5000P / 13장 10000P
    val packages = listOf(Triple(1, 1000, "낱장"), Triple(6, 5000, "묶음"), Triple(13, 10000, "대량"))
    androidx.compose.foundation.lazy.LazyColumn(Modifier.fillMaxSize().padding(14.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(tr("🛒 포인트 상점"), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                Box(Modifier.background(Color(0xFF243247), RoundedCornerShape(20.dp)).padding(horizontal = 12.dp, vertical = 5.dp)) {
                    Text("💠 $points P", color = Color(0xFF7CC7FF), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
            Text(tr("VS 대결로 얻은 포인트로 프리미엄 뽑기권을 구매하세요"), fontSize = 11.sp, color = Color(0xFF8B93AC))
            Spacer(Modifier.height(6.dp))
            Text(tr("프리미엄 뽑기권: 레전더리 1% · 그 외는 만보기 뽑기권과 동일 확률\n레전더리 합성 확률: 0.0001% (극악 - 확률 고시)"),
                fontSize = 10.sp, color = Color(0xFFFBBF6E), modifier = Modifier.padding(vertical = 4.dp))
            Spacer(Modifier.height(8.dp))
            toast?.let { Text(it, color = Color(0xFF34D399), fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp)) }
        }
        items(packages.size) { i ->
            val (count, price, tag) = packages[i]
            androidx.compose.material3.Card(
                Modifier.fillMaxWidth().padding(vertical = 6.dp), shape = RoundedCornerShape(16.dp),
                colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = Color(0xFF20242E))
            ) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("🎫", fontSize = 26.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(tr("프리미엄 뽑기권 %s장").format(count), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                        Text("$tag · ${if (count > 1) "장당 %.0fP".format(price.toFloat()/count) else "낱개 구매"}",
                            fontSize = 11.sp, color = Color(0xFF8B93AC))
                    }
                    Button(
                        enabled = points >= price,
                        onClick = { confirmPurchase = Triple(count, price, tag) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935))
                    ) { Text("$price P", fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                }
            }
        }
        // ✅ v82 경로 보관함 폴더 슬롯 +1 상품
        item {
            val slotPrice = com.navifit.ui.screens.RouteVaultStore.FOLDER_SLOT_PRICE
            androidx.compose.material3.Card(
                Modifier.fillMaxWidth().padding(vertical = 6.dp), shape = RoundedCornerShape(16.dp),
                colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = Color(0xFF20242E))
            ) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("📁", fontSize = 26.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(tr("경로 보관함 폴더 +1"), fontWeight = FontWeight.Bold, fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface)
                        Text(tr("현재 최대 %s개 (기본 5개 + 구매 %s개)").format(folderMax, folderMax - 5),
                            fontSize = 11.sp, color = Color(0xFF8B93AC))
                    }
                    Button(
                        enabled = points >= slotPrice,
                        onClick = { confirmSlotBuy = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6))
                    ) { Text("$slotPrice P", fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                }
            }
        }
        // ✅ v85 닉네임 변경권 (10,000P · 여러 번 구매 가능)
        item {
            val nickPrice = 10000
            val owned = com.navifit.gacha.NicknameTicketStore.count(ctx)
            androidx.compose.material3.Card(
                Modifier.fillMaxWidth().padding(vertical = 6.dp), shape = RoundedCornerShape(16.dp),
                colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = Color(0xFF20242E))
            ) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("📝", fontSize = 26.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(tr("닉네임 변경권"), fontWeight = FontWeight.Bold, fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface)
                        Text(tr("보유 %s장 · 여러 번 구매할 수 있어요").format(owned),
                            fontSize = 11.sp, color = Color(0xFF8B93AC))
                    }
                    Button(
                        enabled = points >= nickPrice,
                        onClick = { confirmNickBuy = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9B51E0))
                    ) { Text("$nickPrice P", fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
    // ✅ v85 닉네임 변경권 구매 확인
    if (confirmNickBuy) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { confirmNickBuy = false },
            title = { Text(tr("닉네임 변경권 구매")) },
            text = { Text(tr("닉네임 변경권을 10,000P에 구매할까요?\n(보유 %sP → 구매 후 %sP)\n\n설정 > 닉네임 변경에서 사용할 수 있어요.").format(points, points - 10000)) },
            confirmButton = {
                TextButton(onClick = {
                    if (points >= 10000) {
                        points -= 10000
                        com.navifit.vs.VsMatchSystem.setMyPoints(ctx, points)
                        com.navifit.gacha.NicknameTicketStore.add(ctx, 1)
                        toast = "✅ 닉네임 변경권 구매 완료! (설정에서 사용)"
                    }
                    confirmNickBuy = false
                }) { Text(tr("구매")) }
            },
            dismissButton = { TextButton(onClick = { confirmNickBuy = false }) { Text(tr("취소")) } }
        )
    }
    if (confirmSlotBuy) {
        val slotPrice = com.navifit.ui.screens.RouteVaultStore.FOLDER_SLOT_PRICE
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { confirmSlotBuy = false },
            title = { Text(tr("폴더 슬롯 구매")) },
            text = { Text(tr("경로 보관함 폴더를 1개 더 만들 수 있게 할까요?\n%sP가 차감돼요. (최대 %s개 → %s개)\n\n폴더를 지웠다 다시 만들어도 구매한 슬롯은 그대로 유지돼요.").format(slotPrice, folderMax, folderMax + 1)) },
            confirmButton = {
                TextButton(onClick = {
                    val err = com.navifit.ui.screens.RouteVaultStore.buyFolderSlot(ctx)
                    if (err == null) {
                        points = com.navifit.vs.VsMatchSystem.myPoints(ctx)
                        folderMax = com.navifit.ui.screens.RouteVaultStore.maxFolders(ctx)
                        toast = "✅ 폴더 슬롯 +1 구매 완료! (최대 ${folderMax}개)"
                    } else toast = "⚠️ $err"
                    confirmSlotBuy = false
                }) { Text(tr("구매")) }
            },
            dismissButton = { TextButton(onClick = { confirmSlotBuy = false }) { Text(tr("취소")) } }
        )
    }
    // ✅ v77 구매 확인 팝업
    confirmPurchase?.let { (count, price, _) ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { confirmPurchase = null },
            title = { Text(tr("구매 확인")) },
            text = { Text(tr("프리미엄 뽑기권 %s장을 %sP에 구매할까요?\n(현재 보유: %sP → 구매 후: %sP)").format(count, price, points, points - price)) },
            confirmButton = {
                TextButton(onClick = {
                    if (points >= price) {
                        points -= price
                        com.navifit.vs.VsMatchSystem.setMyPoints(ctx, points)
                        com.navifit.gacha.PremiumTicketStore.add(ctx, count)
                        toast = "✅ 프리미엄 뽑기권 ${count}장 구매 완료! (뽑기 탭에서 확인)"
                    }
                    confirmPurchase = null
                }) { Text(tr("구매")) }
            },
            dismissButton = { TextButton(onClick = { confirmPurchase = null }) { Text(tr("취소")) } }
        )
    }
}
