package com.navifit.tracking

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.abs

/**
 * 오토바이 vs 자동차 구분용 "코너링 리닝(lean)" 감지기.
 *
 * 원리: 오토바이는 코너를 돌 때 차체와 함께 몸/스마트폰이 실제로 좌우로 "기울어짐"(roll)이 발생함.
 *       자동차 캐빈 안에서는 코너를 돌아도(GPS 방향이 바뀌어도) 차체가 거의 수평을 유지함 -
 *       서스펜션과 4륜이 원심력을 흡수하기 때문에 스마트폰의 롤(roll) 각도 변화가 훨씬 작음.
 *
 * 방법: TYPE_ROTATION_VECTOR 센서로 기기의 롤 각도를 계속 추적하고, GPS 방향(bearing)이
 *       급하게 바뀌는 "코너링 구간"과 겹치는 시점에 롤 각도가 큰 폭(예: 18도 이상)으로
 *       함께 움직이면 "이륜차 리닝 신호"로 기록.
 *
 * ⚠️ 한계 (정직하게 명시):
 *   - 스마트폰이 거치대(핸들바)에 고정된 경우 가장 정확함
 *   - 주머니/가방 안에 있으면 신호가 약하거나 안 잡힐 수 있음 -> 그래서 이 신호는
 *     "자동차인데 리닝이 강하게 잡힘"(오토바이로 의심) 방향으로만 사용하고,
 *     "오토바이인데 리닝이 안 잡힘"은 무효화 근거로 쓰지 않음 (오탐 방지, 비대칭 판정)
 *   - 다회(연속 서로 다른 코너)에서 반복 확인되어야 확정 (급브레이크 한 번 등 단발성 흔들림 배제)
 */
class VehicleLeanMonitor(context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

    private var lastRollDegrees = 0.0
    private var lastBearing: Float? = null
    private var lastBearingUpdateMillis = 0L

    /** 서로 다른 코너에서 "강한 리닝"이 감지된 횟수 (연속 판정용) */
    var strongLeanCorneringEvents = 0
        private set
    private var lastLeanEventMillis = 0L

    companion object {
        const val CORNER_BEARING_DELTA_DEG = 20.0     // 이 정도 방향 변화면 "코너링 중"으로 간주
        const val STRONG_LEAN_DEG = 18.0              // 이 정도 롤 변화면 "리닝" 신호로 간주
        const val MIN_GAP_BETWEEN_EVENTS_MS = 4000L   // 같은 코너를 중복 카운트하지 않기 위한 최소 간격
        const val CONFIRMED_MOTORCYCLE_STREAK = 5     // 서로 다른 코너 5번에서 리닝 확인되면 확정
    }

    fun start() {
        rotationSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        strongLeanCorneringEvents = 0
    }

    fun stop() {
        sensorManager.unregisterListener(this)
        strongLeanCorneringEvents = 0
        lastBearing = null
    }

    /** GPS 갱신마다 호출 - 방향(bearing, 0~360도)을 넘겨주면 코너링 여부를 내부적으로 판단 */
    fun onBearingUpdate(bearingDegrees: Float) {
        val prev = lastBearing
        lastBearing = bearingDegrees
        if (prev == null) return

        var delta = abs(bearingDegrees - prev)
        if (delta > 180) delta = 360 - delta // 0/360 경계 보정

        if (delta >= CORNER_BEARING_DELTA_DEG) {
            // 코너링 감지됨 - 지금 롤 각도가 크게 기울어져 있는지 체크
            val now = System.currentTimeMillis()
            if (abs(lastRollDegrees) >= STRONG_LEAN_DEG && now - lastLeanEventMillis >= MIN_GAP_BETWEEN_EVENTS_MS) {
                strongLeanCorneringEvents++
                lastLeanEventMillis = now
            }
        }
    }

    /** 자동차인데 오토바이처럼 리닝하는 패턴이 여러 코너에서 반복 확정됐는지 */
    val isConfirmedTwoWheelerLean: Boolean get() = strongLeanCorneringEvents >= CONFIRMED_MOTORCYCLE_STREAK

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
        val rotationMatrix = FloatArray(9)
        SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
        val orientation = FloatArray(3)
        SensorManager.getOrientation(rotationMatrix, orientation)
        // orientation[2] = roll (라디안) -> 도(degree)로 변환
        lastRollDegrees = Math.toDegrees(orientation[2].toDouble())
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
