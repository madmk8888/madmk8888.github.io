package com.navifit.tracking

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import androidx.compose.runtime.mutableStateOf

/**
 * ✅ v91 네트워크 상태 실시간 감시.
 *
 * 왜 필요한가:
 *  경로 탐색·지도 타일·화장실 검색은 인터넷이 필요하다.
 *  오프라인이면 이것들이 조용히 실패해서 "앱이 고장났다"고 느끼게 된다.
 *  → 오프라인임을 알려주고, "운동 기록은 계속된다"는 점을 안내해야 한다.
 *
 * 중요: 운동 기록(GPS·센서)은 인터넷 없이도 동작한다. 그 사실을 사용자가 알아야
 *      산·시골에서도 안심하고 운동할 수 있다.
 */
object NetworkMonitor {

    /** 인터넷 연결 여부 (Compose에서 관찰 가능) */
    var isOnline = mutableStateOf(true)
        private set

    /** 데이터 절약 모드 등으로 제한된 연결인지 */
    var isMetered = mutableStateOf(false)
        private set

    private var registered = false
    private var callback: ConnectivityManager.NetworkCallback? = null

    fun start(context: Context) {
        if (registered) return
        try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return
            // 초기 상태 반영
            refreshNow(context)

            val request = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { isOnline.value = true }
                override fun onLost(network: Network) { refreshNow(context) }
                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                    isOnline.value = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                    isMetered.value = !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
                }
            }
            cm.registerNetworkCallback(request, cb)
            callback = cb
            registered = true
        } catch (_: Exception) { }
    }

    fun stop(context: Context) {
        if (!registered) return
        try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            callback?.let { cm?.unregisterNetworkCallback(it) }
        } catch (_: Exception) { }
        callback = null
        registered = false
    }

    /** 지금 즉시 상태 조회 */
    fun refreshNow(context: Context) {
        try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val caps = cm?.getNetworkCapabilities(cm.activeNetwork)
            isOnline.value = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
            isMetered.value = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED) == false
        } catch (_: Exception) { isOnline.value = true }
    }
}
