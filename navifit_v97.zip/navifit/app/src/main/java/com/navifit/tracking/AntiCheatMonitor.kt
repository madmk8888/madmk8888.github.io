package com.navifit.tracking

import com.google.android.gms.location.DetectedActivity
import com.navifit.navigation.TravelMode

/**
 * 이동수단 부정사용 융합 판정기 (v21 - 세계기록 반영 + 오토바이/자동차 구분).
 *
 * ── 도보/달리기(WALK, 걷기·달리기 통합) ──
 * 세계기록 페이스보다 훨씬 낮게 잡으면 엘리트 러너를 오탐하므로, "지속 시간에 따른
 * 세계기록 페이스 + 여유마진" 곡선을 사용함:
 *   - 100m 세계기록(우사인 볼트 9.58초) 평균 37.6km/h, 순간 최고속도는 44km/h 도달
 *   - 마일 세계기록(3:43) 평균 26km/h
 *   - 5000m 세계기록(12:35) 평균 23.8km/h
 *   - 마라톤 세계기록(2:00:35) 평균 21.0km/h
 * 위 기록들에 여유마진을 더해 "이 이상은 인간 지속주행으로 불가능 -> 자전거 이상"으로 판단.
 *
 * ── 자전거(BIKE) ──
 *   - 트랙 플라잉랩(단거리) 순간 60~70km/h, 타임트라이얼(1시간 내외) 평균 50~55km/h,
 *     투르 드 프랑스 평지 구간(장시간) 평균 45km/h 내외, 아워레코드(정확히 1시간, 최고 기록) 약 55km/h
 * 위 기록에 마진을 더한 곡선 사용 -> 이 이상 지속되면 오토바이/자동차로 판단.
 *
 * ── 오토바이 vs 자동차 구분 ──
 * Activity Recognition은 이 둘을 구분하지 못해서(IN_VEHICLE로 통합), 별도로
 * VehicleLeanMonitor(코너링 리닝 감지)를 이용: 자동차로 등록했는데 코너마다 오토바이 같은
 * 좌우 리닝이 반복 확정되면 "오토바이 의심"으로 랭킹 무효화. (반대 방향은 오탐이 많아 판정하지 않음 -
 *   자동차라고 등록하고 오토바이를 타면 걸리지만, 오토바이라 등록하고 자동차를 타는 경우는
 *   이 신호만으로는 확정하지 않고 GPS/AR 신호로 별도 대응)
 */
class AntiCheatMonitor(private val declaredMode: TravelMode) {

    var isRankingValid = true
        private set
    var invalidReason: String? = null
        private set

    // ── ① GPS 지속 속도 (세계기록 기반 동적 상한) ──
    private val recentSpeeds = ArrayDeque<Double>()
    private val SPEED_WINDOW = 4          // ✅ v67 8→4로 단축 (짧은 거리도 빨리 판정)
    private var instantHighStreak = 0     // ✅ v67 순간 고속 연속 카운터

    // ── ② Activity Recognition 연속 감지 카운터 ──
    private var vehicleStreak = 0
    private var bicycleStreak = 0

    // ── ③ 케이던스 검증 ──
    private var noStepFastMovingSince = 0L

    companion object {
        const val AR_CONFIDENCE_MIN = 70
        const val AR_STREAK_REQUIRED = 4

        const val CADENCE_CHECK_SPEED_KMH = 9.0     // 마라톤 페이스 이상에서만 케이던스 체크 (걷기 오탐 방지)
        const val CADENCE_MIN_STEPS_PER_MIN = 50
        const val CADENCE_VIOLATION_MILLIS = 45_000L
        const val BODY_MOTION_VIOLATION_MS = 15_000L  // ✅ v69 15초 연속 "빠른데 몸 안 움직임"이면 탈것 확정

        /**
         * 도보/달리기 - 지속 시간(초)에 따른 세계기록 기반 최대 지속가능 속도(km/h) + 여유마진.
         * 이 값을 넘으면 사람이 뛰어서는 낼 수 없는 속도 -> 자전거 이상의 이동수단으로 판정.
         */
        fun maxHumanRunSpeedKmh(sustainedSeconds: Long): Double = when {
            sustainedSeconds <= 15 -> 42.0   // 100m 세계기록급 순간 스퍼트 허용 (볼트 순간 최고 44.7km/h)
            sustainedSeconds <= 60 -> 34.0   // 400m 세계기록(43.03초) 평균 33.5km/h + 마진
            sustainedSeconds <= 300 -> 29.0  // 마일 세계기록(3:43) 평균 26km/h + 마진
            sustainedSeconds <= 1800 -> 26.0 // 5~10km 세계기록 페이스(23.8km/h) + 마진
            sustainedSeconds <= 7200 -> 24.0 // 마라톤 세계기록 페이스(21.0km/h) + 마진
            else -> 22.0                     // 그 이상 장시간 지속 - 마라톤 페이스보다도 더 여유있게 상한
        }

        /**
         * 자전거 - 지속 시간에 따른 세계기록 기반 최대 지속가능 속도(km/h) + 여유마진.
         * 이 값을 넘으면 오토바이/자동차로 판정.
         */
        fun maxHumanBikeSpeedKmh(sustainedSeconds: Long): Double = when {
            sustainedSeconds <= 15 -> 75.0   // 트랙 플라잉랩/급경사 다운힐 스퍼트 허용
            sustainedSeconds <= 60 -> 65.0
            sustainedSeconds <= 300 -> 58.0  // 단거리 타임트라이얼급
            sustainedSeconds <= 1800 -> 52.0 // 1시간 내외 타임트라이얼 평균(50~55km/h)대
            sustainedSeconds <= 7200 -> 48.0 // 투르 드 프랑스 평지구간 평균(45km/h)대 + 마진
            else -> 44.0                     // 장시간 지속 - 프로 레이스 평균보다도 여유
        }
    }

    private val isWorkoutDeclared get() = declaredMode == TravelMode.WALK || declaredMode == TravelMode.BIKE

    /**
     * ① 매 위치 갱신마다 호출 - GPS 지속 속도 판정.
     * @param sustainedSeconds 이 속도대가 유지된 누적 시간(초) - 보통 내비게이션 경과시간을 넘겨주면 됨
     */
    fun onSpeedSample(speedKmh: Double, sustainedSeconds: Long) {
        if (!isRankingValid || !isWorkoutDeclared) return

        // ✅ v67 순간 명백 고속 즉시 감지 (윈도우가 차기 전이라도):
        //   달리기인데 3샘플 연속 50km/h↑, 자전거인데 3샘플 연속 80km/h↑ → 명백한 차량
        val instantCeiling = if (declaredMode == TravelMode.BIKE) 80.0 else 50.0
        if (speedKmh >= instantCeiling) {
            instantHighStreak++
            if (instantHighStreak >= 3) {
                invalidate("순간 속도 ${speedKmh.toInt()}km/h가 연속 감지됐어요 - 사람 힘으로 낼 수 없는 속도라 탈것으로 판단돼요")
                return
            }
        } else instantHighStreak = 0

        recentSpeeds.addLast(speedKmh)
        if (recentSpeeds.size > SPEED_WINDOW) recentSpeeds.removeFirst()
        if (recentSpeeds.size < SPEED_WINDOW) return

        val avg = recentSpeeds.average()
        when (declaredMode) {
            TravelMode.WALK -> {
                val ceiling = maxHumanRunSpeedKmh(sustainedSeconds)
                if (avg >= ceiling) {
                    invalidate("지속 평균속도 ${avg.toInt()}km/h - 세계기록 페이스를 넘어서 도보/달리기로 볼 수 없어요 (자전거 이상으로 판단)")
                }
            }
            TravelMode.BIKE -> {
                val ceiling = maxHumanBikeSpeedKmh(sustainedSeconds)
                if (avg >= ceiling) {
                    invalidate("지속 평균속도 ${avg.toInt()}km/h - 자전거 세계기록 페이스를 넘어서 오토바이/자동차로 판단돼요")
                }
            }
            else -> {}
        }
    }

    /** ② Activity Recognition 결과 (3초 간격) */
    fun onDetectedActivity(activityType: Int, confidence: Int) {
        if (!isRankingValid || !isWorkoutDeclared) return
        if (confidence < AR_CONFIDENCE_MIN) return

        when (activityType) {
            DetectedActivity.IN_VEHICLE -> {
                vehicleStreak++
                bicycleStreak = 0
                if (vehicleStreak >= AR_STREAK_REQUIRED) {
                    invalidate("센서 분석 결과 차량(오토바이/자동차) 탑승이 지속 감지됐어요")
                }
            }
            DetectedActivity.ON_BICYCLE -> {
                vehicleStreak = 0
                if (declaredMode == TravelMode.WALK) {
                    bicycleStreak++
                    if (bicycleStreak >= AR_STREAK_REQUIRED) {
                        invalidate("센서 분석 결과 자전거 주행이 지속 감지됐어요 (도보/달리기로 등록됨)")
                    }
                }
            }
            DetectedActivity.WALKING, DetectedActivity.RUNNING, DetectedActivity.ON_FOOT,
            DetectedActivity.STILL -> {
                vehicleStreak = 0
                bicycleStreak = 0
            }
        }
    }

    /** ③ 케이던스 교차검증 (도보/달리기 전용) - 진짜 뛰면 반드시 걸음 진동이 잡힘 */
    fun onCadenceCheck(speedKmh: Double, stepsPerMinute: Int) {
        if (!isRankingValid || declaredMode != TravelMode.WALK) return

        val movingFastWithoutSteps = speedKmh >= CADENCE_CHECK_SPEED_KMH && stepsPerMinute < CADENCE_MIN_STEPS_PER_MIN
        if (movingFastWithoutSteps) {
            if (noStepFastMovingSince == 0L) noStepFastMovingSince = System.currentTimeMillis()
            else if (System.currentTimeMillis() - noStepFastMovingSince >= CADENCE_VIOLATION_MILLIS) {
                invalidate("걸음 진동 없이 ${speedKmh.toInt()}km/h로 이동 중 - 탈것으로 판단돼요 (진짜 달리기는 걸음이 감지돼요)")
            }
        } else {
            noStepFastMovingSince = 0L
        }
    }

    /**
     * ④ 오토바이/자동차 구분 - 코너링 리닝 신호 (VehicleLeanMonitor 결과 반영).
     * 자동차로 등록했는데 여러 코너에서 반복적으로 이륜차급 리닝이 확정되면 무효화.
     * (비대칭 판정 - 그 반대 방향은 오탐이 많아 이 신호로는 판정하지 않음)
     */
    fun onLeanSignal(confirmedTwoWheelerLean: Boolean) {
        if (!isRankingValid) return
        if (declaredMode == TravelMode.CAR && confirmedTwoWheelerLean) {
            invalidate("여러 코너에서 오토바이와 같은 좌우 리닝(기울임)이 반복 감지돼서 자동차로 볼 수 없어요")
        }
    }

    /**
     * ✅ v71 자전거 전기/일반 구분 - 페달링 리듬 + 속도 지속의 상관 분석.
     *
     * 사용자 지적 반영: 내리막 무동력 활주도 "연속성"이 있으므로 속도 평탄함만으론 부족.
     * 진짜 구분점 = "속도를 유지/가속하는데 페달링 리듬이 있는가?"
     *  · 사람: 평지·오르막에서 25km/h+ 유지하려면 반드시 규칙적 페달링 리듬이 잡힘.
     *  · 전기: 페달링 리듬 없이(또는 약하게) 고속 유지/가속.
     *  · 내리막 활주: 페달 안 밟아도 되지만, 그땐 평지 진입 시 반드시 감속함(무동력 물리).
     *    → 페달링 없음 + 감속도 없음 + 고속 = 동력원이 있다는 뜻 = 전동.
     */
    private val bikeSpeedWindow = ArrayDeque<Double>()
    private var ebikeSuspicionSince = 0L
    fun onBikeSpeedPattern(speedKmh: Double, isPedaling: Boolean, rhythmRegularity: Double) {
        if (!isRankingValid || declaredMode != TravelMode.BIKE) return
        bikeSpeedWindow.addLast(speedKmh)
        if (bikeSpeedWindow.size > 30) bikeSpeedWindow.removeFirst()
        if (bikeSpeedWindow.size < 15) return

        val avg = bikeSpeedWindow.average()
        val half = bikeSpeedWindow.size / 2
        val older = bikeSpeedWindow.take(half).average()
        val newer = bikeSpeedWindow.drop(half).average()
        val speedSustainedOrRising = newer >= older - 1.0  // 무동력이면 평지서 감속하는데 감속 없음

        // 부정: 30km/h+ 를 페달링 리듬 없이 유지/가속 (전동 어시스트 특유)
        //  ✅ v72 보수적으로: 30km/h(일반 라이더도 낼 수 있는 상한을 넘김) + 60초 지속
        val suspicious = avg >= 30.0 && !isPedaling && rhythmRegularity < 0.35 && speedSustainedOrRising
        if (suspicious) {
            if (ebikeSuspicionSince == 0L) ebikeSuspicionSince = System.currentTimeMillis()
            else if (System.currentTimeMillis() - ebikeSuspicionSince >= 60_000L) {
                invalidate("페달링 리듬 없이 ${avg.toInt()}km/h를 오래 유지했어요 - 전기자전거(전동 어시스트)로 판단됩니다. 직접 페달 밟는 리듬이 감지돼야 기록돼요")
            }
        } else {
            ebikeSuspicionSince = 0L
        }
    }

    /**
     * ✅ v72 신체 움직임 교차검증 — Google Activity Recognition을 보조하는 역할로 축소.
     *
     * 설계 원칙 (사용자 지적 반영 - 주먹구구 임계값 남발 금지):
     *  · 이동수단 판정의 주 판단은 Google Activity Recognition API(온디바이스 ML)가 담당.
     *    (WALKING/RUNNING/IN_VEHICLE를 신뢰도와 함께 정확히 구분 → onDetectedActivity)
     *  · 이 함수는 그 API가 놓치는 극단적 케이스(아주 빠른데 걸음 0)만 백업으로 잡음.
     *  · 걸었다 뛰었다 하는 정상 변화는 절대 무효 처리하지 않음 (매우 보수적).
     */
    private var noBodyMotionSince = 0L
    fun onBodyMotionCheck(speedKmh: Double, mode: TravelMode, bodyPowered: Boolean) {
        if (!isRankingValid || !isWorkoutDeclared) return
        // ✅ v72 백업 판정은 "명백한" 경우만: 20km/h 이상(달리기 세계기록급 초과 지속)인데 몸이 안 움직임
        //   → 이 정도면 Google AR도 곧 IN_VEHICLE를 잡지만, 더 빨리 확정하는 안전망.
        if (speedKmh < 20.0) { noBodyMotionSince = 0L; return }
        if (!bodyPowered) {
            if (noBodyMotionSince == 0L) noBodyMotionSince = System.currentTimeMillis()
            else if (System.currentTimeMillis() - noBodyMotionSince >= BODY_MOTION_VIOLATION_MS) {
                invalidate("${speedKmh.toInt()}km/h로 이동 중인데 달리는 움직임이 전혀 없어요 - 탈것으로 판단됩니다")
            }
        } else {
            noBodyMotionSince = 0L
        }
    }

    private fun invalidate(reason: String) {
        isRankingValid = false
        invalidReason = reason
    }

    fun reset() {
        isRankingValid = true
        invalidReason = null
        recentSpeeds.clear()
        instantHighStreak = 0
        vehicleStreak = 0
        bicycleStreak = 0
        noStepFastMovingSince = 0L
        noBodyMotionSince = 0L
    }
}
