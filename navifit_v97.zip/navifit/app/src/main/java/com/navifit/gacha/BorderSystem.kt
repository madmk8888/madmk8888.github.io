package com.navifit.gacha

/**
 * 랭킹/퀘스트 테두리 시스템 (v19 - 다양성/애니메이션 강화판).
 * 유저가 여러 개 해금하면 그중 원하는 걸 골라서 착용(표시)할 수 있음.
 *
 * ✅ 테두리 종류를 대폭 늘리고, 상위 등급은 회전(spin)+반짝임(sparkle) 애니메이션 플래그를 가짐
 *    (실제 회전/반짝임 렌더링은 UI 쪽 AnimatedBorderRing 에서 처리)
 * ✅ 랭킹 테두리(1/2/3등)는 "현재도 그 등수를 유지 중일 때만" 유효 - 5등으로 밀리면 자동 비활성화
 * ✅ 랭킹 테두리에는 어떤 구간에서 딴 건지 작은 라벨(예: "러닝 5km")이 붙음
 * ✅ 히든 미션은 이동수단마다 난이도가 다르게 분리됨 (도보 15km는 어렵고, 자동차 15km는 쉬우니까
 *    도보는 15km/자동차는 300km처럼 수단 특성에 맞게 기준을 다르게 설계)
 */
enum class BorderTier(val displayLabel: String) {
    RING_BRONZE("브론즈"),
    RING_SILVER("실버"),
    RING_GOLD("골드"),
    RING_GREEN("그린"),
    RING_PURPLE("퍼플"),
    RING_EMERALD("에메랄드"),     // 청록 보석톤 - km50급
    RING_NEON("네온"),           // 전기 시안-마젠타 - km300급 장거리
    RING_PLATINUM("플래티넘"),    // 백금 - 꾸준함 전용
    RING_OBSIDIAN("옵시디언"),    // 검은 보석에 색줄 - 장거리 드라이버 전용
    RING_AMETHYST("자수정"),      // 진보라 보석 - 컬렉터 전용
    RING_SAPPHIRE("사파이어"),    // 진청 보석 - 무결점 드라이버 전용
    RING_RAINBOW("레인보우"),
    RING_FIRE("불꽃"),        // 펄스(맥동) 애니메이션
    RING_ICE("빙결"),         // 천천히 반짝이는 결정 느낌
    RING_COSMIC("코스믹"),     // 회전 + 별가루 반짝임
    RING_HOLOGRAPHIC("홀로그램") // 가장 화려함: 회전 + 반짝임 + 무지개 시프트
}

/**
 * ✅ 테두리 링 모션 (v26): 회전 대신 세련된 모션 5종.
 *  ARC=코멧 아크(빛머리만 돎) · SHIMMER=쉬머 반사 · HUE=색결 변화 · BREATHE=숨쉬기 · NONE
 */
enum class BorderMotion { NONE, ARC, SHIMMER, HUE, BREATHE }

/**
 * ✅ 파티클 이펙트 (v26): 순수 빛 입자 방식.
 *  JEWEL=링 위 보석점 · RISE=떠오르는 입자 · FALL=흩날림 · AURA=아우라 점 · NONE
 */
enum class BorderEffect(val emoji: String, val label: String) {
    NONE("", "없음"),
    JEWEL("◆", "보석 점"),
    RISE("•", "떠오르는 입자"),
    FALL("•", "흩날림"),
    AURA("○", "아우라"),
    // 하위호환용(이전 코드가 참조하던 값 유지)
    SPARKLE("✨", "별빛"), STARDUST("🌟", "별가루"), SNOW("❄️", "눈꽃"),
    FIRE("🔥", "불꽃"), WATER("💧", "물방울"), WIND("🍃", "바람"),
    LIGHTNING("⚡", "번개"), PETAL("🌸", "꽃잎"), GEM("💎", "보석빛")
}

data class BorderDef(
    val key: String,
    val icon: String,
    val name: String,
    val description: String,
    val tier: BorderTier,
    val isHidden: Boolean = false,
    val isAnimated: Boolean = false,
    val hasSparkle: Boolean = false,
    val isRankBorder: Boolean = false,
    val effect: BorderEffect = BorderEffect.NONE,
    val motion: BorderMotion = BorderMotion.NONE,   // v26 링 모션
    val strongGlow: Boolean = false,                 // v26 강발광
    val ripple: Boolean = false                      // v26 파문
)

data class BorderProgress(
    val cumulativeKm: Double,
    val recordCount: Int,
    val hasUniqueMarker: Boolean,
    val epicOrAboveCount: Int,
    val modesUsedCount: Int,
    val longestWalkKm: Double,
    val longestBikeKm: Double,
    val longestCarKm: Double,
    val bestSafetyScore: Int,
    // ── v26 추가: 이동수단별 누적거리 + 횟수 기반 미션 ──
    val walkCumKm: Double = 0.0,           // 도보 누적 km
    val bikeCumKm: Double = 0.0,           // 자전거 누적 km
    val carCumKm: Double = 0.0,            // 자동차 누적 km
    val fullCourseCount: Int = 0,          // 도보 42.195km 이상 완주 횟수
    val walkLongCount: Int = 0,            // 도보 30km 이상 이동 횟수
    val bike100Count: Int = 0,             // 자전거 100km 이상 이동 횟수
    val car500Count: Int = 0,              // 자동차 500km 이상 주행 횟수
    val legendaryMarkerCount: Int = 0,     // 레전더리 마커 보유 종수
    val hasFullCollection: Boolean = false,// 일반~유니크 전체 컬렉션 완성 여부
    val safety100Days: Int = 0,            // 안전점수 100점 연속 유지 일수
    val currentRankLabels: Map<Int, String> = emptyMap()
)

object BorderCatalog {
    /**
     * ✅ v89 구간별 랭킹 테두리.
     *  기존엔 "1등 테두리" 하나뿐이라 3km 1등·5km 1등을 해도 테두리가 하나였다.
     *  이제 (종목 × 구간 × 등수)마다 독립된 테두리를 만들어,
     *  두 구간에서 1등이면 테두리도 두 개를 각각 보유·장착할 수 있다.
     *
     *  키 형식: "rank_{RUN|BIKE}_{km}_{1|2|3}"   예) rank_RUN_3.0_1
     */
    data class BracketSpec(val category: String, val label: String, val km: Double, val kmLabel: String)

    val RUN_BRACKETS = listOf(
        BracketSpec("RUN", "러닝", 0.1, "100m"),
        BracketSpec("RUN", "러닝", 3.0, "3km"),
        BracketSpec("RUN", "러닝", 5.0, "5km"),
        BracketSpec("RUN", "러닝", 10.0, "10km"),
        BracketSpec("RUN", "러닝", 21.0975, "하프"),
        BracketSpec("RUN", "러닝", 42.195, "풀코스")
    )
    val BIKE_BRACKETS = listOf(
        BracketSpec("BIKE", "자전거", 10.0, "10km"),
        BracketSpec("BIKE", "자전거", 30.0, "30km"),
        BracketSpec("BIKE", "자전거", 50.0, "50km"),
        BracketSpec("BIKE", "자전거", 100.0, "100km"),
        BracketSpec("BIKE", "자전거", 200.0, "200km")
    )
    val ALL_BRACKETS = RUN_BRACKETS + BIKE_BRACKETS

    fun rankBorderKey(category: String, km: Double, rank: Int) = "rank_${category}_${km}_$rank"

    /** 구간별 랭킹 테두리 전부 생성 (11구간 × 3등수 = 33개) */
    private val bracketRankBorders: List<BorderDef> = ALL_BRACKETS.flatMap { b ->
        listOf(1, 2, 3).map { rank ->
            val medal = when (rank) { 1 -> "🥇"; 2 -> "🥈"; else -> "🥉" }
            val tier = when (rank) {
                1 -> BorderTier.RING_GOLD
                2 -> BorderTier.RING_SILVER
                else -> BorderTier.RING_BRONZE
            }
            BorderDef(
                key = rankBorderKey(b.category, b.km, rank),
                icon = medal,
                name = "${b.label} ${b.kmLabel} ${rank}등",
                description = "${b.label} ${b.kmLabel} 구간에서 ${rank}위를 유지 중일 때",
                tier = tier,
                isAnimated = rank <= 2,
                hasSparkle = rank == 1,
                isRankBorder = true,
                effect = if (rank <= 2) BorderEffect.JEWEL else BorderEffect.NONE,
                motion = if (rank == 1) BorderMotion.ARC else if (rank == 2) BorderMotion.ARC else BorderMotion.BREATHE,
                strongGlow = rank == 1,
                ripple = rank == 1
            )
        }
    }

    val all = bracketRankBorders + listOf(
        // ===== 누적거리 I~V (도보 기준, 자전거×10 · 자동차×100 배수로 함께 달성) =====
        BorderDef("first", "🏃", "첫 발걸음", "어떤 이동수단이든 누적 10km 이동 시", BorderTier.RING_GREEN, motion = BorderMotion.BREATHE),
        BorderDef("km10", "🎖️", "누적거리 I", "도보 30km · 자전거 300km · 자동차 3000km 중 하나 달성", BorderTier.RING_EMERALD, motion = BorderMotion.ARC),
        BorderDef("km50", "🎖️", "누적거리 II", "도보 50km · 자전거 500km · 자동차 5000km 중 하나 달성", BorderTier.RING_SAPPHIRE, motion = BorderMotion.ARC),
        BorderDef("km100", "🏅", "누적거리 III", "도보 100km · 자전거 1000km · 자동차 10000km 중 하나 달성", BorderTier.RING_PURPLE, motion = BorderMotion.ARC),
        BorderDef("km300", "🏅", "누적거리 IV", "도보 300km · 자전거 3000km · 자동차 30000km 중 하나 달성", BorderTier.RING_NEON,
            isAnimated = true, hasSparkle = true, effect = BorderEffect.JEWEL, motion = BorderMotion.ARC, strongGlow = true),
        BorderDef("km1000", "💠", "누적거리 V", "도보 1000km · 자전거 10000km · 자동차 100000km 중 하나 달성", BorderTier.RING_COSMIC,
            isAnimated = true, hasSparkle = true, effect = BorderEffect.AURA, motion = BorderMotion.ARC, strongGlow = true),

        // ===== 히든 =====
        BorderDef("allModes", "🧭", "올라운더", "도보·자전거·자동차 모두 누적거리 5단계(도보1000·자전거10000·자동차100000km)를 달성", BorderTier.RING_RAINBOW,
            isHidden = true, isAnimated = true, hasSparkle = true, effect = BorderEffect.AURA, motion = BorderMotion.ARC, strongGlow = true, ripple = true),
        BorderDef("tenRecords", "📚", "꾸준함의 증표", "운동·주행 기록을 300회 이상 저장", BorderTier.RING_PLATINUM,
            isAnimated = true, hasSparkle = true, effect = BorderEffect.JEWEL, motion = BorderMotion.SHIMMER),
        BorderDef("longRunWalk", "🥾", "두 다리의 전설", "한 번에 42.195km 이상 도보를 10회 달성 (쉬는 시간 30% 미만·연속 휴식 30분 미만)", BorderTier.RING_FIRE,
            isHidden = true, isAnimated = true, hasSparkle = true, effect = BorderEffect.RISE, motion = BorderMotion.ARC, strongGlow = true),
        BorderDef("walkTraveler", "🚶", "도보 여행자", "한 번에 42.195km 이상 도보를 30회 달성 (쉬는 시간 30% 미만)", BorderTier.RING_GREEN,
            isHidden = true, isAnimated = true, effect = BorderEffect.NONE, motion = BorderMotion.ARC),
        BorderDef("granfondo", "🚵", "그란폰도 라이더", "한 번에 자전거로 100km 이상을 10회 달성 (쉬는 시간 30% 미만)", BorderTier.RING_ICE,
            isHidden = true, isAnimated = true, hasSparkle = true, effect = BorderEffect.FALL, motion = BorderMotion.SHIMMER),
        BorderDef("bikeTraveler", "🚴", "자전거 여행자", "한 번에 자전거로 100km 이상을 30회 달성 (쉬는 시간 30% 미만)", BorderTier.RING_SAPPHIRE,
            isHidden = true, isAnimated = true, effect = BorderEffect.NONE, motion = BorderMotion.ARC),
        BorderDef("longRunCar", "🛣️", "장거리 드라이버", "한 번에 자동차로 500km 이상을 50회 달성 (쉬는 시간 30% 미만)", BorderTier.RING_OBSIDIAN,
            isHidden = true, isAnimated = true, effect = BorderEffect.NONE, motion = BorderMotion.ARC, strongGlow = true),
        BorderDef("uniqueOwner", "✨", "완전 유니크 소유자", "레전더리 마커를 3종 이상 보유", BorderTier.RING_HOLOGRAPHIC,
            isHidden = true, isAnimated = true, hasSparkle = true, effect = BorderEffect.AURA, motion = BorderMotion.SHIMMER, strongGlow = true),
        BorderDef("collector", "💎", "컬렉터", "일반·레어·에픽·유니크까지 마커 전체를 보유", BorderTier.RING_AMETHYST,
            isHidden = true, isAnimated = true, hasSparkle = true, effect = BorderEffect.JEWEL, motion = BorderMotion.SHIMMER),
        BorderDef("perfectSafety", "🛡️", "무결점 드라이버", "안전점수 100점을 1개월(30일) 동안 유지", BorderTier.RING_SAPPHIRE,
            isHidden = true, isAnimated = true, hasSparkle = true, effect = BorderEffect.JEWEL, motion = BorderMotion.HUE),
    )

    fun unlockedKeys(p: BorderProgress): Set<String> {
        val set = mutableSetOf<String>()
        // ✅ v89 구간별 랭킹 테두리 해금 — 내가 그 구간에서 1~3등이면 그 구간 테두리만 해금
        LiveRankTracker.rankByBracket().forEach { (bracketKey, rankIdx) ->
            // bracketKey 형식: "RUN_3.0" → 카테고리·km 분리
            val cat = bracketKey.substringBefore('_')
            val km = bracketKey.substringAfterLast('_').toDoubleOrNull()
            if (km != null && rankIdx in 0..2) {
                set += rankBorderKey(cat, km, rankIdx + 1)
            }
        }
        if (p.cumulativeKm >= 10) set += "first"
        // 누적거리 배수: 도보 기준 × (자전거 10, 자동차 100)
        if (p.walkCumKm >= 30 || p.bikeCumKm >= 300 || p.carCumKm >= 3000) set += "km10"
        if (p.walkCumKm >= 50 || p.bikeCumKm >= 500 || p.carCumKm >= 5000) set += "km50"
        if (p.walkCumKm >= 100 || p.bikeCumKm >= 1000 || p.carCumKm >= 10000) set += "km100"
        if (p.walkCumKm >= 300 || p.bikeCumKm >= 3000 || p.carCumKm >= 30000) set += "km300"
        if (p.walkCumKm >= 1000 || p.bikeCumKm >= 10000 || p.carCumKm >= 100000) set += "km1000"
        // 올라운더: 셋 다 5단계 달성
        if (p.walkCumKm >= 1000 && p.bikeCumKm >= 10000 && p.carCumKm >= 100000) set += "allModes"
        if (p.recordCount >= 300) set += "tenRecords"
        if (p.fullCourseCount >= 10) set += "longRunWalk"
        if (p.fullCourseCount >= 30) set += "walkTraveler"
        if (p.bike100Count >= 10) set += "granfondo"
        if (p.bike100Count >= 30) set += "bikeTraveler"
        if (p.car500Count >= 50) set += "longRunCar"
        if (p.legendaryMarkerCount >= 3) set += "uniqueOwner"
        if (p.hasFullCollection) set += "collector"
        if (p.safety100Days >= 30) set += "perfectSafety"
        return set
    }
}

/**
 * 랭킹화면에서 계산한 "지금 이 순간의 내 등수"를 다른 화면(뽑기/테두리 탭)에서도 알 수 있게
 * 공유하는 가벼운 저장소. 랭킹탭에서 종목·구간을 볼 때마다 갱신됨.
 * (실제 서버 랭킹 연동 시엔 서버에서 실시간으로 이 값을 받아오도록 교체하면 됨)
 */
object LiveRankTracker {
    // key: "카테고리_구간km" (예: "러닝_5.0"), value: 1등=0, 2등=1, 3등=2 (Top3 밖이면 저장 안 함)
    private val top3ByBracket = mutableMapOf<String, Int>()
    private val labelByBracket = mutableMapOf<String, String>() // 사람이 읽을 라벨 (예: "러닝 5km")

    fun report(bracketKey: String, label: String, rankIndex: Int?) {
        if (rankIndex != null && rankIndex < 3) {
            top3ByBracket[bracketKey] = rankIndex
            labelByBracket[bracketKey] = label
        } else {
            top3ByBracket.remove(bracketKey)
            labelByBracket.remove(bracketKey)
        }
    }

    /** 0=1등,1=2등,2=3등 -> 그 등수를 현재 유지 중인 구간 라벨 (여러 구간이면 첫 번째만 - 해금 판정용) */
    fun currentRankLabels(): Map<Int, String> {
        val result = mutableMapOf<Int, String>()
        top3ByBracket.forEach { (bracket, rank) ->
            if (!result.containsKey(rank)) result[rank] = labelByBracket[bracket] ?: bracket
        }
        return result
    }

    /**
     * ✅ v89 구간키 → 등수 인덱스(0=1등,1=2등,2=3등) 전체 맵.
     *  구간별 테두리 해금 판정에 쓰인다.
     */
    fun rankByBracket(): Map<String, Int> = top3ByBracket.toMap()

    /**
     * ✅ v87 등수별로 "내가 그 등수를 지키고 있는 모든 구간"을 반환.
     *  예: 1등 → ["러닝 3km", "러닝 5km"]  (금 테두리에 3km·5km 둘 다 표시)
     *  구간 거리 오름차순으로 정렬해서 보기 좋게 만든다.
     */
    fun allRankLabels(): Map<Int, List<String>> {
        val result = mutableMapOf<Int, MutableList<Pair<Double, String>>>()
        top3ByBracket.forEach { (bracket, rank) ->
            val label = labelByBracket[bracket] ?: bracket
            // bracketKey 형식: "러닝_5.0" → 정렬용 거리 추출
            val km = bracket.substringAfterLast('_').toDoubleOrNull() ?: 0.0
            result.getOrPut(rank) { mutableListOf() }.add(km to label)
        }
        return result.mapValues { (_, list) ->
            list.sortedBy { it.first }.map { it.second }
        }
    }
}
