package com.navifit.social

import android.content.Context

/**
 * ✅ 내정보 "소개 한 줄" (최대 100자) - 랭킹 화면에서 다른 사람들에게 보임.
 * 로컬 저장 - 실서버 연동 시 users/{uid}.bio 필드로 함께 저장하면 됨.
 */
object BioStore {
    private const val PREFS = "bio_store"
    const val MAX_LENGTH = 100

    fun load(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("bio", "") ?: ""

    fun save(context: Context, bio: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString("bio", bio.take(MAX_LENGTH)).apply()
    }
}
