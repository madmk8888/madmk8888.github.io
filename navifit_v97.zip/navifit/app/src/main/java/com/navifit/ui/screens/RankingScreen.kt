package com.navifit.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.navifit.i18n.tr
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.maps.android.compose.*
import com.navifit.data.ActivityRecord
import com.navifit.navigation.TravelMode
import com.navifit.i18n.LocalStrings
import kotlin.math.abs
import kotlin.random.Random

/**
 * 랭킹 화면 (v17 전면 개편).
 *
 * ✅ 종목 분리: 🏃 러닝 · 🚴 자전거 · 🏍️ 오토바이 · 🚗 운전
 * ✅ 구간(브래킷): 러닝은 풀코스 42.195km까지, 자전거/오토바이/운전은 10·50·100·500km 등 장거리 구간
 * ✅ 운전/오토바이 정렬: 안전점수 1순위 → 같은 점수면 빠른 기록 순
 * ✅ 경로 표시: 각 기록의 "어디서 → 어디까지"가 보이고, 검색으로 원하는 경로를 찾을 수 있음
 * ✅ 경로 보기: 기록을 탭하면 그 사람이 간 길이 지도에 형광색으로 표시됨
 * ✅ 표시 정책: 상위 100등까지만 리스트에 공개, 그 밖의 등수는 본인에게만 (내 등수 + 상위 몇% 카드)
 *
 * ⚠️ 다른 유저 데이터는 시연용 가상 데이터. 실제 전세계 랭킹은 서버 연동 후 같은 구조로 동작.
 */

private enum class RankCategory(val label: String, val emoji: String, val modes: List<TravelMode>, val safetyFirst: Boolean) {
    // ✅ v58: 랭킹은 순수 운동만 - 오토바이/운전 카테고리 제거
    RUN("러닝", "🏃", listOf(TravelMode.WALK), false),
    BIKE("자전거", "🚴", listOf(TravelMode.BIKE), false);

    /** 종목별 구간(브래킷) - 종목 특성에 맞게 설계 */
    val brackets: List<Double> get() = when (this) {
        RUN -> listOf(0.1, 3.0, 5.0, 10.0, 21.0975, 42.195)           // ✅ v62 100m·3·5·10·하프·풀
        BIKE -> listOf(10.0, 30.0, 50.0, 100.0, 200.0)                  // 그란폰도/브레베 스타일
    }

    fun bracketLabel(km: Double): String = when (km) {
        42.195 -> "풀코스"
        21.0975 -> "하프"
        0.1 -> "100m"
        else -> "${km.toInt()}km"
    }
}

private data class RankEntry(
    val name: String,
    val flag: String,
    val timeSec: Int,
    val safetyScore: Int,
    val originName: String,
    val destName: String,
    val pathPolyline: String?,
    val isMe: Boolean
)

@Composable
fun RankingScreen(
    myRecords: List<ActivityRecord>, myNickname: String,
    onVisitProfile: (nickname: String) -> Unit = {},   // ✅ v79 랭킹 이름 탭 메뉴
    onAddFriend: (nickname: String) -> Unit = {},
    onSendRm: (nickname: String) -> Unit = {}
) {
    var category by remember { mutableStateOf(RankCategory.RUN) }
    var selectedKm by remember { mutableStateOf(category.brackets.first()) }
    var routeQuery by remember { mutableStateOf("") }
    var viewingEntry by remember { mutableStateOf<RankEntry?>(null) }
    var rankerMenuTarget by remember { mutableStateOf<String?>(null) }   // ✅ v79 이름 탭 메뉴
    var countryFilter by remember { mutableStateOf<String?>(null) } // null=전체, 아니면 국기 이모지로 필터

    // 종목 바뀌면 첫 구간으로
    LaunchedEffect(category) { selectedKm = category.brackets.first() }

    // ===== 엔트리 구성: 가상 데이터 + 내 실제 기록 =====
    val allEntries = remember(category, selectedKm, myRecords) {
        buildEntries(category, selectedKm, myRecords, myNickname)
    }
    // 정렬: 운전/오토바이는 안전점수 ↓ -> 시간 ↑ / 운동은 시간 ↑
    val sorted = remember(allEntries) {
        if (category.safetyFirst)
            allEntries.sortedWith(compareByDescending<RankEntry> { it.safetyScore }.thenBy { it.timeSec })
        else allEntries.sortedBy { it.timeSec }
    }
    val myRank = sorted.indexOfFirst { it.isMe } // -1이면 이 구간 기록 없음
    val myPercentile = if (myRank >= 0) ((myRank + 1).toDouble() / sorted.size * 100) else null

    // ✅ v87 모든 종목·구간의 내 등수를 한 번에 계산해서 보고.
    //   기존엔 "지금 보고 있는 구간"만 보고해서, 3km 랭킹을 열어보지 않으면
    //   금 테두리에 "3km 1등"이 안 떴다. 이제 랭킹 화면에 들어오기만 하면 전부 반영된다.
    LaunchedEffect(myRecords) {
        RankCategory.entries.forEach { cat ->
            cat.brackets.forEach { km ->
                val entries = buildEntries(cat, km, myRecords, myNickname)
                val s = if (cat.safetyFirst)
                    entries.sortedWith(compareByDescending<RankEntry> { it.safetyScore }.thenBy { it.timeSec })
                else entries.sortedBy { it.timeSec }
                val r = s.indexOfFirst { it.isMe }
                com.navifit.gacha.LiveRankTracker.report(
                    "${cat.name}_$km",
                    "${cat.label} ${cat.bracketLabel(km)}",
                    r.takeIf { it >= 0 }
                )
            }
        }
    }

    // ✅ 랭킹 테두리 실시간 반영: 이 구간을 보는 시점의 내 등수를 공유 저장소에 보고
    // (5등으로 밀리면 rank1/2/3 테두리가 자동으로 비활성화되도록 뽑기 화면에서 이 값을 읽음)
    LaunchedEffect(myRank, category, selectedKm) {
        val bracketKey = "${category.name}_$selectedKm"
        val label = "${category.label} ${category.bracketLabel(selectedKm)}"
        com.navifit.gacha.LiveRankTracker.report(bracketKey, label, myRank.takeIf { it >= 0 })
    }

    // 경로 검색 + 나라 필터 (표시용 - 등수 순번 자체는 전체 기준 유지)
    // ✅ v81 내 근처 랭킹: 내 등수 기준 위아래 ±10명만 보기
    var nearMeOnly by remember { mutableStateOf(false) }
    val visible = remember(sorted, routeQuery, countryFilter, nearMeOnly) {
        val base = if (nearMeOnly) {
            val myIdx = sorted.indexOfFirst { it.isMe }
            if (myIdx < 0) sorted.take(100)
            else sorted.subList(
                (myIdx - 10).coerceAtLeast(0),
                (myIdx + 11).coerceAtMost(sorted.size)
            )
        } else sorted.take(100)
        base
            .let { list -> if (routeQuery.isBlank()) list else list.filter { it.originName.contains(routeQuery, true) || it.destName.contains(routeQuery, true) } }
            .let { list -> if (countryFilter == null) list else list.filter { it.flag == countryFilter || it.isMe } }
    }
    val availableCountries = remember(sorted) { sorted.map { it.flag }.distinct().filter { it != "🙋" } }

    Column(Modifier.fillMaxSize()) {
        val ctx = androidx.compose.ui.platform.LocalContext.current
        var viewMode by remember { mutableStateOf(0) }   // 0=랭킹 1=명예의전당 2=내 업적

        // ✅ v63 월 1회 명예의 전당 갱신 (run=풀코스, bike=200km) - 실서버 없으면 데모로 시연
        LaunchedEffect(Unit) {
            if (com.navifit.social.HallOfFameStore.needsMonthlyRoll(ctx)) {
                com.navifit.social.HallOfFameStore.rollMonthly(ctx, "run", "풀코스챔피언", "풀코스 2:58:14 · 서울", System.currentTimeMillis())
                com.navifit.social.HallOfFameStore.rollMonthly(ctx, "bike", "라이딩머신", "200km 6:42:08 · 부산", System.currentTimeMillis())
            }
        }

        // 상단 뷰 전환 탭
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("🏆 랭킹", "💠 포인트", "👑 전당", "🎖 업적").forEachIndexed { i, label ->
                val sel = viewMode == i
                Box(
                    Modifier.weight(1f)
                        .background(if (sel) Brush.linearGradient(listOf(Color(0xFF0095F6), Color(0xFF5C6BC0)))
                                    else Brush.linearGradient(listOf(Color(0xFF1C1C1E), Color(0xFF1C1C1E))),
                            RoundedCornerShape(12.dp))
                        .clickable { viewMode = i }.padding(vertical = 9.dp),
                    contentAlignment = Alignment.Center
                ) { Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    color = if (sel) Color.White else Color(0xFFA8A8A8)) }
            }
        }

        when (viewMode) {
            1 -> { PointRankingView(); return@Column }
            2 -> { HallOfFameView(); return@Column }
            3 -> { AchievementsView(); return@Column }
        }

        Column(Modifier.padding(16.dp)) {
            Text(LocalStrings.current.ranking, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            Text(tr("이 랭킹과 명예의 전당은 매달 1일에 갱신·초기화돼요."), fontSize = 10.sp, color = Color(0xFF8B93AC))
            Spacer(Modifier.height(10.dp))

            // ===== 종목 탭 =====
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(RankCategory.entries) { c ->
                    val sel = c == category
                    Box(
                        Modifier.background(
                            if (sel) Brush.linearGradient(listOf(Color(0xFF8B9FFF), Color(0xFFC9A5F5)))
                            else Brush.linearGradient(listOf(Color(0xFF2A2635), Color(0xFF2A2635))),
                            RoundedCornerShape(18.dp)
                        ).clickable { category = c }.padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text("${c.emoji} ${c.label}", fontSize = 13.sp, fontWeight = FontWeight.Bold,
                            color = if (sel) Color.White else Color(0xFFEDEAF4))
                    }
                }
            }
            Spacer(Modifier.height(8.dp))

            // ===== 구간 선택 =====
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(category.brackets) { km ->
                    val sel = km == selectedKm
                    Box(
                        Modifier.background(if (sel) Color(0xFF7EDDB8) else Color(0xFF2A2635), RoundedCornerShape(16.dp))
                            .clickable { selectedKm = km }
                            .padding(horizontal = 13.dp, vertical = 7.dp)
                    ) {
                        Text(category.bracketLabel(km), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            color = if (sel) Color.White else Color(0xFFEDEAF4))
                    }
                }
            }

            Spacer(Modifier.height(6.dp))

            // ✅ v78 검색·필터를 버튼으로 접기 (평소엔 랭킹 사람들이 화면에 많이 보이게)
            var showFilters by remember { mutableStateOf(false) }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Box(
                    Modifier.background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(14.dp))
                        .clickable { showFilters = !showFilters }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(if (showFilters) "🔍 검색·필터 닫기 ▲" else "🔍 검색·필터 ▼",
                        fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.width(6.dp))
                // ✅ v81 내 근처 랭킹 토글
                Box(
                    Modifier.background(
                        if (nearMeOnly) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        RoundedCornerShape(14.dp))
                        .clickable { nearMeOnly = !nearMeOnly }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(tr("🙋 내 근처"), fontSize = 11.sp, fontWeight = FontWeight.Bold,
                        color = if (nearMeOnly) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            if (showFilters) {
                Spacer(Modifier.height(6.dp))
                // ===== 경로 검색 =====
                OutlinedTextField(
                    value = routeQuery, onValueChange = { routeQuery = it },
                    placeholder = { Text(tr("경로 검색 (예: 강남, 한강공원…)"), fontSize = 13.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    trailingIcon = { if (routeQuery.isNotBlank()) Text("✕", Modifier.clickable { routeQuery = "" }.padding(8.dp)) }
                )
                // ===== 나라별 필터 =====
                Spacer(Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    item {
                        val sel = countryFilter == null
                        Box(
                            Modifier.background(if (sel) Color(0xFF7EDDB8) else Color(0xFF2A2635), RoundedCornerShape(14.dp))
                                .clickable { countryFilter = null }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) { Text(tr("🌍 전체"), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (sel) Color.White else Color.Gray) }
                    }
                    items(availableCountries) { flag ->
                        val sel = countryFilter == flag
                        Box(
                            Modifier.background(if (sel) Color(0xFF7EDDB8) else Color(0xFF2A2635), RoundedCornerShape(14.dp))
                                .clickable { countryFilter = flag }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) { Text(flag, fontSize = 13.sp) }
                    }
                }
            }

            // ===== 내 등수 카드 (100등 밖이어도 본인에게만 표시) =====
            Spacer(Modifier.height(8.dp))
            val bioContext = androidx.compose.ui.platform.LocalContext.current
            val myBio = remember { com.navifit.social.BioStore.load(bioContext) }
            var viewingBio by remember { mutableStateOf<Pair<String, String>?>(null) } // (이름, 소개)
            Card(
                Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF2E3A5C))
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("🙋", fontSize = 20.sp)
                    Spacer(Modifier.width(10.dp))
                    if (myRank >= 0) {
                        Column {
                            Text(tr("내 순위: %s등 / %s명 (상위 %.1f%%)").format(myRank + 1, sorted.size, myPercentile),
                                fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, color = Color.White)
                            // ✅ 내정보에서 쓴 소개 한 줄 - 누르면 전체를 안 끊기고 볼 수 있음
                            if (myBio.isNotBlank()) {
                                Text("💬 $myBio", fontSize = 11.sp, color = Color(0xFFB8C4F0),
                                    maxLines = 1,
                                    modifier = Modifier.clickable { viewingBio = "나" to myBio })
                            }
                        }
                    } else {
                        Text(tr("이 구간(%s)에 아직 내 기록이 없어요").format(category.bracketLabel(selectedKm)), fontSize = 12.sp, color = Color.Gray)
                    }
                }
            }
            // ✅ 소개 전체 보기 다이얼로그 (길어도 안 끊기고 전부 표시)
            viewingBio?.let { (who, text) ->
                AlertDialog(
                    onDismissRequest = { viewingBio = null },
                    title = { Text(tr("💬 %s의 소개").format(who)) },
                    text = { Text(text, fontSize = 13.sp, lineHeight = 19.sp) },
                    confirmButton = { TextButton(onClick = { viewingBio = null }) { Text(tr("닫기")) } }
                )
            }
        }

        // ===== 리스트 (상위 100등까지만 공개) =====
        LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp)) {
            itemsIndexed(visible) { _, e ->
                val realRank = sorted.indexOf(e)
                RankRow(realRank, e, category.safetyFirst, onNameClick = { rankerMenuTarget = e.name }) { viewingEntry = e }
            }
            item {
                Text(
                    tr("· 상위 100등까지만 공개됩니다 (그 외 순위는 본인에게만 표시)\n· 다른 유저는 시연용 가상 데이터예요. 서버 연동 후 실제 전세계 랭킹으로 바뀝니다."),
                    fontSize = 10.sp, color = Color.Gray, lineHeight = 14.sp,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }
        }
    }

    // ===== 경로 보기 다이얼로그: 그 사람이 간 길을 형광색으로 =====
    viewingEntry?.let { e -> RoutePreviewDialog(e, category.modes.first()) { viewingEntry = null } }
    // ✅ v79 랭킹 이름 탭 메뉴 (구경/친구추가/RM)
    rankerMenuTarget?.let { name ->
        AlertDialog(
            onDismissRequest = { rankerMenuTarget = null },
            title = { Text(name) },
            text = {
                Column {
                    DropdownRow("👤 운동장 구경하기") { onVisitProfile(name); rankerMenuTarget = null }
                    DropdownRow("➕ 친구 추가 요청") { onAddFriend(name); rankerMenuTarget = null }
                    DropdownRow("✉️ RM 보내기") { onSendRm(name); rankerMenuTarget = null }
                }
            },
            confirmButton = { TextButton(onClick = { rankerMenuTarget = null }) { Text(tr("닫기")) } }
        )
    }
}

@Composable
private fun DropdownRow(label: String, onClick: () -> Unit) {
    Text(label, fontSize = 15.sp, fontWeight = FontWeight.Medium,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 12.dp))
}

@Composable
private fun RankRow(rank: Int, e: RankEntry, safetyFirst: Boolean, onNameClick: () -> Unit, onClick: () -> Unit) {
    val (medalEmoji, ringBrush) = when (rank) {
        0 -> "🥇" to Brush.sweepGradient(listOf(Color(0xFFFFD700), Color(0xFFFFF3B0), Color(0xFFFFD700)))
        1 -> "🥈" to Brush.sweepGradient(listOf(Color(0xFFE0E0E0), Color.White, Color(0xFFC0C0C0)))
        2 -> "🥉" to Brush.sweepGradient(listOf(Color(0xFFCD7F32), Color(0xFFE8A868), Color(0xFFCD7F32)))
        else -> null to Brush.linearGradient(listOf(Color(0xFF2A2635), Color(0xFF2A2635)))
    }
    Card(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        // ✅ UI 고급화: 흰 카드가 다크 테마와 튀던 문제 → 톤을 맞춘 딥네이비 카드 + 내 기록은 은은한 강조
        colors = CardDefaults.cardColors(containerColor = if (e.isMe) Color(0xFF2A3350) else Color(0xFF1E2233)),
        border = if (rank < 3) androidx.compose.foundation.BorderStroke(1.dp, Color(0x55FFD700))
                 else androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C3145)),
        elevation = CardDefaults.cardElevation(defaultElevation = if (rank < 3) 3.dp else 0.dp)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).clip(CircleShape).background(ringBrush).padding(2.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.fillMaxSize().clip(CircleShape).background(Color(0xFF15182a)), contentAlignment = Alignment.Center) {
                    Text(medalEmoji ?: "#${rank + 1}", fontSize = if (medalEmoji != null) 16.sp else 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFAAB0C4))
                }
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(e.flag, fontSize = 14.sp)
                    Spacer(Modifier.width(4.dp))
                    Text(e.name + if (e.isMe) " (나)" else "", fontWeight = FontWeight.Bold, fontSize = 14.sp,
                        color = Color(0xFFECEDF4),
                        modifier = Modifier.clickable { if (!e.isMe) onNameClick() })
                }
                // 경로: 어디서 → 어디까지
                Text("📍 ${e.originName} → ${e.destName}", fontSize = 11.sp, color = Color(0xFF7C93F5), maxLines = 1)
                Row {
                    if (safetyFirst) {
                        Text(tr("🛡️ %s점").format(e.safetyScore), fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            color = when { e.safetyScore >= 90 -> Color(0xFF5BBD8B); e.safetyScore >= 70 -> Color(0xFFE8B34B); else -> Color(0xFFFF8FA3) })
                        Text("  ·  ", fontSize = 12.sp, color = Color(0xFF6B7188))
                    }
                    Text(formatSec(e.timeSec), fontSize = 12.sp, color = Color(0xFF9AA0B4))
                }
            }
            Text(tr("경로 ›"), fontSize = 10.sp, color = Color(0xFF7C93F5), fontWeight = FontWeight.Bold)
        }
    }
}

/** 기록을 탭하면: 그 사람이 간 길을 지도에 형광색으로 표시 */
@Composable
private fun RoutePreviewDialog(e: RankEntry, mode: TravelMode, onDismiss: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(22.dp), color = Color(0xFF1B1E2C)) {  // ✅ 다크 테마 통일
            Column(Modifier.padding(16.dp)) {
                Text(tr("%s %s의 경로").format(e.flag, e.name), fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                Text("📍 ${e.originName} → ${e.destName} · ${formatSec(e.timeSec)}", fontSize = 12.sp, color = Color.Gray)
                Spacer(Modifier.height(10.dp))

                val pts = remember(e) { e.pathPolyline?.let { decodePolyline(it) } ?: emptyList() }
                val cameraState = rememberCameraPositionState {
                    position = CameraPosition.fromLatLngZoom(
                        pts.firstOrNull()?.let { LatLng(it.latitude, it.longitude) } ?: LatLng(37.5665, 126.9780), 12f)
                }
                LaunchedEffect(pts) {
                    if (pts.size >= 2) {
                        val b = LatLngBounds.builder().apply { pts.forEach { include(LatLng(it.latitude, it.longitude)) } }.build()
                        try { cameraState.move(CameraUpdateFactory.newLatLngBounds(b, 60)) } catch (_: Exception) {}
                    }
                }
                Box(Modifier.fillMaxWidth().height(280.dp).clip(RoundedCornerShape(16.dp))) {
                    if (pts.size >= 2) {
                        GoogleMap(modifier = Modifier.fillMaxSize(), cameraPositionState = cameraState) {
                            val ll = pts.map { LatLng(it.latitude, it.longitude) }
                            // 형광 표시 (글로우 + 본선)
                            Polyline(points = ll, color = Color(0x66FF1744), width = 22f)
                            Polyline(points = ll, color = Color(0xFFFF1744), width = 9f)
                            Marker(state = MarkerState(ll.first()), title = "출발: ${e.originName}")
                            Marker(state = MarkerState(ll.last()), title = "도착: ${e.destName}")
                        }
                    } else {
                        Box(Modifier.fillMaxSize().background(Color(0xFF2A2635)), contentAlignment = Alignment.Center) {
                            Text(tr("이 기록에는 경로 데이터가 없어요"), fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                // ✅ 경로 공유: 고유키 발급 방식 (예: R-4K7P2Q).
                //    키를 친구에게 알려주면, 친구가 "공유경로 키 입력"에서 이 키를 넣어 그 길 그대로 안내받음.
                if (e.pathPolyline != null) {
                    var issuedKey by remember(e) { mutableStateOf<String?>(null) }
                    issuedKey?.let { key ->
                        Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFF232030)) {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Text("🔑 $key", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp,
                                    color = Color(0xFF7EDDB8), modifier = Modifier.weight(1f))
                                Text(tr("복사됨"), fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                    OutlinedButton(
                        onClick = {
                            val key = com.navifit.navigation.RouteKeyStore.issueKey(context, mode, e.pathPolyline)
                            issuedKey = key
                            val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            cm.setPrimaryClip(android.content.ClipData.newPlainText("navifit_route_key", key))
                            android.widget.Toast.makeText(context,
                                "🔑 경로 키 $key 가 복사됐어요! 친구가 지도 화면의 '공유경로 키 입력'에 넣으면 이 길 그대로 안내돼요",
                                android.widget.Toast.LENGTH_LONG).show()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(tr("👣 경로 키 발급 (공유)"), fontSize = 13.sp) }
                    Spacer(Modifier.height(6.dp))
                }
                Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8B9FFF))) { Text(tr("닫기")) }
            }
        }
    }
}

// ===== 엔트리 생성 (가상 유저 + 내 기록) =====

private fun buildEntries(
    category: RankCategory, km: Double, myRecords: List<ActivityRecord>, myNickname: String
): List<RankEntry> {
    val fakeNames = listOf("SwiftFox", "RunnerJane", "김달림", "MikeSpeed", "ThunderLegs", "Ana Corre", "박질주", "빠른바람",
        "서울라이더", "NightOwl", "정속주행", "한강매니아", "GoGoGo", "새벽러너", "안전제일", "Cruiser")
    val flags = listOf("🇺🇸", "🇬🇧", "🇰🇷", "🇺🇸", "🇦🇺", "🇧🇷", "🇰🇷", "🇰🇷", "🇰🇷", "🇯🇵", "🇰🇷", "🇰🇷", "🇩🇪", "🇰🇷", "🇰🇷", "🇫🇷")
    val places = listOf("강남역", "한강공원", "여의도", "잠실", "홍대입구", "서울숲", "북악스카이웨이", "올림픽공원", "판교", "인천대교", "남산", "광화문")

    // 종목별 현실적인 평균 속도(km/h) 범위
    val (minSpd, maxSpd) = when (category) {
        RankCategory.RUN -> 7.0 to 16.0
        RankCategory.BIKE -> 18.0 to 38.0
    }

    val fake = fakeNames.mapIndexed { i, n ->
        val rnd = Random(n.hashCode() * 31 + km.toInt() * 7 + category.ordinal)
        val speed = minSpd + rnd.nextDouble() * (maxSpd - minSpd)
        val o = places[rnd.nextInt(places.size)]
        var d = places[rnd.nextInt(places.size)]
        if (d == o) d = places[(places.indexOf(o) + 1) % places.size]
        RankEntry(
            name = n, flag = flags[i],
            timeSec = (km / speed * 3600).toInt(),
            safetyScore = if (category.safetyFirst) 60 + rnd.nextInt(41) else 100,
            originName = o, destName = d,
            pathPolyline = demoPolyline(rnd, km),
            isMe = false
        )
    }.toMutableList()

    // ✅ 구간·종목마다 참가자 수를 다르게 (등수와 상위 %가 구간별로 서로 다르게 나오도록)
    //    - 짧은 인기 구간일수록 사람이 많고, 긴 구간일수록 적음
    val bracketIndex = category.brackets.indexOf(km).coerceAtLeast(0)
    val extraCount = (140 - bracketIndex * 25 + category.ordinal * 10).coerceIn(20, 160)
    val extraRnd = Random(km.toInt() * 131 + category.ordinal * 17)
    repeat(extraCount) { i ->
        val speed = minSpd + extraRnd.nextDouble() * (maxSpd - minSpd)
        val o = places[extraRnd.nextInt(places.size)]
        var d = places[extraRnd.nextInt(places.size)]
        if (d == o) d = places[(places.indexOf(o) + 1) % places.size]
        // ✅ 버그 수정: 확장 가상 유저들에게 경로가 없어서 "이 기록에는 경로 데이터가 없어요"만 떴음
        //    → 모든 시연용 기록에 가상 경로를 생성해 경로 보기가 항상 동작
        val extraEntryRnd = Random(extraRnd.nextInt())
        fake.add(RankEntry(
            name = "러너${1000 + i}", flag = flags[extraRnd.nextInt(flags.size)],
            timeSec = (km / speed * 3600).toInt(),
            safetyScore = if (category.safetyFirst) 55 + extraRnd.nextInt(46) else 100,
            originName = o, destName = d, pathPolyline = demoPolyline(extraEntryRnd, km), isMe = false
        ))
    }

    // 내 기록: 해당 종목+구간에서 가장 좋은 기록 하나
    // ✅ v81 100m 랭킹은 VS 대결 전용 — 지도에서 한 일반 운동 경로는 들어오지 못하게 막는다.
    //    (VS 측정은 저장 시 제목을 "VS 100m 대결"로 남기므로 그것만 인정)
    val isHundredMeter = km < 0.15
    val myModeRecords = myRecords.filter { rec ->
        rec.mode in category.modes && rec.isRankingValid &&
            (!isHundredMeter || (rec.destinationName?.contains("VS") == true || rec.originName?.contains("VS") == true))
    }
    val myBest = myModeRecords
        .filter { abs(it.rankingBracketKm - km) < 0.5 || abs(it.distanceMeters / 1000 - km) < 0.5 }
        .minByOrNull {
            if (category.safetyFirst) -(it.safetyScore * 1_000_000L) + it.rankingDurationSeconds
            else it.rankingDurationSeconds.takeIf { s -> s > 0 } ?: it.durationSeconds
        }
    myBest?.let {
        fake.add(RankEntry(
            name = myNickname, flag = com.navifit.util.countryCodeToFlag(it.countryCode), // ✅ 실제 뛴 GPS 위치 기반 국가 (언어설정과 무관)
            timeSec = (it.rankingDurationSeconds.takeIf { s -> s > 0 } ?: it.durationSeconds).toInt(),
            safetyScore = it.safetyScore,
            originName = it.originName ?: "내 출발지",
            destName = it.destinationName ?: "내 도착지",
            pathPolyline = it.pathPolyline,
            isMe = true
        ))
    }
    return fake
}

/** 시연용 가상 경로 폴리라인 (서울 근처를 지나는 곡선) */
private fun demoPolyline(rnd: Random, km: Double): String {
    val startLat = 37.45 + rnd.nextDouble() * 0.2
    val startLng = 126.85 + rnd.nextDouble() * 0.25
    val steps = 24
    val totalDeg = km / 111.0 // 대략 1도=111km
    val heading = rnd.nextDouble() * Math.PI * 2
    val pts = (0..steps).map { i ->
        val t = i.toDouble() / steps
        val wobble = Math.sin(t * Math.PI * 3) * totalDeg * 0.08
        com.navifit.navigation.LatLngPoint(
            startLat + Math.cos(heading) * totalDeg * t + wobble,
            startLng + Math.sin(heading) * totalDeg * t / Math.cos(Math.toRadians(startLat)) - wobble
        )
    }
    return encodeTravelPolyline(pts)
}

private fun formatSec(sec: Int): String {
    val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
    return if (h > 0) "${h}시간 ${m}분 ${s}초" else "${m}분 ${s}초"
}

/** ✅ v58 명예의 전당 (전당 20석) */
@Composable
private fun HallOfFameView() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var hofCategory by remember { mutableStateOf("run") }   // ✅ v63 run/bike 분리
    var markerToast by remember { mutableStateOf<String?>(null) }   // ✅ v81 전당 마커 지급 안내
    val entries = remember(hofCategory) { com.navifit.social.HallOfFameStore.listFor(ctx, hofCategory) }
    val isRun = hofCategory == "run"
    // 러닝=빨강 계열 네온, 자전거=파랑 계열 네온
    val neon = if (isRun) Color(0xFFFF3B4E) else Color(0xFF2E9BFF)
    val neonDim = if (isRun) Color(0xFF5A1520) else Color(0xFF13385C)

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(tr("👑 명예의 전당"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
        Text(tr("러닝은 풀코스(42.195km), 자전거는 200km 기록의 매달 1등이 전당에 오릅니다 (각 20석). 20석이 차면 매달 1등이 19위와 겨뤄 이기면 등재되고 20위는 밀려납니다."),
            fontSize = 11.sp, color = Color(0xFF8B93AC))
        Spacer(Modifier.height(10.dp))

        // run/bike 토글
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("run" to "🏃 러닝 (풀코스)", "bike" to "🚴 자전거 (200km)").forEach { (cat, label) ->
                val sel = hofCategory == cat
                val c = if (cat == "run") Color(0xFFFF3B4E) else Color(0xFF2E9BFF)
                Box(
                    Modifier.weight(1f)
                        .background(if (sel) c.copy(alpha = 0.22f) else Color(0xFF1C1C1E), RoundedCornerShape(12.dp))
                        .border(androidx.compose.foundation.BorderStroke(if (sel) 1.5.dp else 1.dp, if (sel) c else Color(0xFF2C3145)), RoundedCornerShape(12.dp))
                        .clickable { hofCategory = cat }.padding(vertical = 9.dp),
                    contentAlignment = Alignment.Center
                ) { Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (sel) c else Color(0xFF8B93AC)) }
            }
        }
        markerToast?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, fontSize = 11.sp, color = Color(0xFFFFD700), fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))

        if (entries.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(tr("아직 전당에 오른 사람이 없어요.\n이번 달 1등이 되어 첫 전당의 주인공이 되어보세요 👑"),
                    fontSize = 13.sp, color = Color(0xFF8B93AC),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        } else LazyColumn {
            items(entries.size) { i ->
                val e = entries[i]
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)
                    .background(Brush.horizontalGradient(listOf(neonDim.copy(alpha = 0.5f), Color(0xFF15151A))), RoundedCornerShape(16.dp))
                    .border(androidx.compose.foundation.BorderStroke(1.dp, neon.copy(alpha = 0.4f)), RoundedCornerShape(16.dp))
                    .padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    // ✅ 네온 티커 숫자 (전구 반짝임)
                    NeonHofNumber(e.enshrinedRank, neon)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(e.nickname, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = Color.White)
                            // ✅ v81 1등에게 주어지는 전용 마커 (명예의 전당 마커)
                            if (e.enshrinedRank == 1) {
                                Spacer(Modifier.width(6.dp))
                                Box(
                                    Modifier.background(
                                        Brush.linearGradient(listOf(Color(0xFFFFD700), Color(0xFFFFA000))),
                                        RoundedCornerShape(8.dp)
                                    ).padding(horizontal = 7.dp, vertical = 2.dp)
                                ) {
                                    Text(tr("👑 전당 마커"), fontSize = 9.sp, fontWeight = FontWeight.ExtraBold,
                                        color = Color(0xFF2A1F00))
                                }
                            }
                        }
                        Text(e.recordText, fontSize = 12.sp, color = Color(0xFFC7CBD9))
                        if (e.enshrinedRank == 1) {
                            Text(tr("이 마커는 명예의 전당 1위에게만 지급돼요"),
                                fontSize = 9.sp, color = Color(0xFFFFD277))
                            Spacer(Modifier.height(4.dp))
                            // ✅ v81 실제로 보유함(뽑기>보유)에 등록되는 버튼 (데모 확인용)
                            Box(
                                Modifier.background(Color(0xFF3A2E00), RoundedCornerShape(8.dp))
                                    .border(androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFD700)), RoundedCornerShape(8.dp))
                                    .clickable {
                                        val granted = com.navifit.social.HallOfFameStore.grantChampionMarker(ctx, e.ym)
                                        markerToast = if (granted)
                                            "👑 전당 마커를 받았어요! (뽑기 > 보유 탭에서 확인)"
                                        else "이미 받은 전당 마커예요"
                                    }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(tr("👑 전당 마커 받기"), fontSize = 9.sp, fontWeight = FontWeight.Bold,
                                    color = Color(0xFFFFD700))
                            }
                        }
                    }
                    Text("${e.ym.substring(0,4)}.${e.ym.substring(4)}", fontSize = 11.sp, color = Color(0xFF8B93AC))
                }
            }
        }
    }
}

/** ✅ v63 명예의 전당 네온 숫자 (전구가 켜졌다 꺼지듯 반짝이는 화려한 랭킹 숫자) */
@Composable
private fun NeonHofNumber(number: Int, neon: Color) {
    val transition = rememberInfiniteTransition(label = "neon")
    val glow: Float by transition.animateFloat(
        initialValue = 0.45f, targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ), label = "glow"
    )
    Box(
        Modifier.size(46.dp)
            .background(neon.copy(alpha = 0.12f * glow), RoundedCornerShape(12.dp))
            .border(androidx.compose.foundation.BorderStroke(2.dp, neon.copy(alpha = glow)), RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) {
        Text("$number", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold,
            color = neon.copy(alpha = 0.6f + 0.4f * glow),
            style = androidx.compose.ui.text.TextStyle(
                shadow = androidx.compose.ui.graphics.Shadow(
                    color = neon.copy(alpha = glow), blurRadius = 14f * glow
                )
            ))
    }
}

/** ✅ v58 내 업적 (매달 100등 안 → 영구 보관, 삭제 불가) */
@Composable
private fun AchievementsView() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val achievements = remember { com.navifit.social.AchievementStore.list(ctx) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(tr("🎖 내 업적"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
        Text(tr("매달 100등 안에 들면 그달의 성적이 영구 기록으로 남아요. (1등 🥇 · 2등 🥈 · 3등 🥉 · 4~100등 ⭐) 삭제되지 않습니다."),
            fontSize = 11.sp, color = Color(0xFF8B93AC))
        Spacer(Modifier.height(12.dp))
        if (achievements.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(tr("아직 업적이 없어요.\n이번 달 100등 안에 들면 첫 업적이 새겨져요 🎖"),
                    fontSize = 13.sp, color = Color(0xFF8B93AC),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        } else LazyColumn {
            items(achievements.size) { i ->
                val a = achievements[i]
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(14.dp))
                    .padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(a.medal, fontSize = 28.sp, modifier = Modifier.padding(end = 12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("${a.ym} · ${com.navifit.social.AchievementStore.medalLabel(a.rank)}",
                            fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                        Text(a.recordText + if (a.pace.isNotBlank()) " · ${a.pace}" else "",
                            fontSize = 12.sp, color = Color(0xFFC7CBD9))
                        a.routeKey?.let { Text("🔑 $it", fontSize = 11.sp, color = Color(0xFF0095F6)) }
                    }
                }
            }
        }
    }
}

/** ✅ v63 포인트 랭킹 (VS 대결 포인트 순위) + 유지 일수 + 유지 보상 안내 */
@Composable
private fun PointRankingView() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val myPoints = remember { com.navifit.vs.VsMatchSystem.myPoints(ctx) }
    val streak = remember { com.navifit.vs.VsMatchSystem.streakDays(ctx) }
    // 데모 포인트 랭킹 상위 (실서버 연동 시 Firestore 집계)
    val pool = remember { com.navifit.vs.VsMatchSystem.generateOpponentPool().sortedByDescending { it.points }.take(50) }
    // 내 순위 = 나보다 점수 높은 사람 수 + 1
    val myRank = remember(myPoints) { pool.count { it.points > myPoints } + 1 }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(tr("💠 포인트 랭킹"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
        Text(tr("VS 대결로 얻은 포인트 순위예요. 포인트를 쓰면 순위가 내려가요."), fontSize = 11.sp, color = Color(0xFF8B93AC))
        Spacer(Modifier.height(10.dp))

        // 내 현황 카드
        Column(Modifier.fillMaxWidth().background(
            Brush.horizontalGradient(listOf(Color(0xFF243247), Color(0xFF1A1C22))), RoundedCornerShape(16.dp))
            .padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr("내 순위"), fontSize = 11.sp, color = Color(0xFF8B93AC))
                    Text(tr("%s 위").format(myRank), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF7CC7FF))
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(tr("내 포인트"), fontSize = 11.sp, color = Color(0xFF8B93AC))
                    Text("$myPoints P", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF34D399))
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(tr("🔥 %s일째 순위 유지 중 (매일 정오 갱신)").format(streak), fontSize = 12.sp, color = Color(0xFFFBBF6E))
            Text(tr("한 달 유지 시 1등 10000 / 2등 5000 / 3등 3000 / 4등 2000 / 5등 1000 P를 매월 1일 우편함으로 지급"),
                fontSize = 10.sp, color = Color(0xFF8B93AC), modifier = Modifier.padding(top = 4.dp))
        }
        Spacer(Modifier.height(12.dp))

        LazyColumn {
            items(pool.size) { i ->
                val o = pool[i]
                val medal = when (i) { 0 -> "🥇"; 1 -> "🥈"; 2 -> "🥉"; else -> "${i+1}" }
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp)).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(medal, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFFFD22E), modifier = Modifier.width(34.dp))
                    Text(o.nickname, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                    Text("${o.points} P", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF3B82F6))
                }
            }
        }
    }
}
