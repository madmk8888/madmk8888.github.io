package com.navifit.gacha

import android.content.Context

/**
 * ✅ v63 프리미엄 뽑기권 (VS 포인트 상점에서 구매).
 *  · 레전더리 확률 1% (일반 만보기 뽑기권보다 높음)
 *  · 그 외 등급은 만보기 뽑기권과 동일 확률
 *  · 레전더리 합성 확률: 0.0001% (극악 - 확률 고시)
 */
object PremiumTicketStore {
    private const val PREFS = "premium_tickets"
    private const val KEY = "count"

    // 확률 고시 (요청 반영)
    const val LEGENDARY_RATE = 0.01           // 1%
    const val LEGENDARY_FUSION_RATE = 0.000001 // 0.0001%

    fun count(c: Context): Int = c.getSharedPreferences(PREFS, 0).getInt(KEY, 0)

    fun add(c: Context, n: Int) {
        val cur = count(c)
        c.getSharedPreferences(PREFS, 0).edit().putInt(KEY, cur + n).apply()
    }

    fun consume(c: Context): Boolean {
        val cur = count(c)
        if (cur <= 0) return false
        c.getSharedPreferences(PREFS, 0).edit().putInt(KEY, cur - 1).apply()
        return true
    }
}
