package com.navifit.social

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  LocalRmStore — v83 RM(쪽지) 전면 재작성: 로컬 우선(local-first)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * 왜 갈아엎었나:
 *  기존 RM은 화면이 Firebase 스트림을 직접 구독했다. 그래서 Firebase가
 *  미설정·오프라인·권한오류일 때 예외가 컴포지션 안에서 터져 **앱이 그대로 꺼졌다.**
 *  try-catch를 아무리 덧대도 스트림·콜백 경로마다 빠져나갈 구멍이 남았다.
 *
 * 새 구조:
 *  · 화면은 오직 이 로컬 저장소만 본다. → 네트워크 예외가 UI에 도달할 수 없다 = 크래시 불가능.
 *  · 저장은 SharedPreferences(JSON). 모든 읽기/쓰기는 예외를 삼키고 빈 값으로 폴백한다.
 *  · 서버 동기화는 나중에 이 저장소 뒤에서 조용히 붙이면 된다(UI 변경 불필요).
 *
 * 데이터: 대화방(Thread) + 메시지(Message)
 */
object LocalRmStore {
    private const val PREFS = "rm_local_v83"
    private const val KEY_THREADS = "threads"

    data class Message(
        val id: String,
        val fromMe: Boolean,
        val senderName: String,
        val text: String,
        val mediaPath: String? = null,
        val at: Long
    )

    data class Thread(
        val peerUid: String,
        val peerNickname: String,
        val messages: List<Message>,
        val unread: Boolean = false,
        val isRequest: Boolean = false
    ) {
        val lastText: String get() = messages.lastOrNull()?.text ?: "아직 대화가 없어요"
        val lastAt: Long get() = messages.lastOrNull()?.at ?: 0L
    }

    private val _threads = MutableStateFlow<List<Thread>>(emptyList())
    val threads: StateFlow<List<Thread>> = _threads

    /** 앱/화면 진입 시 1회 호출. 실패해도 절대 예외를 던지지 않는다. */
    fun load(c: Context) {
        _threads.value = try {
            val raw = c.getSharedPreferences(PREFS, 0).getString(KEY_THREADS, null)
            if (raw.isNullOrBlank()) seedDemo(c)
            else parse(raw)
        } catch (_: Throwable) { emptyList() }
    }

    private fun parse(raw: String): List<Thread> = try {
        val arr = JSONArray(raw)
        (0 until arr.length()).mapNotNull { i ->
            try {
                val o = arr.getJSONObject(i)
                val mArr = o.optJSONArray("messages") ?: JSONArray()
                Thread(
                    peerUid = o.optString("peerUid"),
                    peerNickname = o.optString("peerNickname", "상대"),
                    messages = (0 until mArr.length()).mapNotNull { j ->
                        try {
                            val m = mArr.getJSONObject(j)
                            Message(
                                id = m.optString("id"),
                                fromMe = m.optBoolean("fromMe"),
                                senderName = m.optString("senderName"),
                                text = m.optString("text"),
                                mediaPath = m.optString("mediaPath").takeIf { it.isNotBlank() },
                                at = m.optLong("at")
                            )
                        } catch (_: Throwable) { null }
                    },
                    unread = o.optBoolean("unread"),
                    isRequest = o.optBoolean("isRequest")
                )
            } catch (_: Throwable) { null }
        }.sortedByDescending { it.lastAt }
    } catch (_: Throwable) { emptyList() }

    private fun persist(c: Context) {
        try {
            val arr = JSONArray()
            _threads.value.forEach { t ->
                val mArr = JSONArray()
                t.messages.takeLast(300).forEach { m ->
                    mArr.put(JSONObject().apply {
                        put("id", m.id); put("fromMe", m.fromMe)
                        put("senderName", m.senderName); put("text", m.text)
                        put("mediaPath", m.mediaPath ?: ""); put("at", m.at)
                    })
                }
                arr.put(JSONObject().apply {
                    put("peerUid", t.peerUid); put("peerNickname", t.peerNickname)
                    put("messages", mArr); put("unread", t.unread); put("isRequest", t.isRequest)
                })
            }
            c.getSharedPreferences(PREFS, 0).edit().putString(KEY_THREADS, arr.toString()).apply()
        } catch (_: Throwable) { /* 저장 실패해도 앱은 계속 동작 */ }
    }

    /** 처음 실행 시 바로 써볼 수 있게 예시 대화를 넣어준다. */
    private fun seedDemo(c: Context): List<Thread> {
        val now = System.currentTimeMillis()
        val demo = listOf(
            Thread("demo_run_mate", "같이뛰는친구", listOf(
                Message("m1", false, "같이뛰는친구", "내일 아침 한강 러닝 어때요?", null, now - 120_000)
            ), unread = true),
            Thread("demo_dawn", "새벽러너", listOf(
                Message("m2", false, "새벽러너", "코스 공유 고마워요! 🔑", null, now - 3_600_000),
                Message("m3", true, "나", "다음에 같이 뛰어요!", null, now - 3_500_000)
            )),
            Thread("demo_stranger", "낯선러너99", listOf(
                Message("m4", false, "낯선러너99", "안녕하세요 런친했어요", null, now - 7_200_000)
            ), unread = true, isRequest = true)
        )
        _threads.value = demo
        persist(c)
        return demo
    }

    fun thread(peerUid: String): Thread? = _threads.value.firstOrNull { it.peerUid == peerUid }

    /** 대화방이 없으면 만들고 반환 */
    fun ensureThread(c: Context, peerUid: String, peerNickname: String): Thread {
        thread(peerUid)?.let { return it }
        val t = Thread(peerUid, peerNickname, emptyList())
        _threads.value = _threads.value + t
        persist(c)
        return t
    }

    fun send(c: Context, peerUid: String, peerNickname: String, myNickname: String,
             text: String, mediaPath: String? = null) {
        if (text.isBlank() && mediaPath == null) return
        ensureThread(c, peerUid, peerNickname)
        val msg = Message(
            id = "m" + System.currentTimeMillis(),
            fromMe = true, senderName = myNickname,
            text = text.trim(), mediaPath = mediaPath, at = System.currentTimeMillis()
        )
        _threads.value = _threads.value.map {
            if (it.peerUid == peerUid) it.copy(messages = it.messages + msg, unread = false) else it
        }.sortedByDescending { it.lastAt }
        persist(c)
    }

    fun markRead(c: Context, peerUid: String) {
        _threads.value = _threads.value.map {
            if (it.peerUid == peerUid) it.copy(unread = false) else it
        }
        persist(c)
    }

    fun acceptRequest(c: Context, peerUid: String) {
        _threads.value = _threads.value.map {
            if (it.peerUid == peerUid) it.copy(isRequest = false) else it
        }
        persist(c)
    }

    fun deleteThread(c: Context, peerUid: String) {
        _threads.value = _threads.value.filter { it.peerUid != peerUid }
        persist(c)
    }

    fun unreadCount(): Int = _threads.value.count { it.unread && !it.isRequest }

    fun clearAll(c: Context) {
        _threads.value = emptyList()
        try { c.getSharedPreferences(PREFS, 0).edit().clear().apply() } catch (_: Throwable) {}
    }
}
