package com.navifit.ui.screens

import com.navifit.i18n.tr
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.navifit.data.ActivityRecord
import com.navifit.navigation.TravelMode
import com.google.maps.android.compose.rememberCameraPositionState

/**
 * ✅ v58 "내 경로 보관함" - 기존 '내 운동 분석' 탭을 대체.
 *
 *  · 운동 종료 시 저장된 "실제 이동 궤적"들이 여기 쌓임 (자동차/오토바이 기록 제외)
 *  · 폴더(카테고리)를 만들어 경로를 분류: 예) 겨울, 서울, 1자코스 ...
 *  · 경로마다 이름을 붙일 수 있고, 이름/폴더/출발·도착지로 검색 가능
 *  · [따라 뛰기]: 그 경로 그대로 안내 시작  ·  [🔑 키]: 공유 키 발급(친구에게 전달)
 */
object RouteVaultStore {
    private const val PREFS = "route_vault"

    fun folders(c: android.content.Context): List<String> {
        val stored = c.getSharedPreferences(PREFS, 0).getString("folders", null)
            ?.split("|")?.filter { it.isNotBlank() } ?: emptyList()
        // ✅ v60: "운동 이력"과 "기본"은 항상 존재 (운동 이력은 자동 저장 대상 폴더)
        return (listOf("운동 이력", "기본") + stored).distinct()
    }

    // ✅ v60 설정: 경로 저장 시 폴더 선택 물어보기 (끄면 기본 폴더로 바로 저장)
    fun askFolderOnSave(c: android.content.Context): Boolean =
        c.getSharedPreferences(PREFS, 0).getBoolean("ask_folder", true)
    fun setAskFolderOnSave(c: android.content.Context, on: Boolean) =
        c.getSharedPreferences(PREFS, 0).edit().putBoolean("ask_folder", on).apply()

    // ✅ v78 폴더 삭제 (폴더 자체 + 그 안 경로들의 폴더 지정 제거). "운동 이력"·"기본"은 삭제 불가.
    fun deleteFolder(c: android.content.Context, name: String) {
        if (name == "운동 이력" || name == "기본") return
        val remaining = folders(c).filter { it != name && it != "운동 이력" && it != "기본" }
        c.getSharedPreferences(PREFS, 0).edit().putString("folders", remaining.joinToString("|")).apply()
        // 그 폴더에 있던 경로들의 폴더 지정 제거 (기본으로 돌려보냄)
        val all = c.getSharedPreferences(PREFS, 0).all
        val editor = c.getSharedPreferences(PREFS, 0).edit()
        all.forEach { (k, v) ->
            if (k.startsWith("folder_") && v == name) editor.remove(k)
        }
        editor.apply()
    }

    // ═══════════════ ✅ v82 폴더 슬롯 (구매식) ═══════════════
    //  기본 5개 + 포인트 상점에서 구매한 슬롯 수 = 최대 폴더 개수.
    //  "쓰고 있는 폴더 수"가 아니라 "구매한 슬롯 수"로 관리하므로
    //  폴더를 지웠다 다시 만들어도 개수가 꼬이지 않는다. (버그 없음)
    const val BASE_FOLDER_SLOTS = 5
    const val FOLDER_SLOT_PRICE = 500

    /** 구매로 늘린 추가 슬롯 수 */
    fun extraSlots(c: android.content.Context): Int =
        c.getSharedPreferences(PREFS, 0).getInt("extra_slots", 0)

    /** 최대 폴더 개수 = 기본 5 + 구매 슬롯 */
    fun maxFolders(c: android.content.Context): Int = BASE_FOLDER_SLOTS + extraSlots(c)

    /**
     * 포인트 상점에서 폴더 슬롯 +1 구매.
     * @return null이면 성공, 아니면 실패 사유
     */
    fun buyFolderSlot(c: android.content.Context): String? {
        val pts = com.navifit.vs.VsMatchSystem.myPoints(c)
        if (pts < FOLDER_SLOT_PRICE) return "VS 포인트가 부족해요 (필요 ${FOLDER_SLOT_PRICE}P · 보유 ${pts}P)"
        com.navifit.vs.VsMatchSystem.setMyPoints(c, pts - FOLDER_SLOT_PRICE)
        c.getSharedPreferences(PREFS, 0).edit().putInt("extra_slots", extraSlots(c) + 1).apply()
        return null
    }

    fun addFolder(c: android.content.Context, name: String): String {
        val trimmed = name.trim()
        if (trimmed.isBlank()) return "이름을 입력해주세요"
        val existing = folders(c)
        // ✅ v66 중복 이름 방지
        if (existing.any { it.equals(trimmed, ignoreCase = true) }) return "이미 같은 이름의 폴더가 있어요"
        // ✅ v82 슬롯 한도 검사 (구매 슬롯 반영)
        val customCount = existing.count { it != "운동 이력" && it != "기본" }
        val max = maxFolders(c)
        if (customCount >= max) {
            return "폴더는 최대 ${max}개예요. 포인트 상점에서 '폴더 슬롯 +1'을 구매하면 늘릴 수 있어요"
        }
        val f = (existing + trimmed).distinct()
        c.getSharedPreferences(PREFS, 0).edit().putString("folders", f.filter { it != "운동 이력" && it != "기본" }.joinToString("|")).apply()
        return "OK"
    }

    fun folderOf(c: android.content.Context, recordId: Long): String =
        c.getSharedPreferences(PREFS, 0).getString("folder_$recordId", "운동 이력") ?: "운동 이력"  // ✅ v60 기본=운동 이력

    fun setFolder(c: android.content.Context, recordId: Long, folder: String) =
        c.getSharedPreferences(PREFS, 0).edit().putString("folder_$recordId", folder).apply()

    fun nameOf(c: android.content.Context, recordId: Long): String? =
        c.getSharedPreferences(PREFS, 0).getString("name_$recordId", null)

    fun setName(c: android.content.Context, recordId: Long, name: String) =
        c.getSharedPreferences(PREFS, 0).edit().putString("name_$recordId", name.trim()).apply()
}

@Composable
fun RouteVaultScreen(
    records: List<ActivityRecord>,
    onFollowRoute: (mode: TravelMode, polyline: String) -> Unit,
    onIssueKey: (mode: TravelMode, polyline: String) -> Unit,
    onShareToCommunity: (mode: TravelMode, polyline: String, distanceMeters: Double) -> Unit = { _, _, _ -> }  // ✅ v76
) {
    val context = LocalContext.current
    // ✅ 자동차/오토바이 제외 - 운동(도보·달리기/자전거) 경로만
    val workoutRecords = remember(records) {
        records.filter { it.mode.isWorkoutMode && it.pathPolyline != null }
            .sortedByDescending { it.startTimeMillis }
    }
    var folders by remember { mutableStateOf(RouteVaultStore.folders(context)) }
    var selectedFolder by remember { mutableStateOf<String?>(null) }   // null = 전체
    var modeFilter by remember { mutableStateOf<TravelMode?>(null) }   // ✅ v63 달리기/자전거 필터 (null=전체)
    var query by remember { mutableStateOf("") }
    var renameTarget by remember { mutableStateOf<ActivityRecord?>(null) }
    var moveTarget by remember { mutableStateOf<ActivityRecord?>(null) }
    var showAddFolder by remember { mutableStateOf(false) }
    var deleteFolderTarget by remember { mutableStateOf<String?>(null) }   // ✅ v78 폴더 삭제 확인
    var showFolderManage by remember { mutableStateOf(false) }             // ✅ v86 폴더 관리 화면

    // ✅ v86 폴더 관리: 목록에서 이름 확인 + 삭제 (칩에서 실수로 지우던 문제 해결)
    if (showFolderManage) {
        AlertDialog(
            onDismissRequest = { showFolderManage = false },
            title = { Text(tr("폴더 관리")) },
            text = {
                Column {
                    val maxSlots = RouteVaultStore.maxFolders(context)
                    val customCount = folders.count { it != "운동 이력" && it != "기본" }
                    Text(tr("사용 중 %s/%s개 (기본 5 + 구매 %s)").format(customCount, maxSlots, maxSlots - 5),
                        fontSize = 11.sp, color = Color(0xFF8B93AC))
                    Spacer(Modifier.height(10.dp))
                    folders.forEach { f ->
                        val fixed = f == "운동 이력" || f == "기본"
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("📁 $f", fontSize = 14.sp, modifier = Modifier.weight(1f),
                                color = MaterialTheme.colorScheme.onSurface)
                            if (fixed) {
                                Text(tr("기본"), fontSize = 10.sp, color = Color(0xFF8B93AC))
                            } else {
                                Text(tr("삭제"), fontSize = 13.sp, color = Color(0xFFFF6B6B),
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.clickable { deleteFolderTarget = f }.padding(6.dp))
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(tr("폴더를 지워도 안의 경로는 '운동 이력'으로 이동해 유지돼요"),
                        fontSize = 10.sp, color = Color(0xFF8B93AC))
                }
            },
            confirmButton = { TextButton(onClick = { showFolderManage = false }) { Text(tr("닫기")) } }
        )
    }
    var refresh by remember { mutableStateOf(0) }

    val visible = remember(workoutRecords, selectedFolder, modeFilter, query, refresh) {
        workoutRecords.filter { r ->
            val folder = RouteVaultStore.folderOf(context, r.id)
            val name = RouteVaultStore.nameOf(context, r.id) ?: ""
            (selectedFolder == null || folder == selectedFolder) &&
                (modeFilter == null || r.mode == modeFilter) &&
                (query.isBlank() ||
                    name.contains(query, true) || folder.contains(query, true) ||
                    (r.originName ?: "").contains(query, true) ||
                    (r.destinationName ?: "").contains(query, true))
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(tr("내 경로 보관함"), fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            TextButton(onClick = { showAddFolder = true }) { Text(tr("＋ 폴더"), fontSize = 13.sp) }
        }
        Text(tr("운동 종료 시 실제로 이동한 궤적이 저장돼요. 폴더로 분류하고, 좋아하는 코스를 꺼내 다시 뛰어보세요."),
            fontSize = 11.sp, color = Color(0xFF8B93AC))
        Spacer(Modifier.height(10.dp))

        // 검색 (버튼 포함)
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                placeholder = { Text(tr("코스 이름·폴더·장소 검색"), fontSize = 13.sp) },
                singleLine = true, modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(14.dp)
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { /* query state가 이미 실시간 필터 */ }, shape = RoundedCornerShape(14.dp)) { Text("🔍") }
        }
        Spacer(Modifier.height(10.dp))

        // ✅ v63 이동수단 필터 (전체/달리기/자전거)
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.padding(bottom = 8.dp)) {
            listOf(null to "전체", TravelMode.WALK to "🏃 달리기", TravelMode.BIKE to "🚴 자전거").forEach { (m, label) ->
                FilterChip(selected = modeFilter == m, onClick = { modeFilter = m },
                    label = { Text(label, fontSize = 12.sp) })
            }
        }
        // 폴더 칩들
        androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            item {
                FilterChip(selected = selectedFolder == null, onClick = { selectedFolder = null },
                    label = { Text(tr("전체"), fontSize = 12.sp) })
            }
            items(folders) { f ->
                // ✅ v86 칩에서 🗑 제거 — 삭제는 [폴더 관리] 화면에서만 (실수 삭제 방지)
                FilterChip(
                    selected = selectedFolder == f,
                    onClick = { selectedFolder = if (selectedFolder == f) null else f },
                    label = { Text("📁 $f", fontSize = 12.sp) }
                )
            }
            item {
                FilterChip(
                    selected = false,
                    onClick = { showFolderManage = true },
                    label = { Text(tr("⚙️ 폴더 관리"), fontSize = 12.sp) }
                )
            }
        }
        Spacer(Modifier.height(8.dp))

        if (visible.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(tr("저장된 경로가 없어요.\n운동을 마치고 '저장'을 누르면 여기에 쌓여요 🏃"),
                    fontSize = 13.sp, color = Color(0xFF8B93AC),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }
        } else LazyColumn {
            items(visible, key = { it.id }) { r ->
                val folder = RouteVaultStore.folderOf(context, r.id)
                val name = RouteVaultStore.nameOf(context, r.id)
                    ?: "${r.mode.displayName} %.1fkm".format(r.distanceMeters / 1000)
                // ✅ v81 은은한 그림자 박스 (화이트/다크 모두 자연스러운 칸 구분)
                Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)
                    .then(com.navifit.ui.theme.NaviTheme.subtleCard(16.dp))
                    .padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (r.mode == TravelMode.BIKE) "🚴" else "🏃", fontSize = 18.sp)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            // ✅ v81 화이트테마에서 검정 배경+검정 글자로 안 보이던 문제 → 테마 색 사용
                            Text(name, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface)
                            Text("📁 $folder · ${java.text.SimpleDateFormat("yyyy.MM.dd", java.util.Locale.KOREA).format(java.util.Date(r.startTimeMillis))}",
                                fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        // ✅ v81 연필(✏️) 제거 → 기능이 명확한 아이콘으로
                        Text("🏷️", Modifier.clickable { renameTarget = r }.padding(4.dp))
                        Text("📂", Modifier.clickable { moveTarget = r }.padding(4.dp))
                    }
                    Spacer(Modifier.height(6.dp))
                    val dur = r.durationSeconds
                    val durText = if (dur >= 3600) "%d:%02d:%02d".format(dur/3600, (dur%3600)/60, dur%60)
                                  else "%d:%02d".format(dur/60, dur%60)
                    Text(tr("%.2fkm · %s · 평균 %.1fkm/h").format(
                        r.distanceMeters / 1000, durText, r.avgSpeedKmh),
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    (r.originName ?: r.destinationName)?.let {
                        Text("📍 ${r.originName ?: "?"} → ${r.destinationName ?: "?"}",
                            fontSize = 11.sp, color = Color(0xFF0095F6), maxLines = 1)
                    }
                    // ✅ v81 경로 미리보기 지도 (경로함에 지도가 아예 안 나오던 문제)
                    r.pathPolyline?.let { poly ->
                        val pts = remember(poly) { decodePolyline(poly) }
                        if (pts.size >= 2) {
                            Spacer(Modifier.height(10.dp))
                            val camState = rememberCameraPositionState()
                            LaunchedEffect(pts) {
                                val b = com.google.android.gms.maps.model.LatLngBounds.builder()
                                pts.forEach { b.include(com.google.android.gms.maps.model.LatLng(it.latitude, it.longitude)) }
                                runCatching {
                                    camState.move(
                                        com.google.android.gms.maps.CameraUpdateFactory.newLatLngBounds(b.build(), 60))
                                }
                            }
                            Box(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(12.dp))) {
                                com.google.maps.android.compose.GoogleMap(
                                    modifier = Modifier.fillMaxSize(),
                                    cameraPositionState = camState,
                                    uiSettings = com.google.maps.android.compose.MapUiSettings(
                                        zoomControlsEnabled = false, scrollGesturesEnabled = false,
                                        zoomGesturesEnabled = false, rotationGesturesEnabled = false,
                                        tiltGesturesEnabled = false, mapToolbarEnabled = false
                                    ),
                                    properties = com.google.maps.android.compose.MapProperties(isMyLocationEnabled = false)
                                ) {
                                    com.google.maps.android.compose.Polyline(
                                        points = pts.map { com.google.android.gms.maps.model.LatLng(it.latitude, it.longitude) },
                                        color = if (r.mode == TravelMode.BIKE) Color(0xFF3B82F6) else Color(0xFF34C77B),
                                        width = 10f
                                    )
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    // ✅ v78 따라뛰기는 항상 보이고, 공유 키들은 화살표로 접기
                    var showKeys by remember(r.id) { mutableStateOf(false) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = { r.pathPolyline?.let { onFollowRoute(r.mode, it) } },
                            modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF34C77B)),
                            contentPadding = PaddingValues(vertical = 8.dp)
                        ) { Text(tr("🏃 따라 뛰기"), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                        Box(
                            Modifier.background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                                .clickable { showKeys = !showKeys }
                                .padding(horizontal = 14.dp, vertical = 9.dp)
                        ) { Text(if (showKeys) "공유 ▲" else "공유 ▼", fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                    if (showKeys) {
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { r.pathPolyline?.let { onIssueKey(r.mode, it) } },
                                modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(vertical = 8.dp)
                            ) { Text(tr("🔑 공유 키"), fontSize = 11.sp) }
                            OutlinedButton(
                                onClick = { r.pathPolyline?.let { onShareToCommunity(r.mode, it, r.distanceMeters) } },
                                modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(vertical = 8.dp)
                            ) { Text(tr("📣 운동장"), fontSize = 11.sp) }
                            OutlinedButton(
                                onClick = {
                                    r.pathPolyline?.let { poly ->
                                        val key = com.navifit.navigation.RouteKeyStore.issueKey(context, r.mode, poly)
                                        val text = "🏃 NaviFit 경로 공유! 이 코스 같이 뛰어요 🔑 $key"
                                        val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                            type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, text)
                                        }
                                        context.startActivity(android.content.Intent.createChooser(send, "경로 공유"))
                                    }
                                },
                                modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(vertical = 8.dp)
                            ) { Text(tr("📤 카톡/링크"), fontSize = 11.sp) }
                        }
                    }
                }
            }
        }
    }

    // ✅ v78 폴더 삭제 확인
    deleteFolderTarget?.let { fname ->
        AlertDialog(
            onDismissRequest = { deleteFolderTarget = null },
            title = { Text(tr("폴더 삭제")) },
            text = { Text(tr("'%s' 폴더를 삭제할까요?\n폴더 안의 경로들은 '운동 이력'으로 돌아가요 (경로 자체는 유지돼요).").format(fname)) },
            confirmButton = {
                TextButton(onClick = {
                    RouteVaultStore.deleteFolder(context, fname)
                    folders = RouteVaultStore.folders(context)
                    if (selectedFolder == fname) selectedFolder = null
                    deleteFolderTarget = null
                }) { Text(tr("삭제"), color = Color(0xFFFF6B6B)) }
            },
            dismissButton = { TextButton(onClick = { deleteFolderTarget = null }) { Text(tr("취소")) } }
        )
    }

    // 폴더 추가
    if (showAddFolder) {
        var fname by remember { mutableStateOf("") }
        var errMsg by remember { mutableStateOf<String?>(null) }
        val customCount = folders.count { it != "운동 이력" && it != "기본" }
        AlertDialog(
            onDismissRequest = { showAddFolder = false },
            title = { Text(tr("폴더 만들기")) },
            text = {
                Column {
                    // ✅ v82 구매 슬롯 반영한 안내
                    val maxSlots = RouteVaultStore.maxFolders(context)
                    Text(
                        if (customCount >= maxSlots)
                            "폴더를 다 썼어요 (${customCount}/${maxSlots}). 포인트 상점에서 '폴더 +1'을 구매하면 늘릴 수 있어요"
                        else "폴더 ${customCount}/${maxSlots}개 사용 중 (기본 5개 + 구매 ${maxSlots - 5}개)",
                        fontSize = 11.sp, color = Color(0xFF8B93AC))
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = fname, onValueChange = { fname = it.take(12); errMsg = null },
                        placeholder = { Text(tr("예: 겨울, 서울, 1자코스")) }, singleLine = true)
                    errMsg?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp)) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val r = RouteVaultStore.addFolder(context, fname)
                    if (r == "OK") { folders = RouteVaultStore.folders(context); showAddFolder = false }
                    else errMsg = r   // 중복/포인트부족 등 사유 표시
                }) { Text(tr("만들기")) }
            },
            dismissButton = { TextButton(onClick = { showAddFolder = false }) { Text(tr("취소")) } }
        )
    }

    // 이름 변경
    renameTarget?.let { r ->
        var newName by remember(r.id) { mutableStateOf(RouteVaultStore.nameOf(context, r.id) ?: "") }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text(tr("코스 이름")) },
            text = {
                OutlinedTextField(value = newName, onValueChange = { newName = it.take(20) },
                    placeholder = { Text(tr("예: 한강 야경 코스")) }, singleLine = true)
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newName.isNotBlank()) RouteVaultStore.setName(context, r.id, newName)
                    renameTarget = null; refresh++
                }) { Text(tr("저장")) }
            },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text(tr("취소")) } }
        )
    }

    // 폴더 이동
    moveTarget?.let { r ->
        AlertDialog(
            onDismissRequest = { moveTarget = null },
            title = { Text(tr("폴더로 이동")) },
            text = {
                Column {
                    folders.forEach { f ->
                        Text("📁 $f", fontSize = 15.sp, modifier = Modifier.fillMaxWidth()
                            .clickable {
                                RouteVaultStore.setFolder(context, r.id, f)
                                moveTarget = null; refresh++
                            }.padding(vertical = 10.dp))
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { moveTarget = null }) { Text(tr("취소")) } }
        )
    }

    LaunchedEffect(showAddFolder) { if (!showAddFolder) folders = RouteVaultStore.folders(context) }
}
