package com.navifit.navigation

import kotlinx.coroutines.tasks.await

/**
 * 경로 공유 & "친구 길 따라가기" 모드 (v27).
 *
 * 공유: 실제 이동경로(pathPolyline)를 "NAVIFIT_ROUTE:모드:인코딩폴리라인" 문자열로 만들어
 *      DM/운동장(커뮤니티) 글에 붙여넣기 → 받은 쪽에서 "이 경로대로 안내" 가능.
 *
 * 따라가기: 계산된 최적경로가 아니라 공유받은 그 길 그대로만 안내.
 *          이탈하면 새 경로를 짜지 않고 "공유 경로의 가장 가까운 지점으로 복귀"를 안내.
 */
object RouteShare {
    private const val PREFIX = "NAVIFIT_ROUTE"

    fun encode(mode: TravelMode, pathPolyline: String): String = "$PREFIX:${mode.name}:$pathPolyline"

    data class SharedRoute(val mode: TravelMode, val polyline: String)

    /** 텍스트 안에서 공유 경로를 찾아 파싱 (DM/커뮤 글 본문 전체를 넣어도 됨) */
    fun parse(text: String): SharedRoute? {
        val regex = Regex("$PREFIX:([A-Z_]+):([^\\s]+)")
        val m = regex.find(text) ?: return null
        val mode = try { TravelMode.valueOf(m.groupValues[1]) } catch (_: Exception) { return null }
        return SharedRoute(mode, m.groupValues[2])
    }

    fun containsRoute(text: String): Boolean = text.contains("$PREFIX:")
}

/**
 * ✅ 공유경로 고유키 시스템.
 *
 * 긴 폴리라인 텍스트를 복사·붙여넣기 하는 대신, 짧은 고유키로 경로를 주고받음.
 *   - 형식: 모드 접두 + 숫자·알파벳  (예: 달리기 R-4K7P2Q · 자전거 B-9X2M4A · 오토바이 M-... · 자동차 C-...)
 *   - 같은 경로는 항상 같은 키가 나오도록 폴리라인 해시 기반으로 생성 (사용자별·경로별 고유)
 *   - 발급된 키는 기기에 저장되고, 키를 입력하면 그 경로 그대로 "따라가기" 안내가 시작됨
 *
 * ⚠️ 서버가 붙기 전까지는 "이 기기에서 발급했거나 입력해서 받은 키"만 조회 가능.
 *    → ✅ v52: Firebase(Firestore) 연동 완료. 키 발급 시 shared_routes/{key}에 업로드되므로
 *      친구가 자기 폰에서 키만 입력해도 그 경로가 그대로 열립니다. (로컬 캐시는 오프라인 대비용으로 유지)
 */
object RouteKeyStore {
    private const val PREFS = "route_keys"
    private const val ALPHABET = "23456789ABCDEFGHJKMNPQRSTUVWXYZ" // 헷갈리는 0/O/1/I/L 제외

    private fun modeLetter(mode: TravelMode): Char = when (mode) {
        TravelMode.WALK -> 'R'          // Run/도보·달리기
        TravelMode.BIKE -> 'B'
        TravelMode.MOTORCYCLE -> 'M'
        TravelMode.CAR -> 'C'
    }

    private fun letterMode(c: Char): TravelMode? = when (c) {
        'R' -> TravelMode.WALK; 'B' -> TravelMode.BIKE
        'M' -> TravelMode.MOTORCYCLE; 'C' -> TravelMode.CAR; else -> null
    }

    /** 경로 폴리라인 → 결정적(항상 같은) 고유키 생성 + 로컬 저장 + ✅ Firestore 업로드. 예: "R-4K7P2QXM" */
    fun issueKey(context: android.content.Context, mode: TravelMode, polyline: String): String {
        val digest = java.security.MessageDigest.getInstance("SHA-256")
            .digest("${mode.name}:$polyline".toByteArray())
        val sb = StringBuilder()
        var acc = 0L
        // ✅ v58 전세계 수백만~수십억 경로 대응:
        //   6자(31^6 ≈ 8.9억)는 생일역설로 3만 경로쯤부터 충돌 위험이 생김.
        //   → 8자(31^8 ≈ 8500억)로 확장. 여기에 "모드 접두(R/B/M/C)"가 곱해져 실질 3조 이상.
        //   해시 앞 8바이트를 사용해 폴리라인이 다르면 사실상 겹치지 않음(결정적=같은 경로는 같은 키).
        for (i in 0 until 8) { acc = (acc shl 8) or (digest[i].toLong() and 0xFF) }
        if (acc < 0) acc = -acc
        repeat(8) { sb.append(ALPHABET[(acc % ALPHABET.length).toInt()]); acc /= ALPHABET.length }
        val key = "${modeLetter(mode)}-$sb"
        save(context, key, mode, polyline)
        // ✅ Firebase(Firestore)에 업로드: 이제 키만 알려주면 "다른 사람 기기"에서도 그 경로가 열림
        //    shared_routes/{key} = { mode, polyline, createdAt }
        if (com.navifit.social.FirebaseGuard.available(context)) try {
            com.google.firebase.firestore.FirebaseFirestore.getInstance()
                .collection("shared_routes").document(key)
                .set(mapOf(
                    "mode" to mode.name,
                    "polyline" to polyline,
                    "createdAt" to System.currentTimeMillis()
                ))
            // (오프라인이면 Firestore SDK가 큐에 담았다가 연결되면 자동 업로드)
        } catch (_: Exception) { /* 업로드 실패해도 로컬 키는 유효 */ }
        return key
    }

    /** 키 조회: ① 내 기기 로컬 → ② ✅ Firestore(다른 사람이 발급한 키도 조회 가능) */
    suspend fun resolve(context: android.content.Context, rawKey: String): RouteShare.SharedRoute? {
        val key = normalize(rawKey) ?: return null
        // ① 로컬 (내가 발급했거나 이전에 받은 키 - 오프라인에서도 동작)
        resolveLocal(context, key)?.let { return it }
        // ② Firestore (google-services.json 없으면 건너뜀)
        if (!com.navifit.social.FirebaseGuard.available(context)) return null
        return try {
            val doc = com.google.firebase.firestore.FirebaseFirestore.getInstance()
                .collection("shared_routes").document(key).get().await()
            val poly = doc.getString("polyline") ?: return null
            val mode = try { TravelMode.valueOf(doc.getString("mode") ?: "") }
                       catch (_: Exception) { letterMode(key.first()) } ?: return null
            save(context, key, mode, poly)   // 다음부터는 오프라인에서도 열리게 캐시
            RouteShare.SharedRoute(mode, poly)
        } catch (_: Exception) { null }
    }

    /** 로컬 전용 조회 (동기) */
    fun resolveLocal(context: android.content.Context, rawKey: String): RouteShare.SharedRoute? {
        val key = normalize(rawKey) ?: return null
        val p = context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
        val poly = p.getString("poly_$key", null) ?: return null
        val mode = letterMode(key.first()) ?: return null
        return RouteShare.SharedRoute(mode, poly)
    }

    /** 받은 공유경로(키+폴리라인)를 저장 - DM 등으로 "키+데이터"가 함께 온 경우 */
    fun save(context: android.content.Context, key: String, mode: TravelMode, polyline: String) {
        context.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
            .edit().putString("poly_${normalize(key) ?: key}", polyline).apply()
    }

    /** "r4k7p2qxm", "R-4K7P2QXM ", 등 어떤 형태로 입력해도 표준형(R-4K7P2QXM)으로 정규화.
     *  구버전 6자 키(R-4K7P2Q)와 신버전 8자 키(R-4K7P2QXM)를 모두 허용 */
    fun normalize(raw: String): String? {
        val cleaned = raw.trim().uppercase().replace(Regex("[^A-Z0-9]"), "")
        if (cleaned.length != 7 && cleaned.length != 9) return null   // 접두1 + 6 또는 8
        val head = cleaned.first()
        if (letterMode(head) == null) return null
        return "$head-${cleaned.substring(1)}"
    }

    fun looksLikeKey(text: String): Boolean = normalize(text) != null
}

/**
 * 친구 길 따라가기 안내기.
 * - 공유 경로 폴리라인 위에서 진행률/남은거리 계산
 * - 이탈(35m+) 시: 재탐색 대신 "경로의 가장 가까운 복귀 지점"으로 방향+거리 안내
 */
class FollowRouteGuide(val sharedPath: List<LatLngPoint>) {

    data class FollowState(
        val progressRatio: Float,
        val remainingMeters: Int,
        val isOffPath: Boolean,
        val returnPoint: LatLngPoint?,     // 이탈 시 돌아갈 지점
        val returnDistanceMeters: Int,     // 복귀 지점까지 직선거리
        val returnBearingDeg: Float        // 복귀 방향 (나침반 안내용)
    )

    fun compute(loc: LatLngPoint): FollowState {
        if (sharedPath.size < 2) return FollowState(0f, 0, false, null, 0, 0f)
        var nearestIdx = 0
        var nearestDist = Double.MAX_VALUE
        sharedPath.forEachIndexed { i, p ->
            val d = NavigationProgressCalculator.fastDistanceMeters(p, loc)
            if (d < nearestDist) { nearestDist = d; nearestIdx = i }
        }
        var traveled = 0.0; var total = 0.0
        for (i in 1 until sharedPath.size) {
            val seg = NavigationProgressCalculator.fastDistanceMeters(sharedPath[i - 1], sharedPath[i])
            total += seg
            if (i <= nearestIdx) traveled += seg
        }
        val ratio = if (total > 0) (traveled / total).toFloat().coerceIn(0f, 1f) else 0f
        val remaining = ((1 - ratio) * total).toInt()
        val off = nearestDist > 35.0
        val ret = sharedPath[nearestIdx]
        val brg = bearing(loc, ret)
        return FollowState(ratio, remaining, off, if (off) ret else null, nearestDist.toInt(), brg)
    }

    private fun bearing(a: LatLngPoint, b: LatLngPoint): Float {
        val dLng = Math.toRadians(b.longitude - a.longitude)
        val lat1 = Math.toRadians(a.latitude); val lat2 = Math.toRadians(b.latitude)
        val y = Math.sin(dLng) * Math.cos(lat2)
        val x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng)
        return ((Math.toDegrees(Math.atan2(y, x)) + 360) % 360).toFloat()
    }

    companion object {
        /** 방위각 -> 한글 방위 (나침반 안내: "북동쪽으로 120m") */
        fun bearingToKorean(deg: Float): String {
            val dirs = listOf("북", "북동", "동", "남동", "남", "남서", "서", "북서")
            return dirs[(((deg + 22.5f) % 360) / 45f).toInt().coerceIn(0, 7)] + "쪽"
        }
    }
}

/**
 * ✅ v39 공유 경로 회전 검출기.
 *
 * 문제: 친구 길 따라가기 모드는 폴리라인만 있고 steps(회전 안내)가 없어서
 *       "우회전하세요" 같은 음성 안내가 전혀 나오지 않았음 (그냥 선만 따라가야 했음).
 *
 * 해결: 폴리라인의 방위각 변화를 분석해 회전 지점을 자동으로 찾아내고
 *       RouteStep 목록을 합성. 이러면 공유 경로도 일반 내비처럼 턴바이턴 안내가 됨.
 */
object SharedRouteTurnDetector {

    /** 방위각 변화가 이 각도 이상이면 회전으로 간주 */
    private const val TURN_THRESHOLD_DEG = 32.0
    /** 회전 지점끼리 최소 간격 (너무 촘촘한 안내 방지) */
    private const val MIN_TURN_GAP_M = 60.0

    fun detectSteps(points: List<LatLngPoint>): List<RouteStep> {
        if (points.size < 3) return emptyList()
        val steps = mutableListOf<RouteStep>()
        var lastTurnIdx = 0

        // 방위각 계산에 쓸 구간 길이 (짧으면 GPS 노이즈로 오탐)
        fun bearingAt(i: Int, window: Int): Double? {
            val a = points.getOrNull(i - window) ?: return null
            val b = points.getOrNull(i + window) ?: return null
            if (NavigationProgressCalculator.fastDistanceMeters(a, b) < 12) return null
            return bearing(a, b)
        }

        for (i in 2 until points.size - 2) {
            val before = bearingAt(i, 2) ?: continue
            val after = bearingAt(i + 2, 2) ?: continue
            val delta = angleDelta(before, after)
            if (Math.abs(delta) < TURN_THRESHOLD_DEG) continue

            // 직전 회전과 너무 가까우면 건너뜀
            val gap = distanceBetween(points, lastTurnIdx, i)
            if (steps.isNotEmpty() && gap < MIN_TURN_GAP_M) continue

            val maneuver = when {
                delta >= 130 || delta <= -130 -> "uturn"
                delta >= 75 -> "turn-right"
                delta >= TURN_THRESHOLD_DEG -> "turn-slight-right"
                delta <= -75 -> "turn-left"
                else -> "turn-slight-left"
            }
            val instruction = when (maneuver) {
                "uturn" -> "유턴 구간"
                "turn-right" -> "우회전"
                "turn-slight-right" -> "우측 방향"
                "turn-left" -> "좌회전"
                else -> "좌측 방향"
            }
            steps.add(
                RouteStep(
                    instruction = instruction,
                    distanceMeters = gap.toInt(),
                    durationSeconds = 0,
                    startLocation = points[lastTurnIdx],
                    endLocation = points[i],
                    maneuver = maneuver
                )
            )
            lastTurnIdx = i
        }

        // 마지막: 도착 스텝
        steps.add(
            RouteStep(
                instruction = "목적지 도착",
                distanceMeters = distanceBetween(points, lastTurnIdx, points.size - 1).toInt(),
                durationSeconds = 0,
                startLocation = points[lastTurnIdx],
                endLocation = points.last(),
                maneuver = "arrive"
            )
        )
        return steps
    }

    private fun distanceBetween(pts: List<LatLngPoint>, from: Int, to: Int): Double {
        var d = 0.0
        for (i in (from + 1)..to.coerceAtMost(pts.size - 1)) {
            d += NavigationProgressCalculator.fastDistanceMeters(pts[i - 1], pts[i])
        }
        return d
    }

    private fun bearing(a: LatLngPoint, b: LatLngPoint): Double {
        val dLng = Math.toRadians(b.longitude - a.longitude)
        val lat1 = Math.toRadians(a.latitude); val lat2 = Math.toRadians(b.latitude)
        val y = Math.sin(dLng) * Math.cos(lat2)
        val x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng)
        return (Math.toDegrees(Math.atan2(y, x)) + 360) % 360
    }

    /** -180 ~ +180 (양수=우회전, 음수=좌회전) */
    private fun angleDelta(from: Double, to: Double): Double {
        var d = to - from
        while (d > 180) d -= 360
        while (d < -180) d += 360
        return d
    }
}
