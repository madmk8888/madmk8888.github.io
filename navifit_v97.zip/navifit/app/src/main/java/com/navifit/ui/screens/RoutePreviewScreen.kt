package com.navifit.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.maps.android.compose.*
import com.navifit.navigation.RouteResult
import com.navifit.navigation.TravelMode

/**
 * ✅ v56: 카카오내비/티맵식 "지도 기반 경로 선택" 화면.
 *
 * 기존: 지도 없는 팝업(AlertDialog)에서 글자만 보고 경로 선택 → 허접
 * 지금: 시중 내비와 동일한 구성
 *   · 지도에 후보 경로들이 색으로 동시에 그려짐 (선택 = 파란 굵은 선, 나머지 = 회색)
 *   · 지도의 회색 경로를 탭하거나 하단 카드를 탭하면 선택이 바뀜
 *   · 카드: 배지(최소시간/최단거리/대안) + 소요시간 크게 + 거리 + 도착예정시각
 *   · 하단 대형 [안내 시작 / 운동 시작] 버튼, 차량 모드엔 외부 내비 연결 줄
 */
@Composable
fun RoutePreviewScreen(
    routes: List<RouteResult>,
    mode: TravelMode,
    destName: String,
    originName: String?,
    onStart: (selected: RouteResult, others: List<RouteResult>) -> Unit,
    onCancel: () -> Unit,
    onExternalNavi: (String) -> Unit
) {
    var selectedIdx by remember(routes) { mutableStateOf(0) }
    val decoded = remember(routes) { routes.map { decodePolyline(it.overviewPolyline).map { p -> LatLng(p.latitude, p.longitude) } } }
    val cameraState = rememberCameraPositionState()

    // 모든 경로가 화면에 들어오게 카메라 맞춤
    LaunchedEffect(decoded) {
        val b = LatLngBounds.builder()
        var any = false
        decoded.forEach { pts -> pts.forEach { b.include(it); any = true } }
        if (any) try {
            cameraState.move(CameraUpdateFactory.newLatLngBounds(b.build(), 140))
        } catch (_: Exception) { }
    }

    val fastest = routes.minByOrNull { it.totalDurationSeconds }
    val shortest = routes.minByOrNull { it.totalDistanceMeters }
    fun badge(r: RouteResult) = when {
        r === fastest -> "⚡ 최소 시간"
        r === shortest -> "📏 최단 거리"
        else -> "🔀 대안"
    }
    val accent = if (mode.isWorkoutMode) Color(0xFF34C77B) else Color(0xFF3D6AFE)

    Box(Modifier.fillMaxSize().background(Color(0xFF121420))) {
        GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = cameraState,
            uiSettings = MapUiSettings(zoomControlsEnabled = false, mapToolbarEnabled = false),
            properties = MapProperties(isMyLocationEnabled = false)
        ) {
            // 비선택 경로 먼저(아래), 선택 경로 나중(위) - 클릭 시 선택 전환
            decoded.forEachIndexed { i, pts ->
                if (i != selectedIdx && pts.size >= 2) {
                    Polyline(points = pts, color = Color(0xFF9AA0B4), width = 16f,
                        clickable = true, onClick = { selectedIdx = i })
                }
            }
            decoded.getOrNull(selectedIdx)?.let { pts ->
                if (pts.size >= 2) {
                    Polyline(points = pts, color = Color(0x553D6AFE), width = 26f)   // 외곽 글로우
                    Polyline(points = pts, color = accent, width = 15f)
                    Marker(state = MarkerState(pts.first()), title = originName ?: "출발")
                    Marker(state = MarkerState(pts.last()), title = destName)
                }
            }
        }

        // ── 상단: 출발 → 도착 요약 바 ──
        Surface(
            Modifier.align(Alignment.TopCenter).padding(12.dp).fillMaxWidth(),
            shape = RoundedCornerShape(16.dp), color = Color(0xF01B1E2C),
            shadowElevation = 6.dp
        ) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("✕", fontSize = 17.sp, color = Color(0xFFAAB0C4),
                    modifier = Modifier.clickable(onClick = onCancel).padding(end = 12.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(7.dp).background(Color(0xFF6FD3AC), CircleShape))
                        Spacer(Modifier.width(7.dp))
                        Text(originName ?: "현재 위치", fontSize = 12.sp, color = Color(0xFFAAB0C4), maxLines = 1)
                    }
                    Spacer(Modifier.height(3.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(7.dp).background(Color(0xFFFF6B6B), CircleShape))
                        Spacer(Modifier.width(7.dp))
                        Text(destName, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFECEDF4), maxLines = 1)
                    }
                }
                Text(if (mode.isWorkoutMode) "🏃" else "🚗", fontSize = 20.sp)
            }
        }

        // ── 하단: 경로 카드들 + 시작 버튼 ──
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(Color(0xF5171A28), RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
                .padding(top = 12.dp, bottom = 14.dp)
        ) {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(9.dp),
                contentPadding = PaddingValues(horizontal = 14.dp)
            ) {
                items(routes.size) { i ->
                    val r = routes[i]
                    val sel = i == selectedIdx
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (sel) Color(0xFF232C4E) else Color(0xFF1E2233),
                        border = androidx.compose.foundation.BorderStroke(
                            if (sel) 1.5.dp else 1.dp,
                            if (sel) accent else Color(0xFF2C3145)
                        ),
                        modifier = Modifier.width(150.dp).clickable { selectedIdx = i }
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text(badge(r), fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                color = if (sel) accent else Color(0xFF8B93AC))
                            Spacer(Modifier.height(4.dp))
                            Text("${r.totalDurationSeconds / 60}분", fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (sel) Color.White else Color(0xFFC7CBD9))
                            Text("%.1fkm".format(r.totalDistanceMeters / 1000.0),
                                fontSize = 12.sp, color = Color(0xFF8B93AC))
                            val eta = java.text.SimpleDateFormat("a h:mm", java.util.Locale.KOREA)
                                .format(java.util.Date(System.currentTimeMillis() + r.totalDurationSeconds * 1000L))
                            Text("🏁 $eta", fontSize = 11.sp, color = Color(0xFF6FD3AC))
                        }
                    }
                }
            }

            if (!mode.isWorkoutMode) {
                Spacer(Modifier.height(9.dp))
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("카카오내비" to "kakao", "네이버" to "naver", "티맵" to "tmap", "구글" to "google")
                        .forEach { (label, app) ->
                            OutlinedButton(
                                onClick = { onExternalNavi(app) },
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                modifier = Modifier.weight(1f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C3145))
                            ) { Text(label, fontSize = 10.sp, color = Color(0xFF8B93AC)) }
                        }
                }
            }

            Spacer(Modifier.height(10.dp))
            Button(
                onClick = {
                    val sel = routes.getOrNull(selectedIdx) ?: routes.first()
                    onStart(sel, routes.filter { it !== sel })
                },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp).height(52.dp),
                shape = RoundedCornerShape(15.dp),
                colors = ButtonDefaults.buttonColors(containerColor = accent)
            ) {
                Text(if (mode.isWorkoutMode) "🏃 운동 시작" else "🧭 안내 시작",
                    fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            }
        }
    }
}
