package com.navifit.navigation

import kotlin.math.cos
import kotlin.math.sqrt

/** 다음 안내에서 켜줄 차선 방향 표시등 */
enum class LaneDirection { LEFT, RIGHT, STRAIGHT, UTURN }

data class NavProgress(
    val nearestRouteIndex: Int,          // 경로 폴리라인에서 내 위치와 가장 가까운 점 index
    val traveledRatio: Float,            // 0.0~1.0 경로 진행률 (형광 표시용)
    val remainingMeters: Int,            // 목적지까지 남은 거리
    val remainingSeconds: Int,           // 남은 예상 시간
    val nextStep: RouteStep?,            // 다음 안내 (예: "우회전하세요")
    val distanceToNextTurnMeters: Int,   // 다음 회전 지점까지 남은 거리
    val laneDirection: LaneDirection,    // 좌/우/직진 표시등
    val isOffRoute: Boolean,             // 경로 이탈 여부
    val distanceFromRouteMeters: Double = 0.0,   // ✅ v31: 경로에서 떨어진 실제 거리 (선분 투영)
    val snappedLocation: LatLngPoint? = null     // ✅ v31: 도로 위로 스냅된 위치 (맵매칭 - 시중 내비처럼 마커가 도로 위를 탐)
)

/**
 * 실시간 내비 진행 계산기.
 * - 내 위치를 경로 폴리라인에 투영해서: 진행률, 남은거리, 다음 회전까지 거리, 차선 방향을 계산
 * - 시중 내비처럼 "300m 앞에서 우회전" 식 안내가 가능해짐
 *
 * ✅ v31 수정: 이탈 판정을 "가장 가까운 꼭짓점"이 아니라 "가장 가까운 선분에 투영한 거리"로 계산.
 *    (직선 도로는 폴리라인 점 간격이 100m 넘게 벌어져서, 점 거리 방식은 도로 위에 있어도
 *     이탈로 오판 → 재탐색 반복 버그의 원인이었음)
 */
object NavigationProgressCalculator {

    fun compute(
        routePoints: List<LatLngPoint>,
        steps: List<RouteStep>,
        totalDistanceMeters: Int,
        totalDurationSeconds: Int,
        currentLocation: LatLngPoint,
        offRouteThresholdMeters: Double = 45.0   // ✅ v31: 이동수단별로 다르게 (도보 40 / 차 55)
    ): NavProgress {
        if (routePoints.isEmpty()) {
            return NavProgress(0, 0f, totalDistanceMeters, totalDurationSeconds, steps.firstOrNull(), 0, LaneDirection.STRAIGHT, false)
        }

        // 1) ✅ 선분 투영: 모든 (i-1,i) 선분에 내 위치를 투영해서 최단거리 + 투영점(스냅 위치) 계산
        var nearestIdx = 0
        var nearestDist = Double.MAX_VALUE
        var snapped: LatLngPoint? = null
        var segT = 0.0 // 최단 선분 내 진행 비율 (부분 진행률 계산용)
        if (routePoints.size == 1) {
            nearestDist = fastDistanceMeters(routePoints[0], currentLocation)
            snapped = routePoints[0]
        } else {
            for (i in 1 until routePoints.size) {
                val (d, t, proj) = projectToSegment(currentLocation, routePoints[i - 1], routePoints[i])
                if (d < nearestDist) {
                    nearestDist = d; nearestIdx = i; segT = t; snapped = proj
                }
            }
        }

        // 2) 진행률 & 남은 거리 (선분 부분 진행 포함)
        var traveled = 0.0
        var total = 0.0
        for (i in 1 until routePoints.size) {
            val seg = fastDistanceMeters(routePoints[i - 1], routePoints[i])
            total += seg
            if (i < nearestIdx) traveled += seg
            else if (i == nearestIdx) traveled += seg * segT
        }
        val ratio = if (total > 0) (traveled / total).toFloat().coerceIn(0f, 1f) else 0f
        val remaining = ((1 - ratio) * totalDistanceMeters).toInt().coerceAtLeast(0)
        val remainingSec = ((1 - ratio) * totalDurationSeconds).toInt().coerceAtLeast(0)

        // 3) 다음 안내 스텝 찾기: 아직 지나지 않은 스텝 중 첫 번째
        var nextStep: RouteStep? = null
        var distToTurn = remaining
        if (steps.isNotEmpty()) {
            for (s in steps) {
                val stepEndIdx = nearestPointIndex(routePoints, s.endLocation)
                if (stepEndIdx > nearestIdx || (stepEndIdx == nearestIdx && segT < 0.95)) {
                    nextStep = s
                    var d = 0.0
                    // 현재 선분의 남은 부분부터 스텝 종료점까지 누적
                    if (nearestIdx in 1 until routePoints.size) {
                        d += fastDistanceMeters(routePoints[nearestIdx - 1], routePoints[nearestIdx]) * (1 - segT)
                    }
                    for (i in (nearestIdx + 1)..stepEndIdx.coerceAtMost(routePoints.size - 1)) {
                        d += fastDistanceMeters(routePoints[i - 1], routePoints[i])
                    }
                    distToTurn = d.toInt()
                    break
                }
            }
            if (nextStep == null) nextStep = steps.last()
        }

        val lane = maneuverToLane(nextStep?.maneuver)
        val off = nearestDist > offRouteThresholdMeters

        return NavProgress(
            nearestRouteIndex = nearestIdx,
            traveledRatio = ratio,
            remainingMeters = remaining,
            remainingSeconds = remainingSec,
            nextStep = nextStep,
            distanceToNextTurnMeters = distToTurn,
            laneDirection = lane,
            isOffRoute = off,
            distanceFromRouteMeters = nearestDist,
            snappedLocation = if (!off) snapped else null // 이탈 상태에선 스냅 안 함 (실제 위치 표시)
        )
    }

    /** 점 P를 선분 AB에 투영: (거리m, 선분내 비율 t 0~1, 투영점) */
    private fun projectToSegment(p: LatLngPoint, a: LatLngPoint, b: LatLngPoint): Triple<Double, Double, LatLngPoint> {
        val meanLat = Math.toRadians((a.latitude + b.latitude) / 2)
        val kx = cos(meanLat) * 111_320.0 // 경도 1도당 미터
        val ky = 110_540.0                 // 위도 1도당 미터
        val ax = a.longitude * kx; val ay = a.latitude * ky
        val bx = b.longitude * kx; val by = b.latitude * ky
        val px = p.longitude * kx; val py = p.latitude * ky
        val dx = bx - ax; val dy = by - ay
        val lenSq = dx * dx + dy * dy
        val t = if (lenSq <= 0.0) 0.0 else (((px - ax) * dx + (py - ay) * dy) / lenSq).coerceIn(0.0, 1.0)
        val cx = ax + t * dx; val cy = ay + t * dy
        val dist = sqrt((px - cx) * (px - cx) + (py - cy) * (py - cy))
        return Triple(dist, t, LatLngPoint(cy / ky, cx / kx))
    }

    fun maneuverToLane(maneuver: String?): LaneDirection = when {
        maneuver == null -> LaneDirection.STRAIGHT
        maneuver.contains("uturn") -> LaneDirection.UTURN
        maneuver.contains("left") -> LaneDirection.LEFT
        maneuver.contains("right") -> LaneDirection.RIGHT
        else -> LaneDirection.STRAIGHT
    }

    fun nearestPointIndex(points: List<LatLngPoint>, target: LatLngPoint): Int {
        var idx = 0
        var best = Double.MAX_VALUE
        points.forEachIndexed { i, p ->
            val d = fastDistanceMeters(p, target)
            if (d < best) { best = d; idx = i }
        }
        return idx
    }

    /** 짧은 거리용 근사 거리 계산 (haversine보다 빠름, 내비 스케일에서는 충분히 정확) */
    fun fastDistanceMeters(a: LatLngPoint, b: LatLngPoint): Double {
        val dLat = Math.toRadians(b.latitude - a.latitude)
        val dLng = Math.toRadians(b.longitude - a.longitude)
        val meanLat = Math.toRadians((a.latitude + b.latitude) / 2)
        val x = dLng * cos(meanLat)
        return sqrt(dLat * dLat + x * x) * 6_371_000.0
    }

    /** 남은 거리 표시 포맷: 850m / 1.2km */
    fun formatDistance(meters: Int): String =
        if (meters < 1000) "${meters}m" else "%.1fkm".format(meters / 1000.0)

    /** 남은 시간 포맷: 5분 / 1시간 12분 */
    fun formatDuration(seconds: Int): String {
        val m = seconds / 60
        return if (m < 60) "${m}분" else "${m / 60}시간 ${m % 60}분"
    }
}
