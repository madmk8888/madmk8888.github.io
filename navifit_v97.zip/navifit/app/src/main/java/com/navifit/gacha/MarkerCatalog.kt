package com.navifit.gacha

/**
 * 마커 = 심볼(shape) + 배경(color) 을 독립적으로 뽑아 조합.
 * 등급 확률: 일반 69 · 레어 25 · 에픽 5 · 유니크 0.9999 · 레전더리 0.0001 (레전더리는 부스트 대상 아님)
 *
 * v26 리디자인:
 *  - 심볼 12종은 이모지가 아니라 자체 벡터(SymbolId)로 그려짐 → MarkerSymbolRenderer 참조
 *  - 배경(color)은 등급별 팔레트: 일반 단색 8 · 레어 무광젬 6 · 에픽 발광 6 · 유니크 홀로 3 · 레전더리 6
 *  - 심볼 자체에는 등급이 없고(어느 배경과도 조합 가능), 등급은 "배경"이 결정.
 *    단, 지도/뽑기 연출용으로 심볼도 tier 필드를 갖되 확률 계산엔 배경 tier만 사용.
 */
enum class GachaTier(val label: String, val ratePercent: Double, val hasGlow: Boolean) {
    COMMON("일반", 69.0, false),
    RARE("레어", 25.0, false),
    EPIC("에픽", 5.0, true),
    UNIQUE("유니크", 0.9999, true),
    LEGENDARY("레전더리", 0.0001, true)
}

/** 자체 벡터로 그려지는 심볼 종류 (이모지 대체) */
enum class SymbolId {
    LIGHTNING, BLOSSOM, CROWN, GEM, FLAME, SNOW, MOON, WING, STAR, HEARTGEM, CLOVER, ROSE,
    // 레전더리 전용 심볼
    DRAGON, PHOENIX, COMET, GODCROWN, INFINITY, NEONBOLT
}

data class MarkerShape(val id: String, val symbol: SymbolId, val nameKo: String, val tier: GachaTier) {
    /** 하위호환: 기존 코드가 emoji를 참조하던 자리 대비 (더 이상 렌더에는 안 씀) */
    val emoji: String get() = "•"
}

/**
 * 배경. 등급별로 스타일이 다름:
 *  - COMMON: 단색 (hex)
 *  - RARE: 무광 세로 그라데이션
 *  - EPIC: 라디얼 발광 + 광택
 *  - UNIQUE: 흐르는 홀로그램
 *  - LEGENDARY: 프리즘/오로라 등 + 스파클
 * bgStyle 로 렌더러가 어떤 방식으로 그릴지 구분.
 */
enum class BgStyle { SOLID, MATTE_GRAD, EPIC_ORB, HOLO_FLOW, LEGENDARY }

data class MarkerColor(
    val hex: String,          // 대표색 (SOLID/그라데이션 시작색). RAINBOW 특수값 가능
    val nameKo: String,
    val tier: GachaTier,
    val bgStyle: BgStyle,
    val stops: List<String> = emptyList() // 그라데이션/홀로/레전더리용 색 정지점
) {
    val isRainbow get() = hex == "RAINBOW"
}

data class DrawnMarker(val shape: MarkerShape, val color: MarkerColor) {
    val key get() = "${shape.id}_${if (color.isRainbow) "rainbow" else color.hex}"
    val isUnique get() = shape.tier == GachaTier.LEGENDARY && color.tier == GachaTier.LEGENDARY
    val hasGlow get() = shape.tier.hasGlow || color.tier.hasGlow
    val displayName get() = "${shape.nameKo} · ${color.nameKo}"
    val effectiveTierOrdinal get() = maxOf(shape.tier.ordinal, color.tier.ordinal)
}

object MarkerCatalog {
    // ── 심볼 12종 (일반~유니크 배경과 조합) + 레전더리 전용 6종 ──
    val shapes = listOf(
        MarkerShape("lightning", SymbolId.LIGHTNING, "라이트닝", GachaTier.COMMON),
        MarkerShape("blossom",   SymbolId.BLOSSOM,   "벚꽃",     GachaTier.COMMON),
        MarkerShape("star",      SymbolId.STAR,      "스타",     GachaTier.COMMON),
        MarkerShape("clover",    SymbolId.CLOVER,    "클로버",   GachaTier.COMMON),
        MarkerShape("moon",      SymbolId.MOON,      "문라이트", GachaTier.RARE),
        MarkerShape("snow",      SymbolId.SNOW,      "스노우",   GachaTier.RARE),
        MarkerShape("gem",       SymbolId.GEM,       "크리스탈", GachaTier.RARE),
        MarkerShape("heartgem",  SymbolId.HEARTGEM,  "하트젬",   GachaTier.RARE),
        MarkerShape("flame",     SymbolId.FLAME,     "플레임",   GachaTier.EPIC),
        MarkerShape("wing",      SymbolId.WING,      "엔젤윙",   GachaTier.EPIC),
        MarkerShape("rose",      SymbolId.ROSE,      "로즈",     GachaTier.EPIC),
        MarkerShape("crown",     SymbolId.CROWN,     "크라운",   GachaTier.UNIQUE),
        // 레전더리 전용 심볼 6종
        MarkerShape("dragon",    SymbolId.DRAGON,    "드래곤",     GachaTier.LEGENDARY),
        MarkerShape("phoenix",   SymbolId.PHOENIX,   "피닉스",     GachaTier.LEGENDARY),
        MarkerShape("comet",     SymbolId.COMET,     "코멧",       GachaTier.LEGENDARY),
        MarkerShape("godcrown",  SymbolId.GODCROWN,  "갓크라운",   GachaTier.LEGENDARY),
        MarkerShape("infinity",  SymbolId.INFINITY,  "인피니티",   GachaTier.LEGENDARY),
        MarkerShape("neonbolt",  SymbolId.NEONBOLT,  "네온볼트",   GachaTier.LEGENDARY),
    )

    // ── 배경 팔레트 ──
    val colors = listOf(
        // 일반 단색 8
        MarkerColor("#3D3850", "차콜",   GachaTier.COMMON, BgStyle.SOLID),
        MarkerColor("#2E3A5C", "네이비", GachaTier.COMMON, BgStyle.SOLID),
        MarkerColor("#2F4A3D", "포레스트", GachaTier.COMMON, BgStyle.SOLID),
        MarkerColor("#4A3355", "플럼",   GachaTier.COMMON, BgStyle.SOLID),
        MarkerColor("#4A4030", "모카",   GachaTier.COMMON, BgStyle.SOLID),
        MarkerColor("#37424E", "슬레이트", GachaTier.COMMON, BgStyle.SOLID),
        MarkerColor("#4E2A38", "와인",   GachaTier.COMMON, BgStyle.SOLID),
        MarkerColor("#264A4A", "딥티얼", GachaTier.COMMON, BgStyle.SOLID),
        // 레어 무광젬 6
        MarkerColor("#5B9EDE", "사파이어", GachaTier.RARE, BgStyle.MATTE_GRAD, listOf("#5B9EDE", "#2B5FA8")),
        MarkerColor("#E06A92", "루비",   GachaTier.RARE, BgStyle.MATTE_GRAD, listOf("#E06A92", "#A83258")),
        MarkerColor("#5FBF8E", "에메랄드", GachaTier.RARE, BgStyle.MATTE_GRAD, listOf("#5FBF8E", "#1F7A54")),
        MarkerColor("#A98BD6", "자수정", GachaTier.RARE, BgStyle.MATTE_GRAD, listOf("#A98BD6", "#6B4A9E")),
        MarkerColor("#E0B060", "앰버",   GachaTier.RARE, BgStyle.MATTE_GRAD, listOf("#E0B060", "#A8752B")),
        MarkerColor("#E0A898", "로즈골드", GachaTier.RARE, BgStyle.MATTE_GRAD, listOf("#E0A898", "#B0705A")),
        // 에픽 발광 6
        MarkerColor("#2F7FFF", "마나블루", GachaTier.EPIC, BgStyle.EPIC_ORB, listOf("#D5ECFF", "#2F7FFF", "#123A8F")),
        MarkerColor("#B026D9", "아케인퍼플", GachaTier.EPIC, BgStyle.EPIC_ORB, listOf("#F5C2FF", "#B026D9", "#520080")),
        MarkerColor("#FF2E2E", "블러드레드", GachaTier.EPIC, BgStyle.EPIC_ORB, listOf("#FFD0D0", "#FF2E2E", "#8F0000")),
        MarkerColor("#40D0FF", "프로스트", GachaTier.EPIC, BgStyle.EPIC_ORB, listOf("#F0FFFF", "#40D0FF", "#0470A8")),
        MarkerColor("#FF4DB8", "네온핑크", GachaTier.EPIC, BgStyle.EPIC_ORB, listOf("#FFE0F0", "#FF4DB8", "#A3005C")),
        MarkerColor("#FFD21E", "솔라옐로", GachaTier.EPIC, BgStyle.EPIC_ORB, listOf("#FFFACC", "#FFD21E", "#A87C00")),
        // 유니크 홀로 3
        MarkerColor("#D8B4FE", "펄",     GachaTier.UNIQUE, BgStyle.HOLO_FLOW, listOf("#F8E7FF", "#A5F3FC", "#FFFFFF", "#D8B4FE", "#F8E7FF")),
        MarkerColor("#7C3AED", "오일슬릭", GachaTier.UNIQUE, BgStyle.HOLO_FLOW, listOf("#0F172A", "#7C3AED", "#06B6D4", "#10B981", "#0F172A")),
        MarkerColor("PRISM",   "프리즘", GachaTier.UNIQUE, BgStyle.HOLO_FLOW, listOf("#FFD700", "#FF3CAC", "#5B7FFF", "#39FF88", "#FFD700")),
        // 레전더리 6
        MarkerColor("#FFD700", "골든셀레스티얼", GachaTier.LEGENDARY, BgStyle.LEGENDARY, listOf("#FFF7CC", "#FFD700", "#B8860B")),
        MarkerColor("AURORA",  "오로라홀로", GachaTier.LEGENDARY, BgStyle.LEGENDARY, listOf("#00FFD0", "#A855F7", "#4B8CFF", "#FF6AD5", "#00FFD0")),
        MarkerColor("DIAMOND", "다이아프리즘", GachaTier.LEGENDARY, BgStyle.LEGENDARY, listOf("#FFFFFF", "#E0F7FF", "#FFE3F1", "#E8DCFF", "#FFFFFF")),
        MarkerColor("GALAXY",  "갤럭시노바", GachaTier.LEGENDARY, BgStyle.LEGENDARY, listOf("#FFFFFF", "#FFD86B", "#FF3CAC", "#5B2FB0", "#0D0221")),
        MarkerColor("RAINBOW", "레인보우크롬", GachaTier.LEGENDARY, BgStyle.LEGENDARY, listOf("#FF5F6D", "#FFC371", "#47E5BC", "#5B7FFF", "#C471F5", "#FF5F6D")),
        MarkerColor("#FF9EC7", "셀레스티얼로즈", GachaTier.LEGENDARY, BgStyle.LEGENDARY, listOf("#FFF0F5", "#FF9EC7", "#C9457F", "#6B1240")),
    )

    fun shapesByTier(tier: GachaTier) = shapes.filter { it.tier == tier }
    fun colorsByTier(tier: GachaTier) = colors.filter { it.tier == tier }
}
