package com.navifit.data

import androidx.room.*
import com.navifit.navigation.TravelMode

@Entity(tableName = "activity_records")
data class ActivityRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val mode: TravelMode,
    val startTimeMillis: Long,
    val durationSeconds: Long,       // 실제 총 이동시간 (개인 분석용)
    val distanceMeters: Double,      // 실제 총 이동거리 (개인 분석용)
    val avgSpeedKmh: Double,
    val maxSpeedKmh: Double,
    val originName: String? = null,        // 출발지 이름 (랭킹 경로 표시/검색용)
    val destinationName: String? = null,   // 도착지 이름
    val pathPolyline: String? = null,      // 실제 이동 경로 (인코딩 폴리라인) - 랭킹에서 형광 표시용
    val safetyScore: Int = 100,            // 주행(오토바이/자동차) 안전점수 - 운전 랭킹 1순위 기준
    // 랭킹 전용 필드: 10~14.99km처럼 애매한 거리는 "10km 지점 통과 시각"으로 스냅해서 저장
    val rankingBracketKm: Double = 0.0,     // 랭킹에 반영되는 구간 (예: 10.0)
    val rankingDurationSeconds: Long = 0,   // 그 구간까지 걸린 시간
    val isRankingValid: Boolean = true,     // 부정사용 감지되면 false (안내는 계속되지만 랭킹 제외)
    val invalidReason: String? = null,
    val countryCode: String? = null,        // ✅ GPS 위치 기반 자동 판별 국가코드(ISO 3166-1 alpha-2) - 랭킹 국가 자동분류용 (앱 언어설정과 무관)
    // ✅ v34: "한 번에 달성" 테두리 검증용 - 쉬엄쉬엄 하루 종일 끌어서 따는 것 방지
    val movingSeconds: Long = 0,            // 실제 움직인 시간 (정지·휴식 제외)
    val maxRestSeconds: Long = 0            // 한 번에 가장 오래 쉰 시간
) {
    /** 이동시간 비율 (1.0 = 한 번도 안 쉼). 0이면 옛 기록이라 판정 불가 → 통과 처리 */
    val movingRatio: Double
        get() = if (movingSeconds <= 0 || durationSeconds <= 0) 1.0
                else (movingSeconds.toDouble() / durationSeconds).coerceIn(0.0, 1.0)

    /**
     * ✅ "한 번에" 달성으로 인정되는 세션인가?
     *  - 움직인 시간이 전체의 70% 이상 (30% 넘게 쉬면 탈락)
     *  - 한 번에 쉰 시간이 30분 미만 (밥 먹고 오거나 자고 오면 탈락)
     *  옛 기록(필드 0)은 판정 불가라 통과시킴.
     */
    val isSingleSessionValid: Boolean
        get() = movingSeconds <= 0 || (movingRatio >= 0.70 && maxRestSeconds < 30 * 60)
}

@Dao
interface ActivityRecordDao {
    @Insert
    suspend fun insert(record: ActivityRecord): Long

    @Query("SELECT * FROM activity_records WHERE mode = :mode ORDER BY startTimeMillis DESC")
    suspend fun getByMode(mode: TravelMode): List<ActivityRecord>

    @Query("SELECT * FROM activity_records ORDER BY startTimeMillis DESC")
    suspend fun getAll(): List<ActivityRecord>

    @Query("SELECT * FROM activity_records WHERE mode = :mode AND startTimeMillis >= :sinceMillis ORDER BY startTimeMillis ASC")
    suspend fun getByModeSince(mode: TravelMode, sinceMillis: Long): List<ActivityRecord>

    @Query("DELETE FROM activity_records")
    suspend fun deleteAll()   // ✅ v77 로그아웃 시 기록 초기화
}

class Converters {
    @TypeConverter
    fun fromTravelMode(mode: TravelMode): String = mode.name

    @TypeConverter
    fun toTravelMode(name: String): TravelMode = TravelMode.valueOf(name)
}

@Database(entities = [ActivityRecord::class], version = 5, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun activityRecordDao(): ActivityRecordDao
}
