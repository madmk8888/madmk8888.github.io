package com.navifit.social

import android.content.Context

/**
 * ✅ v35 프라이버시/모더레이션 설정 (인스타·카톡 수준의 기본 방어).
 *
 * 없어서 문제였던 것:
 *  - 아무나 DM을 보낼 수 있었음 (스팸·괴롭힘 무방비)
 *  - 글에 아무나 댓글을 달 수 있었고, 작성자가 막을 방법이 없었음
 *  - 단 댓글을 지울 수 없었음
 */
object PrivacySettings {
    private const val PREF = "privacy_settings"

    /** DM 수신 범위 */
    enum class DmScope(val label: String, val desc: String) {
        EVERYONE("전체 허용", "누구나 나에게 RM을 보낼 수 있어요"),
        FRIENDS_ONLY("친구만", "친구로 등록된 사람만 RM을 보낼 수 있어요"),
        NOBODY("받지 않음", "아무에게도 RM을 받지 않아요")
    }

    /** 내 글에 댓글을 달 수 있는 사람 */
    enum class CommentScope(val label: String, val desc: String) {
        EVERYONE("전체 허용", "누구나 댓글을 달 수 있어요"),
        FRIENDS_ONLY("친구만", "친구만 댓글을 달 수 있어요"),
        NOBODY("댓글 금지", "아무도 댓글을 달 수 없어요")
    }

    fun dmScope(c: Context): DmScope = try {
        DmScope.valueOf(prefs(c).getString("dm_scope", DmScope.EVERYONE.name)!!)
    } catch (_: Exception) { DmScope.EVERYONE }

    fun setDmScope(c: Context, v: DmScope) {
        prefs(c).edit().putString("dm_scope", v.name).apply()
        // ✅ 서버에도 반영해야 상대 기기가 "이 사람은 친구만 DM 받음"을 알 수 있음
        syncToServer(c, v)
    }

    /** 내 DM 설정을 Firestore users/{uid} 에 반영 */
    fun syncToServer(c: Context, v: DmScope = dmScope(c)) {
        try {
            val uid = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid ?: return
            com.google.firebase.firestore.FirebaseFirestore.getInstance()
                .collection("users").document(uid)
                .set(mapOf("dmScope" to v.name), com.google.firebase.firestore.SetOptions.merge())
        } catch (_: Exception) { /* 오프라인이면 다음 실행 때 동기화 */ }
    }

    fun commentScope(c: Context): CommentScope = try {
        CommentScope.valueOf(prefs(c).getString("comment_scope", CommentScope.EVERYONE.name)!!)
    } catch (_: Exception) { CommentScope.EVERYONE }

    fun setCommentScope(c: Context, v: CommentScope) = prefs(c).edit().putString("comment_scope", v.name).apply()

    /** 프로필 비공개 (기록·경로를 친구에게만 공개) */
    fun isPrivateAccount(c: Context) = prefs(c).getBoolean("private_account", false)
    fun setPrivateAccount(c: Context, v: Boolean) {
        prefs(c).edit().putBoolean("private_account", v).apply()
        // ✅ v37 팔로우 요청 판정을 위해 서버에도 반영
        try {
            val uid = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid ?: return
            com.google.firebase.firestore.FirebaseFirestore.getInstance()
                .collection("users").document(uid)
                .set(mapOf("privateAccount" to v), com.google.firebase.firestore.SetOptions.merge())
        } catch (_: Exception) { }
    }

    /** 내 위치 기반 거리 표시 허용 (운동장에서 "3km 거리" 노출) */
    fun showDistance(c: Context) = prefs(c).getBoolean("show_distance", true)
    fun setShowDistance(c: Context, v: Boolean) = prefs(c).edit().putBoolean("show_distance", v).apply()

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
}

/**
 * DM 발송 가능 여부 판정.
 * 상대의 설정 + 차단 여부를 함께 확인해야 함.
 */
object DmGuard {
    /**
     * @return null이면 발송 가능, 문자열이면 차단 사유 (UI에 표시)
     */
    suspend fun checkCanSend(
        myUid: String,
        targetUid: String,
        targetDmScope: PrivacySettings.DmScope,
        areFriends: Boolean
    ): String? {
        // 상대가 나를 차단했으면 발송 불가
        if (FriendRepository().isBlocked(targetUid, myUid)) return "상대방에게 메시지를 보낼 수 없어요"
        // 내가 상대를 차단했으면 발송 불가 (차단해놓고 DM 보내는 건 말이 안 됨)
        if (FriendRepository().isBlocked(myUid, targetUid)) return "차단한 사용자예요. 차단을 해제해야 메시지를 보낼 수 있어요"
        return when (targetDmScope) {
            PrivacySettings.DmScope.NOBODY -> "이 사용자는 RM을 받지 않도록 설정했어요"
            PrivacySettings.DmScope.FRIENDS_ONLY ->
                if (areFriends) null else "이 사용자는 친구에게만 RM을 받아요"
            PrivacySettings.DmScope.EVERYONE -> null
        }
    }
}
