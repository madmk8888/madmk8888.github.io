package com.navifit.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import com.google.android.gms.maps.model.LatLng
import com.google.android.libraries.places.api.model.AutocompletePrediction
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.net.FetchPlaceRequest
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsRequest
import com.google.android.libraries.places.api.net.PlacesClient

/**
 * 목적지 검색창 + 실시간 관련 장소 자동완성 드롭다운.
 *
 * ✅ 검색 중엔 키보드가 멋대로 안 내려감 - 엔터(검색)를 누르거나 결과를 선택할 때만 닫힘
 * ✅ 결과가 많아도 내부 스크롤(LazyColumn, 최대 높이 제한)로 다 볼 수 있음
 * ✅ 건물명/장소명을 크고 굵게 먼저 보여주고, 주소는 아래 작은 글씨로 - 가독성 개선
 * ✅ 정렬 우선순위: ① 최근/자주 선택했던 곳 ② 내 위치에서 가까운 순(Places API origin 기반) ③ 정확도(구글 기본 관련도)
 */
@Composable
fun PlacesAutocompleteField(
    placesClient: PlacesClient,
    currentLocation: LatLngPoint?,
    onPlaceSelected: (name: String, lat: Double, lng: Double, address: String?) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var predictions by remember { mutableStateOf(listOf<AutocompletePrediction>()) }
    var expanded by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val context = LocalContext.current
    val history = remember { SearchHistoryManager.loadAll(context) }

    fun runSearch(text: String) {
        if (text.length < 2) { predictions = emptyList(); expanded = false; return }
        val builder = FindAutocompletePredictionsRequest.builder()
            .setQuery(text)
            .setCountries("KR")
        // ✅ 내 위치를 기준점(origin)으로 넘기면 구글이 거리까지 감안해서 결과를 정렬해줌
        currentLocation?.let { builder.setOrigin(LatLng(it.latitude, it.longitude)) }
        placesClient.findAutocompletePredictions(builder.build())
            .addOnSuccessListener { response ->
                // ✅ ①최근/자주 선택 이력과 이름이 겹치는 결과를 맨 위로, 나머지는 구글이 준 순서(②거리 ③정확도) 그대로 유지
                val historyNames = history.map { it.name }.toSet()
                val (recentMatches, rest) = response.autocompletePredictions.partition { pred ->
                    historyNames.any { hn -> pred.getPrimaryText(null).toString().contains(hn, true) || hn.contains(pred.getPrimaryText(null).toString(), true) }
                }
                predictions = recentMatches + rest
                expanded = predictions.isNotEmpty()
                // ✅ 키보드를 강제로 내리지 않음 - 계속 입력하며 검색어를 다듬을 수 있게
            }
            .addOnFailureListener {
                predictions = emptyList(); expanded = false
            }
    }

    Column {
        OutlinedTextField(
            value = query,
            onValueChange = { text -> query = text; runSearch(text) },
            label = { Text(com.navifit.i18n.LocalStrings.current.destinationInput) },
            placeholder = { Text("건물명, 장소명, 주소로 검색") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            // ✅ 엔터/검색 버튼을 눌러야만 키보드가 내려감 (입력 중엔 절대 안 내려감)
            keyboardActions = KeyboardActions(onSearch = {
                keyboardController?.hide()
                focusManager.clearFocus()
            })
        )

        // ===== 검색 결과: 지도 레이아웃을 자연스럽게 밀어내며 내부 스크롤 가능 (최대 높이 제한) =====
        if (expanded) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 260.dp)
                    .padding(top = 6.dp)
                    .shadow(3.dp, RoundedCornerShape(14.dp))
                    .clip(RoundedCornerShape(14.dp)),
                color = Color.White
            ) {
                LazyColumn(Modifier.fillMaxWidth()) {
                    items(predictions.take(8)) { pred ->
                        val primary = pred.getPrimaryText(null).toString()   // 건물명/장소명/별칭 (크게)
                        val secondary = pred.getSecondaryText(null).toString() // 주소/지번 등 보조정보 (작게)
                        val isRecent = history.any { hn -> hn.name.contains(primary, true) || primary.contains(hn.name, true) }
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    keyboardController?.hide()
                                    focusManager.clearFocus()
                                    val placeFields = listOf(Place.Field.LAT_LNG, Place.Field.NAME, Place.Field.ADDRESS)
                                    val req = FetchPlaceRequest.newInstance(pred.placeId, placeFields)
                                    placesClient.fetchPlace(req)
                                        .addOnSuccessListener { res ->
                                            val latLng = res.place.latLng
                                            if (latLng != null) {
                                                query = res.place.name ?: primary
                                                SearchHistoryManager.record(context, query, res.place.address, latLng.latitude, latLng.longitude)
                                                onPlaceSelected(query, latLng.latitude, latLng.longitude, res.place.address)
                                            }
                                            expanded = false
                                        }
                                }
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(if (isRecent) "🕐" else "📍", fontSize = 15.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(primary, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF3A3546), maxLines = 1)
                                if (secondary.isNotBlank()) {
                                    Spacer(Modifier.height(2.dp))
                                    Text(secondary, fontSize = 11.sp, color = Color.Gray, maxLines = 1)
                                }
                            }
                        }
                        HorizontalDivider(color = Color(0xFFF0EDF7))
                    }
                }
            }
        }
    }
}
