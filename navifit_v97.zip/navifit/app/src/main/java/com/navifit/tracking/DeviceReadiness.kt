package com.navifit.tracking

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.location.LocationManager
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings

/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  DeviceReadiness — 정확한 위치 추적을 막는 기기 설정을 진단 (v91 신규)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * 왜 만들었나:
 *  "밖인데 위치가 안 잡힌다"는 문제의 상당수는 GPS 자체가 아니라 기기 설정 때문이다.
 *  그런데 앱은 아무 말도 안 하고 조용히 실패해서, 사용자는 앱이 고장난 줄 알게 된다.
 *
 * 검사 항목 (전부 안드로이드 표준 API, 권한 불필요):
 *  1) 위치 서비스 자체가 꺼져 있음        → 시스템 설정으로 유도
 *  2) 절전 모드(Power Save)              → 위치 갱신 주기를 OS가 강제로 늘림
 *  3) 배터리 부족                        → 절전이 자동 발동되어 추적이 끊김
 *  4) 기기 과열(Thermal Throttling)      → CPU·GPS 성능 저하 (Android 10+)
 *  5) 배터리 최적화 미해제                → 백그라운드 위치 갱신 제한
 *
 * 각 항목은 "왜 문제인지 + 어떻게 고치는지"를 사람이 읽을 수 있는 문장으로 돌려준다.
 */
object DeviceReadiness {

    data class Issue(
        val id: String,
        val title: String,
        val detail: String,
        /** 눌렀을 때 열 시스템 설정 (없으면 안내만) */
        val fixIntent: Intent? = null,
        /** 심각도: true면 추적이 사실상 불가능한 수준 */
        val critical: Boolean = false
    )

    /** 지금 추적을 방해하는 문제들을 모아서 반환 (없으면 빈 목록) */
    fun check(context: Context): List<Issue> {
        val issues = mutableListOf<Issue>()

        // ── 1) 위치 서비스 on/off ──
        try {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            val gpsOn = lm?.isProviderEnabled(LocationManager.GPS_PROVIDER) == true
            val netOn = lm?.isProviderEnabled(LocationManager.NETWORK_PROVIDER) == true
            if (!gpsOn && !netOn) {
                issues += Issue(
                    id = "location_off",
                    title = "위치 서비스가 꺼져 있어요",
                    detail = "휴대폰의 위치 기능이 꺼져 있어서 운동을 기록할 수 없어요. 켜주세요.",
                    fixIntent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS),
                    critical = true
                )
            } else if (!gpsOn) {
                issues += Issue(
                    id = "gps_off",
                    title = "GPS가 꺼져 있어요",
                    detail = "네트워크 위치만 켜져 있어요. 정확한 운동 기록에는 GPS가 필요해요.",
                    fixIntent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS),
                    critical = true
                )
            }
        } catch (_: Exception) { }

        // ── 2) 절전 모드 ──
        try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            if (pm?.isPowerSaveMode == true) {
                issues += Issue(
                    id = "power_save",
                    title = "절전 모드가 켜져 있어요",
                    detail = "절전 모드에서는 안드로이드가 위치 갱신 주기를 강제로 늘려서, " +
                            "야외에서도 위치가 늦게 잡히거나 끊긴 것처럼 보일 수 있어요.",
                    fixIntent = Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS),
                    critical = false
                )
            }
        } catch (_: Exception) { }

        // ── 3) 배터리 잔량 ──
        try {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
            val level = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
            if (level in 1..15) {
                issues += Issue(
                    id = "battery_low",
                    title = "배터리가 ${level}% 남았어요",
                    detail = "장시간 운동 중 배터리가 부족해지면 절전이 자동으로 켜져 기록이 끊길 수 있어요.",
                    critical = false
                )
            }
        } catch (_: Exception) { }

        // ── 4) 기기 과열 (Android 10+) ──
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
                val thermal = pm?.currentThermalStatus ?: PowerManager.THERMAL_STATUS_NONE
                if (thermal >= PowerManager.THERMAL_STATUS_SEVERE) {
                    issues += Issue(
                        id = "thermal",
                        title = "기기가 뜨거워요",
                        detail = "과열로 성능이 제한되면 위치 정확도가 떨어져요. 직사광선을 피하고 잠시 식혀주세요.",
                        critical = false
                    )
                }
            }
        } catch (_: Exception) { }

        // ── 5) 배터리 최적화 ──
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
                if (pm?.isIgnoringBatteryOptimizations(context.packageName) == false) {
                    issues += Issue(
                        id = "battery_opt",
                        title = "배터리 최적화가 켜져 있어요",
                        detail = "이 앱이 배터리 최적화 대상이면 화면을 끈 사이 위치 갱신이 지연돼요. " +
                                "제외로 설정하면 훨씬 정확해져요.",
                        fixIntent = Intent(
                            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            android.net.Uri.parse("package:${context.packageName}")
                        ),
                        critical = false
                    )
                }
            }
        } catch (_: Exception) { }

        return issues
    }

    /** 추적이 아예 불가능한 수준의 문제만 */
    fun criticalIssues(context: Context): List<Issue> = check(context).filter { it.critical }

    /** 설정 화면 열기 (실패해도 앱이 죽지 않게) */
    fun openFix(activity: Activity, issue: Issue): Boolean {
        val intent = issue.fixIntent ?: return false
        return try {
            activity.startActivity(intent); true
        } catch (_: Exception) {
            try {
                activity.startActivity(Intent(Settings.ACTION_SETTINGS)); true
            } catch (_: Exception) { false }
        }
    }
}
