package com.navifit.moderation

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody

/**
 * ✅ v41 다국어 콘텐츠 필터.
 *
 * 기존 문제: 한국어 욕설 6개만 걸렀음. 영어·일본어·중국어 욕설, 19금 표현,
 *           스팸·사기·도박 광고가 전부 그대로 통과됐음.
 *
 * 이제: 욕설 / 성인물(19금) / 스팸·광고 / 사기·도박 / 개인정보 노출을
 *      한국어·영어·일본어·중국어·스페인어·러시아어 등에서 모두 차단.
 *
 * 우회 방어:
 *  - 자모 분리(ㅅㅂ), 특수문자 삽입(시.발, s h i t), 반복(ㅆㅂㅂㅂ), 숫자치환(f4ck) 정규화
 */
object ContentFilter {

    enum class Violation(val reason: String) {
        PROFANITY("욕설·비속어가 포함돼 있어요"),
        ADULT("성인물·음란 표현은 게시할 수 없어요"),
        SPAM("광고·홍보성 내용은 게시할 수 없어요"),
        SCAM("사기·도박·불법 거래로 의심되는 내용이에요"),
        PERSONAL_INFO("전화번호·계정 등 개인정보는 노출하지 마세요"),
        LINK("외부 링크는 게시할 수 없어요"),
        FLOOD("같은 문자를 너무 많이 반복했어요")
    }

    // ── 정규화: 우회 시도를 무력화 ──
    private fun normalize(text: String): String {
        var t = text.lowercase()
        // 숫자 치환 복원 (f4ck -> fack, sh1t -> shit)
        t = t.replace('4', 'a').replace('1', 'i').replace('0', 'o')
            .replace('3', 'e').replace('5', 's').replace('7', 't').replace('@', 'a')
        // 공백·특수문자 제거 (s h i t -> shit, 시.발 -> 시발)
        t = t.replace(Regex("[\\s._\\-*+~^!?,'\"()\\[\\]{}/\\\\|<>#$%&=]"), "")
        // 같은 글자 3회 이상 반복 → 1회로 (ㅆㅂㅂㅂ -> ㅆㅂ)
        t = Regex("(.)\\1{2,}").replace(t) { it.groupValues[1] }
        return t
    }

    // ── 욕설 (한/영/일/중/스/러) ──
    private val profanity = listOf(
        // 한국어 (자모 분리 포함)
        "씨발", "시발", "ㅅㅂ", "ㅆㅂ", "병신", "ㅄ", "ㅂㅅ", "개새끼", "새끼", "좆", "좇",
        "지랄", "미친놈", "미친년", "꺼져", "닥쳐", "엿먹", "죽어라", "並신",
        // 영어
        "fuck", "fucking", "shit", "bitch", "asshole", "bastard", "cunt", "dick",
        "motherfucker", "whore", "slut", "faggot", "nigger", "retard",
        // 일본어
        "死ね", "殺す", "ばか", "馬鹿", "くそ", "クソ", "きちがい", "アホ",
        // 중국어
        "傻逼", "操你", "混蛋", "王八蛋", "去死", "白痴",
        // 스페인어
        "puta", "mierda", "cabron", "pendejo", "joder",
        // 러시아어
        "блядь", "сука", "хуй", "пизда"
    )

    // ── 성인물 (19금) ──
    private val adult = listOf(
        // 한국어
        "야동", "야한", "섹스", "성인용품", "조건만남", "출장안마", "오피", "건마",
        "애무", "자위", "성기", "음란", "19금", "노출사진", "누드", "성매매", "콜걸",
        // 영어
        "porn", "porno", "xxx", "nude", "naked", "sex", "sexy", "escort", "hentai",
        "onlyfans", "camgirl", "blowjob", "orgasm", "masturbat", "erotic", "nsfw",
        // 일본어
        "エロ", "アダルト", "セックス", "風俗", "援交", "裸",
        // 중국어
        "色情", "裸体", "成人片", "约炮",
        // 기타
        "18+", "adultonly"
    )

    // ── 스팸·광고 ──
    private val spam = listOf(
        // 한국어
        "카톡아이디", "카톡문의", "텔레그램문의", "오픈톡", "디엠주세요", "무료체험",
        "홍보", "광고문의", "부업", "재택알바", "고수익", "일당", "월수익", "투자문의",
        "런친맞팔", "선팔", "맞팔", "구독좋아요", "이벤트참여",
        // 영어
        "freetrial", "clickhere", "buynow", "limitedoffer", "makemoney", "workfromhome",
        "earncash", "getrich", "followback", "f4f", "l4l", "subscribeme", "promocode",
        "dm me", "dmme", "telegram", "whatsapp",
        // 중국어/일본어
        "加微信", "免费领取", "副業", "稼げる"
    )

    // ── 사기·도박·불법 ──
    private val scam = listOf(
        // 한국어
        "토토", "바카라", "슬롯", "먹튀", "배팅", "베팅", "카지노", "홀덤", "사설",
        "코인리딩", "리딩방", "원금보장", "수익보장", "대출", "작업대출", "신용불량",
        "대포통장", "장기매매", "몰카", "해킹", "계정판매", "아이디판매",
        "마약", "대마", "떨", "아이스", "필로폰", "총기", "폭탄",
        // 영어
        "casino", "betting", "gambling", "guaranteedprofit", "getrichquick",
        "bitcoinpump", "pumpanddump", "hackaccount", "buyaccount", "cheapfollowers",
        "cocaine", "heroin", "weed4sale", "gunsforsale"
    )

    // ── 개인정보 ──
    private val personalInfo = listOf(
        Regex("\\d{2,3}[-.\\s]?\\d{3,4}[-.\\s]?\\d{4}"),           // 전화번호
        Regex("\\d{6}[-\\s]?[1-4]\\d{6}"),                          // 주민번호
        Regex("[\\w.]+@[\\w.]+\\.\\w{2,}"),                          // 이메일
        Regex("(?:계좌|입금|송금)\\s*\\d{6,}")                        // 계좌번호
    )

    private val linkPattern = Regex("https?://\\S+|www\\.\\S+|\\S+\\.(?:com|net|kr|jp|cn|ru|io|co)\\b", RegexOption.IGNORE_CASE)

    /**
     * 검사 실행.
     * @return null이면 통과, 값이 있으면 차단 사유
     */
    fun check(text: String, allowLinks: Boolean = false): Violation? {
        if (text.isBlank()) return null
        val norm = normalize(text)

        // 문자 도배 (ㅋㅋㅋㅋㅋㅋ... 100자)
        if (Regex("(.)\\1{15,}").containsMatchIn(text)) return Violation.FLOOD

        if (profanity.any { norm.contains(normalize(it)) }) return Violation.PROFANITY
        if (adult.any { norm.contains(normalize(it)) }) return Violation.ADULT
        if (scam.any { norm.contains(normalize(it)) }) return Violation.SCAM
        if (spam.any { norm.contains(normalize(it)) }) return Violation.SPAM
        if (personalInfo.any { it.containsMatchIn(text) }) return Violation.PERSONAL_INFO
        if (!allowLinks && linkPattern.containsMatchIn(text)) return Violation.LINK

        return null
    }

    /** 통과 여부만 (기존 isCleanText 대체) */
    fun isClean(text: String, allowLinks: Boolean = false): Boolean = check(text, allowLinks) == null

    /**
     * 차단하진 않고 마스킹 (닉네임 등에 사용).
     * 욕설을 ***로 가림.
     */
    fun mask(text: String): String {
        var out = text
        profanity.forEach { word ->
            out = Regex(Regex.escape(word), RegexOption.IGNORE_CASE).replace(out) { "*".repeat(it.value.length) }
        }
        return out
    }
}

/**
 * ✅ v42 2단계 검사 게이트.
 *
 * 1단계: ContentFilter (로컬 키워드 - 즉시, 무료, 오프라인)
 * 2단계: Perspective API (문맥 판단 - 무료, 키가 있을 때만)
 *
 * 로컬 필터가 못 잡는 교묘한 표현("너 진짜 없어져줬으면 좋겠다" 같은)을 문맥으로 잡음.
 * 키가 없거나 API가 실패하면 1단계 결과만 사용 (앱은 항상 동작).
 */
object ModerationGate {

    /**
     * @return null이면 통과, 문자열이면 차단 사유
     */
    suspend fun check(context: android.content.Context, text: String, allowLinks: Boolean = false): String? {
        // 1단계: 로컬 다국어 필터 (즉시·오프라인·무료·무제한)
        ContentFilter.check(text, allowLinks)?.let { return it.reason }

        // 2단계: 링크가 있으면 악성/피싱 검사 (Safe Browsing - 무료 일 1만건)
        //
        // ⚠️ v47: Perspective API는 2026-12-31 종료 + 2026년 2월부로 신규 가입 중단이라
        //    더 이상 발급이 불가능해서 제거했습니다.
        //    대신 OpenAI Moderation API(무료)를 쓸 수 있게 열어뒀습니다 (키 있을 때만).
        val links = Regex("https?://\\S+").findAll(text).map { it.value }.toList()
        val sKey = com.navifit.navigation.NavApiKeys.safeBrowsingKey(context)
        if (links.isNotEmpty() && !sKey.isNullOrBlank()) {
            try {
                val api = ContentModerationApi("", sKey)
                val r = api.checkPost(text)
                if (!r.isSafe) return r.reasons.joinToString(", ")
            } catch (_: Exception) { /* 실패 시 통과 - 로컬 필터가 1차 방어 */ }
        }

        // 3단계: OpenAI Moderation (선택 - 무료. 문맥 기반 판단)
        val oKey = com.navifit.navigation.NavApiKeys.openAiKey(context)
        if (!oKey.isNullOrBlank()) {
            OpenAiModeration.check(oKey, text)?.let { return it }
        }
        return null
    }

    /**
     * ✅ 첨부 사진·동영상 검열 (게시 전).
     * 사진: 그대로 이미지 검열 / 동영상: 대표 프레임 3장 추출 검열.
     * OpenAI 키가 없으면 검열 없이 통과 (로컬에서 미디어 내용 판별은 불가).
     * @return null이면 통과, 문자열이면 차단 사유
     */
    suspend fun checkMedia(context: android.content.Context, paths: List<String>): String? {
        val oKey = com.navifit.navigation.NavApiKeys.openAiKey(context)
        if (oKey.isNullOrBlank()) return null
        for (p in paths.take(5)) {   // 과도한 API 호출 방지: 앞 5개까지
            val reason = if (p.endsWith(".mp4"))
                OpenAiModeration.checkVideo(oKey, p, context)
            else OpenAiModeration.checkImage(oKey, p)
            if (reason != null) return reason
        }
        return null
    }
}

/**
 * ✅ v47 OpenAI Moderation API (Perspective 대체).
 *
 * Perspective API가 2026-12-31 종료 + 2026년 2월부로 신규 발급 중단되어 쓸 수 없게 됐습니다.
 * 대체재 중 "무료"인 것은 OpenAI Moderation 엔드포인트입니다.
 *  - 모더레이션 전용 엔드포인트는 과금되지 않음 (다른 OpenAI API와 달리 무료)
 *  - 문맥을 이해해서 키워드로 못 잡는 표현을 잡아냄
 *  - 한국어 포함 다국어 지원
 *  - 키가 없으면 이 단계는 그냥 건너뜀 (로컬 필터만으로도 동작)
 *
 * 키 발급: https://platform.openai.com/api-keys (가입 → API key 생성)
 */
object OpenAiModeration {
    private val client = okhttp3.OkHttpClient.Builder()
        .callTimeout(6, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    // 이미지 검열은 업로드 시간이 걸려 타임아웃을 넉넉히
    private val imageClient = okhttp3.OkHttpClient.Builder()
        .callTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    /**
     * ✅ 사진 검열: omni-moderation-latest는 이미지 입력을 지원함 (텍스트와 같은 무료 API).
     * 성인물·폭력·자해 이미지 등이 감지되면 차단 사유를 반환.
     * @return null이면 통과, 문자열이면 차단 사유
     */
    suspend fun checkImage(apiKey: String, imagePath: String): String? =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val file = java.io.File(imagePath)
                if (!file.exists() || file.length() > 4_000_000) return@withContext null // 4MB 초과는 스킵
                // 검열용 축소본 (긴 변 768px) - 업로드 용량·속도 최적화
                val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                android.graphics.BitmapFactory.decodeFile(imagePath, opts)
                var sample = 1
                while (maxOf(opts.outWidth, opts.outHeight) / sample > 768) sample *= 2
                val bmp = android.graphics.BitmapFactory.decodeFile(imagePath,
                    android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })
                    ?: return@withContext null
                val baos = java.io.ByteArrayOutputStream()
                bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 70, baos)
                bmp.recycle()
                val b64 = android.util.Base64.encodeToString(baos.toByteArray(), android.util.Base64.NO_WRAP)

                val input = org.json.JSONArray().put(
                    org.json.JSONObject()
                        .put("type", "image_url")
                        .put("image_url", org.json.JSONObject()
                            .put("url", "data:image/jpeg;base64,$b64"))
                )
                val body = org.json.JSONObject()
                    .put("model", "omni-moderation-latest")
                    .put("input", input)
                    .toString()
                    .toRequestBody("application/json".toMediaType())
                val req = okhttp3.Request.Builder()
                    .url("https://api.openai.com/v1/moderations")
                    .addHeader("Authorization", "Bearer $apiKey")
                    .post(body)
                    .build()
                val res = imageClient.newCall(req).execute().use { it.body?.string() } ?: return@withContext null
                val result = org.json.JSONObject(res)
                    .optJSONArray("results")?.optJSONObject(0) ?: return@withContext null
                if (!result.optBoolean("flagged", false)) return@withContext null
                val cats = result.optJSONObject("categories")
                when {
                    cats?.optBoolean("sexual/minors") == true -> "아동 관련 이미지가 감지되어 게시할 수 없어요"
                    cats?.optBoolean("sexual") == true -> "성인물 이미지는 게시할 수 없어요"
                    cats?.optBoolean("violence/graphic") == true -> "잔혹한 이미지는 게시할 수 없어요"
                    cats?.optBoolean("self-harm") == true -> "자해 관련 이미지가 감지됐어요"
                    else -> "부적절한 이미지가 감지되어 게시할 수 없어요"
                }
            } catch (_: Exception) { null }  // 실패 시 통과 (가용성 우선)
        }

    /**
     * ✅ 동영상 검열: 대표 프레임 3장(시작·중간·끝)을 뽑아 이미지 검열과 같은 API로 검사.
     * (풀 영상 검사는 별도 유료 인프라가 필요해서, 프레임 샘플링 방식이 무료로 가능한 현실적 방법)
     */
    suspend fun checkVideo(apiKey: String, videoPath: String, context: android.content.Context): String? =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val mmr = android.media.MediaMetadataRetriever()
                mmr.setDataSource(videoPath)
                val durUs = (mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull() ?: 0L) * 1000L
                val stamps = listOf(durUs / 10, durUs / 2, durUs * 9 / 10)
                for (t in stamps) {
                    val frame = mmr.getFrameAtTime(t, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                        ?: continue
                    val tmp = java.io.File(context.cacheDir, "mod_frame.jpg")
                    java.io.FileOutputStream(tmp).use { out ->
                        frame.compress(android.graphics.Bitmap.CompressFormat.JPEG, 70, out)
                    }
                    frame.recycle()
                    val reason = checkImage(apiKey, tmp.absolutePath)
                    tmp.delete()
                    if (reason != null) { mmr.release(); return@withContext "동영상: $reason" }
                }
                mmr.release()
                null
            } catch (_: Exception) { null }
        }

    /** @return null이면 통과, 문자열이면 차단 사유 */
    suspend fun check(apiKey: String, text: String): String? =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val body = org.json.JSONObject()
                    .put("model", "omni-moderation-latest")
                    .put("input", text)
                    .toString()
                    .toRequestBody("application/json".toMediaType())

                val req = okhttp3.Request.Builder()
                    .url("https://api.openai.com/v1/moderations")
                    .addHeader("Authorization", "Bearer $apiKey")
                    .post(body)
                    .build()

                val res = client.newCall(req).execute().use { it.body?.string() } ?: return@withContext null
                val result = org.json.JSONObject(res)
                    .optJSONArray("results")?.optJSONObject(0) ?: return@withContext null

                if (!result.optBoolean("flagged", false)) return@withContext null

                val cats = result.optJSONObject("categories") ?: return@withContext "부적절한 내용이 감지됐어요"
                val reason = when {
                    cats.optBoolean("sexual/minors") -> "아동 관련 성적 표현은 절대 허용되지 않아요"
                    cats.optBoolean("sexual") -> "성적인 표현은 게시할 수 없어요"
                    cats.optBoolean("hate") || cats.optBoolean("hate/threatening") -> "혐오 표현은 게시할 수 없어요"
                    cats.optBoolean("harassment") || cats.optBoolean("harassment/threatening") -> "괴롭힘·위협 표현은 게시할 수 없어요"
                    cats.optBoolean("violence") || cats.optBoolean("violence/graphic") -> "폭력적인 표현은 게시할 수 없어요"
                    cats.optBoolean("self-harm") -> "자해 관련 표현이 감지됐어요"
                    cats.optBoolean("illicit") -> "불법 행위 관련 내용은 게시할 수 없어요"
                    else -> "커뮤니티 정책에 어긋나는 내용이에요"
                }
                reason
            } catch (_: Exception) {
                null   // 실패 시 통과 (로컬 필터가 이미 1차 방어선)
            }
        }
}
