package com.navifit.tracking

import android.content.Context
import com.navifit.data.ActivityRecord
import com.navifit.navigation.TravelMode

/**
 * 누적 안전점수 "초기화" 관리자.
 *
 * 실제 기록(ActivityRecord)을 지우지는 않고, "이 시점 이후 기록만 누적 통계에 반영"하는
 * 기준시각(baseline)만 저장하는 방식 - 기록 자체는 개인 히스토리로 안전하게 보존됨.
 * 오토바이/자동차 각각 독립적으로 초기화 가능.
 */
object SafetyResetManager {
    private const val PREFS = "safety_reset_prefs"
    private fun key(mode: TravelMode) = "baseline_${mode.name}"

    fun getBaseline(context: Context, mode: TravelMode): Long =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong(key(mode), 0L)

    fun resetNow(context: Context, mode: TravelMode) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putLong(key(mode), System.currentTimeMillis()).apply()
    }

    /** 초기화 기준시각 이후의 기록만 걸러서 반환 - 누적 안전점수 계산에 사용 */
    fun filterSinceReset(context: Context, mode: TravelMode, records: List<ActivityRecord>): List<ActivityRecord> {
        val baseline = getBaseline(context, mode)
        return records.filter { it.mode == mode && it.startTimeMillis >= baseline }
    }
}
