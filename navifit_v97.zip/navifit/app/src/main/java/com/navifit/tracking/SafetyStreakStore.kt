package com.navifit.tracking

import android.content.Context

/**
 * ✅ v32: 안전점수 100점 연속 유지 일수 추적 (무결점 드라이버 테두리 - 30일 조건).
 * 주행 기록이 저장될 때마다 그날의 최저 안전점수를 기록.
 * - 그날 100점이면 streak +1, 100점 미만이면 streak 0으로 리셋
 * - 주행 안 한 날은 streak 유지 (운전 안 했다고 깎이지 않음)
 */
object SafetyStreakStore {
    private const val PREF = "safety_streak"

    fun onRecordSaved(context: Context, safetyScore: Int, isDrivingMode: Boolean) {
        if (!isDrivingMode) return
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val today = todayKey()
        val lastDay = p.getString("last_day", "")
        val todayMin = if (lastDay == today) minOf(p.getInt("today_min", 100), safetyScore) else safetyScore

        var streak = p.getInt("streak", 0)
        if (lastDay != today) {
            // 새 날 시작: 어제까지의 결과를 streak에 반영
            val prevMin = p.getInt("today_min", 100)
            if (!lastDay.isNullOrEmpty()) {
                streak = if (prevMin >= 100) streak + 1 else 0
            }
        }
        p.edit()
            .putString("last_day", today)
            .putInt("today_min", todayMin)
            .putInt("streak", streak)
            .apply()
    }

    /** 현재 연속 100점 유지 일수 (오늘까지 100점이면 오늘도 포함) */
    fun currentStreakDays(context: Context): Int {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val streak = p.getInt("streak", 0)
        val todayMin = p.getInt("today_min", 100)
        val hasToday = p.getString("last_day", "") == todayKey()
        return if (hasToday && todayMin >= 100) streak + 1 else streak
    }

    private fun todayKey(): String {
        val c = java.util.Calendar.getInstance()
        return "%04d-%02d-%02d".format(
            c.get(java.util.Calendar.YEAR),
            c.get(java.util.Calendar.MONTH) + 1,
            c.get(java.util.Calendar.DAY_OF_MONTH)
        )
    }
}
