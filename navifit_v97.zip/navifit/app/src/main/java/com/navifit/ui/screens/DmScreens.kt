package com.navifit.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.navifit.i18n.tr
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.navifit.social.DirectMessage
import com.navifit.social.DmRepository
import com.navifit.social.DmThread
import com.navifit.social.FriendRepository
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

/**
 * RM(러닝 메시지) 받은편지함 - 인스타그램 DM 목록과 동일한 레이아웃
 * (프로필원 + 마지막 메시지 미리보기 + 시간 + 안읽음 점)
 */
@Composable
fun DmInboxScreen(
    myUid: String,
    dmRepo: DmRepository,
    onOpenThread: (otherUid: String, otherNickname: String) -> Unit,
    onOpenFriends: () -> Unit,
    onBack: () -> Unit,
    onOpenGroupRoom: (roomId: String) -> Unit = {}   // ✅ v81 단체 대화방
) {
    val rawThreads by dmRepo.observeThreads(myUid).collectAsState(initial = emptyList())
    // ✅ v58 RM 테스트용: 대화방이 없을 때 데모 3개 표시 (탭하면 대화 화면으로 들어가짐)
    val allThreads = remember(rawThreads) {
        if (rawThreads.isNotEmpty()) rawThreads else listOf(
            DmThread("demo_rm_1", "같이뛰는친구", "내일 아침 한강 러닝 어때요?", System.currentTimeMillis() - 120_000, unread = true, isRequest = false),
            DmThread("demo_rm_2", "새벽러너", "코스 공유 고마워요! 🔑", System.currentTimeMillis() - 3_600_000, unread = false, isRequest = false),
            DmThread("demo_rm_3", "낯선러너99", "안녕하세요 런친했어요", System.currentTimeMillis() - 7_200_000, unread = true, isRequest = true)
        )
    }
    // ✅ v36 DM 요청함: 친구가 아닌 사람의 DM은 별도 탭으로 분리 (스팸·괴롭힘 차단)
    var showRequests by remember { mutableStateOf(false) }
    val normalThreads = allThreads.filter { !it.isRequest }
    val requestThreads = allThreads.filter { it.isRequest }
    val threads = if (showRequests) requestThreads else normalThreads
    val scope = rememberCoroutineScope()
    // ✅ v81 RM 단체 대화방
    val rmCtx = LocalContext.current
    var showGroups by remember { mutableStateOf(false) }
    var groupRooms by remember { mutableStateOf(com.navifit.social.GroupRoomStore.list(rmCtx)) }
    var showCreateGroup by remember { mutableStateOf(false) }
    var renameRoomTarget by remember { mutableStateOf<com.navifit.social.GroupRoomStore.Room?>(null) }

    if (showCreateGroup) {
        var roomName by remember { mutableStateOf("") }
        val candidates = remember(allThreads) { allThreads.map { it.otherUid to it.otherNickname } }
        val picked = remember { mutableStateListOf<String>() }
        AlertDialog(
            onDismissRequest = { showCreateGroup = false },
            title = { Text("단체 대화방 만들기") },
            text = {
                Column {
                    OutlinedTextField(
                        value = roomName, onValueChange = { roomName = it.take(24) },
                        label = { Text("방 이름 (예: 한강 러닝크루)") }, singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("참여할 친구 선택", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    candidates.forEach { (uid, nick) ->
                        val sel = uid in picked
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                if (sel) picked.remove(uid) else picked.add(uid)
                            }.padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(if (sel) "☑" else "☐", fontSize = 16.sp)
                            Spacer(Modifier.width(8.dp))
                            Text(nick, fontSize = 14.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = picked.isNotEmpty(),
                    onClick = {
                        val members = candidates.filter { it.first in picked }
                            .map { com.navifit.social.GroupRoomStore.Member(it.first, it.second) }
                        com.navifit.social.GroupRoomStore.create(rmCtx, roomName, members)
                        groupRooms = com.navifit.social.GroupRoomStore.list(rmCtx)
                        showCreateGroup = false
                        showGroups = true
                    }
                ) { Text("만들기") }
            },
            dismissButton = { TextButton(onClick = { showCreateGroup = false }) { Text("취소") } }
        )
    }

    renameRoomTarget?.let { room ->
        var newName by remember(room.id) { mutableStateOf(room.name) }
        AlertDialog(
            onDismissRequest = { renameRoomTarget = null },
            title = { Text("방 이름 변경") },
            text = {
                OutlinedTextField(
                    value = newName, onValueChange = { newName = it.take(24) },
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    com.navifit.social.GroupRoomStore.rename(rmCtx, room.id, newName)
                    groupRooms = com.navifit.social.GroupRoomStore.list(rmCtx)
                    renameRoomTarget = null
                }) { Text("저장") }
            },
            dismissButton = { TextButton(onClick = { renameRoomTarget = null }) { Text("취소") } }
        )
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("←", fontSize = 20.sp, modifier = Modifier.clickable(onClick = onBack).padding(end = 12.dp))
            Text("RM", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
            Text(tr("👥 친구"), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF8B9FFF),
                modifier = Modifier.clickable(onClick = onOpenFriends).padding(6.dp))
        }
        // ✅ v36 탭: 받은 RM / 요청함 / v81 단체방
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !showRequests && !showGroups, onClick = { showRequests = false; showGroups = false },
                label = { Text("받은 RM (${normalThreads.size})", fontSize = 12.sp) })
            FilterChip(selected = showRequests && !showGroups, onClick = { showRequests = true; showGroups = false },
                label = {
                    Text(
                        if (requestThreads.isNotEmpty()) "요청함 ${requestThreads.size} 🔴" else "요청함",
                        fontSize = 12.sp
                    )
                })
            FilterChip(selected = showGroups, onClick = { showGroups = true; showRequests = false },
                label = { Text("👥 단체방 (${groupRooms.size})", fontSize = 12.sp) })
        }

        // ✅ v81 단체 대화방 목록
        if (showGroups) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                Button(onClick = { showCreateGroup = true }, modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)) {
                    Text("➕ 단체 대화방 만들기", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
            if (groupRooms.isEmpty()) {
                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center) {
                    Text("👥", fontSize = 40.sp)
                    Text("아직 단체방이 없어요", color = Color.Gray, fontSize = 13.sp)
                    Text("친구들과 함께 뛸 방을 만들어보세요", color = Color.Gray, fontSize = 11.sp)
                }
            } else {
                LazyColumn {
                    items(groupRooms, key = { it.id }) { room ->
                        Row(
                            Modifier.fillMaxWidth()
                                .clickable { onOpenGroupRoom(room.id) }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier.size(48.dp).clip(CircleShape)
                                    .background(Brush.sweepGradient(listOf(Color(0xFF8B9FFF), Color(0xFF34D399), Color(0xFF8B9FFF)))),
                                contentAlignment = Alignment.Center
                            ) { Text("👥", fontSize = 20.sp) }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(room.name, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                                Text("${room.members.size + 1}명 · ${room.lastMessage}",
                                    fontSize = 12.sp, color = Color.Gray, maxLines = 1)
                            }
                            Text("🏷️", fontSize = 15.sp,
                                modifier = Modifier.clickable { renameRoomTarget = room }.padding(6.dp))
                        }
                    }
                }
            }
            return@Column
        }
        if (showRequests && requestThreads.isNotEmpty()) {
            Text(tr("모르는 사람이 보낸 메시지예요. 수락하면 받은 RM으로 이동해요"),
                fontSize = 10.sp, color = Color.Gray, modifier = Modifier.padding(horizontal = 16.dp))
        }
        if (threads.isEmpty()) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("✉️", fontSize = 40.sp)
                Text(tr("아직 대화가 없어요"), color = Color.Gray, fontSize = 13.sp)
                Text(tr("친구를 추가하거나 커뮤니티에서 RM을 보내보세요"), color = Color.Gray, fontSize = 11.sp)
            }
            return@Column
        }
        LazyColumn {
            items(threads) { t ->
                var confirmDelete by remember(t.otherUid) { mutableStateOf(false) }
                Row(
                    Modifier.fillMaxWidth().clickable { onOpenThread(t.otherUid, t.otherNickname) }
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(48.dp).clip(CircleShape)
                            .background(Brush.sweepGradient(listOf(Color(0xFFFF8FA3), Color(0xFFC9A5F5), Color(0xFF8B9FFF), Color(0xFFFF8FA3)))),
                        contentAlignment = Alignment.Center
                    ) { Text("🏃", fontSize = 20.sp) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(t.otherNickname, fontWeight = if (t.unread) FontWeight.ExtraBold else FontWeight.Medium, fontSize = 14.sp)
                        Text(t.lastMessage, fontSize = 12.sp, color = if (t.unread) Color(0xFFEDEAF4) else Color.Gray, maxLines = 1)
                    }
                    // ✅ v36 요청함: 수락/삭제 버튼
                    if (t.isRequest) {
                        TextButton(onClick = {
                            scope.launch { dmRepo.acceptRequest(myUid, t.otherUid) }
                        }) { Text(tr("수락"), fontSize = 12.sp, color = Color(0xFF7EDDB8)) }
                        TextButton(onClick = { confirmDelete = true }) {
                            Text(tr("삭제"), fontSize = 12.sp, color = Color(0xFFFF8FA3))
                        }
                    } else {
                        if (t.unread) Box(Modifier.size(9.dp).clip(CircleShape).background(Color(0xFFFF1744)))
                        Text("🗑️", fontSize = 13.sp,
                            modifier = Modifier.clickable { confirmDelete = true }.padding(start = 8.dp, top = 4.dp, bottom = 4.dp))
                    }
                }
                // ✅ 삭제 전 확인 창: "삭제하시겠습니까?"
                if (confirmDelete) {
                    AlertDialog(
                        onDismissRequest = { confirmDelete = false },
                        title = { Text(if (t.isRequest) "요청 삭제" else "대화 삭제") },
                        text = { Text("${t.otherNickname}님과의 ${if (t.isRequest) "메시지 요청을" else "대화를"} 삭제하시겠습니까?\n내 목록에서만 사라지고 되돌릴 수 없어요.", fontSize = 13.sp) },
                        confirmButton = {
                            TextButton(onClick = {
                                confirmDelete = false
                                scope.launch { dmRepo.deleteThread(myUid, t.otherUid) }
                            }) { Text("삭제", color = Color(0xFFFF8FA3)) }
                        },
                        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("취소") } }
                    )
                }
            }
        }
    }
}

/**
 * RM(러닝 메시지) 1:1 채팅 화면 - 내 메시지는 그라데이션 말풍선으로 오른쪽, 상대는 흰색으로 왼쪽 (인스타 DM 스타일)
 * - 사진 첨부 가능, 차단 기능 포함
 * ⚠️ 사진은 현재 기기 로컬 저장 기반 미리보기예요. 실제로 상대 기기까지 사진이 전송되려면
 *    Firebase Storage 연동이 추가로 필요해요 (텍스트는 Firestore로 실시간 동기화됨).
 */
@Composable
fun DmChatScreen(
    myUid: String,
    myNickname: String,
    otherUid: String,
    otherNickname: String,
    dmRepo: DmRepository,
    friendRepo: FriendRepository,
    onBack: () -> Unit
) {
    // ✅ v81 데모 상대(demo_*)는 Firebase를 타지 않고 로컬 대화로 처리.
    //    (친구 목록의 예시 친구를 눌렀을 때 서버 호출이 예외를 던져 앱이 꺼지던 문제 해결)
    val isDemoPeer = otherUid.startsWith("demo_")
    val demoMessages = remember(otherUid) {
        mutableStateListOf(
            DirectMessage("d1", otherUid, otherNickname, "안녕하세요! 오늘 같이 뛰어요 🏃",
                null, System.currentTimeMillis() - 600_000, null),
            DirectMessage("d2", myUid, myNickname, "좋아요! 몇 시에 만날까요?",
                null, System.currentTimeMillis() - 540_000, null)
        )
    }
    val realMessages by (if (isDemoPeer) kotlinx.coroutines.flow.flowOf(emptyList())
                         else dmRepo.observeMessages(myUid, otherUid)).collectAsState(initial = emptyList())
    val messages = if (isDemoPeer) demoMessages.toList() else realMessages
    // ✅ v36 읽음 표시: 상대가 내 메시지를 읽었는지
    val otherRead by (if (isDemoPeer) kotlinx.coroutines.flow.flowOf(true)
                      else dmRepo.observeReadState(myUid, otherUid)).collectAsState(initial = false)
    var draft by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var isBlocked by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }

    // ✅ v81 RM 대화 진입 시 앱이 꺼지던 문제:
    //   uid가 비어있거나(로그인 전) 서버 호출이 예외를 던지면 컴포지션이 통째로 죽었음.
    //   → 전부 try-catch로 감싸고, uid 없으면 안내 화면만 보여준다.
    if (myUid.isBlank() || otherUid.isBlank()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("←", fontSize = 20.sp, modifier = Modifier.clickable(onClick = onBack).padding(end = 12.dp))
                Text(otherNickname.ifBlank { "RM" }, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
            }
            Text("로그인 후에 RM을 주고받을 수 있어요.",
                fontSize = 13.sp, color = Color(0xFF8B93AC), modifier = Modifier.padding(16.dp))
        }
        return
    }

    LaunchedEffect(Unit) {
        if (isDemoPeer) return@LaunchedEffect
        try { dmRepo.markRead(myUid, otherUid) } catch (_: Exception) {}
        isBlocked = try { friendRepo.isBlockedEitherWay(myUid, otherUid) } catch (_: Exception) { false }
    }

    fun copyToInternal(uri: Uri): String? = try {
        val dir = File(context.filesDir, "rm_media").apply { mkdirs() }
        val outFile = File(dir, "rm_${System.currentTimeMillis()}.jpg")
        context.contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(outFile).use { it2 -> input.copyTo(it2) } }
        outFile.absolutePath
    } catch (e: Exception) { null }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { path ->
            copyToInternal(path)?.let {
                scope.launch {
                    if (isDemoPeer) demoMessages.add(
                        DirectMessage("d${System.currentTimeMillis()}", myUid, myNickname,
                            "📷 사진을 보냈어요", it, System.currentTimeMillis(), null))
                    else try {
                        dmRepo.send(myUid, myNickname, otherUid, otherNickname, "📷 사진을 보냈어요", mediaPath = it, friendRepo = friendRepo)
                    } catch (_: Exception) {}
                }
            }
        }
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("←", fontSize = 20.sp, modifier = Modifier.clickable(onClick = onBack).padding(end = 12.dp))
            Text(otherNickname, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, modifier = Modifier.weight(1f))
            Box {
                Text("⋮", fontSize = 20.sp, modifier = Modifier.clickable { showMenu = true }.padding(8.dp))
                DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                    if (isBlocked) {
                        DropdownMenuItem(text = { Text(tr("차단 해제")) }, onClick = {
                            showMenu = false
                            scope.launch { friendRepo.unblock(myUid, otherUid); isBlocked = false }
                        })
                    } else {
                        DropdownMenuItem(text = { Text(tr("🚫 차단하기"), color = Color(0xFFFF8FA3)) }, onClick = {
                            showMenu = false
                            scope.launch { friendRepo.block(myUid, otherUid); isBlocked = true }
                        })
                    }
                }
            }
        }

        if (isBlocked) {
            Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF0F3)), shape = RoundedCornerShape(12.dp)) {
                    Text(tr("🚫 차단된 상대예요. 메시지를 주고받을 수 없어요."), fontSize = 12.sp, color = Color(0xFFE05A78), modifier = Modifier.padding(12.dp))
                }
            }
        }

        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), reverseLayout = true) {
            itemsIndexed(messages.reversed()) { idx, m ->
                val mine = m.senderUid == myUid
                // ✅ v41 RM 번역: 상대 메시지가 다른 언어면 번역 버튼
                val myLangCode = com.navifit.i18n.LanguageStore.current(context).code
                var mTranslated by remember(m.id) { mutableStateOf<String?>(null) }
                // ✅ v42 lang 없는 옛 메시지도 자동 감지
                var mLang by remember(m.id) { mutableStateOf(m.lang) }
                LaunchedEffect(m.id) {
                    if (mLang == null && m.text.isNotBlank() && m.senderUid != myUid) {
                        mLang = com.navifit.i18n.TranslationService.detectLanguage(m.text)
                    }
                }
                // ✅ v36 읽음 표시: 내 마지막 메시지 아래에만 표시
                val isMyLast = mine && idx == 0
                if (isMyLast && otherRead) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        Text(tr("읽음"), fontSize = 9.sp, color = Color(0xFF7EDDB8),
                            modifier = Modifier.padding(end = 4.dp, top = 2.dp))
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 3.dp),
                    horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start
                ) {
                    Box(
                        Modifier
                            .widthIn(max = 260.dp)
                            .clip(RoundedCornerShape(
                                topStart = 16.dp, topEnd = 16.dp,
                                bottomStart = if (mine) 16.dp else 4.dp, bottomEnd = if (mine) 4.dp else 16.dp
                            ))
                            .background(
                                if (mine) Brush.linearGradient(listOf(Color(0xFF8B9FFF), Color(0xFFC9A5F5)))
                                else Brush.linearGradient(listOf(Color(0xFF2A2635), Color(0xFF2A2635)))
                            )
                    ) {
                        if (m.mediaPath != null) {
                            AsyncImage(
                                model = File(m.mediaPath), contentDescription = null,
                                modifier = Modifier.size(180.dp).clip(RoundedCornerShape(14.dp)).padding(4.dp)
                            )
                        } else {
                            Text(mTranslated ?: m.text, fontSize = 14.sp, color = if (mine) Color.White else Color(0xFFEDEAF4),
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp))
                        }
                    }
                }
                // ✅ v41 상대 메시지가 다른 언어면 [🌐 번역] 표시
                if (!mine && mLang != null && mLang != myLangCode && m.text.isNotBlank()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                        Text(
                            if (mTranslated != null) com.navifit.i18n.UiText.get("translate_original", myLangCode)
                            else com.navifit.i18n.UiText.get("translate_show", myLangCode),
                            fontSize = 10.sp, color = Color(0xFF64B5FF), fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(start = 8.dp, bottom = 2.dp).clickable {
                                if (mTranslated != null) mTranslated = null
                                else scope.launch {
                                    mTranslated = com.navifit.i18n.TranslationService.translate(m.text, mLang, myLangCode)
                                }
                            }
                        )
                    }
                }
            }
        }
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("📷", fontSize = 20.sp, modifier = Modifier
                .clickable(enabled = !isBlocked) { pickImage.launch("image/*") }
                .padding(8.dp))
            OutlinedTextField(
                value = draft, onValueChange = { draft = it },
                placeholder = { Text(tr("메시지 보내기...")) },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(22.dp),
                singleLine = true,
                enabled = !isBlocked
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(
                enabled = !isBlocked,
                onClick = {
                    if (draft.isBlank()) return@FilledIconButton
                    val text = draft; draft = ""
                    // ✅ v42 RM: 로컬 필터 + Perspective 문맥 검사 통과 후에만 전송
                    val myLangCode = com.navifit.i18n.LanguageStore.current(context).code
                    scope.launch {
                        val reason = com.navifit.moderation.ModerationGate.check(context, text)
                        if (reason != null) {
                            android.widget.Toast.makeText(context, reason, android.widget.Toast.LENGTH_SHORT).show()
                        } else if (isDemoPeer) {
                            // ✅ v81 예시 친구와의 대화는 로컬에만 쌓임 (서버 호출 없음 = 크래시 없음)
                            demoMessages.add(
                                DirectMessage("d${System.currentTimeMillis()}", myUid, myNickname,
                                    text, null, System.currentTimeMillis(), myLangCode)
                            )
                        } else {
                            try {
                                dmRepo.send(myUid, myNickname, otherUid, otherNickname, text, friendRepo = friendRepo, lang = myLangCode)
                            } catch (_: Exception) {
                                android.widget.Toast.makeText(context, "전송에 실패했어요. 잠시 후 다시 시도해주세요", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                },
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFF8B9FFF))
            ) { Text("➤", color = Color.White) }
        }
    }
}

/**
 * ✅ v81 RM 단체 대화방 화면.
 *  방 이름 변경(🏷️), 참여자 보기, 메시지 주고받기.
 */
@Composable
fun GroupRoomScreen(
    roomId: String,
    myUid: String,
    myNickname: String,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    var room by remember(roomId) { mutableStateOf(com.navifit.social.GroupRoomStore.get(ctx, roomId)) }
    var draft by remember { mutableStateOf("") }
    var showRename by remember { mutableStateOf(false) }
    var showMembers by remember { mutableStateOf(false) }

    val r = room
    if (r == null) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("←", fontSize = 20.sp, modifier = Modifier.clickable(onClick = onBack).padding(end = 12.dp))
                Text("단체방", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
            }
            Text("방을 찾을 수 없어요.", fontSize = 13.sp, color = Color(0xFF8B93AC),
                modifier = Modifier.padding(16.dp))
        }
        return
    }

    if (showRename) {
        var newName by remember { mutableStateOf(r.name) }
        AlertDialog(
            onDismissRequest = { showRename = false },
            title = { Text("방 이름 변경") },
            text = {
                OutlinedTextField(value = newName, onValueChange = { newName = it.take(24) },
                    singleLine = true, modifier = Modifier.fillMaxWidth())
            },
            confirmButton = {
                TextButton(onClick = {
                    com.navifit.social.GroupRoomStore.rename(ctx, r.id, newName)
                    room = com.navifit.social.GroupRoomStore.get(ctx, r.id)
                    showRename = false
                }) { Text("저장") }
            },
            dismissButton = { TextButton(onClick = { showRename = false }) { Text("취소") } }
        )
    }

    if (showMembers) {
        AlertDialog(
            onDismissRequest = { showMembers = false },
            title = { Text("참여자 ${r.members.size + 1}명") },
            text = {
                Column {
                    Text("• $myNickname (나)", fontSize = 14.sp, modifier = Modifier.padding(vertical = 4.dp))
                    r.members.forEach { m ->
                        Text("• ${m.nickname}", fontSize = 14.sp, modifier = Modifier.padding(vertical = 4.dp))
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showMembers = false }) { Text("닫기") } }
        )
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("←", fontSize = 20.sp, modifier = Modifier.clickable(onClick = onBack).padding(end = 12.dp))
            Column(Modifier.weight(1f)) {
                Text(r.name, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                Text("${r.members.size + 1}명 참여중", fontSize = 11.sp, color = Color(0xFF8B93AC),
                    modifier = Modifier.clickable { showMembers = true })
            }
            Text("🏷️", fontSize = 18.sp, modifier = Modifier.clickable { showRename = true }.padding(6.dp))
        }
        HorizontalDivider(color = Color(0x22888888))

        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            if (r.messages.isEmpty()) {
                item {
                    Column(Modifier.fillMaxWidth().padding(top = 60.dp),
                        horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("👥", fontSize = 40.sp)
                        Text("첫 메시지를 보내보세요", color = Color.Gray, fontSize = 13.sp)
                    }
                }
            }
            items(r.messages.size) { i ->
                val m = r.messages[i]
                val mine = m.senderUid == myUid
                Column(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalAlignment = if (mine) Alignment.End else Alignment.Start
                ) {
                    if (!mine) Text(m.senderName, fontSize = 10.sp, color = Color(0xFF8B93AC))
                    Box(
                        Modifier
                            .background(
                                if (mine) Color(0xFF3B82F6) else MaterialTheme.colorScheme.surfaceVariant,
                                RoundedCornerShape(14.dp)
                            )
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(m.text, fontSize = 14.sp,
                            color = if (mine) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = draft, onValueChange = { draft = it },
                placeholder = { Text("메시지 입력", fontSize = 13.sp) },
                modifier = Modifier.weight(1f), shape = RoundedCornerShape(20.dp), maxLines = 3
            )
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = {
                    if (draft.isBlank()) return@Button
                    com.navifit.social.GroupRoomStore.send(ctx, r.id, myUid, myNickname, draft)
                    room = com.navifit.social.GroupRoomStore.get(ctx, r.id)
                    draft = ""
                },
                shape = CircleShape, contentPadding = PaddingValues(14.dp)
            ) { Text("↑", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold) }
        }
    }
}
