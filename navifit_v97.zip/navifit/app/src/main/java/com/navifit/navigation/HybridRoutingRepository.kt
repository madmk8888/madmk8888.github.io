package com.navifit.navigation

import kotlinx.coroutines.delay
import com.navifit.ui.screens.encodeTravelPolyline

/**
 * 경로 계산 통합 창구: OpenRouteService(무료, 항상 접속가능) 먼저 시도하고,
 * 실패하면(요청한도 초과, 서버 문제 등) 자동으로 구글로 넘어감.
 *
 * ✅ 목적지가 건물 한가운데처럼 도로에서 멀리 떨어진 경우나, 일시적인 네트워크 문제로
 *    경로가 안 뜨는 경우를 대비해 각 제공자마다 최대 2~3회 재시도 후 다음 제공자로 넘어감
 *    (한 번 실패했다고 바로 포기하지 않고, 빨간 경로선이 확실히 뜨도록 보강)
 */
class HybridRoutingRepository(
    private val ors: OrsRepository,
    private val googleFallback: GoogleFallbackRepository,
    private val kakao: KakaoRoutingRepository? = null,   // ✅ v29: 키 있으면 최우선 (국내 실시간 교통 최강)
    private val appContext: android.content.Context? = null   // ✅ v76 운동 경로옵션 로드용
) {
    private fun wpref() = appContext?.let { WorkoutRoutePreference.load(it) } ?: WorkoutRoutePreference.SHORTEST_TIME

    suspend fun fetchRoute(
        origin: LatLngPoint,
        destination: LatLngPoint,
        mode: TravelMode,
        preference: RoutePreference = RoutePreference.FAST
    ): Result<RouteResult> {
        val orsResult = fetchWithRetry { ors.fetchRoute(origin, destination, mode, preference, wpref()) }
        if (orsResult.isSuccess) return orsResult

        // ORS가 재시도까지 다 실패 -> 구글로 자동 전환 (역시 재시도 포함)
        return fetchWithRetry { googleFallback.fetchRoute(origin, destination, mode, preference) }
    }

    /**
     * ✅ v27: 실시간 교통 반영 + 대체경로 목록.
     * 반환 리스트 [0] = 실시간 교통 기준 최적경로, 나머지 = 대체경로(지도에 회색으로 표시).
     *
     * 자동차/오토바이: 구글 우선 (departure_time=now 교통 반영 + alternatives)
     *                  구글 실패 시 ORS 단일 경로로 폴백 (교통 미반영이지만 안내는 계속됨)
     * 도보/자전거: 교통 개념이 없으므로 기존 ORS 우선 유지.
     */
    suspend fun fetchRoutesWithTraffic(
        origin: LatLngPoint,
        destination: LatLngPoint,
        mode: TravelMode,
        preference: RoutePreference = RoutePreference.FAST
    ): Result<List<RouteResult>> {
        if (!mode.isWorkoutMode) {
            // ✅ v29 우선순위: 카카오(무료 쿼터, 국내 실시간 교통 반영) → 구글(교통 반영) → ORS(교통 미반영)
            if (kakao?.hasKey() == true) {
                val k = fetchListWithRetry { kakao.fetchRoutes(origin, destination, mode, preference) }
                if (k.isSuccess) return k
            }
            val g = fetchListWithRetry { googleFallback.fetchRoutes(origin, destination, mode, preference, alternatives = true) }
            if (g.isSuccess) return g
            val o = fetchWithRetry { ors.fetchRoute(origin, destination, mode, preference, wpref()) }
            return o.map { listOf(it) }
        }
        // 운동 모드: ORS 우선
        val o = fetchWithRetry { ors.fetchRoute(origin, destination, mode, preference, wpref()) }
        if (o.isSuccess) return o.map { listOf(it) }
        val g2 = fetchListWithRetry { googleFallback.fetchRoutes(origin, destination, mode, preference, alternatives = true) }
        if (g2.isSuccess) return g2
        // ✅ 최후 폴백: 모든 API가 실패해도 "길찾기가 아예 안 되는" 상황은 없도록
        //    출발지→목적지 직선 경로라도 만들어 안내를 시작할 수 있게 함
        return Result.success(listOf(straightLineRoute(origin, destination, mode)))
    }

    /** 모든 경로 API 실패 시 직선 경로 생성 (거리·시간은 직선 기준 추정치) */
    private fun straightLineRoute(origin: LatLngPoint, destination: LatLngPoint, mode: TravelMode): RouteResult {
        val dist = NavigationProgressCalculator.fastDistanceMeters(origin, destination)
        val speedMs = when (mode) {
            TravelMode.WALK -> 1.25; TravelMode.BIKE -> 4.7; else -> 11.1
        }
        val pts = (0..20).map { i ->
            val t = i / 20.0
            LatLngPoint(
                origin.latitude + (destination.latitude - origin.latitude) * t,
                origin.longitude + (destination.longitude - origin.longitude) * t
            )
        }
        return RouteResult(
            steps = listOf(
                RouteStep(
                    instruction = "⚠️ 경로 서버 연결 실패 - 목적지 방향 직선 안내 중",
                    distanceMeters = dist.toInt(), durationSeconds = (dist / speedMs).toInt(),
                    startLocation = origin, endLocation = destination, maneuver = "straight"
                )
            ),
            totalDistanceMeters = dist.toInt(),
            totalDurationSeconds = (dist / speedMs).toInt(),
            overviewPolyline = encodeTravelPolyline(pts),
            mode = mode
        )
    }

    private suspend fun fetchListWithRetry(
        attempts: Int = 2,
        block: suspend () -> Result<List<RouteResult>>
    ): Result<List<RouteResult>> {
        var last: Result<List<RouteResult>>? = null
        repeat(attempts) { attempt ->
            val r = block()
            if (r.isSuccess) return r
            last = r
            if (attempt < attempts - 1) delay(500L * (attempt + 1))
        }
        return last ?: Result.failure(Exception("경로를 찾을 수 없어요"))
    }

    /** 같은 제공자에게 최대 3번까지 시도 (짧은 지연을 두고 재시도 - 일시적 오류/타임아웃 대응) */
    private suspend fun fetchWithRetry(
        attempts: Int = 3,
        block: suspend () -> Result<RouteResult>
    ): Result<RouteResult> {
        var lastResult: Result<RouteResult>? = null
        repeat(attempts) { attempt ->
            val result = block()
            if (result.isSuccess) return result
            lastResult = result
            if (attempt < attempts - 1) delay(500L * (attempt + 1)) // 재시도 간격을 점점 늘림
        }
        return lastResult ?: Result.failure(Exception("경로를 찾을 수 없어요"))
    }
}
