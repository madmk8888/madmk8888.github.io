package com.navifit.tracking

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import com.google.android.gms.location.ActivityRecognition
import com.google.android.gms.location.ActivityRecognitionResult
import com.google.android.gms.location.DetectedActivity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * 이동수단 정밀 판별 시스템 (부정 랭킹 원천 차단용).
 *
 * 사용하는 신호 3가지:
 *
 * 1️⃣ Google Activity Recognition API (play-services-location 내장)
 *    - 가속도계+자이로 신호를 구글의 온디바이스 ML 모델이 분석해서
 *      WALKING / RUNNING / ON_BICYCLE / IN_VEHICLE / STILL 을 신뢰도(%)와 함께 반환
 *    - 오토바이/자동차 탑승은 IN_VEHICLE로 잡힘 - 걷기/달리기로 위장 불가
 *
 * 2️⃣ 걸음 케이던스 (STEP_DETECTOR 센서)
 *    - 진짜 걷기/달리기는 분당 60~200보의 걸음 진동이 반드시 발생
 *    - 차량/오토바이는 빨리 움직여도 걸음 이벤트가 거의 0
 *    - "GPS는 빠르게 움직이는데 걸음이 없다" = 확정적으로 탈것
 *
 * 3️⃣ GPS 지속 속도 패턴 (기존 AntiCheatMonitor)
 *    - 지속 평균속도가 인간 한계를 넘으면 무효
 *
 * 세 신호를 AntiCheatMonitor가 융합 판정. 하나라도 확정 신호가 잡히면 랭킹 무효.
 * (안내/기록 자체는 계속 정상 진행 - 개인 분석에는 저장됨)
 */
class ActivityTypeMonitor(private val context: Context) : SensorEventListener {

    companion object {
        // Activity Recognition 결과를 화면/판정기와 공유하는 버스
        private val _detectedActivity = MutableStateFlow<Pair<Int, Int>?>(null) // (activityType, confidence)
        val detectedActivity: StateFlow<Pair<Int, Int>?> = _detectedActivity

        fun publish(type: Int, confidence: Int) { _detectedActivity.value = type to confidence }

        fun activityName(type: Int): String = when (type) {
            DetectedActivity.WALKING -> "걷기"
            DetectedActivity.RUNNING -> "달리기"
            DetectedActivity.ON_FOOT -> "도보"
            DetectedActivity.ON_BICYCLE -> "자전거"
            DetectedActivity.IN_VEHICLE -> "차량 탑승"
            DetectedActivity.STILL -> "정지"
            else -> "알 수 없음"
        }
    }

    private var pendingIntent: PendingIntent? = null
    private var sensorManager: SensorManager? = null

    // ===== 걸음 케이던스 추적 =====
    private val stepTimestamps = ArrayDeque<Long>() // 최근 걸음 발생 시각들
    /** 최근 60초 동안의 걸음 수 (분당 케이던스) */
    val recentStepsPerMinute: Int
        get() {
            val cutoff = System.currentTimeMillis() - 60_000
            while (stepTimestamps.isNotEmpty() && stepTimestamps.first() < cutoff) stepTimestamps.removeFirst()
            return stepTimestamps.size
        }

    @SuppressLint("MissingPermission") // 호출부(MainActivity)에서 ACTIVITY_RECOGNITION 권한 확인 후 시작함
    fun start() {
        // 1) Activity Recognition API 구독 (3초 간격)
        try {
            val intent = Intent(context, ActivityUpdateReceiver::class.java).apply {
                action = ActivityUpdateReceiver.ACTION
                `package` = context.packageName
            }
            pendingIntent = PendingIntent.getBroadcast(
                context, 7001, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            ActivityRecognition.getClient(context)
                .requestActivityUpdates(3000L, pendingIntent!!)
        } catch (_: Exception) { /* 권한 없거나 미지원 기기 - 케이던스+속도 신호만으로 판정 */ }

        // 2) 걸음 케이던스 센서
        sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sensorManager?.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR)?.let {
            sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
        stepTimestamps.clear()
        _detectedActivity.value = null
    }

    @SuppressLint("MissingPermission")
    fun stop() {
        try {
            pendingIntent?.let { ActivityRecognition.getClient(context).removeActivityUpdates(it) }
        } catch (_: Exception) {}
        sensorManager?.unregisterListener(this)
        stepTimestamps.clear()
        _detectedActivity.value = null
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_STEP_DETECTOR) {
            stepTimestamps.addLast(System.currentTimeMillis())
            if (stepTimestamps.size > 400) stepTimestamps.removeFirst()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

/** Activity Recognition API 결과 수신 리시버 - 가장 신뢰도 높은 활동을 버스에 게시 */
class ActivityUpdateReceiver : BroadcastReceiver() {
    companion object { const val ACTION = "com.navifit.ACTIVITY_UPDATE" }

    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent == null || !ActivityRecognitionResult.hasResult(intent)) return
        val result = ActivityRecognitionResult.extractResult(intent) ?: return
        val top = result.mostProbableActivity
        // TILTING/UNKNOWN 같은 잡신호는 무시
        if (top.type == DetectedActivity.TILTING || top.type == DetectedActivity.UNKNOWN) return
        ActivityTypeMonitor.publish(top.type, top.confidence)
    }
}
