package com.navifit.social

import android.content.Context
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

/**
 * ✅ v36 신고 시스템 (기존엔 🚩 눌러도 토스트만 뜨고 서버로 안 갔음 - 사실상 무기능).
 *
 * 동작:
 *  - 신고하면 Firestore reports 컬렉션에 기록 (중복 신고 방지: 한 사람이 같은 글 1회만)
 *  - 신고가 100건 이상 쌓이면 글쓴이 본인에게만 보이도록 전환 + 운영진 알림 (운영자 검토 전 임시조치)
 *  - 운영자는 reports 컬렉션에서 확인 후 실제 조치
 */
object ReportSystem {
    private val db by lazy { FirebaseFirestore.getInstance() }
    // ✅ v85 자동 숨김 임계치 3건 → 100건 (소수의 악의적 신고로 정상 글이 가려지지 않게)
    //   100건 도달 시: 글쓴이 본인에게만 보이도록 전환 + 운영진 알림 생성
    private const val AUTO_HIDE_THRESHOLD = 100

    enum class Reason(val label: String) {
        SPAM("스팸/광고"),
        ABUSE("욕설/혐오"),
        SEXUAL("음란물"),
        FALSE_INFO("허위정보"),
        PRIVACY("개인정보 노출"),
        OTHER("기타")
    }

    /**
     * @return 신고 처리 결과 메시지
     */
    suspend fun reportPost(
        postId: Long, postAuthorUid: String, reporterUid: String, reason: Reason, detail: String = ""
    ): String {
        if (reporterUid.isBlank()) return "로그인 후 신고할 수 있어요"
        return try {
            val docId = "${postId}_$reporterUid"   // 중복 신고 방지 키
            val ref = db.collection("reports").document(docId)
            if (ref.get().await().exists()) return "이미 신고한 글이에요"

            ref.set(
                mapOf(
                    "type" to "post",
                    "postId" to postId,
                    "targetUid" to postAuthorUid,
                    "reporterUid" to reporterUid,
                    "reason" to reason.name,
                    "detail" to detail.take(300),
                    "createdAt" to System.currentTimeMillis(),
                    "status" to "pending"
                )
            ).await()

            // 누적 신고 수 집계 → 임계치 넘으면 자동 숨김 플래그
            val count = db.collection("reports")
                .whereEqualTo("postId", postId).get().await().size()
            if (count >= AUTO_HIDE_THRESHOLD) {
                db.collection("hidden_posts").document(postId.toString())
                    .set(mapOf("autoHidden" to true, "reportCount" to count, "at" to System.currentTimeMillis())).await()
                // 운영진 알림 생성
                try {
                    db.collection("admin_alerts").add(mapOf(
                        "type" to "auto_hidden_post",
                        "postId" to postId,
                        "reportCount" to count,
                        "at" to System.currentTimeMillis(),
                        "status" to "pending"
                    )).await()
                } catch (_: Exception) { }
                return "신고가 접수됐어요. 신고 ${count}건 누적으로 글쓴이만 볼 수 있게 전환되고 운영진에게 전달됐습니다"
            }
            "신고가 접수됐어요. 운영진이 검토합니다 (누적 ${count}건)"
        } catch (e: Exception) {
            "신고 접수에 실패했어요. 잠시 후 다시 시도해주세요"
        }
    }

    suspend fun reportUser(targetUid: String, reporterUid: String, reason: Reason, detail: String = ""): String {
        if (reporterUid.isBlank()) return "로그인 후 신고할 수 있어요"
        return try {
            db.collection("reports").document("user_${targetUid}_$reporterUid").set(
                mapOf(
                    "type" to "user", "targetUid" to targetUid, "reporterUid" to reporterUid,
                    "reason" to reason.name, "detail" to detail.take(300),
                    "createdAt" to System.currentTimeMillis(), "status" to "pending"
                )
            ).await()
            "사용자 신고가 접수됐어요"
        } catch (e: Exception) { "신고 접수에 실패했어요" }
    }

    /** 자동 숨김된 글 ID 목록 (신고 누적) */
    suspend fun autoHiddenPostIds(): Set<Long> = try {
        db.collection("hidden_posts").get().await()
            .documents.mapNotNull { it.id.toLongOrNull() }.toSet()
    } catch (_: Exception) { emptySet() }
}

/**
 * ✅ v36 알림 센터 (기존엔 알림이 아예 없어서 DM·댓글이 와도 앱을 켜봐야만 알았음).
 * Firestore notifications/{myUid}/items 에 쌓고, 앱에서 구독해 뱃지·목록으로 표시.
 * + 앱이 켜져 있을 때는 시스템 알림(로컬 푸시)도 발송.
 */
object NotificationCenter {
    private val db by lazy { FirebaseFirestore.getInstance() }
    const val CHANNEL_ID = "navifit_social"

    enum class Type(val icon: String) {
        COMMENT("💬"), LIKE("❤️"), DM("💌"), FRIEND_REQUEST("👥"), SYSTEM("📢")
    }

    data class Item(
        val id: String,
        val type: Type,
        val fromNickname: String,
        val message: String,
        val at: Long,
        val read: Boolean,
        /** ✅ v81 알림 딥링크: 좋아요·댓글 알림이 가리키는 게시글 id */
        val postId: String? = null
    )

    /** 상대에게 알림 보내기 */
    suspend fun push(toUid: String, type: Type, fromNickname: String, message: String, postId: String? = null) {
        if (toUid.isBlank()) return
        try {
            db.collection("notifications").document(toUid).collection("items").add(
                mapOf(
                    "type" to type.name, "fromNickname" to fromNickname,
                    "message" to message.take(120), "at" to System.currentTimeMillis(), "read" to false,
                    "postId" to (postId ?: "")
                )
            ).await()
        } catch (_: Exception) { }
    }

    suspend fun list(myUid: String): List<Item> = try {
        db.collection("notifications").document(myUid).collection("items")
            .orderBy("at", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(50).get().await().documents.mapNotNull { d ->
                val t = try { Type.valueOf(d.getString("type") ?: "") } catch (_: Exception) { return@mapNotNull null }
                Item(
                    id = d.id, type = t,
                    fromNickname = d.getString("fromNickname") ?: "",
                    message = d.getString("message") ?: "",
                    at = d.getLong("at") ?: 0L,
                    read = d.getBoolean("read") ?: false,
                    postId = d.getString("postId")?.takeIf { it.isNotBlank() }
                )
            }
    } catch (_: Exception) { emptyList() }

    suspend fun unreadCount(myUid: String): Int = try {
        db.collection("notifications").document(myUid).collection("items")
            .whereEqualTo("read", false).get().await().size()
    } catch (_: Exception) { 0 }

    suspend fun markAllRead(myUid: String) {
        try {
            val docs = db.collection("notifications").document(myUid).collection("items")
                .whereEqualTo("read", false).get().await()
            docs.documents.forEach { it.reference.update("read", true) }
        } catch (_: Exception) { }
    }

    /** ✅ v58 알림 전체 삭제 */
    suspend fun deleteAll(myUid: String) {
        try {
            val docs = db.collection("notifications").document(myUid).collection("items").get().await()
            docs.documents.forEach { it.reference.delete() }
        } catch (_: Exception) { }
    }

    // ✅ v58 알림 설정: 어떤 종류를 받을지 + 앱이 꺼져있을 때(백그라운드) 시스템 알림 허용 여부
    private const val SETTINGS_PREF = "notif_settings"
    fun isTypeEnabled(c: Context, type: Type): Boolean =
        c.getSharedPreferences(SETTINGS_PREF, Context.MODE_PRIVATE).getBoolean("type_${type.name}", true)
    fun setTypeEnabled(c: Context, type: Type, on: Boolean) =
        c.getSharedPreferences(SETTINGS_PREF, Context.MODE_PRIVATE).edit().putBoolean("type_${type.name}", on).apply()
    fun notifyWhenOff(c: Context): Boolean =
        c.getSharedPreferences(SETTINGS_PREF, Context.MODE_PRIVATE).getBoolean("notify_when_off", true)
    fun setNotifyWhenOff(c: Context, on: Boolean) =
        c.getSharedPreferences(SETTINGS_PREF, Context.MODE_PRIVATE).edit().putBoolean("notify_when_off", on).apply()

    /** 시스템 알림 채널 생성 (앱 시작 시 1회) */
    fun ensureChannel(context: Context) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val ch = android.app.NotificationChannel(
                CHANNEL_ID, "커뮤니티 알림", android.app.NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "댓글·DM·친구 요청 알림" }
            context.getSystemService(android.app.NotificationManager::class.java)?.createNotificationChannel(ch)
        }
    }

    /** 로컬 시스템 알림 표시 */
    fun showLocal(context: Context, title: String, body: String) {
        try {
            val n = androidx.core.app.NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_email)
                .setContentTitle(title).setContentText(body)
                .setPriority(androidx.core.app.NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true).build()
            androidx.core.app.NotificationManagerCompat.from(context)
                .notify(System.currentTimeMillis().toInt(), n)
        } catch (_: SecurityException) { /* 알림 권한 없음 */ }
        catch (_: Exception) { }
    }
}

/** ✅ v36 저장(북마크) - 나중에 볼 글 */
object BookmarkStore {
    private const val PREF = "bookmarks"
    fun toggle(c: Context, postId: Long): Boolean {
        val p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val set = p.getStringSet("ids", emptySet())!!.toMutableSet()
        val added = if (set.contains(postId.toString())) { set.remove(postId.toString()); false }
                    else { set.add(postId.toString()); true }
        p.edit().putStringSet("ids", set).apply()
        return added
    }
    fun all(c: Context): Set<Long> =
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getStringSet("ids", emptySet())!!.mapNotNull { it.toLongOrNull() }.toSet()
    fun has(c: Context, postId: Long) = postId in all(c)
}
