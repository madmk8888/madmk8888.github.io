package com.navifit.vs

import android.content.Context
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  NaviFit VS — 실시간 랜덤 매칭 달리기 대결 시스템
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * [게임 방식]
 *  · 100m 고정 거리 달리기 대결. 먼저 100m를 완주하는(=도착 시간이 빠른) 쪽이 승리.
 *  · 시작 전 10초 카운트다운(그동안 하단 배너광고) → 카운트 0에서 거리 측정 시작.
 *  · 한쪽이 끝나면 광고 후 승/패 화면 + 포인트 결산.
 *
 * [매칭 옵션]  (내가 고른 옵션에 "맞는" 상대가 1000명 풀에서 실제로 랜덤 추출됨 - 고정값 아님)
 *  · ALL       : 전체 랜덤 (포인트 무관)
 *  · SIMILAR   : 내 점수 ±50 이내
 *  · HIGH      : 나보다 높은 점수(고수)
 *  · LOW       : 나보다 낮은 점수(하수)
 *
 * [상대가 없을 때 - 봇]
 *  · 5분(테스트에선 즉시 옵션) 안에 실사용자 매칭이 안 되면 "RUN BOT"으로 대체.
 *  · 봇 닉네임 앞에 🤖 RUN BOT, 포인트는 내가 고른 옵션의 점수대 평균과 비슷하게.
 *  · 봇의 100m 도착 시간 = 그 점수대 평균 기록. 데이터 없으면 하수 20초 / 고수 12초,
 *    내 점수대는 현재 랭킹 분포 비율로 그 사이를 보간.
 *
 * [포인트 알고리즘]  (ELO 변형 - 실력차가 클수록 이변의 보상/손실이 큼)
 *  · 기대승률 E = 1 / (1 + 10^((상대 - 나)/400))
 *  · 이기면:  나 += K * (1 - E)      (K=32 기본, 아래 비대칭 보정)
 *  · 지면:    나 -= K * E
 *  · 비대칭 보정(요청 반영): 하수가 고수를 이기면 고수는 크게 잃고 하수는 크게 얻음.
 *      - 예) 0점이 1000점을 이김 → 1000점은 -50, 0점은 +20
 *      - 예) 1000점이 0점을 이김 → 고수는 +5만 (거의 안 오름), 하수는 소폭 하락
 *  · 점수는 0 밑으로 안 내려감. 1000점은 사실상 상한(2주 빡세게 해야 도달).
 *
 * [포인트 랭킹 유지 보상]  (매일 정오 12시 갱신, "N일째 유지 중")
 *  · 한 달(30일) 유지 시 매월 1일 정각 우편함 지급:
 *      1등 10000 / 2등 5000 / 3등 3000 / 4등 2000 / 5등 1000 포인트
 *
 * ※ 지금은 서버가 없어 상대 1000명은 로컬 생성(시드 고정, 매번 같은 풀). 실서버 연동 시
 *   generateOpponentPool()만 Firestore 쿼리로 바꾸면 됨.
 */
object VsMatchSystem {
    private const val PREFS = "vs_system"
    private const val KEY_POINTS = "my_points"
    private const val KEY_STREAK_START = "streak_start_ms"
    private const val K_FACTOR = 32.0

    data class Opponent(
        val uid: String,
        val nickname: String,
        val country: String,     // "KR", "JP", "US" ...
        val points: Int,
        val avgTime100m: Double, // 100m 평균 기록(초)
        val isBot: Boolean = false
    )

    enum class MatchOption { ALL, SIMILAR, HIGH, LOW }

    // ── 내 포인트 ──
    fun myPoints(c: Context): Int = c.getSharedPreferences(PREFS, 0).getInt(KEY_POINTS, 0)
    fun setMyPoints(c: Context, p: Int) =
        c.getSharedPreferences(PREFS, 0).edit().putInt(KEY_POINTS, p.coerceAtLeast(0)).apply()

    // ── 유지 일수 (정오 갱신 기준) ──
    fun streakDays(c: Context): Int {
        val start = c.getSharedPreferences(PREFS, 0).getLong(KEY_STREAK_START, 0L)
        if (start == 0L) return 0
        return ((System.currentTimeMillis() - start) / (24L * 3600 * 1000)).toInt()
    }
    fun markStreakStartIfNeeded(c: Context) {
        val p = c.getSharedPreferences(PREFS, 0)
        if (p.getLong(KEY_STREAK_START, 0L) == 0L)
            p.edit().putLong(KEY_STREAK_START, System.currentTimeMillis()).apply()
    }

    /**
     * 1000명 상대 풀 생성 (시드 고정 → 매번 같은 사람들, 옵션마다 다른 사람이 뽑히게).
     * 실서버 연동 시 여기만 Firestore users 컬렉션 쿼리로 교체.
     */
    fun generateOpponentPool(): List<Opponent> {
        val rnd = Random(20260716L) // 고정 시드
        val countries = listOf("KR", "KR", "KR", "JP", "US", "GB", "FR", "CN", "DE", "ES")
        val nicks = listOf("바람처럼", "번개러너", "스피드킹", "TokyoDash", "RunMaster", "질주본능",
            "새벽질주", "PaceMaker", "달빛러너", "SprintX", "치타", "허리케인", "코스브레이커")
        return (1..1000).map { i ->
            // 포인트 분포: 대부분 낮고(하수 많음), 고수는 드물게 (실제 랭킹 분포 흉내 - 지수 분포)
            val pts = (Math.pow(rnd.nextDouble(), 2.2) * 1000).roundToInt()
            // 점수 높을수록 빠름: 0점 ≈ 20초, 1000점 ≈ 12초 (선형 보간 + 약간의 랜덤)
            val base = 20.0 - (pts / 1000.0) * 8.0
            val avg = (base + rnd.nextDouble(-1.0, 1.0)).coerceIn(11.0, 24.0)
            Opponent(
                uid = "vs_$i",
                nickname = nicks[rnd.nextInt(nicks.size)] + rnd.nextInt(10, 99),
                country = countries[rnd.nextInt(countries.size)],
                points = pts,
                avgTime100m = avg
            )
        }
    }

    /**
     * 옵션에 맞는 상대를 풀에서 실제로 랜덤 추출. 조건에 맞는 사람이 없으면 null(→ 봇 대체).
     */
    fun findOpponent(myPoints: Int, option: MatchOption, pool: List<Opponent>): Opponent? {
        val candidates = when (option) {
            MatchOption.ALL -> pool
            MatchOption.SIMILAR -> pool.filter { kotlin.math.abs(it.points - myPoints) <= 50 }
            MatchOption.HIGH -> pool.filter { it.points > myPoints + 50 }
            MatchOption.LOW -> pool.filter { it.points < myPoints - 50 }
        }
        return candidates.randomOrNull()
    }

    /** 옵션별 봇 매칭 타임아웃(초). 실사용자를 이만큼 기다려도 없으면 봇으로 대체. */
    fun botTimeoutSeconds(option: MatchOption): Int = when (option) {
        MatchOption.LOW -> 3
        MatchOption.SIMILAR -> 5
        MatchOption.ALL -> 5
        MatchOption.HIGH -> 8
    }

    /** 친구 고유코드로 매칭 (친선전, 포인트 변동 없음). */
    fun findFriendByCode(code: String, pool: List<Opponent>): Opponent {
        val idx = kotlin.math.abs(code.hashCode()) % pool.size
        return pool[idx].copy(nickname = "친구($code)")
    }

    /** ✅ v81 4단계 봇: 초고수 10.3 / 고수 12 / 중수 14 / 하수 16초. 봇 포인트는 1/10만 지급. */
    enum class BotTier(val label: String, val time100m: Double, val points: Int) {
        MASTER("초고수 봇", 10.3, 900),
        HIGH("고수 봇", 12.0, 600),
        MID("중수 봇", 14.0, 300),
        LOW("하수 봇", 16.0, 100)
    }

    fun createTieredBot(option: MatchOption, myPoints: Int): Opponent {
        val tier = when (option) {
            MatchOption.HIGH -> if (myPoints >= 600) BotTier.MASTER else BotTier.HIGH
            MatchOption.LOW -> BotTier.LOW
            else -> when {
                myPoints >= 700 -> BotTier.MASTER
                myPoints >= 400 -> BotTier.HIGH
                myPoints >= 150 -> BotTier.MID
                else -> BotTier.LOW
            }
        }
        return Opponent("bot_${tier.name}", "🤖 ${tier.label}", "KR", tier.points, tier.time100m, isBot = true)
    }

    /**
     * 봇 생성 (매칭 실패 시). 점수대 평균 기록으로 상대 도착시간을 정함.
     * @param distribution 현재 랭킹 분포에서 내 점수대의 상대적 위치(0=하수, 1=고수)
     */
    fun createBot(myPoints: Int, option: MatchOption, pool: List<Opponent>): Opponent {
        // 옵션 점수대의 평균 기록 계산 (데이터 없으면 하수 20초 / 고수 12초 사이 보간)
        val band = when (option) {
            MatchOption.ALL -> pool
            MatchOption.SIMILAR -> pool.filter { kotlin.math.abs(it.points - myPoints) <= 50 }
            MatchOption.HIGH -> pool.filter { it.points > myPoints }
            MatchOption.LOW -> pool.filter { it.points < myPoints }
        }
        val avgTime = if (band.isNotEmpty()) band.map { it.avgTime100m }.average()
                      else {
                          // 분포 비율로 20초(하수)~12초(고수) 보간
                          val ratio = (myPoints / 1000.0).coerceIn(0.0, 1.0)
                          20.0 - ratio * 8.0
                      }
        val botPoints = if (band.isNotEmpty()) band.map { it.points }.average().roundToInt()
                        else myPoints
        return Opponent(
            uid = "bot_${System.currentTimeMillis()}",
            nickname = "RUN BOT",
            country = "KR",
            points = botPoints,
            avgTime100m = avgTime,
            isBot = true
        )
    }

    data class Settlement(val myDelta: Int, val oppDelta: Int, val newMyPoints: Int, val iWon: Boolean)

    /**
     * 대결 결과 정산 - 진짜 게임 랭킹처럼 "비율 기반" 점수 이동.
     *
     * 핵심 규칙(요청 반영):
     *  · 실력차가 클수록 이변(약자 승리)의 보상이 크고, 강자가 약자 이기면 거의 안 오름.
     *  · 예) 1000 vs 10에서 10이 이기면: 10은 +100, 1000은 -100
     *  · 예) 500 vs 500이면: 이긴 쪽 +50 / 진 쪽 -50
     *  · 예) 500 vs 10에서 10이 이기면: 10은 +50, 500은 -50
     *  · 1000점은 사실상 상한(2주 열심히 해야 도달), 0점 밑으로 안 내려감.
     *
     * 방식: 기대승률 E = 1/(1+10^((상대-나)/400)).
     *   승리 시 획득 = BASE * (1 - E) * 2  (약자일수록 1-E가 커져 크게 얻음)
     *   패배 시 손실 = BASE * E * 2         (강자일수록 E가 커져 크게 잃음)
     *   BASE=50 → 동점(500vs500) 승부에서 ±50, 극단(1000vs10)에서 ±100 근처로 수렴.
     *
     * @param pointMultiplier 봇전이면 0.6 (사람 대결의 60%만 얻고 잃음), 친구전이면 0.0(점수 변동 없음)
     */
    fun settle(c: Context, myPoints: Int, oppPoints: Int, myTime: Double, oppTime: Double,
               pointMultiplier: Double = 1.0): Settlement {
        val iWon = myTime <= oppTime
        val expectedMe = 1.0 / (1.0 + Math.pow(10.0, (oppPoints - myPoints) / 400.0))
        val base = 50.0
        var myDelta = if (iWon) base * (1.0 - expectedMe) * 2.0
                      else -base * expectedMe * 2.0
        myDelta *= pointMultiplier
        val myDeltaInt = myDelta.roundToInt()
        val newMe = (myPoints + myDeltaInt).coerceIn(0, 999_999)
        setMyPoints(c, newMe)
        val oppDelta = if (iWon) -(base * (1.0 - expectedMe) * 2.0 * pointMultiplier).roundToInt()
                       else (base * expectedMe * 2.0 * pointMultiplier).roundToInt()
        return Settlement(myDeltaInt, oppDelta, newMe, iWon)
    }
}
