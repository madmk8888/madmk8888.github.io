package com.navifit.navigation

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * ✅ v75 화장실 리뷰 저장소.
 *  · 화장실 마커를 누르면 이름/별명을 지어주고, 댓글·별점, "열려있는지/몇 층인지"를 남길 수 있음.
 *  · 좌표를 키로 삼아 로컬 저장 (실서버 연동 시 Firestore toilets/{geohash} 로 이동).
 */
object ToiletReviewStore {
    private const val PREFS = "toilet_reviews"

    data class Review(val nickname: String, val rating: Int, val comment: String,
                      val floor: String, val isOpen: String, val createdAt: Long)
    data class ToiletMeta(val key: String, val nickname: String, val avgRating: Double,
                          val reviewCount: Int, val reviews: List<Review>)

    /** 좌표를 5자리로 반올림해 키 생성 (같은 화장실 묶기) */
    fun keyOf(lat: Double, lng: Double): String =
        "%.5f_%.5f".format(lat, lng)

    fun get(c: Context, key: String): ToiletMeta {
        val raw = c.getSharedPreferences(PREFS, 0).getString(key, null)
            ?: return ToiletMeta(key, "", 0.0, 0, emptyList())
        return try {
            val o = JSONObject(raw)
            val arr = o.optJSONArray("reviews") ?: JSONArray()
            val reviews = (0 until arr.length()).map { i ->
                val r = arr.getJSONObject(i)
                Review(r.optString("nickname"), r.optInt("rating"), r.optString("comment"),
                    r.optString("floor"), r.optString("isOpen"), r.optLong("createdAt"))
            }.sortedByDescending { it.createdAt }
            val avg = if (reviews.isNotEmpty()) reviews.map { it.rating }.average() else 0.0
            ToiletMeta(key, o.optString("nickname"), avg, reviews.size, reviews)
        } catch (_: Exception) { ToiletMeta(key, "", 0.0, 0, emptyList()) }
    }

    /** 별명 지정 (처음 리뷰하는 사람이 붙일 수 있음) */
    fun setNickname(c: Context, key: String, nickname: String) {
        val meta = get(c, key)
        save(c, key, nickname.ifBlank { meta.nickname }, meta.reviews)
    }

    fun addReview(c: Context, key: String, review: Review, toiletNickname: String = "") {
        val meta = get(c, key)
        val newList = listOf(review) + meta.reviews
        save(c, key, toiletNickname.ifBlank { meta.nickname }, newList)
    }

    private fun save(c: Context, key: String, nickname: String, reviews: List<Review>) {
        val arr = JSONArray()
        reviews.forEach {
            arr.put(JSONObject().apply {
                put("nickname", it.nickname); put("rating", it.rating); put("comment", it.comment)
                put("floor", it.floor); put("isOpen", it.isOpen); put("createdAt", it.createdAt)
            })
        }
        val o = JSONObject().apply { put("nickname", nickname); put("reviews", arr) }
        c.getSharedPreferences(PREFS, 0).edit().putString(key, o.toString()).apply()
    }
}
