package com.navifit.navigation

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * 구글 Directions API 연동 - ORS(무료)가 실패했을 때만 쓰는 안전망(fallback).
 * Cloud Console에서 "Directions API" 활성화 필요. 평소엔 안 쓰이니 비용 걱정 크게 없음
 * (ORS가 대부분 처리하고, 이건 정말 안 될 때만 호출됨).
 */
class GoogleFallbackRepository(private val apiKey: String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    suspend fun fetchRoute(
        origin: LatLngPoint,
        destination: LatLngPoint,
        mode: TravelMode,
        preference: RoutePreference = RoutePreference.FAST
    ): Result<RouteResult> =
        fetchRoutes(origin, destination, mode, preference, alternatives = false)
            .map { it.first() }

    /**
     * ✅ v27: 실시간 교통 반영 + 대체경로.
     *  - departure_time=now + traffic_model=best_guess -> duration_in_traffic(교통 반영 시간)으로 계산
     *  - alternatives=true -> 최대 3개 경로 반환 (첫 번째가 교통 기준 최적)
     */
    suspend fun fetchRoutes(
        origin: LatLngPoint,
        destination: LatLngPoint,
        mode: TravelMode,
        preference: RoutePreference = RoutePreference.FAST,
        alternatives: Boolean = true
    ): Result<List<RouteResult>> = withContext(Dispatchers.IO) {
        try {
            val gMode = when (mode) {
                TravelMode.WALK -> "walking"
                TravelMode.BIKE -> "bicycling"
                TravelMode.MOTORCYCLE, TravelMode.CAR -> "driving"
            }
            val avoidItems = buildList {
                if (mode == TravelMode.MOTORCYCLE) add("highways")
                if (!mode.isWorkoutMode) when (preference) {
                    RoutePreference.FREE -> add("tolls")
                    RoutePreference.OPTIMAL -> { add("tolls"); add("ferries") }
                    RoutePreference.FAST, RoutePreference.HIGHWAY -> {}
                }
            }.distinct()
            val avoid = if (avoidItems.isEmpty()) "" else "&avoid=${avoidItems.joinToString("|")}"
            // 실시간 교통은 driving에서만 유효
            val traffic = if (gMode == "driving") "&departure_time=now&traffic_model=best_guess" else ""
            val altParam = if (alternatives) "&alternatives=true" else ""

            val url = "https://maps.googleapis.com/maps/api/directions/json?" +
                "origin=${origin.latitude},${origin.longitude}&destination=${destination.latitude},${destination.longitude}" +
                "&mode=$gMode$avoid$traffic$altParam&key=$apiKey"

            val request = Request.Builder().url(url).build()

            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string() ?: "{}"
                val json = JSONObject(bodyStr)
                if (json.optString("status") != "OK") {
                    Result.failure(IOException("구글 경로 실패: ${json.optString("status")}"))
                } else {
                    val routesArr = json.getJSONArray("routes")
                    val results = mutableListOf<RouteResult>()
                    for (r in 0 until routesArr.length()) {
                        val route = routesArr.getJSONObject(r)
                        val leg = route.getJSONArray("legs").getJSONObject(0)

                        val parsedSteps = mutableListOf<RouteStep>()
                        val stepsArr = leg.optJSONArray("steps")
                        if (stepsArr != null) {
                            for (i in 0 until stepsArr.length()) {
                                val st = stepsArr.getJSONObject(i)
                                val startLoc = st.getJSONObject("start_location")
                                val endLoc = st.getJSONObject("end_location")
                                parsedSteps.add(
                                    RouteStep(
                                        instruction = st.optString("html_instructions", "").replace(Regex("<[^>]*>"), " ").trim(),
                                        distanceMeters = st.getJSONObject("distance").getInt("value"),
                                        durationSeconds = st.getJSONObject("duration").getInt("value"),
                                        startLocation = LatLngPoint(startLoc.getDouble("lat"), startLoc.getDouble("lng")),
                                        endLocation = LatLngPoint(endLoc.getDouble("lat"), endLoc.getDouble("lng")),
                                        maneuver = st.optString("maneuver", null.toString()).takeIf { it != "null" && it.isNotBlank() } ?: "straight"
                                    )
                                )
                            }
                        }
                        // ✅ 교통 반영 시간이 있으면 그걸 우선 사용 (실시간 교통 기반 소요시간)
                        val duration = leg.optJSONObject("duration_in_traffic")?.optInt("value")
                            ?: leg.getJSONObject("duration").getInt("value")
                        results.add(
                            RouteResult(
                                steps = parsedSteps,
                                totalDistanceMeters = leg.getJSONObject("distance").getInt("value"),
                                totalDurationSeconds = duration,
                                overviewPolyline = route.getJSONObject("overview_polyline").getString("points"),
                                mode = mode
                            )
                        )
                    }
                    // 교통 반영 소요시간이 짧은 순으로 정렬 -> [0]이 실시간 최적경로
                    results.sortBy { it.totalDurationSeconds }
                    if (results.isEmpty()) Result.failure(IOException("경로 없음"))
                    else Result.success(results)
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
