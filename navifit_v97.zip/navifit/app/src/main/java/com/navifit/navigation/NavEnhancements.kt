package com.navifit.navigation

import android.content.Context
import android.location.Location

/**
 * v27 내비 개선 모듈 모음.
 *  1) NavSettings   : 내정보에서 켜고 끄는 내비 설정 (음성 / 경고음 / 경고 화면깜빡임 / 자동확대)
 *  2) DeadReckoning : 터널 등 GPS 끊김 구간에서 마지막 속도·방향으로 위치를 추정(추측항법)
 *  3) RoadInfoResolver : 지금 달리는 도로 이름/번호(서해안고속도로·39번 국도 등) + 고가/지하 판별
 */

// ─────────────────────────────────────────────
// 1) 내비 설정 (내정보 탭에서 토글)
// ─────────────────────────────────────────────
object NavSettings {
    private const val PREF = "nav_settings"

    fun voiceEnabled(c: Context) = prefs(c).getBoolean("voice", true)
    fun setVoiceEnabled(c: Context, v: Boolean) = prefs(c).edit().putBoolean("voice", v).apply()

    fun warningSoundEnabled(c: Context) = prefs(c).getBoolean("warn_sound", true)
    fun setWarningSoundEnabled(c: Context, v: Boolean) = prefs(c).edit().putBoolean("warn_sound", v).apply()

    fun warningFlashEnabled(c: Context) = prefs(c).getBoolean("warn_flash", true)
    fun setWarningFlashEnabled(c: Context, v: Boolean) = prefs(c).edit().putBoolean("warn_flash", v).apply()

    fun autoZoomEnabled(c: Context) = prefs(c).getBoolean("auto_zoom", false)  // ✅ 기본 꺼짐: 회전 접근 시 지도를 확대하는 대신 상단에 작은 안내 창을 잠깐 띄움
    fun setAutoZoomEnabled(c: Context, v: Boolean) = prefs(c).edit().putBoolean("auto_zoom", v).apply()

    /** 큰 지도(직진 구간) 기본 줌 - 사용자가 조절한 값을 기억 */
    fun baseZoom(c: Context) = prefs(c).getFloat("base_zoom", 17f)
    fun setBaseZoom(c: Context, v: Float) = prefs(c).edit().putFloat("base_zoom", v.coerceIn(13f, 19f)).apply()

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
}

// ─────────────────────────────────────────────
// 2) 터널 추측항법 (Dead Reckoning)
// ─────────────────────────────────────────────
/**
 * GPS가 6초 이상 안 들어오면(터널·지하차도) 마지막 속도와 진행방향으로 위치를 밀어서 추정.
 * 경로가 있으면 경로 폴리라인 위를 따라가게 스냅해서 더 자연스럽게 이동.
 * 다시 실제 GPS가 들어오면 즉시 실제 위치로 복귀.
 */
class DeadReckoning {
    private var lastFixTime = 0L
    private var lastFix: LatLngPoint? = null
    private var lastSpeedMps = 0.0
    private var lastBearingDeg = 0f
    private var estimating = false

    val isEstimating get() = estimating

    fun onRealFix(loc: LatLngPoint, speedKmh: Double, bearingDeg: Float) {
        lastFixTime = System.currentTimeMillis()
        lastFix = loc
        lastSpeedMps = speedKmh / 3.6
        lastBearingDeg = bearingDeg
        estimating = false
    }

    /**
     * 실제 GPS가 없을 때 호출: 추정 위치 반환 (없으면 null).
     *
     * ✅ v40 수정: 기존엔 추정점을 "경로에서 가장 가까운 점"으로 스냅했는데,
     *    이러면 터널 안에서 위치가 뒤로 가거나 제자리에 머무는 문제가 있었음.
     *    이제 마지막 실측 위치에서 "경로를 따라 앞으로" 이동거리만큼 전진시킴 (올바른 추측항법).
     */
    fun estimate(routePoints: List<LatLngPoint>?): LatLngPoint? {
        val fix = lastFix ?: return null
        val gapSec = (System.currentTimeMillis() - lastFixTime) / 1000.0
        if (gapSec < 6) return null           // 아직 정상 범위 - 추정 불필요
        if (gapSec > 300) return null         // 5분 이상 끊기면 추정 중단 (오차 과대)
        if (lastSpeedMps < 1.0) return fix    // 정지 상태였으면 그 자리 유지
        estimating = true

        val travelDist = lastSpeedMps * gapSec   // 끊긴 뒤 이동했을 거리

        // ── 경로가 있으면: 경로 선을 따라 앞으로 전진 (터널은 경로대로 직진하므로 매우 정확) ──
        if (!routePoints.isNullOrEmpty() && routePoints.size >= 2) {
            val startIdx = NavigationProgressCalculator.nearestPointIndex(routePoints, fix)
            var remaining = travelDist
            var i = startIdx
            while (i < routePoints.size - 1 && remaining > 0) {
                val segLen = NavigationProgressCalculator.fastDistanceMeters(routePoints[i], routePoints[i + 1])
                if (segLen <= 0.0) { i++; continue }
                if (remaining <= segLen) {
                    // 이 구간 안에서 비율만큼 진행한 지점
                    val t = remaining / segLen
                    val a = routePoints[i]; val b = routePoints[i + 1]
                    return LatLngPoint(
                        a.latitude + (b.latitude - a.latitude) * t,
                        a.longitude + (b.longitude - a.longitude) * t
                    )
                }
                remaining -= segLen
                i++
            }
            return routePoints.last()   // 경로 끝까지 갔으면 종점
        }

        // ── 경로가 없으면: 등속 직진 가정으로 위치 밀기 ──
        val rad = Math.toRadians(lastBearingDeg.toDouble())
        val dLat = travelDist * Math.cos(rad) / 111_320.0
        val dLng = travelDist * Math.sin(rad) / (111_320.0 * Math.cos(Math.toRadians(fix.latitude)))
        return LatLngPoint(fix.latitude + dLat, fix.longitude + dLng)
    }
}

// ─────────────────────────────────────────────
// 3) 현재 도로 인식 (도로명·노선번호 + 고가/지하)
// ─────────────────────────────────────────────
/**
 * "지금 무슨 도로를 달리는가"를 두 소스로 판별:
 *  ① 경로 스텝의 도로명 (ORS/구글 안내문에 포함된 도로명 - 무료, 즉시)
 *  ② GPS 고도 변화로 고가도로/지하차도 힌트 (연속 고도 표본 스무딩)
 * 유료 지도 API 없이 가능한 최선의 조합. 노선번호(39번 국도 등)는 안내문에서 정규식으로 추출.
 */
class RoadInfoResolver {
    private val altitudeWindow = ArrayDeque<Double>()
    private var smoothedAltitude = Double.NaN

    data class RoadInfo(
        val roadName: String?,        // 예: "서해안고속도로", "국도39호선", "테헤란로"
        val roadRef: String?,         // 노선번호만 뽑은 것: "39", "15"
        val elevationHint: String?    // "고가/교량 구간" · "지하/터널 구간" · null(일반)
    )

    fun feed(location: Location?) {
        val alt = location?.takeIf { it.hasAltitude() }?.altitude ?: return
        altitudeWindow.addLast(alt)
        while (altitudeWindow.size > 8) altitudeWindow.removeFirst()
        smoothedAltitude = altitudeWindow.average()
    }

    /**
     * @param currentStep 지금 따라가는 경로 스텝 (안내문에 도로명 포함)
     * @param gpsAvailable GPS 수신 여부 (끊겨 있으면 터널 확률 높음)
     */
    fun resolve(currentStep: RouteStep?, gpsAvailable: Boolean): RoadInfo {
        val instruction = currentStep?.instruction ?: ""
        // 도로명 추출: "OO로/OO대로/OO고속도로/국도OO호선/지방도OO호선" 패턴
        val nameRegex = Regex("([가-힣A-Za-z0-9]+(?:고속도로|순환로|대로|로|길))")
        val refRegex = Regex("(?:국도\\s?(\\d+)|지방도\\s?(\\d+)|(\\d+)번\\s?(?:국도|도로))")
        val roadName = nameRegex.find(instruction)?.groupValues?.get(1)
        val refMatch = refRegex.find(instruction)
        val roadRef = refMatch?.groupValues?.drop(1)?.firstOrNull { it.isNotEmpty() }

        // 고도 힌트: 최근 표본 평균이 앞선 표본 대비 +6m 이상 상승 유지 -> 고가 / GPS 끊김 -> 터널
        val elevation = when {
            !gpsAvailable -> "지하/터널 구간"
            altitudeWindow.size >= 6 && altitudeWindow.takeLast(3).average() - altitudeWindow.take(3).average() > 6 -> "고가/교량 구간"
            altitudeWindow.size >= 6 && altitudeWindow.take(3).average() - altitudeWindow.takeLast(3).average() > 6 -> "지하차도 진입"
            else -> null
        }
        return RoadInfo(roadName, roadRef, elevation)
    }
}
