package com.navifit.social

import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

/**
 * ✅ v37 팔로우 (단방향).
 *
 * 기존엔 "친구"(상호 수락)만 있어서, 인스타처럼 관심 있는 사람을 일방적으로 구독할 수 없었음.
 * 팔로우하면 그 사람 글이 피드 "런친" 탭에 뜨고, 새 글을 올리면 알림이 감.
 *
 * 구조:
 *   users/{uid}/following/{targetUid}   - 내가 팔로우하는 사람
 *   users/{uid}/followers/{followerUid} - 나를 팔로우하는 사람
 *   users/{uid}.followerCount / followingCount - 집계
 *
 * 비공개 계정(PrivacySettings.isPrivateAccount)이면 팔로우가 "요청" 상태로 들어가고,
 * 상대가 수락해야 실제 팔로워가 됨.
 */
object FollowSystem {
    private val db by lazy { FirebaseFirestore.getInstance() }

    data class FollowUser(val uid: String, val nickname: String, val at: Long)

    /** 팔로우 (상대가 비공개면 요청으로 들어감) */
    suspend fun follow(myUid: String, myNickname: String, targetUid: String, targetNickname: String): String {
        if (myUid.isBlank() || targetUid.isBlank() || myUid == targetUid) return "런친할 수 없어요"
        return try {
            // 차단 관계면 불가
            if (FriendRepository().isBlocked(targetUid, myUid)) return "런친할 수 없는 사용자예요"

            val targetPrivate = try {
                db.collection("users").document(targetUid).get().await()
                    .getBoolean("privateAccount") ?: false
            } catch (_: Exception) { false }

            val now = System.currentTimeMillis()
            if (targetPrivate) {
                // 비공개 계정 → 팔로우 요청
                db.collection("users").document(targetUid).collection("follow_requests")
                    .document(myUid).set(mapOf("nickname" to myNickname, "at" to now)).await()
                NotificationCenter.push(targetUid, NotificationCenter.Type.FRIEND_REQUEST, myNickname, "회원님을 런친하고 싶어해요")
                "런친를 요청했어요 (비공개 계정)"
            } else {
                db.collection("users").document(myUid).collection("following")
                    .document(targetUid).set(mapOf("nickname" to targetNickname, "at" to now)).await()
                db.collection("users").document(targetUid).collection("followers")
                    .document(myUid).set(mapOf("nickname" to myNickname, "at" to now)).await()
                db.collection("users").document(myUid)
                    .set(mapOf("followingCount" to FieldValue.increment(1)), com.google.firebase.firestore.SetOptions.merge()).await()
                db.collection("users").document(targetUid)
                    .set(mapOf("followerCount" to FieldValue.increment(1)), com.google.firebase.firestore.SetOptions.merge()).await()
                NotificationCenter.push(targetUid, NotificationCenter.Type.FRIEND_REQUEST, myNickname, "회원님을 런친 요청 시작했어요")
                "런친했어요"
            }
        } catch (e: Exception) { "런친에 실패했어요" }
    }

    suspend fun unfollow(myUid: String, targetUid: String): String = try {
        db.collection("users").document(myUid).collection("following").document(targetUid).delete().await()
        db.collection("users").document(targetUid).collection("followers").document(myUid).delete().await()
        db.collection("users").document(myUid)
            .set(mapOf("followingCount" to FieldValue.increment(-1)), com.google.firebase.firestore.SetOptions.merge()).await()
        db.collection("users").document(targetUid)
            .set(mapOf("followerCount" to FieldValue.increment(-1)), com.google.firebase.firestore.SetOptions.merge()).await()
        "런친를 취소했어요"
    } catch (e: Exception) { "처리에 실패했어요" }

    suspend fun isFollowing(myUid: String, targetUid: String): Boolean = try {
        db.collection("users").document(myUid).collection("following")
            .document(targetUid).get().await().exists()
    } catch (_: Exception) { false }

    suspend fun followingUids(myUid: String): Set<String> = try {
        db.collection("users").document(myUid).collection("following")
            .get().await().documents.map { it.id }.toSet()
    } catch (_: Exception) { emptySet() }

    suspend fun followers(uid: String): List<FollowUser> = try {
        db.collection("users").document(uid).collection("followers").get().await()
            .documents.map { FollowUser(it.id, it.getString("nickname") ?: "", it.getLong("at") ?: 0L) }
    } catch (_: Exception) { emptyList() }

    suspend fun following(uid: String): List<FollowUser> = try {
        db.collection("users").document(uid).collection("following").get().await()
            .documents.map { FollowUser(it.id, it.getString("nickname") ?: "", it.getLong("at") ?: 0L) }
    } catch (_: Exception) { emptyList() }

    suspend fun counts(uid: String): Pair<Int, Int> = try {
        val d = db.collection("users").document(uid).get().await()
        (d.getLong("followerCount")?.toInt() ?: 0) to (d.getLong("followingCount")?.toInt() ?: 0)
    } catch (_: Exception) { 0 to 0 }

    /** 비공개 계정의 팔로우 요청 목록 */
    suspend fun pendingRequests(myUid: String): List<FollowUser> = try {
        db.collection("users").document(myUid).collection("follow_requests").get().await()
            .documents.map { FollowUser(it.id, it.getString("nickname") ?: "", it.getLong("at") ?: 0L) }
    } catch (_: Exception) { emptyList() }

    suspend fun acceptRequest(myUid: String, myNickname: String, requesterUid: String, requesterNickname: String) {
        try {
            val now = System.currentTimeMillis()
            db.collection("users").document(requesterUid).collection("following")
                .document(myUid).set(mapOf("nickname" to myNickname, "at" to now)).await()
            db.collection("users").document(myUid).collection("followers")
                .document(requesterUid).set(mapOf("nickname" to requesterNickname, "at" to now)).await()
            db.collection("users").document(myUid).collection("follow_requests")
                .document(requesterUid).delete().await()
            db.collection("users").document(myUid)
                .set(mapOf("followerCount" to FieldValue.increment(1)), com.google.firebase.firestore.SetOptions.merge()).await()
            NotificationCenter.push(requesterUid, NotificationCenter.Type.FRIEND_REQUEST, myNickname, "런친 요청을 수락했어요")
        } catch (_: Exception) { }
    }

    suspend fun rejectRequest(myUid: String, requesterUid: String) {
        try {
            db.collection("users").document(myUid).collection("follow_requests")
                .document(requesterUid).delete().await()
        } catch (_: Exception) { }
    }
}
