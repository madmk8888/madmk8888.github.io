package com.navifit.social

import android.content.Context

/**
 * ✅ Firebase 사용 가능 여부 가드.
 *
 * google-services.json이 없거나 초기화에 실패한 상태에서 Firestore를 부르면
 * 예외/무한대기(타임아웃)가 발생함 → 모든 Firebase 호출 전에 이걸로 확인해서
 * 즉시 건너뛰고, 앱의 나머지 기능(내비·운동·뽑기·로컬 커뮤니티)은 정상 동작하게 함.
 */
object FirebaseGuard {
    @Volatile private var cached: Boolean? = null

    fun available(context: Context): Boolean {
        cached?.let { return it }
        val ok = try {
            com.google.firebase.FirebaseApp.getApps(context.applicationContext).isNotEmpty()
        } catch (_: Throwable) { false }
        cached = ok
        if (!ok) android.util.Log.w("NaviFit-Firebase",
            "Firebase 미초기화: app/google-services.json을 넣고 다시 빌드하면 " +
            "구글로그인·친구·DM·공유키 서버조회·카메라 Firebase 동기화가 켜집니다")
        return ok
    }
}
