package com.navifit.tracking

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.abs

/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  ElevationTracker — 기압계 기반 고도 상승 측정 (v90 신규)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * 왜 기압계인가:
 *  GPS 고도는 오차가 ±10~30m로 매우 부정확해서 언덕을 몇 번 올랐는지 셀 수 없다.
 *  기압계(TYPE_PRESSURE)는 상대 고도 변화를 ±1m 수준으로 잡아낸다.
 *  → "누적 상승고도(elevation gain)"라는 러닝·자전거의 핵심 지표를 만들 수 있다.
 *
 * 비용·권한: 전부 무료, 권한 불필요, 오프라인 동작.
 *  기압계가 없는 기기(저가형 일부)에서는 GPS 고도로 폴백한다.
 *
 * 노이즈 처리:
 *  · 저역통과 필터로 기압 흔들림 제거
 *  · 1m 미만 변화는 무시(문 여닫기·바람 등으로 생기는 미세 변동)
 */
class ElevationTracker(private val context: Context) : SensorEventListener {

    private val sm = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val pressureSensor = sm?.getDefaultSensor(Sensor.TYPE_PRESSURE)

    /** 누적 상승고도(m) — 올라간 것만 합산 */
    @Volatile var gainMeters: Double = 0.0; private set
    /** 누적 하강고도(m) */
    @Volatile var lossMeters: Double = 0.0; private set
    /** 현재 추정 고도(m, 해수면 기준 근사) */
    @Volatile var currentAltitude: Double = 0.0; private set
    /** 기압계 사용 가능 여부 */
    val hasBarometer: Boolean get() = pressureSensor != null

    private var smoothedPressure = 0f
    private var lastAltitude: Double? = null
    private val ALPHA = 0.88f          // 저역통과 계수 (기압 노이즈 억제)
    private val MIN_CHANGE_M = 1.0     // 1m 미만 변화는 노이즈로 무시

    fun start() {
        pressureSensor?.let {
            sm?.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    fun stop() {
        sm?.unregisterListener(this)
    }

    fun reset() {
        gainMeters = 0.0; lossMeters = 0.0
        smoothedPressure = 0f; lastAltitude = null; currentAltitude = 0.0
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_PRESSURE) return
        val raw = event.values[0]   // hPa
        smoothedPressure = if (smoothedPressure == 0f) raw
                           else ALPHA * smoothedPressure + (1 - ALPHA) * raw

        // 표준대기압 기준 고도 환산 (안드로이드 제공 공식)
        val alt = SensorManager.getAltitude(
            SensorManager.PRESSURE_STANDARD_ATMOSPHERE, smoothedPressure
        ).toDouble()
        currentAltitude = alt

        val prev = lastAltitude
        if (prev == null) { lastAltitude = alt; return }
        val diff = alt - prev
        if (abs(diff) >= MIN_CHANGE_M) {
            if (diff > 0) gainMeters += diff else lossMeters += -diff
            lastAltitude = alt
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    /**
     * 기압계가 없는 기기용 폴백: GPS 고도로 누적 상승을 계산.
     * GPS 고도는 오차가 커서 3m 이상 변할 때만 반영한다.
     */
    fun onGpsAltitude(alt: Double) {
        if (hasBarometer) return   // 기압계가 있으면 그쪽이 훨씬 정확하므로 무시
        val prev = lastAltitude
        if (prev == null) { lastAltitude = alt; currentAltitude = alt; return }
        val diff = alt - prev
        if (abs(diff) >= 3.0) {
            if (diff > 0) gainMeters += diff else lossMeters += -diff
            lastAltitude = alt
            currentAltitude = alt
        }
    }
}
