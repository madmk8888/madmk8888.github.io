package com.navifit.navigation

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * ✅ v29 카카오모빌리티 길찾기 API (자동차/오토바이 전용).
 *  - 실시간 교통정보가 반영된 국내 최적경로 (카카오내비 엔진)
 *  - alternatives=true 로 대체경로 포함
 *  - 무료 쿼터 제공 (developers.kakao.com 에서 REST API 키 발급 후 assets/api_keys.properties 에 등록)
 *
 * 키가 없으면 HybridRoutingRepository가 자동으로 구글/ORS로 넘어감.
 */
class KakaoRoutingRepository(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    fun hasKey(): Boolean = NavApiKeys.kakaoRestKey(context) != null

    suspend fun fetchRoutes(
        origin: LatLngPoint,
        destination: LatLngPoint,
        mode: TravelMode,
        preference: RoutePreference
    ): Result<List<RouteResult>> = withContext(Dispatchers.IO) {
        val key = NavApiKeys.kakaoRestKey(context)
            ?: return@withContext Result.failure(IOException("카카오 키 없음"))
        try {
            // priority: RECOMMEND(추천) / TIME(최단시간) / DISTANCE(최단거리)
            val priority = when (preference) {
                RoutePreference.FAST, RoutePreference.HIGHWAY -> "TIME"
                RoutePreference.FREE, RoutePreference.OPTIMAL -> "RECOMMEND"
            }
            // 무료도로 선호 시 유료도로 회피 옵션
            val avoid = when (preference) {
                RoutePreference.FREE -> "&avoid=toll"
                RoutePreference.OPTIMAL -> "&avoid=toll|ferries"
                else -> ""
            }
            val url = "https://apis-navi.kakaomobility.com/v1/directions" +
                "?origin=${origin.longitude},${origin.latitude}" +
                "&destination=${destination.longitude},${destination.latitude}" +
                "&priority=$priority&alternatives=true&road_details=false&summary=false$avoid"

            val req = Request.Builder().url(url)
                .addHeader("Authorization", "KakaoAK $key")
                .build()

            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: "{}"
                if (!resp.isSuccessful) return@use Result.failure(IOException("카카오 경로 실패 HTTP ${resp.code}"))
                val json = JSONObject(body)
                val routesArr = json.optJSONArray("routes")
                    ?: return@use Result.failure(IOException("카카오 경로 없음"))

                val results = mutableListOf<RouteResult>()
                for (r in 0 until routesArr.length()) {
                    val route = routesArr.getJSONObject(r)
                    if (route.optInt("result_code", 0) != 0) continue
                    val summary = route.getJSONObject("summary")
                    val totalDist = summary.getInt("distance")
                    val totalDur = summary.getInt("duration") // 실시간 교통 반영 소요시간(초)

                    val points = mutableListOf<LatLngPoint>()
                    val steps = mutableListOf<RouteStep>()
                    val sections = route.optJSONArray("sections")
                    if (sections != null) {
                        for (s in 0 until sections.length()) {
                            val sec = sections.getJSONObject(s)
                            // 좌표: roads[].vertexes = [x,y,x,y,...] (경도,위도 순)
                            val roads = sec.optJSONArray("roads")
                            if (roads != null) {
                                for (rd in 0 until roads.length()) {
                                    val v = roads.getJSONObject(rd).optJSONArray("vertexes") ?: continue
                                    var i = 0
                                    while (i + 1 < v.length()) {
                                        points.add(LatLngPoint(v.getDouble(i + 1), v.getDouble(i)))
                                        i += 2
                                    }
                                }
                            }
                            // 안내점: guides[] -> RouteStep (좌회전/우회전/회전교차로 출구 등 한글 안내 포함)
                            val guides = sec.optJSONArray("guides")
                            if (guides != null) {
                                for (g in 0 until guides.length()) {
                                    val gd = guides.getJSONObject(g)
                                    val loc = LatLngPoint(gd.optDouble("y", 0.0), gd.optDouble("x", 0.0))
                                    val guidance = gd.optString("guidance", "").ifBlank { gd.optString("name", "직진") }
                                    steps.add(
                                        RouteStep(
                                            instruction = guidance,
                                            distanceMeters = gd.optInt("distance", 0),
                                            durationSeconds = gd.optInt("duration", 0),
                                            startLocation = loc,
                                            endLocation = loc,
                                            maneuver = kakaoTypeToManeuver(gd.optInt("type", 0))
                                        )
                                    )
                                }
                            }
                        }
                    }
                    if (points.size < 2) continue
                    results.add(
                        RouteResult(
                            steps = steps,
                            totalDistanceMeters = totalDist,
                            totalDurationSeconds = totalDur,
                            overviewPolyline = encodePolyline5(points),
                            mode = mode
                        )
                    )
                }
                results.sortBy { it.totalDurationSeconds }
                if (results.isEmpty()) Result.failure(IOException("카카오 경로 파싱 실패"))
                else Result.success(results)
            }
        } catch (e: Exception) { Result.failure(e) }
    }

    /** 카카오 guide type 코드 -> 우리 maneuver 문자열 (음성/차선 아이콘 매핑용) */
    private fun kakaoTypeToManeuver(type: Int): String = when (type) {
        1 -> "turn-left"; 2 -> "turn-right"
        3 -> "turn-slight-left"; 4 -> "turn-slight-right"
        5 -> "uturn"
        6, 7 -> "turn-sharp-left"; 8 -> "turn-sharp-right"
        11, 12, 13, 14 -> "roundabout" // 회전교차로 (출구 번호는 guidance 문장에 포함됨)
        101 -> "merge"; 102 -> "ramp-left"; 103 -> "ramp-right"
        else -> "straight"
    }

    /** Google encoded polyline (precision 5) 인코더 - 기존 decodePolyline과 호환 */
    private fun encodePolyline5(points: List<LatLngPoint>): String {
        val sb = StringBuilder()
        var prevLat = 0L; var prevLng = 0L
        for (p in points) {
            val lat = Math.round(p.latitude * 1e5)
            val lng = Math.round(p.longitude * 1e5)
            encodeDiff(lat - prevLat, sb); encodeDiff(lng - prevLng, sb)
            prevLat = lat; prevLng = lng
        }
        return sb.toString()
    }

    private fun encodeDiff(diff: Long, sb: StringBuilder) {
        var v = diff shl 1
        if (diff < 0) v = v.inv()
        while (v >= 0x20) {
            sb.append(((0x20 or (v and 0x1f).toInt()) + 63).toChar())
            v = v shr 5
        }
        sb.append((v.toInt() + 63).toChar())
    }
}
