package com.navifit.navigation

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * OpenRouteService (ORS) 연동 - 호스팅된 무료 API, PC 서버 필요 없음.
 * OSM 데이터 기반이라 인도(foot-walking)/자전거도로(cycling-regular) 정보가 세분화되어 있음.
 *
 * 무료 키 발급 방법 (5분 소요):
 * 1. https://openrouteservice.org/dev/#/signup 에서 가입
 * 2. 로그인 후 대시보드에서 "Request a token" → 토큰 이름 아무거나 입력 → 발급
 * 3. 발급받은 키를 아래 API_KEY 상수에 붙여넣기
 *
 * ⚠️ 무료 등급 한도: 대략 하루 2,000건 안팎, 분당 40건 수준이에요 (정확한 수치는 로그인 후
 * 대시보드에서 확인 가능, 정책은 바뀔 수 있음). 개인 테스트/소규모 서비스엔 충분해요.
 * ⚠️ 오토바이 전용 프로필은 ORS에도 없어서 driving-car + avoid_features(고속도로 회피)로 처리.
 */
class OrsRepository(private val apiKey: String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    suspend fun fetchRoute(
        origin: LatLngPoint,
        destination: LatLngPoint,
        mode: TravelMode,
        preference: RoutePreference = RoutePreference.FAST,
        workoutPref: WorkoutRoutePreference = WorkoutRoutePreference.SHORTEST_TIME
    ): Result<RouteResult> = withContext(Dispatchers.IO) {
        try {
            val profile = when (mode) {
                TravelMode.WALK -> "foot-walking"
                TravelMode.BIKE -> "cycling-regular"
                TravelMode.MOTORCYCLE, TravelMode.CAR -> "driving-car"
            }
            // ✅ 경로 취향 반영: 오토바이는 항상 고속도로 회피 + 자동차는 선택 옵션에 따라 회피 항목 구성
            val avoidFeatures = buildList {
                if (mode == TravelMode.MOTORCYCLE) add("highways")
                if (!mode.isWorkoutMode) when (preference) {
                    RoutePreference.FREE -> add("tollways")
                    RoutePreference.OPTIMAL -> { add("tollways"); add("ferries") }
                    RoutePreference.FAST, RoutePreference.HIGHWAY -> {}
                }
            }.distinct()
            val avoidParam = if (avoidFeatures.isEmpty()) "" else {
                val joined = avoidFeatures.joinToString(",") { f -> "\"" + f + "\"" }
                "&options={\"avoid_features\":[" + joined + "]}"
            }
            // ✅ v76 달리기·자전거 경로 옵션 (최단시간/최단거리/직진/횡단보도우회)
            val prefParam = if (mode.isWorkoutMode) "&preference=${workoutPref.orsPreference}" else ""

            val url = "https://api.openrouteservice.org/v2/directions/$profile?" +
                "api_key=$apiKey&start=${origin.longitude},${origin.latitude}&end=${destination.longitude},${destination.latitude}$avoidParam$prefParam"

            val request = Request.Builder().url(url).build()

            client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string() ?: "{}"
                if (!response.isSuccessful) {
                    Result.failure(IOException("ORS 오류 (${response.code}): $bodyStr"))
                } else {
                    val json = JSONObject(bodyStr)
                    val features = json.optJSONArray("features")
                    if (features == null || features.length() == 0) {
                        Result.failure(IOException("ORS 경로 없음"))
                    } else {
                        val feature = features.getJSONObject(0)
                        val summary = feature.getJSONObject("properties").getJSONObject("summary")
                        val geometry = feature.getJSONObject("geometry")
                        val coords = geometry.getJSONArray("coordinates")

                        // ORS는 폴리라인이 아니라 좌표 배열(GeoJSON)로 줌 - 구글 인코딩 폴리라인으로 직접 변환
                        val points = (0 until coords.length()).map { i ->
                            val pt = coords.getJSONArray(i)
                            LatLngPoint(pt.getDouble(1), pt.getDouble(0))
                        }
                        val encoded = encodePolyline(points)

                        // 상세 턴바이턴 안내 파싱 (segments[].steps[])
                        val parsedSteps = mutableListOf<RouteStep>()
                        val segments = feature.getJSONObject("properties").optJSONArray("segments")
                        if (segments != null) {
                            for (si in 0 until segments.length()) {
                                val stepsArr = segments.getJSONObject(si).optJSONArray("steps") ?: continue
                                for (ti in 0 until stepsArr.length()) {
                                    val st = stepsArr.getJSONObject(ti)
                                    val wp = st.optJSONArray("way_points")
                                    val startIdx = wp?.optInt(0, 0) ?: 0
                                    val endIdx = wp?.optInt(1, startIdx) ?: startIdx
                                    val startPt = points.getOrNull(startIdx) ?: points.first()
                                    val endPt = points.getOrNull(endIdx) ?: points.last()
                                    parsedSteps.add(
                                        RouteStep(
                                            instruction = translateOrsInstruction(st.optString("instruction", ""), st.optInt("type", 11)),
                                            distanceMeters = st.optDouble("distance", 0.0).toInt(),
                                            durationSeconds = st.optDouble("duration", 0.0).toInt(),
                                            startLocation = startPt,
                                            endLocation = endPt,
                                            maneuver = orsTypeToManeuver(st.optInt("type", 11))
                                        )
                                    )
                                }
                            }
                        }

                        Result.success(
                            RouteResult(
                                steps = parsedSteps,
                                totalDistanceMeters = summary.getDouble("distance").toInt(),
                                totalDurationSeconds = summary.getDouble("duration").toInt(),
                                overviewPolyline = encoded,
                                mode = mode
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Result.failure(IOException("ORS 연결 실패: ${e.message}"))
        }
    }

    /** 구글 표준 인코딩 폴리라인 알고리즘 (기존 디코더와 호환되게) */
    private fun encodePolyline(points: List<LatLngPoint>): String {
        val sb = StringBuilder()
        var prevLat = 0; var prevLng = 0
        points.forEach { p ->
            val lat = Math.round(p.latitude * 1e5).toInt()
            val lng = Math.round(p.longitude * 1e5).toInt()
            encodeValue(lat - prevLat, sb)
            encodeValue(lng - prevLng, sb)
            prevLat = lat; prevLng = lng
        }
        return sb.toString()
    }

    /** ORS 안내 타입 -> 표준 maneuver 문자열 */
    private fun orsTypeToManeuver(type: Int): String = when (type) {
        0 -> "turn-left"
        1 -> "turn-right"
        2 -> "turn-sharp-left"
        3 -> "turn-sharp-right"
        4 -> "turn-slight-left"
        5 -> "turn-slight-right"
        6 -> "straight"
        7 -> "roundabout"
        8 -> "roundabout"
        9 -> "uturn"
        10 -> "arrive"
        11 -> "depart"
        12 -> "keep-left"
        13 -> "keep-right"
        else -> "straight"
    }

    /** ORS 영어 안내문을 자연스러운 한국어로 변환 */
    private fun translateOrsInstruction(raw: String, type: Int): String {
        // 도로명 추출 ("Turn left onto XX로" 형태)
        val road = Regex("onto (.+)$").find(raw)?.groupValues?.get(1)?.trim()
        val roadSuffix = if (!road.isNullOrBlank() && road != "-") " ($road)" else ""
        return when (type) {
            0 -> "좌회전하세요$roadSuffix"
            1 -> "우회전하세요$roadSuffix"
            2 -> "크게 좌회전하세요$roadSuffix"
            3 -> "크게 우회전하세요$roadSuffix"
            4 -> "약간 왼쪽 방향입니다$roadSuffix"
            5 -> "약간 오른쪽 방향입니다$roadSuffix"
            6 -> "직진하세요$roadSuffix"
            7, 8 -> "회전교차로에서 진행하세요$roadSuffix"
            9 -> "유턴하세요"
            10 -> "목적지에 도착했습니다"
            11 -> "출발합니다$roadSuffix"
            12 -> "왼쪽 차선을 유지하세요$roadSuffix"
            13 -> "오른쪽 차선을 유지하세요$roadSuffix"
            else -> raw.ifBlank { "계속 진행하세요" }
        }
    }

    private fun encodeValue(value: Int, sb: StringBuilder) {
        var v = value shl 1
        if (value < 0) v = v.inv()
        while (v >= 0x20) {
            sb.append(((0x20 or (v and 0x1f)) + 63).toChar())
            v = v shr 5
        }
        sb.append((v + 63).toChar())
    }
}
