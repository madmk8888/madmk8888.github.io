package com.navifit.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.maps.android.compose.*
import com.navifit.data.ActivityRecord
import com.navifit.navigation.TravelMode

/**
 * ✅ v60 운동 종료 결과 화면.
 *  · 운동 이력은 이미 자동 저장된 상태(무조건 보관됨).
 *  · 여기서는 결과 요약(시간·거리·속도·페이스) + 예상 랭킹을 보여주고,
 *    "경로 저장" 버튼으로 이 코스를 보관함에 이름/폴더 지정해서 저장.
 */
@Composable
fun WorkoutResultScreen(
    record: ActivityRecord,
    rankingValid: Boolean,
    estimatedRank: Int?,
    folders: List<String>,
    askFolderOnSave: Boolean,      // 설정: 경로 저장 시 폴더 선택 물어보기
    onSaveRoute: (name: String, folder: String) -> Unit,
    onShareToCommunity: ((String) -> Unit)? = null,   // ✅ v81 사용자가 수정한 글로 게시
    onClose: () -> Unit
) {
    var showSaveDialog by remember { mutableStateOf(false) }
    var routeSaved by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier.fillMaxWidth(0.92f)
                .background(Color(0xFF15171C), RoundedCornerShape(24.dp))
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(if (record.mode == TravelMode.BIKE) "🚴" else "🏃", fontSize = 40.sp)
            Text("운동 완료!", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text("운동 이력은 자동으로 저장됐어요", fontSize = 11.sp, color = Color(0xFF8B93AC))
            Spacer(Modifier.height(14.dp))

            // ✅ v63 경로 미리보기 지도 (내가 뛴 궤적을 보여줌)
            record.pathPolyline?.let { poly ->
                val pts = remember(poly) { decodePolyline(poly).map { LatLng(it.latitude, it.longitude) } }
                if (pts.size >= 2) {
                    val camState = rememberCameraPositionState()
                    LaunchedEffect(pts) {
                        val b = LatLngBounds.builder(); pts.forEach { b.include(it) }
                        try { camState.move(CameraUpdateFactory.newLatLngBounds(b.build(), 80)) } catch (_: Exception) {}
                    }
                    Box(Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(16.dp))) {
                        GoogleMap(
                            modifier = Modifier.fillMaxSize(),
                            cameraPositionState = camState,
                            uiSettings = MapUiSettings(zoomControlsEnabled = false, scrollGesturesEnabled = false,
                                zoomGesturesEnabled = false, rotationGesturesEnabled = false, tiltGesturesEnabled = false)
                        ) {
                            Polyline(points = pts, color = if (record.mode == TravelMode.BIKE) Color(0xFF2E9BFF) else Color(0xFF34D399), width = 12f)
                            Marker(state = MarkerState(pts.first()), title = "출발")
                            Marker(state = MarkerState(pts.last()), title = "도착")
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                }
            }

            // 결과 스탯 그리드
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                ResultStat("거리", "%.2f".format(record.distanceMeters / 1000), "km", Color(0xFF6FE3A5))
                ResultStat("시간", "%d:%02d".format(record.durationSeconds / 60, record.durationSeconds % 60), "", Color.White)
                ResultStat("속도", "%.1f".format(record.avgSpeedKmh), "km/h", Color(0xFF7CC7FF))
            }
            Spacer(Modifier.height(14.dp))
            val paceSecPerKm = if (record.distanceMeters > 50)
                (record.durationSeconds.toDouble() / (record.distanceMeters / 1000)) else 0.0
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                ResultStat("평균 페이스",
                    if (paceSecPerKm > 0) "%d'%02d\"".format((paceSecPerKm / 60).toInt(), (paceSecPerKm % 60).toInt()) else "-",
                    "/km", Color(0xFFFFC879))
                // 예상 랭킹
                ResultStat("예상 순위",
                    if (rankingValid && estimatedRank != null) "$estimatedRank" else "-",
                    if (rankingValid && estimatedRank != null) "위" else "", Color(0xFFFFD22E))
            }

            if (!rankingValid) {
                Spacer(Modifier.height(10.dp))
                Text("⚠️ 이 기록은 순위/점수에는 반영되지 않아요 (개인 기록으로는 저장됨)",
                    fontSize = 11.sp, color = Color(0xFFFF8FA3), textAlign = TextAlign.Center)
            }

            Spacer(Modifier.height(22.dp))

            if (record.pathPolyline != null && !routeSaved) {
                Button(
                    onClick = {
                        if (askFolderOnSave) showSaveDialog = true
                        else { onSaveRoute("", "운동 이력"); routeSaved = true }
                    },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0095F6))
                ) { Text("💾 경로 저장", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold) }
                Spacer(Modifier.height(8.dp))
            } else if (routeSaved) {
                Text("✅ 경로가 보관함에 저장됐어요", color = Color(0xFF6FE3A5), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
            }

            // ✅ v65 경로 자랑 게시 (운동장에 바로 올리기) + v78 확인 팝업
            if (onShareToCommunity != null && record.pathPolyline != null) {
                var confirmShare by remember { mutableStateOf(false) }
                OutlinedButton(
                    onClick = { confirmShare = true },
                    modifier = Modifier.fillMaxWidth().height(46.dp),
                    shape = RoundedCornerShape(14.dp)
                ) { Text("📣 운동장에 자랑하기", fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.height(8.dp))
                if (confirmShare) {
                    // ✅ v81 자동 완성된 글을 팝업에서 직접 수정한 뒤 게시할 수 있게
                    val durTxt = run {
                        val d = record.durationSeconds
                        if (d >= 3600) "%d시간 %d분".format(d / 3600, (d % 3600) / 60)
                        else "%d분 %d초".format(d / 60, d % 60)
                    }
                    var shareText by remember {
                        mutableStateOf(
                            "%s %.2fkm 완주! ⏱ %s · 평균 %.1fkm/h\n오늘도 해냈어요 💪".format(
                                if (record.mode == com.navifit.navigation.TravelMode.BIKE) "🚴 자전거" else "🏃 러닝",
                                record.distanceMeters / 1000, durTxt, record.avgSpeedKmh
                            )
                        )
                    }
                    AlertDialog(
                        onDismissRequest = { confirmShare = false },
                        title = { Text("운동장에 게시할까요?") },
                        text = {
                            Column {
                                Text("아래 내용으로 글이 올라가요. 필요하면 수정할 수 있어요.",
                                    fontSize = 12.sp, color = Color(0xFF8B93AC))
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = shareText,
                                    onValueChange = { if (it.length <= 500) shareText = it },
                                    modifier = Modifier.fillMaxWidth().height(130.dp),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                Spacer(Modifier.height(6.dp))
                                Text("경로 공유키는 게시할 때 자동으로 붙습니다.",
                                    fontSize = 10.sp, color = Color(0xFF8B93AC))
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = { confirmShare = false; onShareToCommunity(shareText) }) { Text("게시") }
                        },
                        dismissButton = { TextButton(onClick = { confirmShare = false }) { Text("취소") } }
                    )
                }
            }

            TextButton(onClick = onClose) { Text("닫기", color = Color(0xFF8B93AC)) }
        }
    }

    // 경로 이름 + 폴더 선택 다이얼로그
    if (showSaveDialog) {
        var routeName by remember { mutableStateOf("") }
        var selectedFolder by remember { mutableStateOf(folders.firstOrNull() ?: "운동 이력") }
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("경로 저장") },
            text = {
                Column {
                    OutlinedTextField(
                        value = routeName, onValueChange = { routeName = it.take(20) },
                        placeholder = { Text("코스 이름 (예: 한강 야경 코스)") }, singleLine = true
                    )
                    Spacer(Modifier.height(12.dp))
                    Text("폴더 선택", fontSize = 12.sp, color = Color(0xFF8B93AC))
                    Spacer(Modifier.height(4.dp))
                    folders.forEach { f ->
                        Row(Modifier.fillMaxWidth().clickable { selectedFolder = f }.padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = selectedFolder == f, onClick = { selectedFolder = f })
                            Text("📁 $f", fontSize = 14.sp)
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    onSaveRoute(routeName, selectedFolder)
                    showSaveDialog = false; routeSaved = true
                }) { Text("저장") }
            },
            dismissButton = { TextButton(onClick = { showSaveDialog = false }) { Text("취소") } }
        )
    }
}

@Composable
private fun ResultStat(label: String, value: String, unit: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, fontSize = 11.sp, color = Color(0xFF8B93AC))
        Spacer(Modifier.height(3.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = color)
            if (unit.isNotEmpty()) {
                Spacer(Modifier.width(2.dp))
                Text(unit, fontSize = 11.sp, color = Color(0xFF8B93AC), modifier = Modifier.padding(bottom = 4.dp))
            }
        }
    }
}
