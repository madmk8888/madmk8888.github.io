package com.navifit.monetization

/**
 * 리워드 광고 연동 매니저.
 *
 * ⚠️ 현재 상태: 과금/실제 광고 SDK 연동은 비활성화되어 있음.
 * ENABLE_REAL_ADS 를 true로 바꾸고, 주석 처리된 AdMob 연동 코드의 주석을 해제하면
 * 실제 리워드 광고가 붙습니다. 지금은 "광고 봤다고 치고" 바로 보상 콜백이 실행돼요.
 *
 * 실제 연동 시 필요한 것:
 * 1. build.gradle에 com.google.android.gms:play-services-ads 추가
 * 2. AndroidManifest.xml에 AdMob App ID 메타데이터 추가
 * 3. 아래 REWARD_AD_UNIT_ID를 실제 발급받은 광고 단위 ID로 교체
 */
object RewardAdManager {

    // 기능 스위치 - 나중에 true로 바꾸면 실제 광고 로직 활성화
    private const val ENABLE_REAL_ADS = false

    // 실제 배포 전 AdMob 콘솔에서 발급받은 리워드 광고 단위 ID로 교체 필요
    private const val REWARD_AD_UNIT_ID = "ca-app-pub-XXXXXXXXXXXXXXXX/YYYYYYYYYY"

    /**
     * 리워드 광고를 보여주고, 시청 완료 시 onRewardEarned 콜백 실행.
     * 지금은 ENABLE_REAL_ADS = false 라서 광고 없이 바로 보상 지급 (테스트/개발용).
     */
    // ✅ 연타 방지: 한 번에 하나의 광고 세션만 허용 + 보상 지급 후 최소 쿨다운
    @Volatile private var adSessionActive = false
    @Volatile private var lastRewardAtMs = 0L
    private const val MIN_INTERVAL_MS = 2500L   // 뽑기 연출이 끝나기 전 연타로 중복 뽑기 방지

    fun showRewardedAd(
        onRewardEarned: () -> Unit,
        onAdFailedOrSkipped: (() -> Unit)? = null
    ) {
        val now = System.currentTimeMillis()
        // ✅ 이미 광고/뽑기 진행 중이거나 쿨다운이 안 지났으면 무시 (연타 버그 수정)
        if (adSessionActive || now - lastRewardAtMs < MIN_INTERVAL_MS) {
            onAdFailedOrSkipped?.invoke()
            return
        }
        adSessionActive = true

        if (!ENABLE_REAL_ADS) {
            // 개발 단계: 광고 없이 바로 보상 지급
            lastRewardAtMs = System.currentTimeMillis()
            adSessionActive = false
            onRewardEarned()
            return
        }

        // ↓↓↓ 실제 배포 시 아래 주석 해제하고 위 if문 제거 ↓↓↓
        // ⚠️ 실광고 연동 시에도 반드시 콜백에서 adSessionActive = false / lastRewardAtMs 갱신을 해야
        //    연타 방지가 유지됩니다 (아래 주석 코드에 이미 반영해둠).
        /*
        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(
            context,
            REWARD_AD_UNIT_ID,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(rewardedAd: RewardedAd) {
                    rewardedAd.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() { adSessionActive = false }
                        override fun onAdFailedToShowFullScreenContent(e: AdError) {
                            adSessionActive = false; onAdFailedOrSkipped?.invoke()
                        }
                    }
                    rewardedAd.show(activity) { rewardItem ->
                        lastRewardAtMs = System.currentTimeMillis()
                        onRewardEarned()
                    }
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    adSessionActive = false
                    onAdFailedOrSkipped?.invoke()
                }
            }
        )
        */
    }

    /** 하루 무료 뽑기 횟수 제한 등 정책은 여기서 관리 (지금은 무제한, 나중에 제한 로직 추가 가능) */
    fun canWatchAdNow(): Boolean = true
}
