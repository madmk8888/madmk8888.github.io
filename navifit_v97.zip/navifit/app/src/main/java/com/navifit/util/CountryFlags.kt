package com.navifit.util

/**
 * ISO 3166-1 alpha-2 국가코드(예: "KR", "JP")를 국기 이모지로 변환.
 * 유니코드 Regional Indicator Symbol 조합 방식 (전 세계 국기를 다 하드코딩할 필요 없음).
 */
fun countryCodeToFlag(countryCode: String?): String {
    val code = countryCode?.uppercase()?.takeIf { it.length == 2 } ?: return "🌍"
    return try {
        val first = Character.codePointAt(code, 0) - 'A'.code + 0x1F1E6
        val second = Character.codePointAt(code, 1) - 'A'.code + 0x1F1E6
        String(Character.toChars(first)) + String(Character.toChars(second))
    } catch (e: Exception) { "🌍" }
}
