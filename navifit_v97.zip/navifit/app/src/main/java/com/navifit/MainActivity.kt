package com.navifit

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.room.Room
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.net.PlacesClient
import com.navifit.auth.AuthRepository
import com.navifit.auth.NicknameManager
import com.navifit.auth.UserProfile
import com.navifit.auth.UserProfileRepository
import com.navifit.data.ActivityRecord
import com.navifit.data.AppDatabase
import com.navifit.gacha.GachaInventory
import com.navifit.monetization.RewardAdManager
import com.navifit.navigation.*
import com.navifit.tracking.AntiCheatMonitor
import com.navifit.tracking.LocationTrackingService
import com.navifit.tracking.SafetyScoreTracker
import com.navifit.tracking.SessionGuard
import com.navifit.tracking.StepCounterService
import com.navifit.ui.screens.*
import com.navifit.i18n.*
import com.navifit.voice.VoiceGuidanceManager
import com.navifit.workout.WorkoutAnalyzer
import kotlinx.coroutines.launch

/**
 * NaviFit 메인 (v17).
 * 탭: 길찾기 / 뽑기 / 분석 / 랭킹 / 커뮤 / 내정보
 *
 * ⚠️ 실행 전 필수:
 * 1. AndroidManifest.xml 의 Google Maps API 키 확인
 * 2. Cloud Console에서 Maps SDK for Android + Directions API + Places API 활성화
 * 3. Firebase 콘솔에서 Authentication(구글+익명) 활성화 + google-services.json 을 app/ 에 배치
 */
// ✅ v74 테마 변경 함수를 하위 컴포저블(설정 화면)에서 호출할 수 있게 하는 CompositionLocal
val LocalThemeSetter = androidx.compose.runtime.staticCompositionLocalOf<(String) -> Unit> { {} }

class MainActivity : ComponentActivity() {

    // ✅ v59: 안내가 실제 진행 중인지 (startNavigation에서 출발지 GPS 판단용)
    @Volatile private var navFlowActive = false

    // ✅ v60: 운동 종료 후 결과 화면을 띄우는 콜백 (Compose에서 설정)
    private var workoutResult: ((com.navifit.data.ActivityRecord, Boolean) -> Unit)? = null

    // ✅ v65 VS 100m 측정 코루틴
    private var vsMeasureJob: kotlinx.coroutines.Job? = null

    private lateinit var db: AppDatabase
    private lateinit var inventory: GachaInventory
    private lateinit var voice: VoiceGuidanceManager
    private var warnToneRef: android.media.ToneGenerator? = null   // ✅ v34 onDestroy에서 해제 (누수 방지)
    private lateinit var routing: HybridRoutingRepository
    private lateinit var placesClient: PlacesClient

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* 결과는 각 기능 사용 시점에 다시 확인 */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ✅ v91 네트워크 상태 실시간 감시 시작 (오프라인 안내용)
        com.navifit.tracking.NetworkMonitor.start(this)

        db = Room.databaseBuilder(applicationContext, AppDatabase::class.java, "navifit-db")
            .fallbackToDestructiveMigration() // 개발단계: 스키마 바뀌면 재생성 (배포 전 마이그레이션으로 교체)
            .build()
        inventory = GachaInventory(this)
        voice = VoiceGuidanceManager(this)
        // ✅ v46: 모든 API 키를 assets/api_keys.properties 한 파일에서 읽음 (하드코딩 제거)
        routing = HybridRoutingRepository(
            ors = OrsRepository(apiKey = com.navifit.navigation.NavApiKeys.orsKey(this)),
            googleFallback = GoogleFallbackRepository(apiKey = com.navifit.navigation.NavApiKeys.googleMapsKey(this)),
            kakao = KakaoRoutingRepository(this),
            appContext = applicationContext
        )
        if (!Places.isInitialized()) {
            Places.initialize(applicationContext, com.navifit.navigation.NavApiKeys.googleMapsKey(this))
        }
        placesClient = Places.createClient(this)

        permissionLauncher.launch(arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACTIVITY_RECOGNITION,
            Manifest.permission.POST_NOTIFICATIONS
        ))

        setContent {
            var language by remember {
                mutableStateOf(
                    AppLanguage.entries.find {
                        it.code == getSharedPreferences("settings", Context.MODE_PRIVATE).getString("lang", "ko")
                    } ?: AppLanguage.KOREAN
                )
            }
            fun setLanguage(lang: AppLanguage) {
                language = lang
                getSharedPreferences("settings", Context.MODE_PRIVATE).edit().putString("lang", lang.code).apply()
                com.navifit.i18n.TranslationCache.clearMemory()   // ✅ v43 언어 바꾸면 메모리 캐시 리셋
            }
            CompositionLocalProvider(
                LocalAppLanguage provides language,
                LocalStrings provides stringsFor(language)
            ) {
                // ✅ v74 다크/라이트 테마 선택 (설정에서 변경). 기본=다크.
                var themeMode by remember { mutableStateOf(
                    getSharedPreferences("settings", Context.MODE_PRIVATE).getString("theme", "dark") ?: "dark"
                ) }
                val darkScheme = darkColorScheme(
                    primary = Color(0xFF3B82F6),
                    onPrimary = Color.White,
                    primaryContainer = Color(0xFF243247),
                    onPrimaryContainer = Color(0xFFD6E4FF),
                    secondary = Color(0xFF34D399),
                    tertiary = Color(0xFFFBBF6E),
                    background = Color(0xFF16181D),
                    onBackground = Color(0xFFECEEF2),
                    surface = Color(0xFF1F2229),
                    onSurface = Color(0xFFECEEF2),
                    surfaceVariant = Color(0xFF262A33),
                    onSurfaceVariant = Color(0xFFAAB0BD),
                    outline = Color(0xFF2E323C),
                    outlineVariant = Color(0xFF23262F)
                )
                // ✅ v81 화이트 테마 배색 전면 재구성
                //   · 배경을 살짝 따뜻한 오프화이트로 (순백은 눈이 부시고 카드 경계가 안 보임)
                //   · 카드(surface)는 순백 → 배경과 자연스럽게 대비되어 "은은한 박스"가 됨
                //   · 글자는 충분히 진한 잉크색으로 (대비 확보 → 글자 안 보이는 문제 해결)
                //   · 버튼(primary)은 진한 블루 + 흰 글자로 항상 읽히게
                // ✅ v86 화이트 테마 = 로즈/핑크 톤으로 고급스럽게 재배색.
                //   기존 파랑 계열이 딱딱하고 검은 버튼이 튀어 보인다는 피드백 반영.
                //   포인트=딥 로즈, 배경=아주 옅은 웜 핑크, 카드=순백 → 부드럽고 정돈된 느낌.
                val lightScheme = lightColorScheme(
                    primary = Color(0xFFC2185B),          // 딥 로즈 (버튼 배경)
                    onPrimary = Color.White,              // 버튼 위 글자
                    primaryContainer = Color(0xFFFCE1EC), // 선택된 칩 배경 (연한 핑크)
                    onPrimaryContainer = Color(0xFF6D0F35),
                    secondary = Color(0xFF00796B),        // 청록 (핑크와 보색 균형)
                    onSecondary = Color.White,
                    tertiary = Color(0xFFAD5A2E),         // 테라코타
                    onTertiary = Color.White,
                    background = Color(0xFFFDF7F9),       // 아주 옅은 웜 핑크 배경
                    onBackground = Color(0xFF1F1216),     // 웜 블랙 (제목)
                    surface = Color(0xFFFFFFFF),          // 카드=순백
                    onSurface = Color(0xFF1F1216),        // 카드 위 본문
                    surfaceVariant = Color(0xFFF6E7ED),   // 보조 칩/입력 배경 (핑크 그레이)
                    onSurfaceVariant = Color(0xFF6B4A56), // 보조 글자 (웜 그레이)
                    outline = Color(0xFFD9BCC7),
                    outlineVariant = Color(0xFFEEDDE4),   // 은은한 카드 테두리
                    error = Color(0xFFB3261E),
                    onError = Color.White
                )
                val useDark = themeMode != "light"
                val scheme = if (useDark) darkScheme else lightScheme
                CompositionLocalProvider(LocalThemeSetter provides { mode ->
                    themeMode = mode
                    getSharedPreferences("settings", Context.MODE_PRIVATE).edit().putString("theme", mode).apply()
                }) {
                MaterialTheme(colorScheme = scheme) {
                    Surface(Modifier.fillMaxSize(), color = scheme.background) {
                        NaviFitApp(currentLanguage = language, onLanguageChange = ::setLanguage)
                    }
                }
                }
            }
        }
    }

    // =====================================================================================
    //  앱 루트: 로그인 -> (구글이면 닉네임 설정) -> 메인 탭
    // =====================================================================================
    @Composable
    fun NaviFitApp(currentLanguage: AppLanguage, onLanguageChange: (AppLanguage) -> Unit) {
        val strings = LocalStrings.current
        val auth = remember { AuthRepository(this@MainActivity) }
        val nicknameManager = remember { NicknameManager() }
        val profileRepo = remember { UserProfileRepository(this@MainActivity) }
        val scope = rememberCoroutineScope()

        // auth 단계: LOADING(자동로그인 확인) -> LOGIN(선택화면) -> NICKNAME(구글 신규) -> READY
        var stage by remember { mutableStateOf("LOADING") }
        var busy by remember { mutableStateOf(false) }
        var nickname by remember { mutableStateOf("게스트") }
        // ✅ v48: 알림·팔로우 등에서 쓰는 내 uid (컴포저블 스코프에 없어서 컴파일 에러였음)
        val myUid = auth.currentUser()?.uid ?: ""
        var isAnonymous by remember { mutableStateOf(true) }
        var googleEmail by remember { mutableStateOf<String?>(null) }
        var myUniqueCode by remember { mutableStateOf<String?>(null) }
        val codeManagerTop = remember { com.navifit.social.UniqueCodeManager() }

        // ✅ v43: 토스트도 선택 언어로 자동 번역 (한국어면 즉시, 다른 언어면 캐시 → 번역)
        fun toast(msg: String) {
            val lang = com.navifit.i18n.LanguageStore.current(this@MainActivity).code
            if (lang == "ko") {
                android.widget.Toast.makeText(this@MainActivity, msg, android.widget.Toast.LENGTH_LONG).show()
                return
            }
            val cached = com.navifit.i18n.TranslationCache.get(this@MainActivity, msg, lang)
            if (cached != null) {
                android.widget.Toast.makeText(this@MainActivity, cached, android.widget.Toast.LENGTH_LONG).show()
                return
            }
            // 번역 준비 전엔 원문을 먼저 보여주고, 번역되면 캐시에 저장 (다음부터 번역본)
            android.widget.Toast.makeText(this@MainActivity, msg, android.widget.Toast.LENGTH_LONG).show()
            lifecycleScope.launch {
                com.navifit.i18n.TranslationService.translate(msg, "ko", lang)?.let {
                    com.navifit.i18n.TranslationCache.put(this@MainActivity, msg, lang, it)
                }
            }
        }

        /** 로그인 성공 후 프로필 복원 or 신규 설정으로 분기 */
        suspend fun afterSignIn() {
            val user = auth.currentUser() ?: run { stage = "LOGIN"; return }
            isAnonymous = user.isAnonymous
            googleEmail = user.email
            // ✅ 무한로딩 수정: 서버 응답이 늦으면(8초) 프로필 없음으로 간주하고 진행
            //    (오프라인·Firebase 설정 문제 시 앱이 로딩 화면에 영원히 갇히던 문제)
            val restored = kotlinx.coroutines.withTimeoutOrNull(8_000L) { profileRepo.load(user.uid) }
            // ✅ 개인 고유코드(국가+번호) 발급/조회 - 한 번 만들어지면 평생 유지, RM/친구추가에 사용
            val deviceCountry = java.util.Locale.getDefault().country.ifBlank { "XX" }
            scope.launch { myUniqueCode = codeManagerTop.getOrCreate(user.uid, deviceCountry) }
            if (restored != null) {
                // ✅ 재로그인: 이전 정보 복원
                nickname = restored.nickname
                stage = "READY"
            } else if (user.isAnonymous) {
                // ✅ 비회원: 닉네임 자동 생성 - 서버 지연 시 로컬 생성으로 폴백 (무한로딩 방지)
                nickname = kotlinx.coroutines.withTimeoutOrNull(6_000L) {
                    nicknameManager.generateGuestNickname(user.uid)
                } ?: "러너${(1000..9999).random()}"
                kotlinx.coroutines.withTimeoutOrNull(5_000L) {
                    profileRepo.save(UserProfile(user.uid, nickname, true, null))
                }
                stage = "READY"
            } else {
                // 구글 신규 가입: 닉네임 설정 필요
                stage = "NICKNAME"
            }
        }

        // 앱 시작: 기존 로그인 세션이 있으면 그대로 복원, 없으면 로그인 화면
        LaunchedEffect(Unit) {
            if (!com.navifit.social.FirebaseGuard.available(this@MainActivity)) {
                // ✅ google-services.json이 없어도 앱은 켜지게: 오프라인 게스트 모드
                //    (내비·운동·뽑기·로컬 운동장은 전부 정상. 구글로그인/친구/DM/공유키 서버조회만 꺼짐)
                nickname = "게스트(오프라인)"
                stage = "READY"
                toast("⚠️ Firebase 미설정 상태로 실행 중이에요. app/google-services.json을 넣고 다시 빌드하면 로그인·친구·RM이 켜집니다")
            } else if (auth.currentUser() != null) afterSignIn() else stage = "LOGIN"
            // ✅ 만보기 자동 시작: 버튼 없이, 권한만 있으면 앱이 켜져 있는 동안 항상 측정
            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED) {
                StepCounterService.start(this@MainActivity)
            }
        }

        val googleLoginLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            scope.launch {
                busy = true
                // ✅ 무한로딩 수정: 로그인 처리 전체에 20초 제한 (넘으면 원인 안내 후 버튼 복구)
                val done = kotlinx.coroutines.withTimeoutOrNull(20_000L) {
                    auth.handleGoogleSignInResult(result.data)
                        .onSuccess { afterSignIn() }
                        .onFailure { toast("구글 로그인 실패: ${it.message}") }
                    true
                }
                if (done == null) toast("⏱️ 로그인 응답이 없어요. 인터넷 연결과 Firebase 설정(오류10: SHA-1 지문 등록 여부)을 확인해주세요")
                busy = false
            }
        }

        // ✅ 첫 화면 스플래시(RRN: Running·Ranking·Navi) - 로그인 상태 확인은 백그라운드에서 동시에 진행되고,
        //    스플래시 연출이 끝나면 그때 이미 정해진 stage(LOADING/LOGIN/READY 등)로 자연스럽게 넘어감
        var splashDone by remember { mutableStateOf(false) }
        if (!splashDone) {
            SplashScreen(onFinished = { splashDone = true })
            return
        }

        when (stage) {
            "LOADING" -> {
                // ✅ 무한로딩 방지 워치독: 12초 안에 준비가 안 되면 로그인 화면으로
                LaunchedEffect(Unit) {
                    kotlinx.coroutines.delay(12_000L)
                    if (stage == "LOADING") {
                        toast("서버 응답이 늦어 로그인 화면으로 이동했어요")
                        stage = "LOGIN"
                    }
                }
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                return
            }
            "LOGIN" -> {
                LoginScreen(
                    busy = busy,
                    onGoogleLogin = { googleLoginLauncher.launch(auth.getGoogleSignInIntent()) },
                    onGuestLogin = {
                        // ✅ v58 비회원 로그인 전면 수정:
                        //   서버(익명 인증)가 실패하거나 10초 안에 응답이 없으면
                        //   "오프라인 게스트"로라도 무조건 앱에 들어가짐 (무한로딩·막다른길 제거)
                        scope.launch {
                            busy = true
                            val ok = kotlinx.coroutines.withTimeoutOrNull(10_000L) {
                                auth.ensureSignedIn().isSuccess
                            } ?: false
                            if (ok) {
                                kotlinx.coroutines.withTimeoutOrNull(8_000L) { afterSignIn() }
                                if (stage != "READY" && stage != "NICKNAME") {
                                    nickname = "러너${(1000..9999).random()}"
                                    stage = "READY"
                                }
                            } else {
                                nickname = "러너${(1000..9999).random()}"
                                isAnonymous = true
                                stage = "READY"
                                toast("📡 서버 연결이 원활하지 않아 오프라인 게스트로 시작했어요. 친구/DM은 연결이 회복되면 사용 가능해요")
                            }
                            busy = false
                        }
                    }
                )
                return
            }
            "NICKNAME" -> {
                // 구글 신규 가입: 중복 안 되는 닉네임 설정
                GoogleNicknameSetupDialog(
                    nicknameManager = nicknameManager,
                    onClaim = { input, done ->
                        scope.launch {
                            // ✅ v62: Firestore 오류(권한 거부 등)로 앱이 죽던 문제 방지 - 전부 감싸서 처리
                            try {
                                val uid = auth.currentUser()?.uid ?: return@launch done(false, "로그인 상태를 확인할 수 없어요")
                                val r = kotlinx.coroutines.withTimeoutOrNull(12_000) {
                                    nicknameManager.claim(input, uid)
                                }
                                when (r) {
                                    is NicknameManager.ClaimResult.Success -> {
                                        nickname = input
                                        try { profileRepo.save(UserProfile(uid, input, false, auth.currentUser()?.email)) } catch (_: Exception) {}
                                        stage = "READY"
                                        done(true, "")
                                    }
                                    is NicknameManager.ClaimResult.Taken -> done(false, "이미 사용 중인 닉네임이에요 😢")
                                    is NicknameManager.ClaimResult.Error -> done(false, r.message)
                                    null -> {
                                        // 타임아웃/서버 무응답 → 일단 입장시키고 로컬 닉네임 사용 (앱이 멈추지 않게)
                                        nickname = input
                                        stage = "READY"
                                        done(true, "")
                                    }
                                }
                            } catch (e: Exception) {
                                // 권한 거부(Permission denied) 등 → 막다른 길 대신 로컬 진행
                                nickname = input
                                stage = "READY"
                                done(true, "")
                            }
                        }
                    }
                )
                return
            }
        }

        // ================================ 메인 탭 ================================
        // ✅ key(stage): 로그인/로그아웃으로 stage가 바뀔 때마다 아래 모든 remember 상태를
        //    완전히 새로 만들어서, 이전 세션의 잔여 상태 때문에 "재시작해야 반영되는" 문제를 방지
        key(stage) {
        var tab by remember { mutableStateOf(0) }
        // ✅ v66 VS 게임 상태: 탭을 바꿔도 대결이 유지되도록 앱 스코프에 보관
        val vsGameState = remember { com.navifit.ui.screens.VsGameState() }

        // 내비게이션 상태
        var navigating by remember { mutableStateOf(false) }
        var alreadyRunningWarn by remember { mutableStateOf(false) }   // ✅ v81 '이미 운동중' 팝업
        var vsLeaveWarn by remember { mutableStateOf(false) }          // ✅ v85 VS 진행 중 이탈 경고

        // ═══ ✅ v85 계층적 뒤로가기 ═══
        //  기존엔 BackHandler가 아예 없어서 어느 화면이든 뒤로가기를 누르면 앱이 바로 종료됐다.
        //  이제 "한 단계 위"로 이동하고, 최상위(운동 탭)에서만 두 번 눌러 종료한다.
        //  더 안쪽 화면(RM 대화, 프로필 등)은 각자 BackHandler를 갖고 있고,
        //  Compose는 가장 안쪽의 enabled BackHandler를 우선 처리하므로 자연스럽게 계층이 만들어진다.
        var lastBackPressAt by remember { mutableStateOf(0L) }
        androidx.activity.compose.BackHandler(enabled = true) {
            when {
                // 운동/안내 중이면 종료 확인 (실수로 기록 날리는 것 방지)
                navigating -> alreadyRunningWarn = true
                // 다른 탭이면 운동(홈) 탭으로
                tab != 0 -> tab = 0
                // 홈에서 두 번 연속 누르면 종료
                else -> {
                    val now = System.currentTimeMillis()
                    if (now - lastBackPressAt < 2000) finish()
                    else { lastBackPressAt = now; toast("한 번 더 누르면 종료돼요") }
                }
            }
        }

        // ✅ v63 매끄러운 1초 타이머: GPS 수신(1~6초 불규칙)에 의존하지 않고 매초 갱신 → 시간이 끊겨 오르던 문제 해결
        var liveElapsedSeconds by remember { mutableStateOf(0L) }
        LaunchedEffect(navigating) {
            while (navigating) {
                val st = LocationTrackingService.trackingState.value
                liveElapsedSeconds = if (st.startTimeMillis > 0 && !LocationTrackingService.paused)
                    (System.currentTimeMillis() - st.startTimeMillis) / 1000
                else st.elapsedSeconds
                kotlinx.coroutines.delay(1000)
            }
        }
        // ✅ v61 긴급 화장실 안내 상태
        var emergencyDetour by remember { mutableStateOf(false) }
        var emergencyBackupRoute by remember { mutableStateOf<RouteResult?>(null) }
        var emergencyBackupMode by remember { mutableStateOf<TravelMode?>(null) }
        // ✅ v60 운동 종료 결과 화면 상태
        var workoutResultData by remember { mutableStateOf<Pair<com.navifit.data.ActivityRecord, Boolean>?>(null) }
        LaunchedEffect(Unit) {
            workoutResult = { rec, valid -> workoutResultData = rec to valid }
        }
        var isFollowingSharedRoute by remember { mutableStateOf(false) }   // ✅ v58 공유경로 모드: 이탈해도 재탐색 안 함
        var route by remember { mutableStateOf<RouteResult?>(null) }
        var currentMode by remember { mutableStateOf(TravelMode.default()) }
        var currentOriginName by remember { mutableStateOf<String?>(null) }
        var currentDestName by remember { mutableStateOf<String?>(null) }
        var currentDest by remember { mutableStateOf<LatLngPoint?>(null) } // ✅ 재탐색용 목적지 좌표
        var lastHapticStepKey by remember { mutableStateOf("") }   // ✅ v90 회전 진동 중복 방지
        var lastKmMilestone by remember { mutableStateOf(0) }       // ✅ v90 1km 스플릿 진동
        var offRouteStreak by remember { mutableStateOf(0) }               // ✅ 연속 이탈 샘플 수 (오탐 방지)
        val offRouteDistHistory = remember { ArrayDeque<Double>() }        // ✅ v70 경로이탈 거리 추세(다른 방향 감지용)
        var rerouting by remember { mutableStateOf(false) }
        // ✅ 공유경로 따라가기용 접근 경로 (현위치 → 공유경로 출발점, 지도에 파란선)
        var approachRoute by remember { mutableStateOf<RouteResult?>(null) }
        var sharedStartPoint by remember { mutableStateOf<LatLngPoint?>(null) }
        var lastRerouteAtMillis by remember { mutableStateOf(0L) }
        // ═══ v27 내비 확장 상태 ═══
        var alternativeRoutes by remember { mutableStateOf<List<RouteResult>>(emptyList()) }
        var followGuide by remember { mutableStateOf<com.navifit.navigation.FollowRouteGuide?>(null) } // 친구 길 따라가기
        var followState by remember { mutableStateOf<com.navifit.navigation.FollowRouteGuide.FollowState?>(null) }
        var hazardAlert by remember { mutableStateOf<com.navifit.safety.HazardAlert?>(null) }
        var isViolationWarning by remember { mutableStateOf(false) }
        var isGpsEstimating by remember { mutableStateOf(false) }
        var lastFixAtMs by remember { mutableStateOf(0L) }
        var gpsRecoveryUntilMs by remember { mutableStateOf(0L) }   // ✅ v40 터널 복구 후 GPS 안정화 유예
        var currentRoadInfo by remember { mutableStateOf<com.navifit.navigation.RoadInfoResolver.RoadInfo?>(null) }
        var latestProgress by remember { mutableStateOf<NavProgress?>(null) }          // ✅ v31: 스마트 재조회용 최신 진행상태
        var suggestedRoute by remember { mutableStateOf<RouteResult?>(null) }           // ✅ v32: 제안된 빠른 길 (연한 파란색, 자동전환 X)
        var suggestedSavedMinutes by remember { mutableStateOf(0) }
        var rerouteFailStreak by remember { mutableStateOf(0) }   // ✅ v33 재탐색 연속 실패 백오프
        // ✅ v44 출발 전 경로 비교/선택 (카카오내비처럼 여러 경로를 보고 고르기)
        var previewRoutes by remember { mutableStateOf<List<RouteResult>>(emptyList()) }
        // ✅ v45 성능: 경로 폴리라인 디코딩 캐시.
        //    기존엔 위치가 갱신될 때마다(1~2초) 폴리라인을 통째로 다시 디코딩했음.
        //    500km 경로면 매번 수만 개 좌표를 재파싱 → CPU 낭비·발열·배터리 소모.
        //    이제 경로가 바뀔 때만 1회 디코딩.
        val routePointsCache = remember(route?.overviewPolyline) {
            route?.overviewPolyline?.let { decodePolyline(it) } ?: emptyList()
        }
        var previewOriginName by remember { mutableStateOf<String?>(null) }
        var pendingStart by remember { mutableStateOf<Triple<LatLngPoint, TravelMode, String>?>(null) }


        // ✅ v33 고속도로 휴게소 안내 (한국도로공사 무료 API)
        val restRepo = remember { com.navifit.navigation.RestAreaRepository(this@MainActivity) }
        var restAreas by remember { mutableStateOf<List<com.navifit.navigation.RestAreaRepository.RestArea>>(emptyList()) }
        var nextRestArea by remember { mutableStateOf<Pair<com.navifit.navigation.RestAreaRepository.RestArea, Int>?>(null) }
        var announcedRestAreas by remember { mutableStateOf(setOf<String>()) }
        LaunchedEffect(navigating) {
            if (navigating && !currentMode.isWorkoutMode && restRepo.hasKey() && restAreas.isEmpty()) {
                restAreas = restRepo.loadAll()
            }
            if (!navigating) { nextRestArea = null; announcedRestAreas = emptySet() }
        }
        var lastSuggestAtMs by remember { mutableStateOf(0L) }
        var lowSpeedAccumMs by remember { mutableStateOf(0L) }                          // ✅ v31: 정체 감지 (저속 지속시간)
        var lastCongestionCheckMs by remember { mutableStateOf(0L) }
        var lastDecisionCheckStepKey by remember { mutableStateOf("") }
        val deadReckoning = remember { com.navifit.navigation.DeadReckoning() }
        val roadResolver = remember { com.navifit.navigation.RoadInfoResolver() }
        val warnTone = remember {
            try { android.media.ToneGenerator(android.media.AudioManager.STREAM_ALARM, 85) } catch (_: Exception) { null }
                .also { warnToneRef = it }
        }
        val alertEngine = remember {
            com.navifit.safety.SafetyAlertEngine(
                onAnnounce = { msg ->
                    if (com.navifit.navigation.NavSettings.voiceEnabled(this@MainActivity)) voice.speakFreeform(msg)
                },
                onViolationChanged = { violating ->
                    isViolationWarning = violating && com.navifit.navigation.NavSettings.warningFlashEnabled(this@MainActivity)
                    if (violating && com.navifit.navigation.NavSettings.warningSoundEnabled(this@MainActivity)) {
                        try { warnTone?.startTone(android.media.ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 700) } catch (_: Exception) {}
                    }
                }
            )
        }
        LaunchedEffect(Unit) {
            com.navifit.social.PrivacySettings.syncToServer(this@MainActivity)  // ✅ v35 DM 설정 서버 동기화
            // ✅ v44: 한국어가 아닌 언어를 쓰면 앱 시작 시 언어팩을 미리 받아둠.
            //    (첫 화면에서 번역이 하나씩 늦게 뜨거나 실패하던 문제 해소)
            val myLangCode = com.navifit.i18n.LanguageStore.current(this@MainActivity).code
            if (myLangCode != "ko") {
                val warm = com.navifit.i18n.TranslationService.translate("경로 안내", "ko", myLangCode)
                if (warm == null) {
                    toast("번역 언어팩을 내려받는 중이에요. 잠시 후 다시 열어주세요 (Wi-Fi 권장)")
                }
            }
            com.navifit.social.NotificationCenter.ensureChannel(this@MainActivity) // ✅ v36 알림 채널
            com.navifit.safety.SafetyCameraStore.ensureLoaded(this@MainActivity)
            // ✅ v52: 카메라 동기화 우선순위 - ① Firebase(Firestore, 키 불필요) → ② data.go.kr API(키 있으면) → ③ 내장 데이터
            val fbOk = com.navifit.safety.SafetyCameraStore.syncFromFirebase(this@MainActivity)
            if (!fbOk) com.navifit.safety.SafetyCameraStore.syncFromPublicApi(this@MainActivity)
        }
        // ✅ 음성 설정 동기화: 내정보에서 끄면 모든 내비 음성이 즉시 무음 (탭 전환 때마다 재확인)
        LaunchedEffect(navigating, tab) {
            voice.muted = !com.navifit.navigation.NavSettings.voiceEnabled(this@MainActivity)
        }

        val traveledPath = remember { mutableStateListOf<LatLngPoint>() }
        val safetyTracker = remember { SafetyScoreTracker() }
        var antiCheat by remember { mutableStateOf(AntiCheatMonitor(TravelMode.default())) }

        val activityTypeMonitor = remember { com.navifit.tracking.ActivityTypeMonitor(this@MainActivity) }
        val leanMonitor = remember { com.navifit.tracking.VehicleLeanMonitor(this@MainActivity) }
        // ✅ v69 센서융합 신체움직임 엔진 (오프라인 추정 + 실제 운동 검증)
        val motionEngine = remember { com.navifit.tracking.MotionEngine(this@MainActivity) }

        /** ✅ v44 미리보기에서 경로를 고르면 그 경로로 안내 시작 */
        var records by remember { mutableStateOf(listOf<ActivityRecord>()) }
        val rankingSnapshots = remember { mutableStateMapOf<Int, Long>() }

        // 권한 안내 다이얼로그 (길안내 시작 시 권한 없으면 표시)
        var showPermissionDialog by remember { mutableStateOf(false) }
        var pendingNav by remember { mutableStateOf<(() -> Unit)?>(null) }
        // ✅ 부정행위 감지 안내 팝업 (토스트 대신 - 왜 무효화됐는지 명확히 설명)
        var cheatDialogReason by remember { mutableStateOf<String?>(null) }
        // ✅ 목적지 도착 자동 종료 - "도착 종료" 안 눌러도 자동으로 기록 저장 (한 번만 트리거)
        var hasAutoFinished by remember { mutableStateOf(false) }

        val trackingState by LocationTrackingService.trackingState.collectAsState()

        // ✅ v32 정체 구간 색상 (ITS 소통정보 - 무료, 5분 갱신)
        val trafficRepo = remember { com.navifit.navigation.TrafficFlowRepository(this@MainActivity) }
        var trafficSegments by remember { mutableStateOf<List<Pair<List<LatLngPoint>, com.navifit.navigation.TrafficFlowRepository.Level>>>(emptyList()) }
        LaunchedEffect(navigating, route) {
            if (!navigating || currentMode.isWorkoutMode || !trafficRepo.hasKey()) { trafficSegments = emptyList(); return@LaunchedEffect }
            while (true) {
                val loc = trackingState.currentLocation
                val r = route
                if (loc != null && r != null) {
                    val flows = trafficRepo.fetchNear(loc)
                    trafficSegments = trafficRepo.colorizeRoute(routePointsCache, flows)
                }
                kotlinx.coroutines.delay(5 * 60_000L)
            }
        }

        // ✅ v48 고속도로 돌발정보 (사고·공사·통제) — 카카오/티맵 대비 차별점
        //    "전방 3km 사고 발생, 2차로 통제" 를 미리 알려줘서 2차 사고를 막습니다.
        val exRoadRepo = remember { com.navifit.navigation.ExRoadInfoRepository(this@MainActivity) }
        var incidents by remember { mutableStateOf<List<com.navifit.navigation.ExRoadInfoRepository.Incident>>(emptyList()) }
        var announcedIncidents by remember { mutableStateOf(setOf<String>()) }
        var nextIncident by remember { mutableStateOf<Pair<com.navifit.navigation.ExRoadInfoRepository.Incident, Int>?>(null) }
        LaunchedEffect(navigating) {
            if (!navigating || currentMode.isWorkoutMode || !exRoadRepo.hasKey()) {
                incidents = emptyList(); nextIncident = null; announcedIncidents = emptySet()
                return@LaunchedEffect
            }
            while (true) {
                incidents = exRoadRepo.fetchIncidents()
                kotlinx.coroutines.delay(5 * 60_000L)   // 5분마다 갱신
            }
        }


        fun beginNavigationWith(selected: RouteResult, others: List<RouteResult>) {
            val (dest, mode, name) = pendingStart ?: return
            currentMode = mode
            currentDest = dest
            currentDestName = name
            currentOriginName = previewOriginName
            route = selected
            alternativeRoutes = others.take(2)
            followGuide = null
            navigating = true; navFlowActive = true
            traveledPath.clear()
            safetyTracker.reset()
            antiCheat = AntiCheatMonitor(mode)
            offRouteStreak = 0
            lastRerouteAtMillis = 0L
            voice.resetForNewRoute()
            if (mode.isWorkoutMode) { activityTypeMonitor.start(); motionEngine.start(); promptBatteryOptimizationIfNeeded() }
            if (mode == TravelMode.CAR) leanMonitor.start()
            // ✅ v83 이전 긴급안내 등으로 남아있을 수 있는 일시정지 상태를 반드시 해제하고 시작
            //    (이게 남아있으면 안내는 시작되는데 거리·시간이 0으로 멈춰 "안내가 안 된다"고 느껴졌음)
            LocationTrackingService.paused = false
            LocationTrackingService.startWithMode(this@MainActivity, mode)
            if (mode.needsVoiceGuidance && com.navifit.navigation.NavSettings.voiceEnabled(this@MainActivity)) {
                voice.announceRouteStart(selected.totalDistanceMeters, selected.totalDurationSeconds)
            }
            toast(if (mode.isWorkoutMode) "🏃 운동 시작! 위치를 잡는 중이에요" else "🧭 길안내를 시작합니다")
            previewRoutes = emptyList()
            pendingStart = null
        }

        // ✅ v67 자유 운동(제자리 시작·경로 없이 내 궤적만 그리기).
        //   길안내만 없고 나머지(거리·시간 기록, 궤적 그리기, 부정행위 감지, 저장)는 전부 동일.
        fun beginFreeRun(mode: TravelMode) {
            currentMode = mode
            currentDest = null
            currentDestName = null
            route = null
            alternativeRoutes = emptyList()
            followGuide = null
            navigating = true; navFlowActive = true
            traveledPath.clear()
            safetyTracker.reset()
            antiCheat = AntiCheatMonitor(mode)
            offRouteStreak = 0
            lastRerouteAtMillis = 0L
            voice.resetForNewRoute()
            if (mode.isWorkoutMode) { activityTypeMonitor.start(); motionEngine.start(); promptBatteryOptimizationIfNeeded() }
            LocationTrackingService.paused = false   // ✅ v83 잔여 일시정지 해제
            LocationTrackingService.startWithMode(this@MainActivity, mode)
            toast("🏃 자유 운동 시작! 마음껏 뛰고 종료하면 궤적이 저장돼요")
        }

        // ✅ v56: 카카오내비식 지도 기반 경로 선택 화면 (전체화면 오버레이)
        //    후보 경로들이 지도에 동시에 그려지고, 지도의 경로선/하단 카드를 눌러 선택 → 시작
        if (previewRoutes.isNotEmpty()) {
            val startMode = pendingStart?.second ?: currentMode
            androidx.compose.ui.window.Dialog(
                onDismissRequest = { previewRoutes = emptyList(); pendingStart = null },
                properties = androidx.compose.ui.window.DialogProperties(
                    usePlatformDefaultWidth = false, decorFitsSystemWindows = false
                )
            ) {
                com.navifit.ui.screens.RoutePreviewScreen(
                    routes = previewRoutes,
                    mode = startMode,
                    destName = pendingStart?.third ?: "목적지",
                    originName = previewOriginName,
                    onStart = { sel, others -> beginNavigationWith(sel, others) },
                    onCancel = { previewRoutes = emptyList(); pendingStart = null },
                    onExternalNavi = { app ->
                        pendingStart?.let { (dest, _, name) -> openExternalNavi(app, dest, name) }
                    }
                )
            }
        }

        // ✅ v34 세션 복구: 30초마다 진행상황을 디스크에 저장.
        //    앱이 OS에 강제 종료돼도 그때까지의 기록을 살릴 수 있음 (장거리 주행 중 앱 죽으면 다 날아갔음)
        LaunchedEffect(navigating) {
            if (!navigating) return@LaunchedEffect
            while (true) {
                kotlinx.coroutines.delay(30_000L)
                if (!navigating) break
                val st = LocationTrackingService.trackingState.value
                if (st.totalDistanceMeters < 100) continue
                val sampled = traveledPath.toList().let { pts ->
                    if (pts.size > 800) pts.filterIndexed { i, _ -> i % (pts.size / 800 + 1) == 0 } else pts
                }
                com.navifit.tracking.SessionRecoveryStore.save(
                    this@MainActivity, currentMode, System.currentTimeMillis() - st.elapsedSeconds * 1000,
                    st.totalDistanceMeters, st.elapsedSeconds, st.movingSeconds, st.maxRestSeconds,
                    safetyTracker.maxSpeedKmh,
                    if (currentMode.isWorkoutMode) 100 else safetyTracker.currentScore(),
                    if (sampled.size >= 2) encodeTravelPolyline(sampled) else null,
                    currentOriginName, currentDestName
                )
            }
        }

        // ✅ v34 앱 시작 시 미완료 세션 복구 제안
        // ✅ v36 알림: 미읽음 개수 뱃지 + 새 알림 도착 시 시스템 알림
        var notifUnread by remember { mutableStateOf(0) }
        var notifItems by remember { mutableStateOf<List<com.navifit.social.NotificationCenter.Item>>(emptyList()) }
        var showNotifications by remember { mutableStateOf(false) }
        var showNotifSettings by remember { mutableStateOf(false) }
        // ✅ v61 알림 탭 → 커뮤니티 하위화면 요청 ("friends"/"inbox"/"feed"), 소비되면 null
        var communitySubRequest by remember { mutableStateOf<String?>(null) }
        var focusPostId by remember { mutableStateOf<String?>(null) }   // ✅ v81 알림 딥링크 대상 글
        // ✅ v83 RM 안 읽음 개수 - 로컬 저장소 기반 (서버 오류와 무관하게 항상 동작)
        val rmCtx = this@MainActivity
        LaunchedEffect(Unit) { com.navifit.social.LocalRmStore.load(rmCtx) }
        val rmThreads by com.navifit.social.LocalRmStore.threads.collectAsState()
        val dmUnreadCount = rmThreads.count { it.unread && !it.isRequest }
        var lastNotifiedId by remember { mutableStateOf("") }
        LaunchedEffect(myUid) {
            if (myUid.isBlank()) return@LaunchedEffect
            while (true) {
                val items = com.navifit.social.NotificationCenter.list(myUid)
                    // ✅ v58: 설정에서 끈 종류의 알림은 목록에서도 제외
                    .filter { com.navifit.social.NotificationCenter.isTypeEnabled(this@MainActivity, it.type) }
                // ✅ 알림함 테스트용 데모 3개 (실제 알림이 없을 때만) + 우편함 도착 알림
                val mailUnclaimed = com.navifit.vs.MailboxStore.unclaimedCount(this@MainActivity)
                val mailNotif = if (mailUnclaimed > 0) listOf(
                    com.navifit.social.NotificationCenter.Item("mail_arrival",
                        com.navifit.social.NotificationCenter.Type.SYSTEM, "🎁 VS 랭킹 선물",
                        "우편함에 선물이 ${mailUnclaimed}개 도착했어요! (뽑기 → 우편함)", System.currentTimeMillis() - 30_000, false)
                ) else emptyList()
                notifItems = mailNotif + items.ifEmpty {
                    listOf(
                        com.navifit.social.NotificationCenter.Item("demo1",
                            com.navifit.social.NotificationCenter.Type.LIKE, "새벽러너", "회원님의 글을 좋아합니다", System.currentTimeMillis() - 60_000, false),
                        com.navifit.social.NotificationCenter.Item("demo2",
                            com.navifit.social.NotificationCenter.Type.COMMENT, "한강매니아", "댓글: 이 코스 저도 뛰어봤어요!", System.currentTimeMillis() - 3_600_000, false),
                        com.navifit.social.NotificationCenter.Item("demo3",
                            com.navifit.social.NotificationCenter.Type.FRIEND_REQUEST, "박질주", "친구 요청을 보냈어요", System.currentTimeMillis() - 86_400_000, true)
                    )
                }
                notifUnread = notifItems.count { !it.read }
                // 새로 온 미읽음 알림이 있으면 시스템 알림 1회 발송 (설정에서 허용 + 종류 켜짐일 때만)
                items.firstOrNull { !it.read }?.let { newest ->
                    if (newest.id != lastNotifiedId &&
                        com.navifit.social.NotificationCenter.notifyWhenOff(this@MainActivity) &&
                        com.navifit.social.NotificationCenter.isTypeEnabled(this@MainActivity, newest.type)) {
                        lastNotifiedId = newest.id
                        com.navifit.social.NotificationCenter.showLocal(
                            this@MainActivity,
                            "${newest.type.icon} ${newest.fromNickname}",
                            newest.message
                        )
                    }
                }
                kotlinx.coroutines.delay(20_000L)
            }
        }

        // ✅ v36 알림함
        // ✅ v61 로컬 읽음/삭제 상태 (데모 알림 + Firestore 알림 공통 처리)
        var locallyRead by remember { mutableStateOf<Set<String>>(emptySet()) }
        var locallyDeleted by remember { mutableStateOf<Set<String>>(emptySet()) }
        val shownNotifs = notifItems.filter { it.id !in locallyDeleted }
            .map { if (it.id in locallyRead) it.copy(read = true) else it }
        // 미읽음 뱃지 = 로컬 삭제/읽음 반영
        LaunchedEffect(shownNotifs) { notifUnread = shownNotifs.count { !it.read } }

        // ✅ v81 이미 운동 중일 때 따라뛰기 차단 안내
        if (alreadyRunningWarn) {
            AlertDialog(
                onDismissRequest = { alreadyRunningWarn = false },
                title = { Text("이미 운동 중입니다") },
                text = { Text("지금 진행 중인 운동이 있어요.\n따라뛰기를 시작하려면 먼저 현재 운동을 종료해주세요.") },
                confirmButton = {
                    TextButton(onClick = { alreadyRunningWarn = false; tab = 0 }) { Text("운동 화면으로") }
                },
                dismissButton = { TextButton(onClick = { alreadyRunningWarn = false }) { Text("닫기") } }
            )
        }

        // ✅ v85 VS 진행 중 화면 이탈 경고
        if (vsLeaveWarn) {
            AlertDialog(
                onDismissRequest = { vsLeaveWarn = false },
                title = { Text("⚔️ 대결 진행 중") },
                text = {
                    Text(
                        when (vsGameState.phase) {
                            com.navifit.ui.screens.VsPhase.MATCHING -> "상대를 찾는 중이에요.\n지금 나가면 매칭이 취소됩니다."
                            com.navifit.ui.screens.VsPhase.COUNTDOWN -> "곧 출발해요!\n지금 나가면 대결이 취소됩니다."
                            else -> "달리는 중이에요.\n지금 나가면 기권 처리되고 포인트가 차감될 수 있어요."
                        }
                    )
                },
                confirmButton = {
                    TextButton(onClick = { vsLeaveWarn = false }) { Text("대결 계속하기") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        vsLeaveWarn = false
                        vsGameState.phase = com.navifit.ui.screens.VsPhase.OPTION
                        vsGameState.opponent = null
                        vsGameState.settlement = null
                        vsGameState.runProgress = 0.0
                        vsMeasureJob?.cancel()
                        LocationTrackingService.stop(this@MainActivity)
                        toast("대결을 취소했어요")
                    }) { Text("취소하고 나가기", color = Color(0xFFFF6B6B)) }
                }
            )
        }

        if (showNotifications) {
            fun typeColor(t: com.navifit.social.NotificationCenter.Type) = when (t) {
                com.navifit.social.NotificationCenter.Type.LIKE -> androidx.compose.ui.graphics.Color(0xFFFF3B5C)
                com.navifit.social.NotificationCenter.Type.COMMENT -> androidx.compose.ui.graphics.Color(0xFF3B82F6)
                com.navifit.social.NotificationCenter.Type.DM -> androidx.compose.ui.graphics.Color(0xFF34D399)
                com.navifit.social.NotificationCenter.Type.FRIEND_REQUEST -> androidx.compose.ui.graphics.Color(0xFFFBBF6E)
                else -> androidx.compose.ui.graphics.Color(0xFF8B93AC)
            }
            Dialog(onDismissRequest = { showNotifications = false }) {
                Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
                    color = androidx.compose.ui.graphics.Color(0xFF1B1E26)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("🔔 알림", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = Color.White,
                                modifier = Modifier.weight(1f))
                            Text("⚙️", fontSize = 18.sp, modifier = Modifier.clickable { showNotifSettings = true }.padding(6.dp))
                        }
                        Spacer(Modifier.height(10.dp))
                        if (shownNotifs.isEmpty()) {
                            Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                                Text("새 알림이 없어요", color = androidx.compose.ui.graphics.Color(0xFF8B93AC), fontSize = 13.sp)
                            }
                        } else {
                            Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                                shownNotifs.forEach { n ->
                                    val bg = if (n.read) androidx.compose.ui.graphics.Color(0xFF20242E)
                                             else androidx.compose.ui.graphics.Color(0xFF2A3550)
                                    Row(
                                        Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                            .clip(androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
                                            .background(bg)
                                            .clickable {
                                                // 읽음 처리 + 뱃지 감소
                                                locallyRead = locallyRead + n.id
                                                scope.launch { com.navifit.social.NotificationCenter.markAllRead(myUid) }
                                                showNotifications = false
                                                // ✅ 종류별로 해당 화면으로 이동
                                                when (n.type) {
                                                    com.navifit.social.NotificationCenter.Type.FRIEND_REQUEST -> {
                                                        tab = 4; communitySubRequest = "friends"
                                                    }
                                                    com.navifit.social.NotificationCenter.Type.DM -> {
                                                        tab = 4; communitySubRequest = "inbox"
                                                    }
                                                    com.navifit.social.NotificationCenter.Type.SYSTEM -> {
                                                        // 우편 도착 알림 → 뽑기(우편함) 탭으로
                                                        if (n.id == "mail_arrival") tab = 1 else tab = 4
                                                    }
                                                    else -> {
                                                        // ✅ v81 좋아요·댓글 알림 딥링크: 해당 글로 바로 이동
                                                        tab = 4
                                                        communitySubRequest = if (n.postId != null)
                                                            "post:${n.postId}" else "feed"
                                                    }
                                                }
                                            }
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(Modifier.size(38.dp).clip(androidx.compose.foundation.shape.CircleShape)
                                            .background(typeColor(n.type).copy(alpha = 0.22f)),
                                            contentAlignment = Alignment.Center) {
                                            Text(n.type.icon, fontSize = 18.sp)
                                        }
                                        Spacer(Modifier.width(11.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(n.fromNickname, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = typeColor(n.type))
                                            Text(n.message, fontSize = 12.sp, lineHeight = 16.sp,
                                                color = androidx.compose.ui.graphics.Color(0xFFECEEF2))
                                            // ✅ v79 알림 시간 표시 (분/시간/일 단위)
                                            Text(run {
                                                val d = (System.currentTimeMillis() - n.at) / 1000
                                                when {
                                                    d < 60 -> "방금 전"; d < 3600 -> "${d/60}분 전"
                                                    d < 86400 -> "${d/3600}시간 전"; else -> "${d/86400}일 전"
                                                }
                                            }, fontSize = 10.sp, color = androidx.compose.ui.graphics.Color(0xFF8B93AC))
                                        }
                                        if (!n.read) Box(Modifier.size(9.dp)
                                            .clip(androidx.compose.foundation.shape.CircleShape)
                                            .background(androidx.compose.ui.graphics.Color(0xFFFF3040)))
                                        Text("✕", fontSize = 13.sp,
                                            color = androidx.compose.ui.graphics.Color(0xFF6B7180),
                                            modifier = Modifier.clickable { locallyDeleted = locallyDeleted + n.id }.padding(start = 8.dp))
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = {
                                locallyRead = locallyRead + shownNotifs.map { it.id }.toSet()
                                scope.launch { com.navifit.social.NotificationCenter.markAllRead(myUid) }
                            }) { Text("모두 읽음") }
                            TextButton(onClick = {
                                locallyDeleted = locallyDeleted + notifItems.map { it.id }.toSet()
                                scope.launch { com.navifit.social.NotificationCenter.deleteAll(myUid) }
                            }) { Text("전체 삭제", color = androidx.compose.ui.graphics.Color(0xFFFF6B6B)) }
                            TextButton(onClick = { showNotifications = false }) { Text("닫기") }
                        }
                    }
                }
            }
        }

        // ✅ v58 알림 설정 다이얼로그
        if (showNotifSettings) {
            AlertDialog(
                onDismissRequest = { showNotifSettings = false },
                title = { Text("알림 설정", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text("받을 알림 종류", fontSize = 12.sp, color = androidx.compose.ui.graphics.Color.Gray)
                        com.navifit.social.NotificationCenter.Type.values().forEach { t ->
                            var on by remember { mutableStateOf(com.navifit.social.NotificationCenter.isTypeEnabled(this@MainActivity, t)) }
                            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("${t.icon} ${when(t){
                                    com.navifit.social.NotificationCenter.Type.COMMENT -> "댓글"
                                    com.navifit.social.NotificationCenter.Type.LIKE -> "좋아요"
                                    com.navifit.social.NotificationCenter.Type.DM -> "쪽지(RM)"
                                    com.navifit.social.NotificationCenter.Type.FRIEND_REQUEST -> "친구 요청"
                                    com.navifit.social.NotificationCenter.Type.SYSTEM -> "공지"
                                }}", Modifier.weight(1f), fontSize = 14.sp)
                                Switch(checked = on, onCheckedChange = {
                                    on = it; com.navifit.social.NotificationCenter.setTypeEnabled(this@MainActivity, t, it)
                                })
                            }
                        }
                        Divider(Modifier.padding(vertical = 8.dp), color = androidx.compose.ui.graphics.Color(0x22FFFFFF))
                        var offOn by remember { mutableStateOf(com.navifit.social.NotificationCenter.notifyWhenOff(this@MainActivity)) }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("앱이 꺼져있을 때도 알림 받기", Modifier.weight(1f), fontSize = 14.sp)
                            Switch(checked = offOn, onCheckedChange = {
                                offOn = it; com.navifit.social.NotificationCenter.setNotifyWhenOff(this@MainActivity, it)
                            })
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showNotifSettings = false }) { Text("완료") } }
            )
        }

        var pendingRecovery by remember { mutableStateOf(com.navifit.tracking.SessionRecoveryStore.loadPending(this@MainActivity)) }
        pendingRecovery?.let { snap ->
            AlertDialog(
                onDismissRequest = { },
                title = { Text("완료되지 않은 기록이 있어요") },
                text = {
                    Text("%s · %.2fkm · %d분\n\n앱이 예기치 않게 종료된 것 같아요. 이 기록을 저장할까요?".format(
                        snap.mode.displayName, snap.distanceMeters / 1000, snap.elapsedSeconds / 60))
                },
                confirmButton = {
                    TextButton(onClick = {
                        scope.launch {
                            db.activityRecordDao().insert(
                                ActivityRecord(
                                    mode = snap.mode,
                                    startTimeMillis = snap.startTimeMillis,
                                    durationSeconds = snap.elapsedSeconds,
                                    distanceMeters = snap.distanceMeters,
                                    avgSpeedKmh = if (snap.elapsedSeconds > 0)
                                        snap.distanceMeters / snap.elapsedSeconds * 3.6 else 0.0,
                                    maxSpeedKmh = snap.maxSpeedKmh,
                                    originName = snap.originName,
                                    destinationName = snap.destName,
                                    pathPolyline = snap.pathPolyline,
                                    safetyScore = snap.safetyScore,
                                    isRankingValid = false,   // 복구 기록은 랭킹 제외 (검증 불가 - 부정사용 방지)
                                    invalidReason = "앱 종료 후 복구된 기록이라 랭킹에는 반영되지 않아요",
                                    movingSeconds = snap.movingSeconds,
                                    maxRestSeconds = snap.maxRestSeconds
                                )
                            )
                            records = db.activityRecordDao().getAll()
                            com.navifit.tracking.SessionRecoveryStore.clear(this@MainActivity)
                            pendingRecovery = null
                            toast("복구된 기록을 저장했어요 (개인 기록에만 반영)")
                        }
                    }) { Text("저장하기") }
                },
                dismissButton = {
                    TextButton(onClick = {
                        com.navifit.tracking.SessionRecoveryStore.clear(this@MainActivity)
                        pendingRecovery = null
                    }) { Text("버리기") }
                }
            )
        }

        // ✅ 접속 하트비트: 앱이 켜져 있는 동안 60초마다 lastSeenAt 갱신 -> 친구들에게 "🟢 접속중" 표시
        LaunchedEffect(Unit) {
            val presenceRepo = com.navifit.social.FriendRepository()
            while (true) {
                auth.currentUser()?.uid?.let { presenceRepo.heartbeat(it) }
                kotlinx.coroutines.delay(60_000L)
            }
        }
        val steps by StepCounterService.stepsFlow.collectAsState()
        val tickets by StepCounterService.ticketsFlow.collectAsState()
        val boostLevel by StepCounterService.boostLevelFlow.collectAsState()

        val navPermissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { grants ->
            if (grants[Manifest.permission.ACCESS_FINE_LOCATION] == true) {
                pendingNav?.invoke(); pendingNav = null
            } else {
                toast("위치 권한이 없으면 길안내를 시작할 수 없어요")
            }
        }

        /** ✅ 길안내 시작 전 권한 체크: 없으면 매번 안내 다이얼로그 */
        fun ensureLocationPermissionThen(action: () -> Unit) {
            val granted = ContextCompat.checkSelfPermission(
                this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
            if (granted) action()
            else { pendingNav = action; showPermissionDialog = true }
        }

        // ✅ 버튼으로 눌러도, 도착 자동감지로도 똑같이 호출되는 종료 로직 (중복 코드 방지 + 항상 동일하게 동작)
        fun finishNavigation() {
            finishTracking(
                currentMode, trackingState, safetyTracker, antiCheat,
                rankingSnapshots.toMap(), currentOriginName, currentDestName,
                traveledPath.toList(),
                routePolyline = route?.let { decodePolyline(it.overviewPolyline) }   // ✅ v74 맵매칭용 경로
            ) {
                scope.launch { records = db.activityRecordDao().getAll() }
            }
            navigating = false; navFlowActive = false
            traveledPath.clear()
            rankingSnapshots.clear()
            antiCheat = AntiCheatMonitor(currentMode)
            activityTypeMonitor.stop()
            motionEngine.stop()
            leanMonitor.stop()
            hasAutoFinished = false
            // ═══ v27 상태 초기화 ═══
            alternativeRoutes = emptyList()
            followGuide = null
            followState = null
            hazardAlert = null
            suggestedRoute = null
            rerouteFailStreak = 0
            com.navifit.tracking.SessionRecoveryStore.clear(this@MainActivity)  // ✅ v34 정상 종료 - 복구 대상 해제
            isViolationWarning = false
            isGpsEstimating = false
            currentRoadInfo = null
        }

        // ✅ v59: 로컬 함수는 "선언 뒤"에만 호출 가능 → beginFollow를 먼저 정의
        fun beginFollow(shared: com.navifit.navigation.RouteShare.SharedRoute, points: List<LatLngPoint>) {
            var total = 0.0
            for (i in 1 until points.size) {
                total += NavigationProgressCalculator.fastDistanceMeters(points[i - 1], points[i])
            }
            val estSec = when (shared.mode) {
                TravelMode.WALK -> (total / 1.25).toInt()      // 4.5km/h
                TravelMode.BIKE -> (total / 4.7).toInt()       // 17km/h
                else -> (total / 11.1).toInt()                 // 40km/h
            }
            currentMode = shared.mode
            currentDest = points.last()
            currentDestName = "공유 경로 도착지"
            currentOriginName = "공유 경로 출발지"
            route = RouteResult(
                steps = com.navifit.navigation.SharedRouteTurnDetector.detectSteps(points),
                totalDistanceMeters = total.toInt(),
                totalDurationSeconds = estSec,
                overviewPolyline = shared.polyline,
                mode = shared.mode
            )
            alternativeRoutes = emptyList()
            followGuide = com.navifit.navigation.FollowRouteGuide(points)
            followState = null
            offRouteStreak = 0
            lastRerouteAtMillis = 0L
            traveledPath.clear()
            safetyTracker.reset()
            antiCheat = AntiCheatMonitor(shared.mode)
            if (shared.mode.isWorkoutMode) { activityTypeMonitor.start(); motionEngine.start(); promptBatteryOptimizationIfNeeded() }
            navigating = true; navFlowActive = true
            approachRoute = null
            // ✅ v58 공유경로 모드 플래그: 이탈해도 "새 경로 재탐색" 하지 않고
            //    항상 이 공유 경로만 따라감 (시작점까지 접근 안내를 제외하고).
            isFollowingSharedRoute = true
            LocationTrackingService.startWithMode(this@MainActivity, shared.mode)
            toast("👣 친구 길 따라가기 모드 시작!")
            // ✅ 현위치 → 공유경로 출발점까지 "접근 경로"를 계산해 파란선으로 안내
            //    (출발점에서 40m 이상 떨어져 있을 때만 - 이미 출발점 근처면 불필요)
            val myLoc = LocationTrackingService.trackingState.value.currentLocation
            val startPt = points.first()
            sharedStartPoint = startPt
            if (myLoc != null &&
                NavigationProgressCalculator.fastDistanceMeters(myLoc, startPt) > 40.0) {
                scope.launch {
                    routing.fetchRoutesWithTraffic(myLoc, startPt, shared.mode,
                        RoutePreference.load(this@MainActivity))
                        .onSuccess { rts ->
                            approachRoute = rts.firstOrNull()
                            toast("🔵 파란선을 따라 공유경로 출발점으로 이동하세요")
                        }
                }
            }
        }

        /** ✅ v27 친구 길 따라가기 시작: 공유받은 경로 그대로만 안내 (재탐색 없음, 이탈 시 복귀 안내) */
        fun startFollowSharedRoute(shared: com.navifit.navigation.RouteShare.SharedRoute) {
            val points = decodePolyline(shared.polyline)
            if (points.size < 2) { toast("공유 경로가 올바르지 않아요"); return }
            // ✅ v58: 공유경로 따라가기도 "진짜 내 위치"를 먼저 확보 (안 그러면 시간·거리·진행률이 다 엉킴)
            lifecycleScope.launch {
                val here = LocationTrackingService.trackingState.value.currentLocation ?: awaitFreshLocation()
                if (here == null) { toast("📡 현재 위치를 찾지 못했어요. GPS를 켜고 다시 시도해주세요"); return@launch }
                beginFollow(shared, points)
            }
        }

        LaunchedEffect(trackingState) {
            trackingState.currentLocation?.let { loc ->
                if (navigating) {
                    // ✅ v62 경로 지그재그 방지: 신호 불량/튐 좌표를 궤적에 넣지 않음
                    //  - 정확도(오차)가 나쁜 fix(±35m 초과)는 무시 → 건물 사이/터널에서 튀는 점 제거
                    //  - 직전 점에서 물리적으로 불가능한 점프(> 이동시간×속도한계)는 무시
                    //  - 너무 촘촘한 점(< 6m)도 무시 (지터 누적 방지)
                    val acc = trackingState.accuracyMeters
                    val lastPt = traveledPath.lastOrNull()
                    val gap = if (lastPt != null) NavigationProgressCalculator.fastDistanceMeters(lastPt, loc) else 999.0
                    val maxSpeed = when (currentMode) {
                        TravelMode.WALK -> 8.0; TravelMode.BIKE -> 22.0; else -> 55.0
                    }
                    val plausibleJump = maxSpeed * 3.0
                    // ✅ v63: 정확도 나쁜 fix라도 "적당히 큰 이동"이면 받아들임 (경로가 아예 안 그려지던 문제 방지).
                    //   - 명백한 지터(6m 미만)나 순간이동(불가능한 점프)만 배제
                    //   - 정확도는 참고만: 매우 나쁠 때(±60m↑)만 그리고 점프도 클 때 배제
                    val isJitter = lastPt != null && gap < 6.0
                    val isTeleport = lastPt != null && gap > plausibleJump
                    val isVeryBadAndJumpy = acc > 60f && lastPt != null && gap > 40.0
                    val acceptable = lastPt == null || (!isJitter && !isTeleport && !isVeryBadAndJumpy)
                    if (acceptable) {
                        traveledPath.add(loc)
                        if (traveledPath.size > 20_000) {
                            val thinned = traveledPath.filterIndexed { i, _ -> i % 2 == 0 }
                            traveledPath.clear()
                            traveledPath.addAll(thinned)
                        }
                    }
                    // ✅ 공유경로 출발점 도착 시 파란 접근선 자동 제거
                    if (approachRoute != null && followGuide != null) {
                        val sp = sharedStartPoint
                        if (sp != null && NavigationProgressCalculator.fastDistanceMeters(loc, sp) < 25.0) {
                            approachRoute = null
                            toast("🔴 출발점 도착! 이제 빨간 공유경로를 따라가세요")
                            if (currentMode.needsVoiceGuidance) voice.speakFreeform("출발점에 도착했습니다. 이제 공유 경로를 따라가세요")
                        }
                    }
                    // ═══ v27: 엔진 피드 ═══
                    // ✅ v40: 터널 등에서 빠져나와 GPS가 복구되면 10초간 "안정화 유예".
                    //    복구 직후 5~15초는 위치가 크게 튀어서, 그대로 두면 즉시 "경로 이탈"로 오판하고
                    //    불필요한 재탐색이 돌았음 (터널 지나면 항상 재탐색되던 문제의 원인).
                    if (trackingState.isAfterSignalGap || (lastFixAtMs > 0 && System.currentTimeMillis() - lastFixAtMs > 6000)) {
                        gpsRecoveryUntilMs = System.currentTimeMillis() + 10_000L
                        offRouteStreak = 0
                    }
                    lastFixAtMs = System.currentTimeMillis()
                    isGpsEstimating = false
                    deadReckoning.onRealFix(loc, trackingState.speedKmh, trackingState.bearingDegrees)
                    if (!currentMode.isWorkoutMode) {
                        // ✅ v31 정체 감지: 저속 지속시간 누적 (신호대기 수준 잠깐 저속은 4분 조건에 안 걸림)
                        val nowMs2 = System.currentTimeMillis()
                        if (trackingState.speedKmh < 25 && !trackingState.isAfterSignalGap) {
                            lowSpeedAccumMs += 2000L // 위치 업데이트 주기 근사
                        } else if (trackingState.speedKmh > 40) lowSpeedAccumMs = 0L
                        // ✅ v31 안전점수에 현재 도로 제한속도 힌트 전달 (카메라 구간 제한 > 고속도로 100 > 기본 80)
                        safetyTracker.speedLimitHintKmh = alertEngine.currentAlert?.hazard?.limitKmh
                            ?: if (currentRoadInfo?.roadName?.contains("고속도로") == true) 100 else null
                        // 카메라/방지턱 800m 사전경보 + 위반 지속경보
                        alertEngine.feed(loc, trackingState.speedKmh, trackingState.bearingDegrees)
                        hazardAlert = alertEngine.currentAlert
                        // ✅ v27 안전점수 연동: 카메라를 위반 상태로 통과하면 감점
                        alertEngine.currentAlert?.let { a ->
                            if (a.phase == com.navifit.safety.AlertPhase.PASSING) {
                                if (a.isViolating) safetyTracker.onCameraViolation()
                                if (a.hazard.type == com.navifit.safety.RoadHazardType.SIGNAL_CAMERA) {
                                    safetyTracker.onSignalCameraPass(trackingState.speedKmh)
                                }
                            }
                        }
                    }
                    // 친구 길 따라가기: 진행률/이탈 복귀 안내 계산
                    followGuide?.let { fg ->
                        val fs = fg.compute(loc)
                        val wasOff = followState?.isOffPath == true
                        followState = fs
                        if (fs.isOffPath && !wasOff && currentMode.needsVoiceGuidance &&
                            com.navifit.navigation.NavSettings.voiceEnabled(this@MainActivity)) {
                            voice.speakFreeform("공유 경로를 벗어났어요. ${com.navifit.navigation.FollowRouteGuide.bearingToKorean(fs.returnBearingDeg)} ${fs.returnDistanceMeters}m 지점에서 경로로 복귀하세요")
                        }
                    }
                    // ✅ 신호 끊김 직후 샘플은 안전점수 판정에서도 제외 (재연결 순간 속도 튐 -> 억울한 급가속 감점 방지)
                    // ✅ v33 안전점수 판정 제외 조건 (억울한 감점 방지):
                    //    - 신호 공백 직후 (터널 출구에서 속도가 튐)
                    //    - GPS 오차 25m 초과 (도심 협곡·고가 하부에서 속도가 부정확)
                    //    - 추측항법 중 (실측이 아니라 추정값)
                    val gpsTrustworthy = trackingState.accuracyMeters in 0.1f..25f
                    if (!currentMode.isWorkoutMode && !trackingState.isAfterSignalGap &&
                        gpsTrustworthy && !isGpsEstimating) {
                        safetyTracker.onSpeedUpdate(trackingState.speedKmh)
                    }

                    // ✅ 터널 등으로 신호가 끊겼다 방금 복구된 샘플은 튄 값일 수 있어서
                    //    부정행위 판정에서 이번 한 번만 건너뜀 (억울한 오판정 방지) - 다음 정상 샘플부터 이어서 계산
                    if (!trackingState.isAfterSignalGap) {
                        val wasValid = antiCheat.isRankingValid
                        // ① 세계기록 페이스 기반 동적 속도 상한 판정 (경과시간을 함께 넘겨서 지속시간별 상한 적용)
                        antiCheat.onSpeedSample(trackingState.speedKmh, trackingState.elapsedSeconds)
                        // ③ 케이던스 교차검증: MotionEngine의 실측 케이던스(가속도 리듬) 우선, 없으면 활동인식값
                        val realCadence = if (motionEngine.cadencePerMin > 0) motionEngine.cadencePerMin
                                          else activityTypeMonitor.recentStepsPerMinute
                        antiCheat.onCadenceCheck(trackingState.speedKmh, realCadence)
                        // ③-b ✅ v70 부정행위 판정을 이동수단별로:
                        //   달리기 = 신체 진동/케이던스 (폰 위치 무관하게 상하 진동 큼)
                        //   자전거 = 속도 패턴 (핸들 거치라 진동 약함 → 전동 어시스트 특유의 평탄 고속으로 판정)
                        if (currentMode == TravelMode.BIKE) {
                            antiCheat.onBikeSpeedPattern(trackingState.speedKmh, motionEngine.isPedaling, motionEngine.rhythmRegularity)
                        } else {
                            antiCheat.onBodyMotionCheck(
                                trackingState.speedKmh, currentMode,
                                motionEngine.isMovementBodyPowered(trackingState.speedKmh, currentMode)
                            )
                        }
                        // ④ 오토바이/자동차 구분: 코너링 리닝 신호 갱신 후 판정
                        if (!currentMode.isWorkoutMode) {
                            leanMonitor.onBearingUpdate(trackingState.bearingDegrees)
                            antiCheat.onLeanSignal(leanMonitor.isConfirmedTwoWheelerLean)
                        }
                        if (wasValid && !antiCheat.isRankingValid) {
                            cheatDialogReason = antiCheat.invalidReason ?: "비정상적인 움직임이 감지됐어요"
                        }
                    }

                    val currentKm = (trackingState.totalDistanceMeters / 1000).toInt()
                    if (currentKm > 0 && !rankingSnapshots.containsKey(currentKm)) {
                        rankingSnapshots[currentKm] = trackingState.elapsedSeconds
                    }
                    // ✅ v90 1km 갱신 진동 (스플릿) — 달리면서 화면 안 봐도 페이스 감각
                    if (currentMode.isWorkoutMode && currentKm > lastKmMilestone) {
                        lastKmMilestone = currentKm
                        com.navifit.tracking.HapticFeedback.kmSplit(this@MainActivity)
                    }

                    // ✅ 경로 안내 + 도착 자동감지 (모든 이동수단 공통) - "도착 종료" 안 눌러도 자동 저장
                    route?.let { r ->
                        val pts = routePointsCache   // ✅ v45 캐시 사용 (매번 디코딩 안 함)
                        if (pts.isNotEmpty()) {
                            val pg = NavigationProgressCalculator.compute(
                                pts, r.steps, r.totalDistanceMeters, r.totalDurationSeconds, loc,
                                offRouteThresholdMeters = 45.0 // ✅ v70 45m (평행도로 오탐↓, 실제 이탈은 추세 감지로 보완)
                            )
                            latestProgress = pg

                            // ✅ v33 휴게소: 경로 앞 휴게소 탐색 + 5km 전 1회 안내 (장거리 주행 편의)
                            if (restAreas.isNotEmpty() && currentRoadInfo?.roadName?.contains("고속도로") == true) {
                                val next = restRepo.nextOnRoute(pts, pg.nearestRouteIndex, restAreas)
                                nextRestArea = next
                                next?.let { (area, dist) ->
                                    if (dist in 1..5000 && area.name !in announcedRestAreas) {
                                        announcedRestAreas = announcedRestAreas + area.name
                                        val amenities = buildList {
                                            if (area.hasGasStation) add("주유소")
                                            if (area.hasEvCharger) add("전기충전")
                                        }.joinToString("·")
                                        val msg = "전방 ${dist / 1000}킬로미터 ${area.name}" +
                                            if (amenities.isNotEmpty()) " ($amenities)" else ""
                                        if (currentMode.needsVoiceGuidance &&
                                            com.navifit.navigation.NavSettings.voiceEnabled(this@MainActivity)) {
                                            voice.speakFreeform(msg)
                                        }
                                        toast("🛣️ $msg")
                                    }
                                }
                            }
                            if (currentMode.needsVoiceGuidance) {
                                pg.nextStep?.let { step ->
                                    // ✅ v38: 인덱스 대신 고유키 사용 (재탐색으로 인덱스가 바뀌어도 안내가 꼬이지 않음)
                                    //         + 현재 속도를 넘겨 고속에선 더 일찍 안내
                                    val stepKey = "${step.instruction}|${step.endLocation.latitude},${step.endLocation.longitude}"
                                    voice.announceIfNeeded(step, stepKey, pg.distanceToNextTurnMeters, trackingState.speedKmh)
                                    // ✅ v90 회전 진동: 좌회전=길게 1번, 우회전=짧게 2번 → 화면 안 봐도 방향 구분
                                    if (pg.distanceToNextTurnMeters in 1..60 && lastHapticStepKey != stepKey) {
                                        lastHapticStepKey = stepKey
                                        val instr = step.instruction
                                        when {
                                            instr.contains("왼") || instr.contains("좌회전") ->
                                                com.navifit.tracking.HapticFeedback.turnLeft(this@MainActivity)
                                            instr.contains("오른") || instr.contains("우회전") ->
                                                com.navifit.tracking.HapticFeedback.turnRight(this@MainActivity)
                                            else -> com.navifit.tracking.HapticFeedback.turnGeneric(this@MainActivity)
                                        }
                                    }
                                }
                                // ✅ v48 돌발상황(사고·공사) 경보 — 경로 앞쪽 20km 내
                            if (!currentMode.isWorkoutMode && incidents.isNotEmpty() && pts.isNotEmpty()) {
                                val ahead = exRoadRepo.findAhead(incidents, pts, loc)
                                nextIncident = ahead
                                if (ahead != null) {
                                    val (inc, meters) = ahead
                                    val key = "${inc.location.latitude},${inc.location.longitude}"
                                    // 3km 이내로 접근하면 1회만 음성 경보
                                    if (meters in 1..3000 && key !in announcedIncidents) {
                                        announcedIncidents = announcedIncidents + key
                                        val laneTxt = if (inc.lanesBlocked > 0) "${inc.lanesBlocked}차로 통제" else ""
                                        voice.speakFreeform(
                                            "전방 ${meters / 100 * 100}미터 ${inc.type.label} 발생. $laneTxt 주의하세요"
                                        )
                                        toast("${inc.type.icon} 전방 ${meters}m ${inc.type.label} · ${inc.message}")
                                    }
                                }
                            }

                            // ✅ v33: 남은거리 계산이 어긋나도 목적지 반경 40m 내면 도착으로 인정
                                //    (announceArrival 내부에서 1회만 재생되도록 가드 - 기존엔 매 업데이트마다 반복됐음)
                                val directToDest = currentDest?.let {
                                    NavigationProgressCalculator.fastDistanceMeters(loc, it)
                                } ?: Double.MAX_VALUE
                                if (pg.remainingMeters < 20 || directToDest < 40) {
                                    voice.announceArrival()
                                    com.navifit.tracking.HapticFeedback.arrive(this@MainActivity)  // ✅ v90
                                }
                            }

                            // ✅ v70 경로이탈 판정 개선 (평행도로 오탐↓ + 다른방향 재탐색↑):
                            currentRoadInfo = roadResolver.resolve(pg.nextStep, gpsAvailable = true)
                            val gpsSteady = System.currentTimeMillis() > gpsRecoveryUntilMs &&
                                    trackingState.accuracyMeters in 0.1f..50f

                            // 경로에서 떨어진 거리 이력 (추세 판단용)
                            offRouteDistHistory.addLast(pg.distanceFromRouteMeters)
                            if (offRouteDistHistory.size > 5) offRouteDistHistory.removeFirst()
                            // "멀어지는 추세": 최근 거리들이 계속 증가 + 마지막이 30m 이상이면 다른 길로 가는 중
                            val trendingAway = offRouteDistHistory.size >= 4 &&
                                offRouteDistHistory.last() > 30.0 &&
                                offRouteDistHistory.zipWithNext().count { (a, b) -> b > a } >= 3

                            if (!trackingState.isAfterSignalGap && gpsSteady) {
                                // 이탈(45m↑) 또는 "멀어지는 추세"면 카운트 증가
                                if (pg.isOffRoute || trendingAway) offRouteStreak++ else offRouteStreak = 0
                            } else if (!gpsSteady) {
                                offRouteStreak = 0
                            }
                            val nowMs = System.currentTimeMillis()
                            val sugRoute = suggestedRoute
                            if (followGuide == null && pg.isOffRoute && sugRoute != null) {
                                // ✅ v83 강제 언랩 제거 (안내 중 앱이 꺼지던 위험 제거)
                                val sug = sugRoute
                                val sugPts = decodePolyline(sug.overviewPolyline)
                                val distToSuggested = if (sugPts.size >= 2) {
                                    NavigationProgressCalculator.compute(
                                        sugPts, sug.steps, sug.totalDistanceMeters, sug.totalDurationSeconds, loc
                                    ).distanceFromRouteMeters
                                } else Double.MAX_VALUE
                                if (distToSuggested < 40.0) {
                                    route = sug
                                    voice.resetForNewRoute()
                                    suggestedRoute = null
                                    offRouteStreak = 0
                                    lastRerouteAtMillis = nowMs
                                    if (currentMode.needsVoiceGuidance && com.navifit.navigation.NavSettings.voiceEnabled(this@MainActivity)) {
                                        voice.speakFreeform("빠른 길로 안내합니다. 약 ${suggestedSavedMinutes}분 단축됩니다")
                                    }
                                    toast("⚡ 빠른 길로 안내합니다 (약 ${suggestedSavedMinutes}분 단축)")
                                }
                            }
                            if (suggestedRoute != null && !pg.isOffRoute &&
                                nowMs - lastSuggestAtMs > 3 * 60_000L) suggestedRoute = null

                            // ✅ v70 재탐색: 3샘플 연속 이탈/멀어짐이면 즉시 재탐색 (8초 간격)
                            //   distanceFromRouteMeters > 30 (평행도로 오탐 줄이려 추세 조건과 병행)
                            if (followGuide == null && offRouteStreak >= 3 &&
                                (pg.distanceFromRouteMeters > 45 || (trendingAway && pg.distanceFromRouteMeters > 30)) &&
                                !rerouting && nowMs - lastRerouteAtMillis > 8_000L) {
                                val dest = currentDest
                                if (dest != null) {
                                    rerouting = true
                                    lastRerouteAtMillis = nowMs
                                    offRouteStreak = 0
                                    if (currentMode.needsVoiceGuidance) voice.announceOffRoute()
                                    com.navifit.tracking.HapticFeedback.offRoute(this@MainActivity)  // ✅ v90 강한 진동
                                    scope.launch {
                                        routing.fetchRoutesWithTraffic(loc, dest, currentMode, RoutePreference.load(this@MainActivity))
                                            .onSuccess { newRoutes ->
                                                rerouteFailStreak = 0
                                                route = newRoutes.first()
                                                voice.resetForNewRoute()
                                                alternativeRoutes = newRoutes.drop(1).take(2)
                                                suggestedRoute = null
                                                if (currentMode.needsVoiceGuidance) {
                                                    voice.announceRouteStart(newRoutes.first().totalDistanceMeters, newRoutes.first().totalDurationSeconds)
                                                }
                                            }
                                            .onFailure {
                                                rerouteFailStreak++
                                                if (rerouteFailStreak == 3) {
                                                    toast(
                                                        if (!com.navifit.navigation.NetworkCheck.isOnline(this@MainActivity))
                                                            "📵 인터넷 연결이 끊겼어요. 연결되면 자동으로 재탐색합니다 (기존 경로로 계속 안내 중)"
                                                        else "⚠️ 경로 재탐색이 계속 실패해요. 잠시 후 다시 시도합니다 (기존 경로로 계속 안내합니다)"
                                                    )
                                                }
                                                lastRerouteAtMillis = System.currentTimeMillis() +
                                                    (rerouteFailStreak.coerceAtMost(6) * 8_000L)
                                            }
                                        rerouting = false
                                    }
                                }
                            }

                            // 목적지 반경 25m 이내 진입 + 최소 이동거리(오작동 방지) 조건을 만족하면 자동 종료
                            // ✅ v38: 남은거리 계산이 어긋나도 목적지 반경 35m 직선거리로 도착 인정
                            val directDist = currentDest?.let {
                                NavigationProgressCalculator.fastDistanceMeters(loc, it)
                            } ?: Double.MAX_VALUE
                            // ✅ v58: 시작하자마자 "도착 완료"되던 오탐 방지 - 최소 30초 경과 + 60m 이동 필요
                            if (!hasAutoFinished && (pg.remainingMeters < 25 || directDist < 35) &&
                                trackingState.totalDistanceMeters > 60 &&
                                trackingState.elapsedSeconds > 30) {
                                hasAutoFinished = true
                                toast("🏁 목적지에 도착해서 자동으로 기록을 종료했어요")
                                finishNavigation()
                            }
                        }
                    }
                }
            }
        }

        // ✅ "저장했는데 기록이 안 보이던" 문제 수정: 탭을 오갈 때·안내가 끝날 때마다 기록을 다시 읽음
        //    (기존엔 앱 시작 시 1번만 읽어서, 방금 저장한 운동이 분석/랭킹 화면에 안 나타났음)
        LaunchedEffect(tab, navigating) { records = db.activityRecordDao().getAll() }
        // ✅ 발열 방지 안전장치: 안내 중이 아닌데 위치추적 서비스가 살아있으면 강제 종료
        //    (예외 경로로 서비스가 남아 GPS가 계속 돌며 폰이 뜨거워지는 문제 차단)
        LaunchedEffect(navigating) {
            if (!navigating) {
                LocationTrackingService.stop(this@MainActivity)
                approachRoute = null
            }
        }

        // ✅ v27 터널 추측항법 틱커: GPS가 6초 이상 안 들어오면 마지막 속도·방향으로 위치를 추정해서
        //    지도가 멈추지 않고 계속 따라가게 함 (경로 있으면 경로 위로 스냅). 실제 fix 오면 즉시 복귀.
        var estimatedLocation by remember { mutableStateOf<LatLngPoint?>(null) }

        // ✅ v31 "더 빠른 경로" 스마트 감시 (요청 반영: 맨날 하는 게 아니라):
        //   ① IC·JC·분기점·램프 등 "갈아탈 수 있는 큰 갈림길" 2.5km 전 접근 시 딱 1회 조회
        //   ② 정체 감지(25km/h 미만 저속이 4분+ 지속 = 3km급 막힘) 시 30분에 1회만 조회
        //   그 외엔 호출 안 함. 3분 이상 빨라질 때만 갈아타고 음성 안내. (친구 길 따라가기 모드 제외)
        var routeSetAtMs by remember { mutableStateOf(0L) }
        LaunchedEffect(route) { if (route != null) routeSetAtMs = System.currentTimeMillis() }
        LaunchedEffect(navigating, currentMode) {
            if (!navigating || currentMode.isWorkoutMode) return@LaunchedEffect
            while (true) {
                kotlinx.coroutines.delay(30_000L)
                if (!navigating || followGuide != null || rerouting) continue
                val loc = trackingState.currentLocation ?: continue
                val dest = currentDest ?: continue
                val cur = route ?: continue
                val lp = latestProgress

                // ① 큰 갈림길 접근 판정: 다음 스텝이 램프/분기/합류/회전교차로이거나 안내문에 IC·JC·분기·방면 포함
                val step = lp?.nextStep
                val stepKey = "${step?.instruction}|${step?.endLocation?.latitude}"
                // ✅ v48: maneuver는 nullable(String?)이라 직접 .contains 하면 컴파일 에러
                val mv = step?.maneuver ?: ""
                val ins = step?.instruction ?: ""
                val isDecisionManeuver = step != null && (
                    mv.contains("ramp") || mv.contains("merge") ||
                    mv.contains("fork") || mv.contains("roundabout") ||
                    ins.contains("IC") || ins.contains("JC") ||
                    ins.contains("분기") || ins.contains("갈림") ||
                    ins.contains("방면") || ins.contains("고속도로")
                )
                val approachingDecision = isDecisionManeuver && lp != null &&
                    (lp.distanceToNextTurnMeters in 400..2500) && stepKey != lastDecisionCheckStepKey

                // ② 정체 판정: 저속(25km/h 미만) 4분 이상 지속 + 남은 거리 3km 이상
                val congested = lowSpeedAccumMs >= 4 * 60_000L && (lp?.remainingMeters ?: 0) > 3000
                val congestionDue = congested && System.currentTimeMillis() - lastCongestionCheckMs >= 30 * 60_000L

                if (!approachingDecision && !congestionDue) continue
                if (approachingDecision) lastDecisionCheckStepKey = stepKey
                if (congestionDue) lastCongestionCheckMs = System.currentTimeMillis()

                routing.fetchRoutesWithTraffic(loc, dest, currentMode, RoutePreference.load(this@MainActivity))
                    .onSuccess { newRoutes ->
                        val newBest = newRoutes.first()
                        val elapsedSec = (System.currentTimeMillis() - routeSetAtMs) / 1000
                        val curRemaining = (cur.totalDurationSeconds - elapsedSec).coerceAtLeast(60)
                        val savedSec = curRemaining - newBest.totalDurationSeconds
                        if (savedSec >= 180) {
                            // ✅ v32: 자동으로 갈아타지 않음! 연한 파란색으로 "제안"만 하고 안내 메시지.
                            //    사용자가 실제로 그 길로 핸들을 틀면 → 이탈 감지 → 그 제안 경로로 자동 전환.
                            suggestedRoute = newBest
                            suggestedSavedMinutes = (savedSec / 60).toInt()
                            lastSuggestAtMs = System.currentTimeMillis()
                            if (currentMode.needsVoiceGuidance && com.navifit.navigation.NavSettings.voiceEnabled(this@MainActivity)) {
                                voice.speakFreeform(
                                    if (approachingDecision) "전방 분기점에서 약 ${savedSec / 60}분 빠른 길이 있습니다. 그 길로 가시면 자동으로 안내합니다"
                                    else "정체 구간을 우회하는 약 ${savedSec / 60}분 빠른 길이 있습니다"
                                )
                            }
                            toast("💡 약 ${savedSec / 60}분 빠른 길이 있어요 (연한 파란색). 그쪽으로 가시면 자동 안내됩니다")
                        } else {
                            alternativeRoutes = newRoutes.drop(1).take(2)
                        }
                    }
            }
        }
        LaunchedEffect(navigating) {
            if (!navigating) { estimatedLocation = null; isGpsEstimating = false; return@LaunchedEffect }
            while (true) {
                kotlinx.coroutines.delay(2000L)
                val gapMs = System.currentTimeMillis() - lastFixAtMs
                if (lastFixAtMs > 0 && gapMs > 6000) {
                    // ✅ v69 GPS 끊겨도 신체가 실제로 움직이는 중이면 추정 이동 계속 (터널·지하·오프라인)
                    //   몸이 멈춰있으면(정지) 추정도 멈춰서 "가만히 있는데 거리 늘어남" 방지
                    val bodyMoving = motionEngine.isBodyMoving
                    val routePts = routePointsCache.ifEmpty { null }   // ✅ v45 캐시
                    val est = if (bodyMoving) deadReckoning.estimate(routePts) else estimatedLocation
                    estimatedLocation = est
                    isGpsEstimating = deadReckoning.isEstimating && bodyMoving

                    if (deadReckoning.isEstimating && est != null) {
                        currentRoadInfo = roadResolver.resolve(latestProgress?.nextStep, gpsAvailable = false)

                        // ✅ v40: 터널 안에서도 안내가 계속되게 함.
                        //    기존엔 GPS가 끊기면 진행률·회전안내·카메라경보가 전부 멈춰서
                        //    긴 터널을 지나면 출구에서 갑자기 "경로 이탈"이 뜨거나 회전을 놓쳤음.
                        val r = route
                        if (r != null && routePts != null && routePts.isNotEmpty()) {
                            val pg = NavigationProgressCalculator.compute(
                                routePts, r.steps, r.totalDistanceMeters, r.totalDurationSeconds, est,
                                offRouteThresholdMeters = 200.0   // 추정 위치이므로 이탈 판정은 매우 관대하게
                            )
                            latestProgress = pg
                            if (currentMode.needsVoiceGuidance) {
                                pg.nextStep?.let { step ->
                                    val stepKey = "${step.instruction}|${step.endLocation.latitude},${step.endLocation.longitude}"
                                    voice.announceIfNeeded(step, stepKey, pg.distanceToNextTurnMeters, trackingState.speedKmh)
                                }
                            }
                            // 터널 안 카메라(구간단속 등)도 계속 감시
                            if (!currentMode.isWorkoutMode) {
                                alertEngine.feed(est, trackingState.speedKmh, trackingState.bearingDegrees)
                                hazardAlert = alertEngine.currentAlert
                            }
                        }
                    }
                } else {
                    estimatedLocation = null
                }
            }
        }

        // ② Activity Recognition (가속도계+자이로 ML 분석) 결과 수신 -> 판정기에 전달
        LaunchedEffect(navigating) {
            if (navigating) {
                com.navifit.tracking.ActivityTypeMonitor.detectedActivity.collect { detected ->
                    detected?.let { (type, confidence) ->
                        val wasValid = antiCheat.isRankingValid
                        antiCheat.onDetectedActivity(type, confidence)
                        if (wasValid && !antiCheat.isRankingValid) {
                            cheatDialogReason = antiCheat.invalidReason ?: "비정상적인 움직임이 감지됐어요"
                        }
                    }
                }
            }
        }

        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> if (navigating) {
                        NavigationMapScreen(
                            mode = currentMode,
                            nickname = nickname,
                            rerouting = rerouting,
                            isEmergencyDetour = emergencyDetour,
                            onEmergencyToilet = { pos, name ->
                                // ✅ v75 긴급 화장실 안내:
                                //   - 운동 중이면 기존 "길안내"만 화장실로 바꾸고, 운동 기록(거리·시간)은 계속 측정.
                                //     (일시정지하면 화장실 핑계로 쉬는 꼼수가 가능하므로 기록은 절대 멈추지 않음)
                                //   - 운동 중이 아니면(그냥 지도) 기록 없이 화장실 안내만.
                                emergencyBackupRoute = route
                                emergencyBackupMode = currentMode
                                // paused = true 를 하지 않음! 운동 기록은 계속 흐름
                                emergencyDetour = true
                                scope.launch {
                                    val origin = trackingState.currentLocation ?: awaitFreshLocation()
                                    if (origin != null) {
                                        routing.fetchRoutesWithTraffic(origin,
                                            LatLngPoint(pos.latitude, pos.longitude), TravelMode.WALK,
                                            com.navifit.navigation.RoutePreference.load(this@MainActivity))
                                            .onSuccess { rts -> route = rts.firstOrNull() }
                                    }
                                    toast("🚨 $name 로 안내합니다. 운동 기록은 계속 측정돼요 (쉬어도 기록은 흐릅니다)")
                                }
                            },
                            onReturnFromEmergency = {
                                // 원래 운동 경로 복귀 (기록은 멈춘 적 없으니 그대로 이어짐)
                                route = emergencyBackupRoute
                                currentMode = emergencyBackupMode ?: currentMode
                                emergencyDetour = false
                                toast("↩️ 원래 운동 안내로 돌아왔어요")
                            },
                            // ✅ v40 치명적 버그 수정: 기존 `trackingState.currentLocation ?: estimatedLocation` 은
                            //    터널에서도 마지막 위치가 남아있어 null이 아니므로 폴백이 절대 발동하지 않았음
                            //    → 추측항법이 사실상 죽은 코드였고 지도가 그냥 멈췄음.
                            //    이제 "추정 중"일 때는 명시적으로 추정 위치를 사용.
                            currentLocation = if (isGpsEstimating && estimatedLocation != null)
                                estimatedLocation else trackingState.currentLocation,
                            plannedRoute = route,
                            traveledPath = traveledPath.toList(),
                            equippedMarker = inventory.equippedKey?.let { inventory.resolveMarker(it) },
                            deviceBearing = trackingState.bearingDegrees,
                            equippedBorderKey = inventory.selectedBorderKey,
                            elapsedSeconds = liveElapsedSeconds,
                            distanceMeters = trackingState.totalDistanceMeters,
                            speedKmh = trackingState.speedKmh,
                            safetyTracker = if (currentMode.isWorkoutMode) null else safetyTracker,
                            onFinish = { finishNavigation() },
                            // ═══ v27 ═══
                            alternativeRoutes = alternativeRoutes,
                            onSelectAlternative = { sel ->
                                // 회색 대체경로 탭 -> 그 경로로 교체, 기존 메인은 대체경로 목록으로
                                val oldMain = route
                                route = sel
                                voice.resetForNewRoute()   // ✅ v38 새 경로 → 안내 단계 초기화
                                alternativeRoutes = (alternativeRoutes.filter { it !== sel } + listOfNotNull(oldMain)).take(2)
                                if (currentMode.needsVoiceGuidance && com.navifit.navigation.NavSettings.voiceEnabled(this@MainActivity)) {
                                    voice.speakFreeform("대체 경로로 변경했어요")
                                }
                            },
                            suggestedRoute = suggestedRoute,
                            suggestedSavedMinutes = suggestedSavedMinutes,
                            trafficSegments = trafficSegments,
                            hazardAlert = hazardAlert,
                            isViolationWarning = isViolationWarning,
                            isGpsEstimating = isGpsEstimating,
                            gpsAccuracyMeters = trackingState.accuracyMeters,
                            gpsSatellites = trackingState.satellitesUsed,
                            elevationGainMeters = trackingState.elevationGainMeters,
                            roadInfo = currentRoadInfo,
                            followRouteState = followState,
                            approachRoute = approachRoute
                        )
                    } else {
                        Box(Modifier.fillMaxSize()) {
                        // ✅ 공유경로 키 다이얼로그 상태 (상단 🔑 버튼에서 열림 - 하단 FAB 제거)
                        var showRouteKeyDialog by remember { mutableStateOf(false) }
                        ModeSelectScreen(
                            placesClient = placesClient,
                            onOpenRouteKey = { showRouteKeyDialog = true },
                            onModeSelected = { currentMode = it },
                            onStartFreeRun = { mode ->
                                ensureLocationPermissionThen { beginFreeRun(mode) }
                            },
                            onSearchDestination = { name, lat, lng, mode ->
                                // ✅ 권한 없으면 알림 먼저
                                ensureLocationPermissionThen {
                                    currentMode = mode
                                    currentDestName = name
                                    currentDest = LatLngPoint(lat, lng)
                                    offRouteStreak = 0
                                    lastRerouteAtMillis = 0L
                                    scope.launch {
                                        startNavigation(LatLngPoint(lat, lng), mode) { r, alts, originName ->
                                            // ✅ 모든 모드 공통: 경로가 나오면 바로 출발하지 않고
                                            //    "🏃 운동 시작 / 🧭 길안내 시작" 버튼이 있는 확인 창을 띄움.
                                            //    (기존엔 운동 모드가 이 창을 건너뛰고 즉시 시작됐는데,
                                            //     그 경로에서는 위치추적 서비스를 켜지 않아 거리 0으로 기록되는
                                            //     치명적 버그가 있었음 → 이제 전 모드가 beginNavigationWith로 통일)
                                            previewRoutes = listOf(r) + alts
                                            previewOriginName = originName
                                            pendingStart = Triple(LatLngPoint(lat, lng), mode, name)
                                        }
                                    }
                                }
                            }
                        )
                        if (showRouteKeyDialog) {
                            var keyInput by remember { mutableStateOf("") }
                            var keyError by remember { mutableStateOf<String?>(null) }
                            var resolving by remember { mutableStateOf(false) }
                            AlertDialog(
                                onDismissRequest = { if (!resolving) showRouteKeyDialog = false },
                                title = { Text("공유경로 따라가기", fontWeight = FontWeight.Bold) },
                                text = {
                                    Column {
                                        Text("친구에게 받은 경로 키를 입력하세요.\n(달리기 R- · 자전거 B- 로 시작해요)",
                                            fontSize = 12.sp, color = androidx.compose.ui.graphics.Color.Gray)
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedTextField(
                                            value = keyInput,
                                            onValueChange = { keyInput = it.uppercase(); keyError = null },
                                            placeholder = { Text("예: R-4K7P2Q") },
                                            singleLine = true, isError = keyError != null, enabled = !resolving
                                        )
                                        keyError?.let {
                                            Text(it, color = androidx.compose.ui.graphics.Color(0xFFFF8FA3),
                                                fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                                        }
                                        if (resolving) {
                                            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                                CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                                                Spacer(Modifier.width(8.dp))
                                                Text("서버에서 경로를 찾는 중...", fontSize = 12.sp,
                                                    color = androidx.compose.ui.graphics.Color.Gray)
                                            }
                                        }
                                    }
                                },
                                confirmButton = {
                                    Button(enabled = !resolving, onClick = {
                                        if (com.navifit.navigation.RouteKeyStore.normalize(keyInput) == null &&
                                            com.navifit.navigation.RouteShare.parse(keyInput) == null) {
                                            keyError = "키 형식이 올바르지 않아요 (예: R-4K7P2Q)"; return@Button
                                        }
                                        resolving = true
                                        scope.launch {
                                            // ✅ 로컬 → Firebase(Firestore) 순으로 조회: 친구가 발급한 키도 열림
                                            val shared = com.navifit.navigation.RouteKeyStore.resolve(this@MainActivity, keyInput)
                                                ?: com.navifit.navigation.RouteShare.parse(keyInput) // (구버전 원문 호환)
                                            resolving = false
                                            if (shared == null) {
                                                keyError = "존재하지 않는 키예요. 키를 다시 확인하거나, 인터넷 연결 상태를 확인해주세요"
                                            } else {
                                                showRouteKeyDialog = false
                                                ensureLocationPermissionThen { startFollowSharedRoute(shared) }
                                            }
                                        }
                                    }) { Text("안내 시작") }
                                },
                                dismissButton = {
                                    TextButton(enabled = !resolving, onClick = { showRouteKeyDialog = false }) { Text("취소") }
                                }
                            )
                        }
                        }
                    }
                    1 -> MarkerGachaScreen(
                        inventory = inventory,
                        exchangeTickets = tickets,
                        stepBoostLevel = boostLevel,
                        onConsumeTicket = { consumeTicket() },
                        myRecords = records,
                        questContent = { StepCounterPanel(steps, tickets, boostLevel) }   // ✅ v61 만보 퀘스트 탭
                    )
                    2 -> Column(Modifier.fillMaxSize()) {
                        // ✅ v58: "내 운동 분석" → "내 경로 보관함" 교체
                        //    폴더로 분류·이름·검색, 저장된 경로를 꺼내 [따라 뛰기] / [공유 키 발급]
                        //    (자동차·오토바이 기록은 제외되고 운동 궤적만 보관됨)
                        com.navifit.ui.screens.RouteVaultScreen(
                            records = records,
                            onFollowRoute = { m, poly ->
                                // ✅ v81 이미 운동 중이면 자유운동 위로 덮어써서 재시작되던 버그 → 팝업으로 차단
                                if (navigating) {
                                    alreadyRunningWarn = true
                                } else {
                                    ensureLocationPermissionThen {
                                        tab = 0
                                        startFollowSharedRoute(com.navifit.navigation.RouteShare.SharedRoute(m, poly))
                                    }
                                }
                            },
                            onIssueKey = { m, poly ->
                                val key = com.navifit.navigation.RouteKeyStore.issueKey(this@MainActivity, m, poly)
                                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                cm.setPrimaryClip(android.content.ClipData.newPlainText("navifit_route_key", key))
                                toast("🔑 공유 키 $key 복사됨! 친구가 '공유경로 키 입력'에 넣으면 이 코스 그대로 안내돼요")
                            },
                            onShareToCommunity = { m, poly, dist ->
                                // ✅ v76 경로를 운동장 게시물로
                                val key = com.navifit.navigation.RouteKeyStore.issueKey(this@MainActivity, m, poly)
                                val text = "🏃 %.2fkm %s 코스 공유! 같이 뛰어요 🔑 %s".format(
                                    dist / 1000, if (m == TravelMode.BIKE) "🚴 자전거" else "🏃 러닝", key)
                                com.navifit.ui.screens.CommunityStore.addPost(this@MainActivity, nickname, myUid, text,
                                    theme = if (m == TravelMode.BIKE) "bike" else "run")
                                toast("📣 운동장에 게시했어요!")
                                tab = 4
                            }
                        )
                    }
                    3 -> RankingScreen(records, nickname,
                        onVisitProfile = { name -> tab = 4; communitySubRequest = "profile:$name" },
                        onAddFriend = { name -> toast("$name 님에게 친구 요청을 보냈어요") },
                        onSendRm = { name -> tab = 4; communitySubRequest = "inbox" }
                    )
                    4 -> {
                        var communitySub by remember { mutableStateOf<Triple<String, String, String>?>(null) } // (mode, uid, nickname) mode: "feed"|"inbox"|"thread"|"friends"
                        // ✅ v85 운동장 하위 화면 뒤로가기: 대화 → 목록 → 피드 순으로 한 단계씩
                        androidx.activity.compose.BackHandler(enabled = communitySub != null) {
                            val cur = communitySub
                            communitySub = when (cur?.first) {
                                // 대화방에서 뒤로 → RM 목록으로
                                "thread" -> Triple("inbox", "", "")
                                // 그 외 하위 화면 → 피드로
                                else -> null
                            }
                        }
                        var showProfileEdit by remember { mutableStateOf(false) }   // ✅ v64 프로필 편집 다이얼로그
                        if (showProfileEdit) {
                            ProfileEditDialog(onDismiss = { showProfileEdit = false })
                        }
                        // ✅ v61 알림 탭에서 온 요청 처리 (친구요청/RM 화면 바로 열기)
                        LaunchedEffect(communitySubRequest) {
                            val req = communitySubRequest
                            when {
                                req == "friends" -> communitySub = Triple("friends", "", "")
                                req == "inbox" -> communitySub = Triple("inbox", "", "")
                                req == "feed" -> communitySub = null
                                req != null && req.startsWith("profile:") -> {
                                    val name = req.removePrefix("profile:")
                                    communitySub = Triple("profile", "", name)   // ✅ v79 랭킹→프로필 구경
                                }
                                req != null && req.startsWith("post:") -> {
                                    // ✅ v81 알림 딥링크 → 피드에서 해당 글로 스크롤
                                    communitySub = null
                                    focusPostId = req.removePrefix("post:")
                                }
                            }
                            if (communitySubRequest != null) communitySubRequest = null
                        }
                        val friendRepo = remember { com.navifit.social.FriendRepository() }
                        val codeManager = remember { com.navifit.social.UniqueCodeManager() }
                        // ✅ v83 네비게이션 구조 재작성:
                        //   기존엔 communitySub!! 강제 언랩을 써서, 뒤로가기로 상태가 null이 되는 순간
                        //   NullPointerException이 터져 앱이 꺼졌다(= RM 튕김의 진짜 원인).
                        //   이제 화면 진입 시 값을 "한 번만" 안전하게 꺼내서(local val) 쓰고,
                        //   값이 없으면 크래시 대신 목록으로 되돌린다.
                        val sub = communitySub
                        val subKind = sub?.first ?: "feed"
                        val subArg1 = sub?.second.orEmpty()
                        val subArg2 = sub?.third.orEmpty()
                        when (subKind) {
                            // ✅ v83 RM 전면 재작성 화면 (로컬 우선 = 서버 오류로 안 꺼짐)
                            "inbox" -> com.navifit.ui.screens.RmInboxScreen(
                                myNickname = nickname,
                                onOpenThread = { uid, nick -> communitySub = Triple("thread", uid, nick) },
                                onOpenGroupRoom = { roomId -> communitySub = Triple("group", roomId, "") },
                                onOpenFriends = { communitySub = Triple("friends", "", "") },
                                onBack = { communitySub = null }
                            )
                            "group" -> {
                                if (subArg1.isBlank()) communitySub = Triple("inbox", "", "")
                                else com.navifit.ui.screens.GroupRoomScreen(
                                    roomId = subArg1,
                                    myUid = myUid, myNickname = nickname,
                                    onBack = { communitySub = Triple("inbox", "", "") }
                                )
                            }
                            "friends" -> FriendsScreen(
                                myUid = myUid, friendRepo = friendRepo, codeManager = codeManager,
                                onOpenRm = { uid, nick -> communitySub = Triple("thread", uid, nick) },
                                onBack = { communitySub = null }
                            )
                            "thread" -> {
                                if (subArg1.isBlank()) communitySub = Triple("inbox", "", "")
                                else com.navifit.ui.screens.RmChatScreen(
                                    myNickname = nickname,
                                    peerUid = subArg1, peerNickname = subArg2.ifBlank { "상대" },
                                    onBack = { communitySub = Triple("inbox", "", "") }
                                )
                            }
                            "profile" -> {
                                // ✅ v64 인스타식 프로필 화면
                                val pNick = subArg2
                                val pUid = subArg1
                                val isMe = pNick == nickname
                                val allPosts = com.navifit.ui.screens.CommunityStore.currentPosts()
                                val mine = allPosts.filter { it.author == pNick }
                                val photos = mine.flatMap { post ->
                                    (post.mediaPaths.ifEmpty { listOfNotNull(post.mediaPath) })
                                        .filter { !it.endsWith(".mp4") }
                                        .map { com.navifit.ui.screens.PostMediaItem(post.id, it, false, post.createdAt) }
                                }
                                val videos = mine.flatMap { post ->
                                    (post.mediaPaths.ifEmpty { listOfNotNull(post.mediaPath) })
                                        .filter { it.endsWith(".mp4") }
                                        .map { com.navifit.ui.screens.PostMediaItem(post.id, it, true, post.createdAt) }
                                }
                                val texts = mine.filter { it.mediaPaths.isEmpty() && it.mediaPath == null }
                                    .map { com.navifit.ui.screens.PostTextItem(it.id, it.text, it.createdAt, it.likes) }
                                com.navifit.ui.screens.SnsProfileScreen(
                                    profileNickname = pNick, profileUid = pUid, isMe = isMe,
                                    allPosts = mine, photoPosts = photos, videoPosts = videos, textPosts = texts,
                                    records = if (isMe) records else emptyList(),
                                    onBack = { communitySub = null },
                                    onEditProfile = { showProfileEdit = true },
                                    onOpenPost = { communitySub = null }
                                )
                            }
                            else -> {
                                // ✅ @멘션 검증용 친구 닉네임 목록 (친구만 멘션 가능)
                                var friendNicks by remember { mutableStateOf<Set<String>>(emptySet()) }
                                LaunchedEffect(myUid) {
                                    if (myUid.isNotBlank()) friendNicks = try {
                                        com.navifit.social.FriendRepository().listFriends(myUid).map { it.nickname }.toSet()
                                    } catch (e: Exception) { emptySet() }
                                }
                                CommunityScreen(
                                focusPostId = focusPostId,
                                onFocusConsumed = { focusPostId = null },
                                myNickname = nickname, isAnonymous = isAnonymous, myUid = myUid,
                                myLocation = trackingState.currentLocation,
                                onOpenDm = { uid, nick -> communitySub = Triple("thread", uid, nick) },
                                onOpenInbox = { communitySub = Triple("inbox", "", "") },
                                onOpenFriends = { communitySub = Triple("friends", "", "") },
                                notifUnreadCount = notifUnread,
                                dmUnreadCount = dmUnreadCount,
                                onOpenNotifications = { showNotifications = true },
                                onOpenProfile = { nick, uid -> communitySub = Triple("profile", uid, nick) },
                                onRequestRm = { nick, uid ->
                                    // ✅ v86 RM 요청 → 그 사람과의 대화방으로 바로 이동
                                    if (uid.isNotBlank()) communitySub = Triple("thread", uid, nick)
                                    else toast("$nick 님은 RM을 받을 수 없어요")
                                },
                                onRequestRunFriend = { nick, uid ->
                                    // ✅ v86 런친(러닝 친구) 요청
                                    scope.launch {
                                        try {
                                            if (uid.isNotBlank()) {
                                                friendRepo.sendRequest(myUid, uid, nickname)
                                                toast("🏃 $nick 님에게 런친 요청을 보냈어요")
                                            } else toast("$nick 님에게는 요청할 수 없어요")
                                        } catch (_: Exception) { toast("요청에 실패했어요") }
                                    }
                                },
                                friendNicknames = friendNicks,
                                onFollowSharedRoute = { sr ->
                                    ensureLocationPermissionThen {
                                        tab = 0                       // 지도 탭으로 이동
                                        startFollowSharedRoute(sr)
                                    }
                                }
                            )
                            }
                        }
                    }
                    5 -> com.navifit.ui.screens.VsScreen(
                        myNickname = nickname,
                        state = vsGameState,
                        onMeasure100m = { onProgress, onDone ->
                            // ✅ v71 실제 100m 측정 + 부정출발 감지 (정지 상태에서 시작해야 함)
                            ensureLocationPermissionThen {
                                LocationTrackingService.paused = false   // ✅ v77 이전 긴급안내 잔여 일시정지 해제
                                LocationTrackingService.startWithMode(this@MainActivity, TravelMode.WALK)
                                motionEngine.start()
                                vsMeasureJob?.cancel()
                                vsMeasureJob = lifecycleScope.launch {
                                    // ── 부정출발 체크: 카운트다운 끝 시점에 이미 뛰고 있으면(속도 5km/h↑) 부정출발 ──
                                    val startSpeed = LocationTrackingService.trackingState.value.speedKmh
                                    val alreadyMoving = startSpeed > 5.0 || motionEngine.motionEnergy > 3.0
                                    if (alreadyMoving) {
                                        // 부정출발 → 즉시 종료, 큰 페널티 시간(사실상 패배) + 플래그
                                        LocationTrackingService.stop(this@MainActivity)
                                        motionEngine.stop()
                                        onDone(999.0, null)   // 999초 = 부정출발 패배 신호
                                        return@launch
                                    }
                                    val startDist = LocationTrackingService.trackingState.value.totalDistanceMeters
                                    val startTime = System.currentTimeMillis()
                                    val startPath = ArrayList<LatLngPoint>()
                                    while (true) {
                                        val st = LocationTrackingService.trackingState.value
                                        val ran = st.totalDistanceMeters - startDist
                                        onProgress(ran.coerceIn(0.0, 100.0))
                                        st.currentLocation?.let { startPath.add(it) }
                                        if (ran >= 100.0) break
                                        if (System.currentTimeMillis() - startTime > 120_000) break
                                        kotlinx.coroutines.delay(500)
                                    }
                                    val elapsed = (System.currentTimeMillis() - startTime) / 1000.0
                                    LocationTrackingService.stop(this@MainActivity)
                                    motionEngine.stop()
                                    val poly = if (startPath.size >= 2) encodeTravelPolyline(startPath) else null
                                    onDone(elapsed, poly)
                                }
                            }
                        },
                        onSaveRoute = { poly, timeSec ->
                            // VS 경로도 운동 이력처럼 보관함에 저장 (✅ v81 실제 기록 시간·속도 반영)
                            lifecycleScope.launch {
                                val secs = timeSec.coerceAtLeast(0.1)
                                val rec = com.navifit.data.ActivityRecord(
                                    mode = TravelMode.WALK, distanceMeters = 100.0,
                                    durationSeconds = secs.toLong().coerceAtLeast(1L),
                                    avgSpeedKmh = (100.0 / secs) * 3.6,
                                    maxSpeedKmh = (100.0 / secs) * 3.6,
                                    startTimeMillis = System.currentTimeMillis(),
                                    pathPolyline = poly, originName = "VS 대결", destinationName = "100m"
                                )
                                try {
                                    val id = db.activityRecordDao().insert(rec)
                                    com.navifit.ui.screens.RouteVaultStore.setName(this@MainActivity, id, "VS 100m 대결")
                                } catch (_: Exception) {}
                            }
                        },
                        onShowAd = { onAdDone ->
                            // 광고 자리 (실제 광고 SDK 연동 전 - 2초 대기 후 진행)
                            lifecycleScope.launch { kotlinx.coroutines.delay(2000); onAdDone() }
                        }
                    )   // ✅ v63 VS 대결
                    7 -> com.navifit.ui.screens.CameraApiTestScreen(onBack = { tab = 6 })  // 화장실 API 테스트
                    6 -> ProfileScreen(
                        onOpenCameraTest = { tab = 7 },
                        nickname = nickname,
                        isAnonymous = isAnonymous,
                        googleEmail = googleEmail,
                        records = records,
                        totalSteps = steps,
                        uniqueCode = myUniqueCode,
                        currentLanguage = currentLanguage,
                        onLanguageChange = onLanguageChange,
                        onChangeNickname = { newNick, done ->
                            // ✅ v41 닉네임에도 다국어 필터 (욕설·19금·광고 닉네임 차단)
                            val nickViolation = com.navifit.moderation.ContentFilter.check(newNick, allowLinks = true)
                            if (nickViolation != null) {
                                done(false, nickViolation.reason)
                            } else scope.launch {
                                val uid = auth.currentUser()?.uid ?: return@launch done(false, "로그인 상태를 확인할 수 없어요")
                                when (val r = nicknameManager.claim(newNick, uid, previousNickname = nickname)) {
                                    is NicknameManager.ClaimResult.Success -> {
                                        nickname = newNick
                                        profileRepo.save(UserProfile(uid, newNick, isAnonymous, googleEmail))
                                        done(true, "")
                                    }
                                    is NicknameManager.ClaimResult.Taken -> done(false, "이미 사용 중인 닉네임이에요 😢")
                                    is NicknameManager.ClaimResult.Error -> done(false, r.message)
                                }
                            }
                        },
                        onGoogleLink = { googleLoginLauncher.launch(auth.getGoogleSignInIntent()) },
                        onVerifyLink = { report ->
                            scope.launch {
                                val user = auth.currentUser()
                                when {
                                    user == null -> report("❌ 로그인 정보가 없어요")
                                    user.isAnonymous -> report("아직 게스트 상태예요 - 구글 연결이 필요해요")
                                    else -> {
                                        try { user.reload() } catch (_: Exception) {}
                                        report("✅ 연동 정상 · ${user.email ?: "구글 계정"} 으로 연결되어 있어요")
                                    }
                                }
                            }
                        },
                        onLogout = {
                            scope.launch {
                                // 구글 연동 계정은 서버에 프로필 저장돼 있어 재로그인 시 복원됨
                                auth.currentUser()?.let { u ->
                                    profileRepo.save(UserProfile(u.uid, nickname, isAnonymous, googleEmail))
                                }
                                auth.signOut()
                                // ✅ v77 로그아웃 시 기기에 남은 개인 데이터 초기화 (마커·포인트·인벤토리 등)
                                clearLocalUserData()
                                nickname = "게스트"; isAnonymous = true; googleEmail = null
                                tab = 0
                                stage = "LOGIN"
                            }
                        }
                    )
                }
            }

            // ✅ v61 운동 종료 결과 화면 - navigating 상태와 무관하게 최상위에서 표시
            //    (기존엔 navigating 블록 안이라 종료(navigating=false) 즉시 사라져 저장/결과가 안 떴음)
            workoutResultData?.let { (rec, valid) ->
                com.navifit.ui.screens.WorkoutResultScreen(
                    record = rec,
                    rankingValid = valid,
                    estimatedRank = if (valid) (1..500).random() else null,
                    folders = com.navifit.ui.screens.RouteVaultStore.folders(this@MainActivity),
                    askFolderOnSave = com.navifit.ui.screens.RouteVaultStore.askFolderOnSave(this@MainActivity),
                    onSaveRoute = { name, folder ->
                        com.navifit.ui.screens.RouteVaultStore.setFolder(this@MainActivity, rec.id, folder)
                        if (name.isNotBlank())
                            com.navifit.ui.screens.RouteVaultStore.setName(this@MainActivity, rec.id, name)
                        toast("💾 '$folder' 폴더에 경로를 저장했어요")
                    },
                    onShareToCommunity = { userText ->
                        // ✅ v81 사용자가 팝업에서 수정한 글 + 경로키를 붙여 게시
                        val key = rec.pathPolyline?.let {
                            com.navifit.navigation.RouteKeyStore.issueKey(this@MainActivity, rec.mode, it)
                        }
                        val text = buildString {
                            append(userText.trim())
                            if (key != null) append("\n이 코스 같이 뛰어요 🔑 ").append(key)
                        }
                        com.navifit.ui.screens.CommunityStore.addPost(
                            this@MainActivity, nickname, myUid, text,
                            theme = if (rec.mode == com.navifit.navigation.TravelMode.BIKE) "bike" else "run"
                        )
                        toast("📣 운동장에 게시했어요!")
                        workoutResultData = null
                        tab = 4
                    },
                    onClose = { workoutResultData = null }
                )
            }
            NavigationBar(
                containerColor = Color(0xFF1E1B27),
                tonalElevation = 8.dp,
                modifier = Modifier.clip(androidx.compose.foundation.shape.RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
            ) {
                // ✅ v61 아이콘 변경: 운동=지도, 뽑기, 경로함=폴더, 랭킹, 운동장=트랙, 내정보=사람그림자
                // ✅ v63 VS 탭 추가: 운동·뽑기·경로함·랭킹·운동장·VS·내정보
                val navIcons = listOf("🗺️", "🎁", "📁", "🏆", "🏟️", "⚔️", "👥")
                val navLabels = listOf("운동", strings.navGacha, "경로함", strings.navRanking, "운동장", "VS", strings.navProfile)
                navIcons.indices.forEach { i ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = {
                            // ✅ v85 VS 매칭·카운트다운·달리기 중에는 탭 이동을 막는다.
                            //   (기존: 다른 화면으로 나가면 대결이 멈춰버렸음)
                            val vsBusy = tab == 5 && vsGameState.phase in listOf(
                                com.navifit.ui.screens.VsPhase.MATCHING,
                                com.navifit.ui.screens.VsPhase.COUNTDOWN,
                                com.navifit.ui.screens.VsPhase.RUNNING
                            )
                            if (vsBusy && i != 5) vsLeaveWarn = true else tab = i
                        },
                        icon = { Text(navIcons[i], fontSize = 17.sp) },
                        label = { Text(navLabels[i], fontSize = 9.sp, fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF8B9FFF),
                            selectedTextColor = Color(0xFF8B9FFF),
                            indicatorColor = Color(0xFF2E3A5C)
                        )
                    )
                }
            }
        }

        // ===== 길안내 권한 안내 다이얼로그 =====
        if (showPermissionDialog) {
            AlertDialog(
                onDismissRequest = { showPermissionDialog = false; pendingNav = null },
                title = { Text("📍 위치 권한이 필요해요") },
                text = {
                    Text("길안내를 하려면 위치 권한이 꼭 필요해요.\n\n권한을 허용하면 실시간 안내, 이동거리 기록, 안전점수 측정이 가능해져요.\n\n'권한 허용'을 눌러도 창이 안 뜨면(이전에 '다시 묻지 않음'을 선택한 경우) '설정 열기'에서 직접 허용해주세요.")
                },
                confirmButton = {
                    TextButton(onClick = {
                        showPermissionDialog = false
                        navPermissionLauncher.launch(arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        ))
                    }) { Text("권한 허용") }
                },
                dismissButton = {
                    Row {
                        TextButton(onClick = {
                            showPermissionDialog = false; pendingNav = null
                            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)))
                        }) { Text("설정 열기") }
                        TextButton(onClick = { showPermissionDialog = false; pendingNav = null }) { Text("취소") }
                    }
                }
            )
        }

        // ✅ 부정행위 감지 팝업 - 왜 무효 처리됐는지 명확히 설명 (토스트 대신 확실하게 안내)
        if (cheatDialogReason != null) {
            AlertDialog(
                onDismissRequest = { cheatDialogReason = null },
                title = { Text("⚠️ 부정행위가 감지됐어요") },
                text = {
                    Column {
                        Text(cheatDialogReason ?: "", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "이 기록은 랭킹에는 반영되지 않지만, 길안내와 개인 운동 분석 기록은 그대로 정상 진행돼요.\n\n" +
                            "실제로 정상적으로 이동했는데 이 안내가 떴다면, 터널 등에서 GPS 신호가 잠깐 끊겼거나 센서 인식이 " +
                            "불안정했을 수 있어요. 이런 경우를 위해 신호가 끊겼다 복구된 구간은 판정에서 자동으로 제외하도록 " +
                            "되어 있지만, 계속 반복되면 알려주세요.",
                            fontSize = 12.sp, color = Color.Gray, lineHeight = 17.sp
                        )
                    }
                },
                confirmButton = { TextButton(onClick = { cheatDialogReason = null }) { Text("확인") } }
            )
        }
        } // key(stage) 종료
    }

    // =====================================================================================
    //  구글 신규 가입 닉네임 설정 다이얼로그 (중복 확인)
    // =====================================================================================
    @Composable
    fun ProfileEditDialog(onDismiss: () -> Unit) {
        val ctx = this
        var bio by remember { mutableStateOf(com.navifit.social.UserProfileStore.bio(ctx)) }
        var usePhoto by remember { mutableStateOf(com.navifit.social.UserProfileStore.usePhotoAvatar(ctx)) }
        var showHistory by remember { mutableStateOf(com.navifit.social.UserProfileStore.showWorkoutHistory(ctx)) }
        var showAch by remember { mutableStateOf(com.navifit.social.UserProfileStore.showAchievements(ctx)) }
        var photoPath by remember { mutableStateOf(com.navifit.social.UserProfileStore.profilePhotoPath(ctx)) }
        val pickPhoto = androidx.activity.compose.rememberLauncherForActivityResult(
            androidx.activity.result.contract.ActivityResultContracts.GetContent()
        ) { uri ->
            uri?.let {
                try {
                    val dir = java.io.File(filesDir, "profile").apply { mkdirs() }
                    val f = java.io.File(dir, "avatar_${System.currentTimeMillis()}.jpg")
                    contentResolver.openInputStream(it)?.use { inp -> f.outputStream().use { out -> inp.copyTo(out) } }
                    photoPath = f.absolutePath
                    com.navifit.social.UserProfileStore.setProfilePhotoPath(ctx, f.absolutePath)
                } catch (_: Exception) {}
            }
        }
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("프로필 편집") },
            text = {
                Column {
                    OutlinedTextField(value = bio, onValueChange = { bio = it.take(150) },
                        placeholder = { Text("소개를 입력하세요 (최대 150자)") },
                        modifier = Modifier.fillMaxWidth().height(90.dp))
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = { pickPhoto.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (photoPath != null) "✅ 프로필 사진 변경" else "📷 프로필 사진 선택")
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("아이콘: 사진으로 표시", Modifier.weight(1f), fontSize = 13.sp)
                        Switch(checked = usePhoto, onCheckedChange = { usePhoto = it })
                    }
                    Text("끄면 랭킹/RM/운동장에 마커+테두리로 표시돼요", fontSize = 10.sp, color = Color.Gray)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("운동 이력 공개", Modifier.weight(1f), fontSize = 13.sp)
                        Switch(checked = showHistory, onCheckedChange = { showHistory = it })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("업적 공개", Modifier.weight(1f), fontSize = 13.sp)
                        Switch(checked = showAch, onCheckedChange = { showAch = it })
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    com.navifit.social.UserProfileStore.setBio(ctx, bio)
                    com.navifit.social.UserProfileStore.setUsePhotoAvatar(ctx, usePhoto)
                    com.navifit.social.UserProfileStore.setShowWorkoutHistory(ctx, showHistory)
                    com.navifit.social.UserProfileStore.setShowAchievements(ctx, showAch)
                    onDismiss()
                }) { Text("저장") }
            },
            dismissButton = { TextButton(onClick = onDismiss) { Text("취소") } }
        )
    }

    @Composable
    fun GoogleNicknameSetupDialog(
        nicknameManager: NicknameManager,
        onClaim: (String, (Boolean, String) -> Unit) -> Unit
    ) {
        var input by remember { mutableStateOf("") }
        var checking by remember { mutableStateOf(false) }
        var error by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = {},
            title = { Text("🏃 닉네임을 정해주세요") },
            text = {
                Column {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it; error = null },
                        singleLine = true,
                        placeholder = { Text("예: 달리는감자 (2~12자)") },
                        isError = error != null
                    )
                    error?.let { Text(it, color = Color(0xFFFF8FA3), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
                    Text("닉네임은 다른 사람과 중복될 수 없어요.", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(top = 8.dp))
                    if (checking) Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                        CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("중복 확인 중...", fontSize = 12.sp, color = Color.Gray)
                    }
                }
            },
            confirmButton = {
                TextButton(enabled = !checking, onClick = {
                    val candidate = input.trim()
                    nicknameManager.validate(candidate)?.let { error = it; return@TextButton }
                    checking = true
                    onClaim(candidate) { ok, msg -> checking = false; if (!ok) error = msg }
                }) { Text("시작하기") }
            }
        )
    }

    // =====================================================================================
    //  만보기 패널 - 광고 없이 바로 시작 + 상태가 서비스와 동기화되도록 수정
    // =====================================================================================
    @Composable
    fun StepCounterPanel(steps: Int, tickets: Int, boostLevel: Int) {
        val progress = StepCounterService.progressToNextMilestone(steps)
        val serviceRunning by StepCounterService.runningFlow.collectAsState()
        val unclaimedMilestones by StepCounterService.unclaimedMilestonesFlow.collectAsState()
        // 서비스 실행 표시: 플로우 + 저장된 플래그 둘 다 확인 (앱 재시작 직후에도 정확)
        val isTracking = serviceRunning || StepCounterService.isMarkedRunning(this@MainActivity)
        var claimingAd by remember { mutableStateOf(false) }

        val activityPermLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->
            if (granted) StepCounterService.start(this@MainActivity)
            else android.widget.Toast.makeText(this@MainActivity,
                "걸음수 측정 권한을 허용해야 만보기가 동작해요. 설정 > 권한에서 '신체 활동'을 허용해주세요.",
                android.widget.Toast.LENGTH_LONG).show()
        }

        fun startPedometer() {
            val granted = ContextCompat.checkSelfPermission(
                this@MainActivity, Manifest.permission.ACTIVITY_RECOGNITION
            ) == PackageManager.PERMISSION_GRANTED
            if (granted) StepCounterService.start(this@MainActivity)
            else activityPermLauncher.launch(Manifest.permission.ACTIVITY_RECOGNITION)
        }

        // ✅ 측정 시작 버튼 제거: 패널이 보이면 자동으로 권한 확인 -> 곧바로 측정 시작
        LaunchedEffect(Unit) {
            if (!isTracking) startPedometer()
        }

        Card(Modifier.fillMaxWidth().padding(16.dp), shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp)) {
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("🎯 만보 퀘스트 · ${steps.toLocaleFormatted()}보", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                    Text(
                        if (isTracking) "🟢 자동 측정중" else "⏳ 권한 확인중",
                        fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        color = if (isTracking) Color(0xFF5BBD8B) else Color.Gray
                    )
                }
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().height(10.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(6.dp)),
                    color = Color(0xFF7EDDB8), trackColor = Color(0xFF2A2635)
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "다음 뽑기권까지 ${(progress * 100).toInt()}% · 부스트 레벨 ${boostLevel}/5 (에픽 +${boostLevel}%p · 유니크 +${"%.1f".format(boostLevel * 0.5)}%p, 레전더리는 부스트 안 됨)",
                    fontSize = 11.sp, color = Color.Gray
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "📌 하루 단위로 리셋되지 않아요. 걸음수는 평생 누적돼요.\n" +
                    "📌 맛보기: 1만·2만·3만·4만·5만보 도달마다 뽑기권 1장 (총 5장)\n" +
                    "📌 5만보부터: 5만보 걸을 때마다 뽑기권 1장 + 확률 부스트 +1단계 (5단계까지)\n" +
                    "📌 확률 부스트는 5단계(25만보)에서 멈추고, 뽑기권은 그 뒤에도 5만보마다 계속 나와요.\n" +
                    "📌 화면이 꺼져있어도 백그라운드에서 계속 측정돼요.\n" +
                    "🎫 보유 교환권: ${tickets}장",
                    fontSize = 11.sp, color = Color(0xFF6E85F0), lineHeight = 16.sp
                )

                // ✅ v81 만보 퀘스트 완료 → 뽑기권 수령 (눈에 띄게 강조)
                if (unclaimedMilestones > 0) {
                    Spacer(Modifier.height(12.dp))
                    Column(
                        Modifier.fillMaxWidth()
                            .background(Color(0xFF2A2410), androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
                            .border(1.dp, Color(0xFFE8B34B), androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
                            .padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("🎉 만보 퀘스트 완료!", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFE8B34B))
                        Spacer(Modifier.height(4.dp))
                        Text("받을 수 있는 만보 뽑기권 ${unclaimedMilestones}장", fontSize = 12.sp, color = Color(0xFFF0D9A8))
                        Spacer(Modifier.height(10.dp))
                        Button(
                            enabled = !claimingAd,
                            onClick = {
                                claimingAd = true
                                RewardAdManager.showRewardedAd(
                                    onRewardEarned = {
                                        StepCounterService.claimOneMilestoneTicket(this@MainActivity)
                                        claimingAd = false
                                        android.widget.Toast.makeText(this@MainActivity, "🎟️ 만보 뽑기권 1장 받았어요! (뽑기 탭에서 사용)", android.widget.Toast.LENGTH_SHORT).show()
                                    },
                                    onAdFailedOrSkipped = {
                                        // 광고 실패 시에도 보상은 지급 (사용자 손해 방지)
                                        StepCounterService.claimOneMilestoneTicket(this@MainActivity)
                                        claimingAd = false
                                        android.widget.Toast.makeText(this@MainActivity, "🎟️ 만보 뽑기권 1장 받았어요!", android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                )
                            },
                            modifier = Modifier.fillMaxWidth().height(46.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE8B34B))
                        ) {
                            Text(if (claimingAd) "광고 재생 중..." else "🎟️ 뽑기권 수령하기",
                                fontWeight = FontWeight.ExtraBold, color = Color(0xFF2A2410))
                        }
                    }
                }
            }
        }
    }

    private fun Int.toLocaleFormatted(): String = "%,d".format(this)

    // =====================================================================================
    //  내비게이션 시작/종료
    // =====================================================================================
    private suspend fun startNavigation(
        dest: LatLngPoint, mode: TravelMode,
        onRoute: (RouteResult, List<RouteResult>, String?) -> Unit
    ) {
        // ✅ v58 치명 버그 수정: 위치를 못 잡으면 "서울시청"에서 출발시켜서
        //    - 안내가 서울에서 시작되고
        //    - 실제 GPS(집 근처)와 목적지가 가까우면 시작하자마자 "도착" 100% 완료 처리되고
        //    - 거리/속도/진행률이 전부 엉키는 연쇄 문제가 있었음
        //    → 이제 GPS를 실제로 받아올 때까지 최대 12초 기다리고, 못 받으면 안내를 시작하지 않음
        // ✅ v59: "최근목적지/자주가는곳을 누르면 엉뚱한 위치에서 경로가 잡히던" 근본 원인 수정.
        //    tracking 서비스가 남긴 오래된 좌표(currentLocation)를 그대로 출발지로 썼음.
        //    → 안내 중이 아닐 땐 항상 새 GPS를 받아서 출발지로 사용. (안내 중이면 실시간 좌표 사용)
        val origin = (if (navFlowActive) LocationTrackingService.trackingState.value.currentLocation else null)
            ?: awaitFreshLocation()
            ?: LocationTrackingService.trackingState.value.currentLocation   // 최후: 그래도 있으면 사용
            ?: run {
                runOnUiThread {
                    android.widget.Toast.makeText(this,
                        "📡 현재 위치를 찾지 못했어요. 하늘이 보이는 곳에서 GPS를 켜고 다시 시도해주세요",
                        android.widget.Toast.LENGTH_LONG).show()
                }
                return
            }

        // 출발지 이름(랭킹 경로 표시용) - 실패해도 진행
        val originName = try {
            @Suppress("DEPRECATION")
            android.location.Geocoder(this, java.util.Locale.KOREA)
                .getFromLocation(origin.latitude, origin.longitude, 1)
                ?.firstOrNull()?.let { addr ->
                    addr.thoroughfare ?: addr.subLocality ?: addr.locality ?: "현재 위치"
                }
        } catch (e: Exception) { null } ?: "현재 위치"

        // ✅ v39: 오프라인이면 원인을 정확히 알려줌 (기존엔 "경로를 찾을 수 없어요"라는 모호한 메시지만 떴음)
        if (!com.navifit.navigation.NetworkCheck.isOnline(this)) {
            runOnUiThread {
                android.widget.Toast.makeText(
                    this, "📵 인터넷 연결이 없어요. 경로 계산은 네트워크가 필요합니다", android.widget.Toast.LENGTH_LONG
                ).show()
            }
            return
        }

        // ✅ v27: 실시간 교통 반영 최적경로 + 대체경로 (첫 번째가 교통 기준 가장 빠른 길)
        routing.fetchRoutesWithTraffic(origin, dest, mode, RoutePreference.load(this))
            .onSuccess { routes ->
                runOnUiThread {
                    // ✅ v83 빈 결과일 때 routes.first()가 예외를 던져 앱이 꺼지던 문제 → 안내 메시지로 대체
                    val best = routes.firstOrNull()
                    if (best == null) {
                        android.widget.Toast.makeText(this,
                            "이 목적지까지 갈 수 있는 길을 찾지 못했어요. 다른 지점을 골라보세요",
                            android.widget.Toast.LENGTH_LONG).show()
                        return@runOnUiThread
                    }
                    onRoute(best, routes.drop(1).take(2), originName)
                    // ✅ 버그 수정: 여기서 위치추적 서비스를 미리 켜지 않음.
                    //    (경로 미리보기 단계에서 켜지면, 사용자가 "취소"해도 GPS가 계속 돌아
                    //     폰이 뜨거워지는 원인이었음. 시작 버튼을 누르는 beginNavigationWith에서만 켬)
                }
            }
            .onFailure { e ->
                // ✅ v83 실패 원인을 사용자가 알 수 있게 구체화 (기존엔 원인 불명으로 "안내가 안 된다"고 느껴졌음)
                val msg = when {
                    e.message?.contains("timeout", true) == true ||
                    e.message?.contains("timed out", true) == true ->
                        "⏱ 경로 서버 응답이 느려요. 잠시 후 다시 시도해주세요"
                    e.message?.contains("401") == true || e.message?.contains("403") == true ->
                        "🔑 경로 API 키가 유효하지 않아요 (api_keys.properties 확인)"
                    e.message?.contains("Unable to resolve host", true) == true ->
                        "📵 인터넷 연결을 확인해주세요"
                    else -> "경로를 찾을 수 없어요: ${e.message ?: "알 수 없는 오류"}"
                }
                runOnUiThread { android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_LONG).show() }
            }
    }

    // ✅ v77 로그아웃 시 기기 로컬 개인 데이터 초기화 (마커/포인트/인벤토리/뽑기권/우편함 등)
    /**
     * ✅ v84 배터리 최적화 예외 안내.
     * 배터리 최적화가 켜져 있으면 안드로이드가 백그라운드 위치 갱신을 조여서
     * 야외인데도 위치가 늦게 오고, 앱이 "신호 두절"로 오판하게 된다.
     * 운동 시작 전에 한 번만 안내한다.
     */
    /**
     * ✅ v91 운동 시작 전 기기 상태 종합 진단.
     * 위치 꺼짐·절전 모드·배터리 부족·과열·배터리 최적화를 한 번에 검사해서,
     * "왜 위치가 안 잡히는지"를 사용자가 알 수 있게 알려주고 해당 설정으로 바로 보낸다.
     * (기존엔 배터리 최적화 하나만 봤고, 나머지는 조용히 실패했음)
     */
    private fun promptBatteryOptimizationIfNeeded() {
        try {
            val issues = com.navifit.tracking.DeviceReadiness.check(this)
            if (issues.isEmpty()) return

            val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
            // 심각한 문제(위치 꺼짐)는 매번 알린다. 그 외 권고는 하루 한 번만.
            val critical = issues.filter { it.critical }
            val advisory = issues.filter { !it.critical }
            val lastShown = prefs.getLong("readiness_prompt_at", 0L)
            val dayPassed = System.currentTimeMillis() - lastShown > 24 * 60 * 60 * 1000L
            val toShow = when {
                critical.isNotEmpty() -> critical
                dayPassed && advisory.isNotEmpty() -> advisory
                else -> return
            }
            if (critical.isEmpty()) {
                prefs.edit().putLong("readiness_prompt_at", System.currentTimeMillis()).apply()
            }

            val first = toShow.first()
            val body = buildString {
                toShow.forEach { append("• ").append(it.title).append("\n  ").append(it.detail).append("\n\n") }
                append("이 설정들을 조정하면 위치가 훨씬 정확해져요.")
            }
            android.app.AlertDialog.Builder(this)
                .setTitle(if (critical.isNotEmpty()) "⚠️ 위치 추적을 시작할 수 없어요" else "📍 GPS 정확도 향상")
                .setMessage(body)
                .setPositiveButton(if (first.fixIntent != null) "설정 열기" else "확인") { _, _ ->
                    com.navifit.tracking.DeviceReadiness.openFix(this, first)
                }
                .setNegativeButton("나중에", null)
                .show()
        } catch (_: Exception) { }
    }

    private fun clearLocalUserData() {
        val prefsToClear = listOf(
            "gacha_inventory", "premium_tickets", "vs_system", "mailbox",
            "step_counter", "route_vault", "toilet_reviews", "user_profile_sns",
            "community_store", "hall_of_fame", "achievements", "border_system",
            "rm_local_v83", "rm_group_rooms"      // ✅ v83 RM(쪽지)·단체방도 초기화
        )
        prefsToClear.forEach { name ->
            try { getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear().apply() } catch (_: Exception) {}
        }
        // Room DB 운동 기록 삭제
        try {
            lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                try { db.activityRecordDao().deleteAll() } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
    }

    private fun finishTracking(
        mode: TravelMode,
        state: LocationTrackingService.TrackingSnapshot,
        safety: SafetyScoreTracker,
        antiCheat: AntiCheatMonitor,
        rankingSnapshots: Map<Int, Long>,
        originName: String?,
        destName: String?,
        traveledPath: List<LatLngPoint>,
        routePolyline: List<LatLngPoint>? = null,   // ✅ v74 안내 경로(맵매칭용) - Composable에서 넘겨받음
        onSaved: (Boolean) -> Unit
    ) {
        LocationTrackingService.stop(this)

        val actualKm = (state.totalDistanceMeters / 1000).toInt()
        val rankingKm = actualKm.coerceAtLeast(0)
        val rankingDuration = rankingSnapshots[rankingKm] ?: state.elapsedSeconds

        // 이동 경로 저장 (너무 길면 400 포인트로 다운샘플링)
        val sampledRaw = if (traveledPath.size > 400) {
            val step = traveledPath.size / 400.0
            (0 until 400).map { traveledPath[(it * step).toInt()] } + traveledPath.last()
        } else traveledPath.toList()
        // ✅ v81 저장 경로 지그재그 완전 제거 (2단계)
        //   ① polishTrack: 스파이크(급격한 꺾임) 제거 + 5점 가중 이동평균으로 완만화
        //   ② MapMatcher: 안내 경로가 있으면 도로에 스냅, 없으면 추가 스무딩
        val polished = com.navifit.tracking.GpsSmoother.polishTrack(sampledRaw)
        val sampled = com.navifit.navigation.MapMatcher.match(polished, routePolyline)
        val polyline = if (sampled.size >= 2) encodeTravelPolyline(sampled) else null

        // ✅ 랭킹 국가 자동분류: 앱 언어설정이 아니라 실제로 "운동한 GPS 위치"로 나라를 판별
        //    (일본에서 뛰었으면 언어가 한국어로 되어있어도 일본 랭킹으로 들어감)
        val countryCode = try {
            val loc = state.currentLocation
            if (loc != null) {
                @Suppress("DEPRECATION")
                android.location.Geocoder(this, java.util.Locale.getDefault())
                    .getFromLocation(loc.latitude, loc.longitude, 1)
                    ?.firstOrNull()?.countryCode
            } else null
        } catch (e: Exception) { null }

        // ✅ 세션 토글 매크로 방어: 껐다켰다 반복으로 안전점수·운동 점수를 부풀리는 수법 차단
        //    (짧은 세션 / 반복 토글 패턴 / 하루 상한 초과 시 -> 기록은 저장되지만 점수·랭킹 미반영)
        val guardVerdict = SessionGuard.evaluateAndRecord(this, mode, state.totalDistanceMeters, state.elapsedSeconds)
        val finalRankingValid = antiCheat.isRankingValid && guardVerdict.countsForRanking
        val finalInvalidReason = antiCheat.invalidReason ?: guardVerdict.reason

        val record = ActivityRecord(
            mode = mode,
            startTimeMillis = System.currentTimeMillis() - state.elapsedSeconds * 1000,
            durationSeconds = state.elapsedSeconds,
            distanceMeters = state.totalDistanceMeters,
            // ✅ v33: 운동은 "실제 이동시간" 기준 평균속도 (신호대기·휴식 제외 → 러닝 페이스가 정확해짐)
            //         주행은 기존대로 총 경과시간 기준 (정체도 주행의 일부)
            avgSpeedKmh = run {
                val base = if (mode.isWorkoutMode && state.movingSeconds > 30) state.movingSeconds else state.elapsedSeconds
                if (base > 0) state.totalDistanceMeters / base * 3.6 else 0.0
            },
            maxSpeedKmh = safety.maxSpeedKmh,
            originName = originName,
            destinationName = destName,
            pathPolyline = polyline,
            safetyScore = if (mode.isWorkoutMode) 100 else safety.currentScore(),
            rankingBracketKm = rankingKm.toDouble(),
            rankingDurationSeconds = rankingDuration,
            isRankingValid = finalRankingValid,
            invalidReason = finalInvalidReason,
            countryCode = countryCode,
            movingSeconds = state.movingSeconds,      // ✅ v34 "한 번에 달성" 검증용
            maxRestSeconds = state.maxRestSeconds
        )

        // ✅ v32: 안전점수 100점 연속 유지 일수 기록 (무결점 드라이버 테두리 30일 조건)
        com.navifit.tracking.SafetyStreakStore.onRecordSaved(
            this, if (mode.isWorkoutMode) 100 else safety.currentScore(), !mode.isWorkoutMode
        )

        val cheatSuffix = if (!finalRankingValid)
            "\n\n⚠️ ${finalInvalidReason}\n이 기록은 점수·랭킹에는 반영되지 않지만, 개인 기록으로는 저장돼요."
        else ""

        if (mode.isWorkoutMode) {
            // ✅ v60: 운동 이력은 "묻지 않고" 항상 자동 저장 (경로보관함의 '운동 이력' 폴더로)
            //    → 저장 안 되던 문제 해결. 그다음 결과 화면을 띄워 경로 저장 여부만 선택.
            lifecycleScope.launch {
                val newId = db.activityRecordDao().insert(record)
                // 방금 저장된 레코드에 실제 id 부여해 결과화면/보관함에서 참조
                val savedRecord = record.copy(id = newId)
                // 개인 업적 (이번 달 100등 안이면 영구 기록)
                if (finalRankingValid && record.distanceMeters > 500) {
                    val demoRank = (1..100).random()
                    val pace = if (record.avgSpeedKmh > 0)
                        "%d'%02d\"/km".format((60 / record.avgSpeedKmh).toInt(),
                            (((60 / record.avgSpeedKmh) % 1) * 60).toInt()) else ""
                    val rk = polyline?.let {
                        com.navifit.navigation.RouteKeyStore.issueKey(this@MainActivity, mode, it)
                    }
                    com.navifit.social.AchievementStore.record(
                        this@MainActivity, demoRank,
                        "%.2fkm · %d분".format(record.distanceMeters / 1000, record.durationSeconds / 60),
                        pace, rk
                    )
                }
                // 결과 화면 표시 (경로 저장 버튼 포함) - 콜백으로 Compose에 전달
                runOnUiThread { workoutResult?.invoke(savedRecord, finalRankingValid) }
            }
            onSaved(true)
        } else {
            lifecycleScope.launch { db.activityRecordDao().insert(record) }
            android.widget.Toast.makeText(this,
                "주행 종료 · 안전점수 ${safety.currentScore()}점 자동 저장$cheatSuffix", android.widget.Toast.LENGTH_LONG).show()
            onSaved(true)
        }
    }

    /**
     * ✅ v58: 실제 GPS 좌표를 1회 요청해서 기다림 (최대 12초).
     * 경로 계산 전에 반드시 "진짜 내 위치"를 확보하기 위한 함수.
     * 우선순위: ① 고정밀 현재위치 요청 → ② 최근 캐시 위치(lastLocation, 2분 이내)
     */
    private suspend fun awaitFreshLocation(): LatLngPoint? = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
        if (androidx.core.content.ContextCompat.checkSelfPermission(
                this@MainActivity, android.Manifest.permission.ACCESS_FINE_LOCATION
            ) != android.content.pm.PackageManager.PERMISSION_GRANTED) return@withContext null
        val fused = com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(this@MainActivity)
        // ① 신선한 고정밀 위치 요청 (12초 제한)
        val fresh = kotlinx.coroutines.withTimeoutOrNull(12_000) {
            kotlinx.coroutines.suspendCancellableCoroutine<android.location.Location?> { cont ->
                val cts = com.google.android.gms.tasks.CancellationTokenSource()
                fused.getCurrentLocation(
                    com.google.android.gms.location.Priority.PRIORITY_HIGH_ACCURACY, cts.token
                ).addOnSuccessListener { cont.resume(it) {} }
                 .addOnFailureListener { cont.resume(null) {} }
                cont.invokeOnCancellation { cts.cancel() }
            }
        }
        if (fresh != null) return@withContext LatLngPoint(fresh.latitude, fresh.longitude)
        // ② 최근 캐시 위치 (2분 이내 것만 신뢰)
        val last = kotlinx.coroutines.suspendCancellableCoroutine<android.location.Location?> { cont ->
            fused.lastLocation.addOnSuccessListener { cont.resume(it) {} }
                .addOnFailureListener { cont.resume(null) {} }
        }
        if (last != null && System.currentTimeMillis() - last.time < 2 * 60_000) {
            LatLngPoint(last.latitude, last.longitude)
        } else null
    }

    /**
     * ✅ 검증된 외부 내비 앱으로 안내 전환 (완성된 내비 API/앱 연동 - 전부 무료).
     * 앱이 설치돼 있으면 딥링크로 바로 목적지 안내가 시작되고, 없으면 스토어로 이동.
     */
    private fun openExternalNavi(app: String, dest: LatLngPoint, destName: String) {
        val name = java.net.URLEncoder.encode(destName, "UTF-8")
        val (uri, pkg) = when (app) {
            "kakao" -> "kakaonavi://navigate?name=$name&x=${dest.longitude}&y=${dest.latitude}&coord_type=wgs84" to "com.locnall.KimGiSa"
            "naver" -> "nmap://route/car?dlat=${dest.latitude}&dlng=${dest.longitude}&dname=$name&appname=com.navifit" to "com.nhn.android.nmap"
            "tmap" -> "tmap://route?goalname=$name&goaly=${dest.latitude}&goalx=${dest.longitude}" to "com.skt.tmap.ku"
            else -> "google.navigation:q=${dest.latitude},${dest.longitude}" to "com.google.android.apps.maps"
        }
        try {
            startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(uri)))
        } catch (e: Exception) {
            // 앱 미설치 → 플레이스토어로
            try {
                startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW,
                    android.net.Uri.parse("market://details?id=$pkg")))
            } catch (_: Exception) {
                android.widget.Toast.makeText(this, "해당 내비 앱을 열 수 없어요", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun consumeTicket() {
        val prefs = getSharedPreferences(StepCounterService.PREFS, Context.MODE_PRIVATE)
        val t = prefs.getInt(StepCounterService.KEY_TICKETS, 0)
        if (t > 0) prefs.edit().putInt(StepCounterService.KEY_TICKETS, t - 1).apply()
    }

    override fun onDestroy() {
        voice.release()
        try { warnToneRef?.release() } catch (_: Exception) {}   // ✅ v34 ToneGenerator 누수 방지
        try { com.navifit.i18n.TranslationService.close() } catch (_: Exception) {}  // ✅ v41 번역기 정리
        super.onDestroy()
    }
}
