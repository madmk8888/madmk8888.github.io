package com.navifit.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.navifit.social.FriendEntry
import com.navifit.social.FriendRepository
import com.navifit.social.ListedUser
import com.navifit.social.UniqueCodeManager
import kotlinx.coroutines.launch

/**
 * 친구 화면 (v25 확장).
 * - 🟢 접속중 / N분 전 접속 표시 (하트비트 기반)
 * - 친구 삭제 = 상호 삭제 (상대 목록에서도 같이 사라짐)
 * - 스팸/차단 목록 관리 탭 - 상대는 스팸·차단된 걸 알 수 없고, RM은 조용히 버려짐
 */
@Composable
fun FriendsScreen(
    myUid: String,
    friendRepo: FriendRepository,
    codeManager: UniqueCodeManager,
    onOpenRm: (uid: String, nickname: String) -> Unit,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var friends by remember { mutableStateOf<List<FriendEntry>>(emptyList()) }
    var blocked by remember { mutableStateOf<List<ListedUser>>(emptyList()) }
    var spam by remember { mutableStateOf<List<ListedUser>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var showAddDialog by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(0) } // 0=친구, 1=요청, 2=스팸, 3=차단
    // ✅ 예시 항목 해제 여부 (해제하면 다시 안 나타남 - 이 세션 동안)
    var demoSpamReleased by remember { mutableStateOf(false) }
    var demoFriendReleased by remember { mutableStateOf(false) }
    var demoBlockReleased by remember { mutableStateOf(false) }
    // ✅ v61 데모 친구 요청 (수락/거절 테스트용)
    var demoRequests by remember { mutableStateOf(listOf(FriendEntry("demo_req_uid", "박질주", System.currentTimeMillis()))) }

    fun reload() {
        scope.launch {
            loading = true
            // ✅ 무한로딩 수정: Firebase 미설정/오프라인이면 조회가 영원히 안 끝나는 문제
            //    → 전체 조회에 8초 제한. 어떤 경우에도 loading은 반드시 해제됨
            try {
                kotlinx.coroutines.withTimeout(8_000L) {
                    friends = friendRepo.listFriends(myUid)
                    spam = friendRepo.listSpam(myUid)
                    blocked = friendRepo.listBlocked(myUid)
                }
            } catch (e: Exception) {
                friends = emptyList(); spam = emptyList(); blocked = emptyList()
            }
            // ✅ 예시 항목: 친구/스팸/차단 목록이 동작하는지 볼 수 있게 하나씩
            if (friends.isEmpty() && !demoFriendReleased) {
                friends = listOf(FriendEntry("demo_friend_uid", "예시) 같이뛰는친구", System.currentTimeMillis()))
            }
            if (spam.isEmpty() && !demoSpamReleased) {
                spam = listOf(ListedUser("demo_spam_uid", "예시) 광고봇_그만", System.currentTimeMillis()))
            }
            if (blocked.isEmpty() && !demoBlockReleased) {
                blocked = listOf(ListedUser("demo_block_uid", "예시) 매너없는러너", System.currentTimeMillis()))
            }
            loading = false
        }
    }
    LaunchedEffect(Unit) { reload() }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("←", fontSize = 20.sp, modifier = Modifier.clickable(onClick = onBack).padding(end = 12.dp))
            Text("👋", fontSize = 22.sp, modifier = Modifier.padding(end = 6.dp))  // ✅ 손 흔드는 친구 아이콘
            Text("친구", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
            Button(onClick = { showAddDialog = true }, shape = RoundedCornerShape(20.dp)) { Text("＋ 친구 추가") }
        }

        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("👤 친구 (${friends.size})", fontSize = 11.sp) })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("📨 요청 (${demoRequests.size})", fontSize = 11.sp) })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("📛 스팸 (${spam.size})", fontSize = 11.sp) })
            Tab(selected = tab == 3, onClick = { tab = 3 }, text = { Text("🚫 차단 (${blocked.size})", fontSize = 11.sp) })
        }

        if (loading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else when (tab) {
            0 -> FriendsList(friends, friendRepo, myUid, scope, onOpenRm, ::reload,
                onDeleteDemo = { demoFriendReleased = true; friends = friends.filter { it.uid != "demo_friend_uid" } })
            1 -> {
                // ✅ v61 친구 요청 목록 (수락 → 친구 목록으로 이동 / 거절 → 삭제)
                if (demoRequests.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("받은 친구 요청이 없어요", color = Color(0xFF8B93AC), fontSize = 13.sp)
                    }
                } else LazyColumn {
                    items(demoRequests, key = { it.uid }) { req ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), shape = RoundedCornerShape(16.dp)) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("👤", fontSize = 18.sp)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(req.nickname, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("친구 요청을 보냈어요", fontSize = 11.sp, color = Color(0xFF8B93AC))
                                }
                                Button(onClick = {
                                    // 수락: 친구 목록에 추가 + 요청에서 제거
                                    friends = friends + req
                                    demoRequests = demoRequests.filter { it.uid != req.uid }
                                    tab = 0
                                }, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF34C77B))) {
                                    Text("수락", fontSize = 12.sp)
                                }
                                Spacer(Modifier.width(6.dp))
                                OutlinedButton(onClick = { demoRequests = demoRequests.filter { it.uid != req.uid } },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)) {
                                    Text("거절", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
            2 -> ManagedList(spam, "📛", "스팸 목록이 비어있어요", "스팸 해제") { uid ->
                if (uid == "demo_spam_uid") { demoSpamReleased = true; spam = emptyList() }
                else scope.launch { friendRepo.unmarkSpam(myUid, uid); reload() }
            }
            3 -> ManagedList(blocked, "🚫", "차단한 사람이 없어요", "차단 해제") { uid ->
                if (uid == "demo_block_uid") { demoBlockReleased = true; blocked = emptyList() }
                else scope.launch { friendRepo.unblock(myUid, uid); reload() }
            }
        }
    }

    if (showAddDialog) {
        var code by remember { mutableStateOf("") }
        var error by remember { mutableStateOf<String?>(null) }
        var busy by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { if (!busy) showAddDialog = false },
            title = { Text("고유코드로 친구 추가") },
            text = {
                Column {
                    Text("상대방의 내정보 화면에 있는 고유코드를 입력해주세요 (예: KR-048291)", fontSize = 12.sp, color = Color.Gray)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = code, onValueChange = { code = it.uppercase(); error = null }, singleLine = true, isError = error != null)
                    error?.let { Text(it, color = Color(0xFFFF8FA3), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
                }
            },
            confirmButton = {
                TextButton(enabled = !busy, onClick = {
                    busy = true
                    scope.launch {
                        val result = friendRepo.addFriendByCode(myUid, code, codeManager)
                        busy = false
                        result.onSuccess { showAddDialog = false; reload() }
                            .onFailure { error = it.message }
                    }
                }) { Text(if (busy) "확인 중..." else "추가") }
            },
            dismissButton = { TextButton(enabled = !busy, onClick = { showAddDialog = false }) { Text("취소") } }
        )
    }
}

@Composable
private fun FriendsList(
    friends: List<FriendEntry>,
    friendRepo: FriendRepository,
    myUid: String,
    scope: kotlinx.coroutines.CoroutineScope,
    onOpenRm: (String, String) -> Unit,
    reload: () -> Unit,
    onDeleteDemo: () -> Unit = {}   // ✅ v59 예시 친구 삭제(로컬 처리)
) {
    if (friends.isEmpty()) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("👥", fontSize = 40.sp)
            Text("아직 친구가 없어요", color = Color.Gray, fontSize = 13.sp)
            Text("내정보에서 내 고유코드를 확인해서 친구에게 알려주세요", color = Color.Gray, fontSize = 11.sp)
        }
        return
    }
    LazyColumn(Modifier.padding(horizontal = 16.dp)) {
        items(friends, key = { it.uid }) { f ->
            var showMenu by remember { mutableStateOf(false) }
            var confirmDelete by remember { mutableStateOf(false) }
            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), shape = RoundedCornerShape(16.dp)) {
                Row(
                    Modifier.fillMaxWidth().clickable { onOpenRm(f.uid, f.nickname) }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(contentAlignment = Alignment.BottomEnd) {
                        Box(
                            Modifier.size(42.dp).clip(CircleShape)
                                .background(Brush.sweepGradient(listOf(Color(0xFFFF8FA3), Color(0xFF8B9FFF), Color(0xFF7EDDB8), Color(0xFFFF8FA3)))),
                            contentAlignment = Alignment.Center
                        ) { Text("👤", fontSize = 18.sp) }   // ✅ v58 친구 = 사람 얼굴 아이콘
                        // ✅ 접속중이면 초록 점 표시
                        if (f.isOnline) {
                            Box(Modifier.size(12.dp).clip(CircleShape).background(Color(0xFF4ADE80)))
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(f.nickname, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        // ✅ 🟢 접속중 / N분 전 접속
                        Text(f.lastSeenLabel, fontSize = 11.sp,
                            color = if (f.isOnline) Color(0xFF4ADE80) else Color.Gray)
                    }
                    Box {
                        Text("⋮", fontSize = 18.sp, modifier = Modifier.clickable { showMenu = true }.padding(8.dp))
                        DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                            DropdownMenuItem(text = { Text("💬 RM 보내기") }, onClick = { showMenu = false; onOpenRm(f.uid, f.nickname) })
                            DropdownMenuItem(text = { Text("🗑️ 친구 삭제") }, onClick = { showMenu = false; confirmDelete = true })
                            DropdownMenuItem(text = { Text("📛 스팸 처리 (상대는 몰라요)") }, onClick = {
                                showMenu = false
                                scope.launch { friendRepo.markSpam(myUid, f.uid); reload() }
                            })
                            DropdownMenuItem(text = { Text("🚫 차단하기 (상대는 몰라요)", color = Color(0xFFFF8FA3)) }, onClick = {
                                showMenu = false
                                scope.launch { friendRepo.block(myUid, f.uid); friendRepo.removeFriend(myUid, f.uid); reload() }
                            })
                        }
                    }
                }
            }
            if (confirmDelete) {
                AlertDialog(
                    onDismissRequest = { confirmDelete = false },
                    title = { Text("친구 삭제") },
                    text = { Text("${f.nickname}님을 삭제하면 상대방 친구 목록에서도 내가 사라져요. 삭제할까요?", fontSize = 13.sp) },
                    confirmButton = {
                        TextButton(onClick = {
                            confirmDelete = false
                            if (f.uid == "demo_friend_uid") onDeleteDemo()
                            else scope.launch { friendRepo.removeFriend(myUid, f.uid); reload() }
                        }) { Text("삭제", color = Color(0xFFFF8FA3)) }
                    },
                    dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("취소") } }
                )
            }
        }
    }
}

@Composable
private fun ManagedList(
    users: List<ListedUser>,
    icon: String,
    emptyText: String,
    releaseLabel: String,
    onRelease: (uid: String) -> Unit
) {
    if (users.isEmpty()) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(icon, fontSize = 40.sp)
            Text(emptyText, color = Color.Gray, fontSize = 13.sp)
        }
        return
    }
    LazyColumn(Modifier.padding(horizontal = 16.dp)) {
        items(users, key = { it.uid }) { u ->
            var confirmRelease by remember(u.uid) { mutableStateOf(false) }
            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(icon, fontSize = 18.sp)
                    Spacer(Modifier.width(12.dp))
                    Text(u.nickname, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    OutlinedButton(onClick = { confirmRelease = true }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)) {
                        Text(releaseLabel, fontSize = 11.sp)
                    }
                }
            }
            // ✅ 해제 전 확인 창
            if (confirmRelease) {
                AlertDialog(
                    onDismissRequest = { confirmRelease = false },
                    title = { Text(releaseLabel) },
                    text = { Text("${u.nickname}님을 ${releaseLabel}하시겠습니까?", fontSize = 13.sp) },
                    confirmButton = {
                        TextButton(onClick = { confirmRelease = false; onRelease(u.uid) }) { Text("확인") }
                    },
                    dismissButton = { TextButton(onClick = { confirmRelease = false }) { Text("취소") } }
                )
            }
        }
    }
}
