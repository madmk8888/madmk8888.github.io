package com.navifit.tracking

import android.app.*
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import com.navifit.gacha.GachaEngine

/**
 * 만보기 포그라운드 서비스.
 * - 화면 꺼져도 백그라운드에서 계속 측정
 * - ⚠️ 하루 단위로 리셋되지 않음 - 누적(평생) 걸음수를 계속 쌓음
 * - 30만보 달성마다: 교환권 1장 지급 + 에픽/레전더리 확률이 영구적으로 +5%p씩 상승 (최대 5단계=+25%p)
 */
class StepCounterService : Service(), SensorEventListener {

    companion object {
        const val CHANNEL_ID = "navifit_step_channel"
        const val NOTIFICATION_ID = 1002
        const val PREFS = "step_prefs"
        const val KEY_TOTAL_STEPS = "total_steps" // 평생 누적, 리셋 없음
        const val KEY_TICKETS = "exchange_tickets"
        const val KEY_BOOST_LEVEL = "boost_level"
        const val STEPS_PER_MILESTONE = 300_000
        const val KEY_SERVICE_RUNNING = "service_running"       // 측정중 상태를 저장 -> 앱 재시작해도 UI가 정확히 표시
        const val KEY_COUNTER_BASELINE = "counter_baseline"     // STEP_COUNTER 폴백용 기준값
        // ✅ 30만보 마일스톤은 부스트(최대 5단계)와 별개로 "영원히" 계속 발생함 -> 티켓은 계속 받되
        //    확률 부스트만 5단계에서 멈춤. 마일스톤을 찍으면 바로 티켓을 안 주고 "광고보고 받기" 대상으로 쌓아둠.
        const val KEY_MILESTONES_REACHED = "milestones_reached" // 지금까지 도달한 30만보 마일스톤 총 횟수 (무제한)
        const val KEY_MILESTONES_CLAIMED = "milestones_claimed" // 광고 보고 실제로 티켓으로 바꾼 횟수

        private val _runningFlow = MutableStateFlow(false)
        val runningFlow: StateFlow<Boolean> = _runningFlow

        fun isMarkedRunning(context: Context): Boolean =
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_SERVICE_RUNNING, false)

        private val _stepsFlow = MutableStateFlow(0)
        val stepsFlow: StateFlow<Int> = _stepsFlow
        private val _ticketsFlow = MutableStateFlow(0)
        val ticketsFlow: StateFlow<Int> = _ticketsFlow
        private val _boostLevelFlow = MutableStateFlow(0)
        val boostLevelFlow: StateFlow<Int> = _boostLevelFlow
        private val _unclaimedMilestonesFlow = MutableStateFlow(0)
        val unclaimedMilestonesFlow: StateFlow<Int> = _unclaimedMilestonesFlow

        /** 광고 시청 완료 후 호출 - 대기 중인 마일스톤 1개를 실제 교환권 1장으로 전환 */
        fun claimOneMilestoneTicket(context: Context) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val reached = prefs.getInt(KEY_MILESTONES_REACHED, 0)
            val claimed = prefs.getInt(KEY_MILESTONES_CLAIMED, 0)
            if (claimed >= reached) return // 받을 게 없음
            val tickets = prefs.getInt(KEY_TICKETS, 0) + 1
            prefs.edit()
                .putInt(KEY_MILESTONES_CLAIMED, claimed + 1)
                .putInt(KEY_TICKETS, tickets)
                .apply()
            _ticketsFlow.value = tickets
            _unclaimedMilestonesFlow.value = reached - (claimed + 1)
        }

        fun start(context: Context) {
            context.startForegroundService(Intent(context, StepCounterService::class.java))
        }
        fun stop(context: Context) {
            context.stopService(Intent(context, StepCounterService::class.java))
        }

        // ✅ v58 새 뽑기권 지급 규칙 (맛보기 구간 도입):
        //  · 맛보기: 1만/2만/3만/4만/5만보 도달 시 각 1장 (총 5장 - 초반에 재미 붙이라고)
        //  · 5만보부터 확률 부스트 시작: 5만보마다 +1단계, 최대 5단계 (5만/10만/15만/20만/25만)
        //  · 5만보 이후: 5만보 걸을 때마다 뽑기권 1장 (10만, 15만, 20만... 무제한)
        const val TASTER_STEP = 10_000       // 맛보기 간격 (1만보)
        const val REGULAR_STEP = 50_000      // 본 구간 간격 (5만보)

        /** 누적 걸음수 → 지금까지 발생한 마일스톤(티켓) 총 개수 */
        fun milestonesFor(steps: Int): Int =
            if (steps < REGULAR_STEP) steps / TASTER_STEP                       // 1만보당 1장 (0~4장)
            else 5 + (steps - REGULAR_STEP) / REGULAR_STEP                      // 5만보에 5장째, 이후 5만보당 1장

        /** 누적 걸음수 → 확률 부스트 단계 (5만보부터 5만보당 +1, 최대 5) */
        fun boostFor(steps: Int): Int =
            (steps / REGULAR_STEP).coerceAtMost(GachaEngine.MAX_BOOST_LEVEL)

        /** 현재 진행률(다음 마일스톤까지 몇 %) - 게이지 표시용 */
        fun progressToNextMilestone(totalSteps: Int): Float {
            return if (totalSteps < REGULAR_STEP) {
                (totalSteps % TASTER_STEP).toFloat() / TASTER_STEP
            } else {
                ((totalSteps - REGULAR_STEP) % REGULAR_STEP).toFloat() / REGULAR_STEP
            }
        }
    }

    private lateinit var sensorManager: SensorManager
    private var stepSensor: Sensor? = null
    private var usingCounterFallback = false // STEP_DETECTOR 없는 기기용 폴백 여부

    override fun onCreate() {
        super.onCreate()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        // 1순위: STEP_DETECTOR (한 걸음마다 이벤트) / 2순위 폴백: STEP_COUNTER (부팅 후 누적값)
        stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR)
        if (stepSensor == null) {
            stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
            usingCounterFallback = stepSensor != null
        }
        createChannel()
        loadState()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification(_stepsFlow.value))
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)

        if (stepSensor == null) {
            // 걸음 센서가 아예 없는 기기 - 사용자에게 알리고 종료
            prefs.edit().putBoolean(KEY_SERVICE_RUNNING, false).apply()
            _runningFlow.value = false
            android.widget.Toast.makeText(this, "이 기기에는 걸음 센서가 없어서 만보기를 사용할 수 없어요", android.widget.Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }

        var registered = sensorManager.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_NORMAL)
        if (!registered) {
            // ✅ v62: 한 번 실패해도 바로 종료하지 않고 잠시 후 재시도 (권한 직후 타이밍 이슈 대응)
            android.os.Handler(mainLooper).postDelayed({
                try {
                    val ok = sensorManager.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_NORMAL)
                    if (!ok) {
                        prefs.edit().putBoolean(KEY_SERVICE_RUNNING, false).apply()
                        _runningFlow.value = false
                        stopSelf()
                    } else {
                        prefs.edit().putBoolean(KEY_SERVICE_RUNNING, true).apply()
                        _runningFlow.value = true
                    }
                } catch (_: Exception) { stopSelf() }
            }, 1500)
            return START_STICKY
        }

        prefs.edit().putBoolean(KEY_SERVICE_RUNNING, true).apply()
        _runningFlow.value = true
        return START_STICKY // ✅ v58: 다른 앱 사용 중/앱 종료 후에도 만보기가 계속 측정되도록 시스템이 자동 재시작
    }

    override fun onSensorChanged(event: SensorEvent) {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)

        val increment: Int = when (event.sensor.type) {
            Sensor.TYPE_STEP_DETECTOR -> 1
            Sensor.TYPE_STEP_COUNTER -> {
                // STEP_COUNTER는 "부팅 이후 총 걸음수"를 줌 -> 기준값 대비 증가분만 반영
                val current = event.values[0].toInt()
                val baseline = prefs.getInt(KEY_COUNTER_BASELINE, -1)
                if (baseline < 0 || current < baseline) { // 첫 이벤트 또는 재부팅으로 카운터 리셋됨
                    prefs.edit().putInt(KEY_COUNTER_BASELINE, current).apply()
                    0
                } else {
                    val delta = current - baseline
                    prefs.edit().putInt(KEY_COUNTER_BASELINE, current).apply()
                    delta
                }
            }
            else -> return
        }
        if (increment <= 0) return

        val steps = prefs.getInt(KEY_TOTAL_STEPS, 0) + increment // 누적, 리셋 없음
        var boostLevel = prefs.getInt(KEY_BOOST_LEVEL, 0)
        var reached = prefs.getInt(KEY_MILESTONES_REACHED, 0)
        val claimed = prefs.getInt(KEY_MILESTONES_CLAIMED, 0)

        // ✅ v58 새 규칙: 맛보기(1만보×5) → 이후 5만보마다 티켓 / 부스트는 5만보부터 5단계까지
        val newTotalMilestones = milestonesFor(steps)
        if (newTotalMilestones > reached) {
            reached = newTotalMilestones
        }
        val newBoostLevel = boostFor(steps)
        if (newBoostLevel > boostLevel) boostLevel = newBoostLevel

        prefs.edit()
            .putInt(KEY_TOTAL_STEPS, steps)
            .putInt(KEY_MILESTONES_REACHED, reached)
            .putInt(KEY_BOOST_LEVEL, boostLevel)
            .apply()

        _stepsFlow.value = steps
        _boostLevelFlow.value = boostLevel
        _unclaimedMilestonesFlow.value = reached - claimed

        if (steps % 50 == 0) updateNotification(steps)
    }

    private fun loadState() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        _stepsFlow.value = prefs.getInt(KEY_TOTAL_STEPS, 0)
        _ticketsFlow.value = prefs.getInt(KEY_TICKETS, 0)
        _boostLevelFlow.value = prefs.getInt(KEY_BOOST_LEVEL, 0)
        val reached = prefs.getInt(KEY_MILESTONES_REACHED, 0)
        val claimed = prefs.getInt(KEY_MILESTONES_CLAIMED, 0)
        _unclaimedMilestonesFlow.value = reached - claimed
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    override fun onBind(intent: Intent?): IBinder? = null

    /** ✅ 앱을 최근앱에서 스와이프해 완전히 끄면 만보기도 함께 종료 (배터리 걱정 없게) */
    override fun onTaskRemoved(rootIntent: Intent?) {
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        sensorManager.unregisterListener(this)
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(KEY_SERVICE_RUNNING, false).apply()
        _runningFlow.value = false
        super.onDestroy()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "만보기", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(steps: Int): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("NaviFit 만보기")
            .setContentText("누적 ${steps}보 · 화면이 꺼져도 계속 측정돼요")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()

    private fun updateNotification(steps: Int) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(steps))
    }
}
