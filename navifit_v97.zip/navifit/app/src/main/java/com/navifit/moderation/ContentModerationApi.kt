package com.navifit.moderation

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * 커뮤니티 글/댓글 자동 검사 (게시 전 차단용).
 * - 텍스트 유해성(욕설/성적표현/위협): Google Perspective API (무료)
 * - 링크 피싱/악성사이트: Google Safe Browsing API (무료, 일 10,000건)
 * - 로컬 키워드 필터: API 없이도 즉시 동작하는 1차 방어선
 *
 * 무료 키 발급:
 * - Perspective API: https://developers.perspectiveapi.com/s/docs-get-started
 * - Safe Browsing API: Cloud Console에서 "Safe Browsing API" 활성화 (기존 구글맵 키와 별개 프로젝트 권장)
 *
 * ⚠️ 사진/동영상 속 성인물 자동검사(Cloud Vision SafeSearch)는 월 1,000건 이후 유료라
 * 여기 포함 안 함 - 필요하면 별도로 안내해드릴 수 있음.
 */
class ContentModerationApi(
    private val perspectiveApiKey: String,
    private val safeBrowsingApiKey: String
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS).readTimeout(10, TimeUnit.SECONDS).build()
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    data class ModerationResult(val isSafe: Boolean, val reasons: List<String>)

    suspend fun checkPost(text: String): ModerationResult = withContext(Dispatchers.IO) {
        val reasons = mutableListOf<String>()

        try {
            val scores = checkTextToxicity(text)
            if ((scores["TOXICITY"] ?: 0.0) > 0.75) reasons += "욕설/공격성 표현 감지"
            if ((scores["SEXUALLY_EXPLICIT"] ?: 0.0) > 0.7) reasons += "성적인 표현 감지 (19금)"
            if ((scores["THREAT"] ?: 0.0) > 0.7) reasons += "위협적 표현 감지"
        } catch (e: Exception) { /* API 실패시 통과 (가용성 우선), 로컬 필터가 최종 방어선 */ }

        val urls = Regex("https?://\\S+").findAll(text).map { it.value }.toList()
        if (urls.isNotEmpty()) {
            try { if (checkUrlsMalicious(urls)) reasons += "피싱/악성 의심 링크 포함" }
            catch (e: Exception) { /* 실패시 통과 */ }
        }

        if (containsSpamPattern(text)) reasons += "스팸/광고성 패턴 감지"

        ModerationResult(isSafe = reasons.isEmpty(), reasons = reasons)
    }

    private fun checkTextToxicity(text: String): Map<String, Double> {
        val body = JSONObject().apply {
            put("comment", JSONObject().apply { put("text", text) })
            put("languages", JSONArray().put("ko").put("en"))
            put("requestedAttributes", JSONObject().apply {
                put("TOXICITY", JSONObject())
                put("SEXUALLY_EXPLICIT", JSONObject())
                put("THREAT", JSONObject())
            })
        }
        val request = Request.Builder()
            .url("https://commentanalyzer.googleapis.com/v1alpha1/comments:analyze?key=$perspectiveApiKey")
            .post(body.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            val json = JSONObject(response.body?.string() ?: "{}")
            val attrScores = json.optJSONObject("attributeScores") ?: return emptyMap()
            val result = mutableMapOf<String, Double>()
            attrScores.keys().forEach { key ->
                result[key] = attrScores.getJSONObject(key).getJSONObject("summaryScore").getDouble("value")
            }
            return result
        }
    }

    private fun checkUrlsMalicious(urls: List<String>): Boolean {
        val threatEntries = JSONArray().apply { urls.forEach { put(JSONObject().apply { put("url", it) }) } }
        val body = JSONObject().apply {
            put("client", JSONObject().apply { put("clientId", "navifit"); put("clientVersion", "1.0") })
            put("threatInfo", JSONObject().apply {
                put("threatTypes", JSONArray().put("MALWARE").put("SOCIAL_ENGINEERING").put("UNWANTED_SOFTWARE"))
                put("platformTypes", JSONArray().put("ANY_PLATFORM"))
                put("threatEntryTypes", JSONArray().put("URL"))
                put("threatEntries", threatEntries)
            })
        }
        val request = Request.Builder()
            .url("https://safebrowsing.googleapis.com/v4/threatMatches:find?key=$safeBrowsingApiKey")
            .post(body.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            val json = JSONObject(response.body?.string() ?: "{}")
            return json.has("matches")
        }
    }

    private val spamPatterns = listOf(
        Regex("카톡\\s*아이디|텔레그램\\s*문의|무료\\s*체험\\s*신청", RegexOption.IGNORE_CASE),
        Regex("\\d{2,3}[-.\\s]?\\d{3,4}[-.\\s]?\\d{4}"),
        Regex("씨발|ㅅㅂ|병신|ㅄ|개새끼|좆|지랄", RegexOption.IGNORE_CASE)
    )
    private fun containsSpamPattern(text: String) = spamPatterns.any { it.containsMatchIn(text) }
}
