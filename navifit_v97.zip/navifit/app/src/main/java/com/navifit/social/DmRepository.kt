package com.navifit.social

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

data class DirectMessage(
    val id: String = "",
    val senderUid: String = "",
    val senderName: String = "",
    val text: String = "",
    val mediaPath: String? = null, // ⚠️ 로컬 기기 경로 - 실제 상대 기기까지 사진 전송하려면 Storage 연동 필요
    val timestamp: Long = System.currentTimeMillis(),
    val lang: String? = null       // ✅ v41 작성 언어 (RM도 번역 보기 지원)
)

data class DmThread(
    val otherUid: String,
    val otherNickname: String,
    val lastMessage: String,
    val lastTimestamp: Long,
    val unread: Boolean = false,
    val isRequest: Boolean = false   // ✅ v36 모르는 사람의 DM (요청함)
)

/**
 * 인스타그램 DM과 동일한 구조의 1:1 채팅.
 * - 대화방 id는 두 uid를 정렬해서 합친 값이라 항상 동일하게 매칭됨
 * - 메시지: dms/{conversationId}/messages/{autoId}
 * - 받은편지함 목록: dm_threads/{myUid}/threads/{otherUid} (보낼 때 양쪽 다 갱신)
 *
 * ⚠️ 비회원(게스트)은 DM을 보낼 수 없음 (AnonymousLimits.CAN_SEND_DM) - 스팸 방지 + 신원 보장 목적
 */
class DmRepository {
    private val db by lazy { FirebaseFirestore.getInstance() }  // ✅ lazy: Firebase 미설정 시 생성만으로는 안 죽음

    private fun conversationId(a: String, b: String) = listOf(a, b).sorted().joinToString("_")

    /**
     * 메시지 전송 + 양쪽 받은편지함 미리보기 갱신.
     * ✅ 차단/스팸 무음 차단: 받는 쪽이 나를 차단·스팸 처리했으면 메시지가 상대에게 전달되지 않음.
     *    보낸 사람 화면에는 정상 전송된 것처럼 내 쪽 스레드에만 기록됨 (상대가 눈치 못 채게).
     */
    suspend fun send(
        myUid: String, myNickname: String, otherUid: String, otherNickname: String,
        text: String, mediaPath: String? = null,
        friendRepo: FriendRepository? = null,
        lang: String? = null          // ✅ v41 작성 언어
    ) {
        val blocked = friendRepo?.canDeliver(fromUid = myUid, toUid = otherUid)?.not() ?: false
        // ✅ v35: 상대의 "RM 받기" 설정도 확인 (전체 / 친구만 / 받지 않음)
        val scopeBlocked = try {
            val doc = db.collection("users").document(otherUid).get().await()
            when (doc.getString("dmScope")) {
                "NOBODY" -> true
                "FRIENDS_ONLY" -> {
                    // 상대의 친구 목록에 내가 있는지 확인
                    val f = db.collection("users").document(otherUid)
                        .collection("friends").document(myUid).get().await()
                    !f.exists()
                }
                else -> false
            }
        } catch (_: Exception) { false }

        val deliverable = !blocked && !scopeBlocked
        val now = System.currentTimeMillis()

        if (!deliverable) {
            // 상대에게는 아무것도 쓰지 않고, 내 쪽 미리보기만 갱신 (정상 전송처럼 보임)
            db.collection("dm_threads").document(myUid).collection("threads").document(otherUid)
                .set(mapOf("otherNickname" to otherNickname, "lastMessage" to text, "lastTimestamp" to now, "unread" to false)).await()
            return
        }

        val convId = conversationId(myUid, otherUid)
        val msg = mutableMapOf(
            "senderUid" to myUid, "senderName" to myNickname,
            "text" to text, "timestamp" to now
        )
        mediaPath?.let { msg["mediaPath"] = it }
        lang?.let { msg["lang"] = it }   // ✅ v41
        db.collection("dms").document(convId).collection("messages").add(msg).await()

        db.collection("dm_threads").document(myUid).collection("threads").document(otherUid)
            .set(mapOf("otherNickname" to otherNickname, "lastMessage" to text, "lastTimestamp" to now, "unread" to false)).await()
        // ✅ v36 DM 요청함: 친구가 아니면 상대 받은편지함이 아니라 "요청함"으로 분류
        //    (모르는 사람의 DM이 바로 받은편지함에 꽂히던 문제 - 스팸·괴롭힘 노출)
        val areFriends = try {
            db.collection("users").document(otherUid).collection("friends")
                .document(myUid).get().await().exists()
        } catch (_: Exception) { false }

        db.collection("dm_threads").document(otherUid).collection("threads").document(myUid)
            .set(mapOf(
                "otherNickname" to myNickname, "lastMessage" to text,
                "lastTimestamp" to now, "unread" to true,
                "isRequest" to !areFriends       // 친구 아니면 요청함으로
            )).await()

        // ✅ v36 DM 알림
        try {
            NotificationCenter.push(otherUid, NotificationCenter.Type.DM, myNickname, text.take(40))
        } catch (_: Exception) { }
    }

    /** ✅ v36 DM 요청 수락 → 일반 받은편지함으로 이동 */
    suspend fun acceptRequest(myUid: String, otherUid: String) {
        try {
            db.collection("dm_threads").document(myUid).collection("threads").document(otherUid)
                .update("isRequest", false).await()
        } catch (_: Exception) { }
    }

    /** ✅ v36 상대가 내 메시지를 읽었는지 (읽음 표시용) */
    fun observeReadState(myUid: String, otherUid: String): Flow<Boolean> = callbackFlow {
        val reg = try {
            db.collection("dm_threads").document(otherUid).collection("threads").document(myUid)
                .addSnapshotListener { snap, _ ->
                    trySend(snap?.getBoolean("unread") == false)
                }
        } catch (_: Exception) { trySend(false); null }
        awaitClose { reg?.remove() }
    }

    /** 특정 상대와의 대화 실시간 구독 */
    fun observeMessages(myUid: String, otherUid: String): Flow<List<DirectMessage>> = callbackFlow {
        val reg: ListenerRegistration? = try {
            val convId = conversationId(myUid, otherUid)
            db.collection("dms").document(convId).collection("messages")
                .orderBy("timestamp", Query.Direction.ASCENDING)
                .addSnapshotListener { snap, _ ->
                    val list = snap?.documents?.map { d ->
                        DirectMessage(
                            id = d.id,
                            senderUid = d.getString("senderUid") ?: "",
                            senderName = d.getString("senderName") ?: "",
                            text = d.getString("text") ?: "",
                            mediaPath = d.getString("mediaPath"),
                            timestamp = d.getLong("timestamp") ?: 0L,
                            lang = d.getString("lang")
                        )
                    } ?: emptyList()
                    trySend(list)
                }
        } catch (_: Exception) {
            trySend(emptyList())   // ✅ v78 Firebase 미설정/오류 시 크래시 대신 빈 목록 (RM 튕김 방지)
            null
        }
        awaitClose { reg?.remove() }
    }

    /** 받은편지함(대화 목록) 실시간 구독 - 인스타 DM 리스트처럼 최근 순 */
    fun observeThreads(myUid: String): Flow<List<DmThread>> = callbackFlow {
        val reg: ListenerRegistration? = try {
            db.collection("dm_threads").document(myUid).collection("threads")
                .orderBy("lastTimestamp", Query.Direction.DESCENDING)
                .addSnapshotListener { snap, _ ->
                    val list = snap?.documents?.map { d ->
                        DmThread(
                            otherUid = d.id,
                            otherNickname = d.getString("otherNickname") ?: "알 수 없음",
                            lastMessage = d.getString("lastMessage") ?: "",
                            lastTimestamp = d.getLong("lastTimestamp") ?: 0L,
                            unread = d.getBoolean("unread") ?: false,
                            isRequest = d.getBoolean("isRequest") ?: false
                        )
                    } ?: emptyList()
                    trySend(list)
                }
        } catch (_: Exception) {
            trySend(emptyList()); null
        }
        awaitClose { reg?.remove() }
    }

    suspend fun markRead(myUid: String, otherUid: String) {
        db.collection("dm_threads").document(myUid).collection("threads").document(otherUid)
            .update("unread", false).await()
    }

    /** ✅ 대화(스레드) 삭제 - 내 받은편지함에서만 사라짐 (상대 쪽 목록은 유지) */
    suspend fun deleteThread(myUid: String, otherUid: String) {
        try {
            db.collection("dm_threads").document(myUid).collection("threads").document(otherUid)
                .delete().await()
        } catch (_: Exception) { }
    }
}
