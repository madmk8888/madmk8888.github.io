package com.navifit.navigation

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

/**
 * ✅ v33 고속도로 휴게소 정보 (한국도로공사 공공데이터 - 무료).
 * data.ex.co.kr 에서 발급받은 키를 assets/api_keys.properties 의 ex_key 에 넣으면 활성화.
 * 키가 없으면 기능만 비활성 (앱은 정상 동작).
 *
 * 장거리 주행 시 "전방 12km 안성휴게소 (주유소·전기충전)" 안내에 사용.
 */
class RestAreaRepository(private val context: android.content.Context) {

    private val client = OkHttpClient()

    data class RestArea(
        val name: String,
        val location: LatLngPoint,
        val routeName: String,       // 노선명 (경부선 등)
        val hasGasStation: Boolean,
        val hasEvCharger: Boolean,
        val hasPharmacy: Boolean
    )

    private var cache: List<RestArea> = emptyList()

    fun hasKey(): Boolean = key() != null
    private fun key(): String? = try {
        context.assets.open("api_keys.properties").use { ins ->
            java.util.Properties().apply { load(ins) }
                .getProperty("ex_key")?.trim()?.takeIf { it.isNotBlank() && !it.startsWith("여기에") }
        }
    } catch (_: Exception) { null }

    /** 전국 휴게소 목록 로드 (1회 캐시 - 휴게소는 잘 안 바뀜) */
    suspend fun loadAll(): List<RestArea> = withContext(Dispatchers.IO) {
        if (cache.isNotEmpty()) return@withContext cache
        val k = key() ?: return@withContext emptyList()
        try {
            val url = "https://data.ex.co.kr/openapi/restinfo/restAreaRouteList" +
                "?key=$k&type=json&numOfRows=500&pageNo=1"
            val body = client.newCall(Request.Builder().url(url).build())
                .execute().use { it.body?.string() } ?: return@withContext emptyList()
            val arr = JSONObject(body).optJSONArray("list") ?: return@withContext emptyList()
            val list = mutableListOf<RestArea>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val lat = o.optString("yValue").toDoubleOrNull() ?: continue
                val lng = o.optString("xValue").toDoubleOrNull() ?: continue
                list.add(
                    RestArea(
                        name = o.optString("serviceAreaName", "휴게소"),
                        location = LatLngPoint(lat, lng),
                        routeName = o.optString("routeName", ""),
                        hasGasStation = o.optString("gasStationYn") == "Y" || o.optString("oilYn") == "Y",
                        hasEvCharger = o.optString("evChargerYn") == "Y",
                        hasPharmacy = o.optString("pharmacyYn") == "Y"
                    )
                )
            }
            if (list.isNotEmpty()) cache = list
            cache
        } catch (_: Exception) { emptyList() }
    }

    /**
     * 경로 앞쪽에 있는 다음 휴게소 찾기 (경로에서 2km 이내 + 진행 방향 앞).
     * @return (휴게소, 남은거리m) 또는 null
     */
    fun nextOnRoute(
        routePoints: List<LatLngPoint>,
        currentIndex: Int,
        areas: List<RestArea>
    ): Pair<RestArea, Int>? {
        if (routePoints.isEmpty() || areas.isEmpty()) return null
        var best: Pair<RestArea, Int>? = null
        var accum = 0.0
        for (i in (currentIndex + 1) until routePoints.size) {
            accum += NavigationProgressCalculator.fastDistanceMeters(routePoints[i - 1], routePoints[i])
            if (accum > 60_000) break // 60km 앞까지만 탐색
            for (a in areas) {
                if (NavigationProgressCalculator.fastDistanceMeters(routePoints[i], a.location) < 2000) {
                    if (best == null || accum < best!!.second) best = a to accum.toInt()
                }
            }
            if (best != null && accum > best!!.second + 5000) break // 가장 가까운 것 확정
        }
        return best
    }
}
