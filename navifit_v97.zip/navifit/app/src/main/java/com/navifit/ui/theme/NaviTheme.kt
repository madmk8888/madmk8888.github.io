package com.navifit.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * ✅ v79 테마 대응 UI 헬퍼.
 *  - 화이트 테마: 살짝 그림자 + 아주 옅은 테두리로 "은은한 카드" 느낌 (박스처럼 안 보이게)
 *  - 다크 테마: 어두운 카드 + 옅은 밝은 테두리로 칸 구분
 *  - 글자색은 MaterialTheme.colorScheme.onSurface 를 쓰면 테마에 따라 자동으로 대비됨
 */
object NaviTheme {
    val isDark: Boolean @Composable get() = MaterialTheme.colorScheme.background.luminance() < 0.5f

    /** 은은한 카드 배경 Modifier (테마에 맞는 그림자/테두리 포함) */
    @Composable
    fun subtleCard(radius: Dp = 16.dp, elevation: Dp = 3.dp): Modifier {
        val cs = MaterialTheme.colorScheme
        val dark = cs.background.luminance() < 0.5f
        return Modifier
            .shadow(elevation, RoundedCornerShape(radius), clip = false,
                ambientColor = if (dark) Color.Black else Color(0x22000000),
                spotColor = if (dark) Color.Black else Color(0x22000000))
            .background(cs.surface, RoundedCornerShape(radius))
            .border(BorderStroke(0.8.dp, cs.outlineVariant), RoundedCornerShape(radius))
    }
}

private fun Color.luminance(): Float = 0.299f * red + 0.587f * green + 0.114f * blue
