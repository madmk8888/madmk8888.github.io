package com.navifit.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * 로그인 화면.
 * - 구글로 시작하기: 구글 브랜드 가이드 스타일 버튼 (흰 배경 + G 로고 + 그림자)
 * - 비회원으로 시작하기: 누르면 닉네임 입력 없이 자동으로 게스트 닉네임 생성 후 바로 입장
 */
@Composable
fun LoginScreen(
    busy: Boolean,
    onGoogleLogin: () -> Unit,
    onGuestLogin: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // 로고 영역
        Box(
            Modifier.size(96.dp).clip(CircleShape)
                .background(Brush.sweepGradient(listOf(
                    Color(0xFFFF8FA3), Color(0xFFC9A5F5), Color(0xFF8B9FFF), Color(0xFF7EDDB8), Color(0xFFFF8FA3)
                )))
                .padding(4.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.fillMaxSize().clip(CircleShape).background(Color(0xFF1E1B27)), contentAlignment = Alignment.Center) {
                Text("🧭", fontSize = 42.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("NaviFit", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFEDEAF4))
        Text("길찾기 · 운동기록 · 랭킹을 한 번에", fontSize = 13.sp, color = Color.Gray)
        Spacer(Modifier.height(48.dp))

        // ===== 구글로 시작하기 (브랜드 스타일) =====
        GoogleSignInButton(enabled = !busy, onClick = onGoogleLogin)

        Spacer(Modifier.height(14.dp))

        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth(0.85f)) {
            HorizontalDivider(Modifier.weight(1f), color = Color(0xFFE4E1EC))
            Text("  또는  ", fontSize = 11.sp, color = Color.Gray)
            HorizontalDivider(Modifier.weight(1f), color = Color(0xFFE4E1EC))
        }

        Spacer(Modifier.height(14.dp))

        // ===== 비회원으로 시작하기 =====
        OutlinedButton(
            onClick = onGuestLogin,
            enabled = !busy,
            modifier = Modifier.fillMaxWidth(0.85f).height(52.dp),
            shape = RoundedCornerShape(26.dp),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFD9D4E4))
        ) {
            Text("👤 비회원으로 시작하기", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFFEDEAF4))
        }
        Spacer(Modifier.height(10.dp))
        Text(
            "비회원은 닉네임이 자동으로 만들어지고,\n글쓰기 하루 3회 · 레어 마커까지만 장착 등 일부 제한이 있어요.\n나중에 구글 계정을 연결하면 기록을 그대로 가진 채 제한이 풀려요.",
            fontSize = 11.sp, color = Color.Gray, lineHeight = 15.sp,
            modifier = Modifier.fillMaxWidth(0.85f)
        )

        if (busy) {
            Spacer(Modifier.height(24.dp))
            CircularProgressIndicator(color = Color(0xFF8B9FFF))
        }
    }
}

/** 구글 브랜딩 가이드 스타일 로그인 버튼 (흰 배경 + 4색 G 로고 + 은은한 그림자) */
@Composable
fun GoogleSignInButton(enabled: Boolean, onClick: () -> Unit, label: String = "Google 계정으로 시작하기") {
    Surface(
        modifier = Modifier
            .fillMaxWidth(0.85f)
            .height(52.dp)
            .shadow(4.dp, RoundedCornerShape(26.dp))
            .clip(RoundedCornerShape(26.dp))
            .clickable(enabled = enabled, onClick = onClick),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE8E8E8))
    ) {
        Row(
            Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            GoogleGLogo(size = 20.dp)
            Spacer(Modifier.width(12.dp))
            Text(label, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color(0xFF3C4043))
        }
    }
}

/** 구글 4색 'G' 로고를 Canvas로 직접 그림 (이미지 리소스 불필요) */
@Composable
fun GoogleGLogo(size: androidx.compose.ui.unit.Dp) {
    Canvas(Modifier.size(size)) {
        val stroke = this.size.minDimension * 0.22f
        val r = (this.size.minDimension - stroke) / 2f
        val c = Offset(this.size.width / 2f, this.size.height / 2f)
        val arcSize = androidx.compose.ui.geometry.Size(r * 2, r * 2)
        val topLeft = Offset(c.x - r, c.y - r)
        val style = Stroke(width = stroke, cap = StrokeCap.Butt)

        // 빨강 (좌상단)
        drawArc(Color(0xFFEA4335), startAngle = 180f, sweepAngle = 100f, useCenter = false, topLeft = topLeft, size = arcSize, style = style)
        // 노랑 (좌하단)
        drawArc(Color(0xFFFBBC05), startAngle = 110f, sweepAngle = 80f, useCenter = false, topLeft = topLeft, size = arcSize, style = style)
        // 초록 (하단-우측)
        drawArc(Color(0xFF34A853), startAngle = 45f, sweepAngle = 75f, useCenter = false, topLeft = topLeft, size = arcSize, style = style)
        // 파랑 (우상단 짧은 호 + 가로 바)
        drawArc(Color(0xFF4285F4), startAngle = 0f, sweepAngle = 45f, useCenter = false, topLeft = topLeft, size = arcSize, style = style)
        drawLine(
            Color(0xFF4285F4),
            start = Offset(c.x, c.y - stroke / 2 + stroke / 2),
            end = Offset(c.x + r + stroke / 2, c.y),
            strokeWidth = stroke
        )
    }
}
