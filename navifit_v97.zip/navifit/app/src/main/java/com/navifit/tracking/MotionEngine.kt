package com.navifit.tracking

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  MotionEngine — 센서 융합 기반 신체 움직임 엔진 (v69 네비/트래킹 전면 개편)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * 목적:
 *  1) GPS가 끊겨도(터널·지하·실내) 신체 센서로 이동을 추정 → 운동이 계속됨 (오프라인 대응)
 *  2) "실제로 뛰거나 페달을 밟았는지"를 신체 진동 리듬으로 검증 → 전기자전거·차량 부정행위 차단
 *
 * 사용 센서 (모두 무료, 오프라인 동작):
 *  · TYPE_ACCELEROMETER : 몸의 흔들림 에너지 → 걷기/뛰기/페달링 리듬 검출
 *  · TYPE_STEP_DETECTOR : 걸음 이벤트(달리기 케이던스)
 *  · TYPE_GYROSCOPE     : 회전(자전거 페달링·코너링) 보조
 *
 * 핵심 지표:
 *  · motionEnergy    : 최근 가속도 변동량(중력 제거). 정지=0, 걷기≈1~3, 뛰기≈5~15, 차량≈0.2~1(엔진진동만)
 *  · cadencePerMin   : 분당 리듬 수 (걸음/페달 왕복). 뛰기 150~190, 자전거 페달 70~100
 *  · isBodyMoving    : 신체가 실제로 운동 중인지 (차량 이동과 구분)
 *  · strideEstimate  : GPS 없을 때 걸음×보폭으로 이동거리 추정 (dead-reckoning 보조)
 *
 * 부정행위 판정 원리:
 *  · 전기자전거/차량은 "빠르게 이동하지만 몸의 상하 진동(케이던스)이 거의 없음".
 *    → 속도는 빠른데 motionEnergy가 낮고 cadence가 없으면 "탈것"으로 판정.
 *  · 반대로 진짜 달리기/자전거는 규칙적인 흔들림 리듬이 반드시 잡힘.
 */
class MotionEngine(private val context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accelSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR)
    private val gyroSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

    // ── 실시간 노출 지표 ──
    @Volatile var motionEnergy: Double = 0.0; private set
    @Volatile var cadencePerMin: Int = 0; private set
    @Volatile var isBodyMoving: Boolean = false; private set
    @Volatile var totalSteps: Int = 0; private set
    // ✅ v71 리듬 규칙성(0~1): 페달링·달리기처럼 일정한 주기가 있으면 1에 가까움.
    //   차량 엔진진동/무동력 활주는 규칙적 주기가 없어 0에 가까움.
    @Volatile var rhythmRegularity: Double = 0.0; private set
    // ✅ v71 페달링 감지: 저주파 주기 진동(0.8~2Hz=48~120rpm)이 규칙적으로 있으면 true
    @Volatile var isPedaling: Boolean = false; private set

    // ── 내부 상태 ──
    private val energyWindow = ArrayDeque<Double>()
    private val ENERGY_WINDOW = 25          // 약 1초(50Hz 기준 25샘플)
    private val stepTimestamps = ArrayDeque<Long>()
    private var gravity = FloatArray(3)
    private val ALPHA = 0.8f                 // 중력 저역통과 계수

    // 가속도 피크 감지(페달링/걸음 리듬) - 걸음센서 없는 기기 대비
    private var lastPeakAt = 0L
    private var peakIntervals = ArrayDeque<Long>()

    fun start() {
        accelSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        stepSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_FASTEST) }
        gyroSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    fun stop() {
        sensorManager.unregisterListener(this)
        reset()
    }

    fun reset() {
        motionEnergy = 0.0; cadencePerMin = 0; isBodyMoving = false; totalSteps = 0
        rhythmRegularity = 0.0; isPedaling = false
        energyWindow.clear(); stepTimestamps.clear(); peakIntervals.clear()
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> handleAccel(event)
            Sensor.TYPE_STEP_DETECTOR -> handleStep()
            Sensor.TYPE_GYROSCOPE -> { /* 회전 에너지는 필요 시 확장 */ }
        }
    }

    private fun handleAccel(event: SensorEvent) {
        // 중력 성분 저역통과 분리 → 순수 신체 움직임(선형가속) 추출
        for (i in 0..2) gravity[i] = ALPHA * gravity[i] + (1 - ALPHA) * event.values[i]
        val lx = event.values[0] - gravity[0]
        val ly = event.values[1] - gravity[1]
        val lz = event.values[2] - gravity[2]
        val magnitude = sqrt((lx * lx + ly * ly + lz * lz).toDouble())

        energyWindow.addLast(magnitude)
        if (energyWindow.size > ENERGY_WINDOW) energyWindow.removeFirst()
        motionEnergy = energyWindow.average()

        // 피크(리듬) 감지 - 걸음센서 없는 기기용 케이던스 추정
        val now = System.currentTimeMillis()
        if (magnitude > 1.6 && now - lastPeakAt > 250) {   // 최소 250ms 간격(=최대 240rpm), 임계 낮춰 페달링도 잡음
            if (lastPeakAt > 0) {
                peakIntervals.addLast(now - lastPeakAt)
                if (peakIntervals.size > 10) peakIntervals.removeFirst()
            }
            lastPeakAt = now
        }
        // 신체 움직임 판정
        isBodyMoving = motionEnergy > 0.7

        // ✅ v71 리듬 규칙성 분석 - 피크 간격의 일관성(변동계수 낮을수록 규칙적)
        if (peakIntervals.size >= 5) {
            val avgMs = peakIntervals.average()
            val variance = peakIntervals.map { (it - avgMs) * (it - avgMs) }.average()
            val stdev = kotlin.math.sqrt(variance)
            val cv = if (avgMs > 0) stdev / avgMs else 1.0  // 변동계수
            // 규칙적일수록(cv 작을수록) 1에 가까움. 사람의 페달링/달리기는 cv<0.35, 차량진동은 불규칙
            rhythmRegularity = (1.0 - (cv / 0.5)).coerceIn(0.0, 1.0)
            // 페달링/달리기 주기: 0.3~1.2초 간격(50~200rpm) + 규칙적이면 신체동력
            isPedaling = avgMs in 300.0..1300.0 && rhythmRegularity >= 0.5
            // 케이던스 (걸음센서 이벤트 없을 때 피크로 추정)
            if (stepTimestamps.isEmpty()) {
                cadencePerMin = if (avgMs > 0) (60_000.0 / avgMs).toInt().coerceIn(0, 240) else 0
            }
        } else {
            rhythmRegularity = 0.0
            isPedaling = false
        }
    }

    private fun handleStep() {
        totalSteps++
        val now = System.currentTimeMillis()
        stepTimestamps.addLast(now)
        // 최근 10초 걸음만 유지
        while (stepTimestamps.isNotEmpty() && now - stepTimestamps.first() > 10_000) stepTimestamps.removeFirst()
        // 케이던스 = 최근 걸음 빈도 → 분당 환산
        if (stepTimestamps.size >= 2) {
            val spanSec = (stepTimestamps.last() - stepTimestamps.first()) / 1000.0
            cadencePerMin = if (spanSec > 0) ((stepTimestamps.size - 1) / spanSec * 60).toInt().coerceIn(0, 260) else 0
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    /**
     * ✅ GPS 없을 때 이동거리 추정 (dead-reckoning 보조).
     * 걸음수 × 개인 보폭으로 근사. dtSeconds 동안의 추정 이동거리(m) 반환.
     */
    fun estimatedDistanceMeters(strideMeters: Double = 0.7): Double {
        // 최근 케이던스 기반 - 1초당 (cadence/60) 걸음 × 보폭
        return (cadencePerMin / 60.0) * strideMeters
    }

    /**
     * ✅ 부정행위 판정 핵심: "이 속도로 이동 중인데 신체 리듬이 있는가?"
     * @return true면 정상(신체 운동), false면 탈것 의심(빠른데 몸이 안 흔들림)
     */
    fun isMovementBodyPowered(speedKmh: Double, mode: com.navifit.navigation.TravelMode): Boolean {
        // 20km/h 미만은 사람이 낼 수 있는 속도(단거리 스퍼트 포함)라 정상 취급.
        //  → 걸었다 뛰었다 하는 인터벌은 여기서 전부 통과. (주 판정은 Google AR이 담당)
        if (speedKmh < 20.0) return true
        return when (mode) {
            com.navifit.navigation.TravelMode.WALK -> {
                // 20km/h 이상(달리기 세계기록 페이스 초과)이면 걸음/진동이 조금이라도 있어야 함
                cadencePerMin >= 100 || motionEnergy >= 2.5
            }
            com.navifit.navigation.TravelMode.BIKE -> true  // 자전거 전기/일반은 onBikeSpeedPattern이 담당
            else -> true
        }
    }
}
