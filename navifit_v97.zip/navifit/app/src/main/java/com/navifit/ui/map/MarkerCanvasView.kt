package com.navifit.ui.map

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.navifit.gacha.DrawnMarker

/**
 * 뽑기/컬렉션 화면에서 마커(배경+심볼)를 벡터로 그려 보여주는 Compose 컴포저블.
 * 유니크/레전더리는 흐름·스파클이 있어 애니메이션 프레임을 돌린다.
 */
@Composable
fun MarkerCanvas(marker: DrawnMarker?, size: Dp = 48.dp, animated: Boolean = true) {
    val density = LocalDensity.current.density
    val px = with(LocalDensity.current) { size.toPx() }.toInt().coerceAtLeast(8)

    var rotation by remember { mutableStateOf(0f) }
    val needsAnim = animated && (marker?.effectiveTierOrdinal ?: -1) >= 3
    if (needsAnim) {
        LaunchedEffect(marker) {
            while (true) {
                withFrameNanos { }
                rotation = (rotation + 3f) % 360f
            }
        }
    }

    val imageBitmap = remember(marker, rotation, px) {
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val cx = px / 2f
        val r = px / 2f - 2
        MarkerSymbolRenderer.drawBackground(canvas, marker?.color, cx, cx, r, rotation)
        MarkerSymbolRenderer.drawSymbol(canvas, marker?.shape?.symbol, cx, cx, r * 1.25f)
        bmp.asImageBitmap()
    }

    Image(bitmap = imageBitmap, contentDescription = marker?.displayName ?: "마커", modifier = Modifier)
}
