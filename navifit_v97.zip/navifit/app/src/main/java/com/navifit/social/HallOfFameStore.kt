package com.navifit.social

import android.content.Context

/**
 * ✅ v58 명예의 전당 + 개인 업적
 *
 * ── 명예의 전당 (전당 20석) ──
 *  · 매달 1회 갱신일에 그 달 1등을 전당에 올림 (한 달에 1명씩)
 *  · 20석이 다 차기 전(1~20개월): 매달 1등이 순서대로 등재
 *  · 20석이 찬 뒤(21개월차~): 기록순 경쟁. 이번 달 1등이 전당 19등보다 좋으면
 *    19등으로 올라가고, 기존 20등은 밀려서 사라짐 (한 자리만 교체)
 *  · 일반 랭킹은 이 갱신일마다 초기화
 *
 * ── 개인 업적 (삭제 불가, 영구 보관) ──
 *  · 매달 100등 안에 들었으면 그 달 업적으로 남김
 *  · 1등 🥇 / 2등 🥈 / 3등 🥉 / 4~100등 ⭐(은색 별)
 *  · 기록·페이스·경로·날짜와 함께 저장 (예: "2026년 1월 · 은색별 99등")
 *
 * 서버 연동 시 이 저장 로직을 Firestore(hall_of_fame, achievements/{uid})로 옮기면 됨.
 */
object HallOfFameStore {
    private const val PREFS = "hall_of_fame"
    private const val KEY_LAST_ROLL = "last_roll_ym" // 마지막 갱신 연월(yyyyMM)

    data class HofEntry(val nickname: String, val recordText: String, val ym: String, val enshrinedRank: Int, val category: String = "run")

    fun list(c: Context): List<HofEntry> = listFor(c, "run") + listFor(c, "bike")

    /** ✅ v63 카테고리별 명예의 전당 (run=러닝 풀코스, bike=자전거 200km) */
    fun listFor(c: Context, category: String): List<HofEntry> = try {
        val raw = c.getSharedPreferences(PREFS, 0).getString("hof_${category}", "[]") ?: "[]"
        val arr = org.json.JSONArray(raw)
        val real = (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            HofEntry(o.getString("nickname"), o.getString("recordText"), o.getString("ym"), o.optInt("rank", i + 1), category)
        }
        // ✅ v78 명예의전당 데모 1~20위 (실제 기록 없을 때만)
        if (real.isNotEmpty()) real else demoHof(category)
    } catch (_: Exception) { demoHof(category) }

    /**
     * ✅ v81 명예의 전당 1위 전용 마커 지급.
     *  갓크라운(레전더리 심볼) + 레인보우크롬(레전더리 배경) 조합을 보유함에 넣는다.
     *  같은 달에 중복 지급되지 않도록 지급 이력을 남긴다.
     */
    fun grantChampionMarker(c: Context, ym: String = "demo"): Boolean {
        val prefs = c.getSharedPreferences(PREFS, 0)
        val key = "champion_marker_$ym"
        if (prefs.getBoolean(key, false)) return false
        return try {
            val shape = com.navifit.gacha.MarkerCatalog.shapes.first { it.id == "godcrown" }
            val color = com.navifit.gacha.MarkerCatalog.colors.first { it.hex == "RAINBOW" }
            com.navifit.gacha.GachaInventory(c)
                .addMarker(com.navifit.gacha.DrawnMarker(shape, color))
            prefs.edit().putBoolean(key, true).apply()
            true
        } catch (_: Exception) { false }
    }

    private fun demoHof(category: String): List<HofEntry> {
        val runNicks = listOf("번개주자","새벽질주","바람의아들","페이스메이커","마라토너K","질주본능","트랙마스터",
            "은빛다리","스피드스타","한강철인","러너스하이","심박수왕","엔듀런스","골든페이스","라스트스퍼트",
            "무한질주","레이스킹","피니시라인","포레스트런","챌린저")
        val bikeNicks = listOf("페달황제","라이딩킹","체인브레이커","클라이머","다운힐러","로드마스터","윈드브레이커",
            "스프린터J","펠로톤","기어체인저","카본휠","업힐크러셔","케이던스킹","드래프팅","벨로시티",
            "그란폰도","힐클라임","타임트라이얼","브레이크어웨이","라이더X")
        val nicks = if (category == "bike") bikeNicks else runNicks
        return (1..20).map { rank ->
            val record = if (category == "bike") {
                val km = 200 - (rank - 1) * 6
                "${km}km 완주"
            } else {
                val base = 2 * 3600 + 40 * 60 + (rank - 1) * 90  // 2:40:00부터
                "풀코스 %d:%02d:%02d".format(base / 3600, (base % 3600) / 60, base % 60)
            }
            HofEntry(nicks[rank - 1], record, "2026년 7월", rank, category)
        }
    }

    private fun save(c: Context, category: String, list: List<HofEntry>) {
        val arr = org.json.JSONArray()
        list.forEach {
            arr.put(org.json.JSONObject().apply {
                put("nickname", it.nickname); put("recordText", it.recordText)
                put("ym", it.ym); put("rank", it.enshrinedRank)
            })
        }
        c.getSharedPreferences(PREFS, 0).edit().putString("hof_${category}", arr.toString()).apply()
    }

    private fun currentYm(): String =
        java.text.SimpleDateFormat("yyyyMM", java.util.Locale.KOREA).format(java.util.Date())

    /** 이번 달 갱신이 아직 안 됐으면 true (월 1회 실행 판단용) */
    fun needsMonthlyRoll(c: Context): Boolean =
        c.getSharedPreferences(PREFS, 0).getString(KEY_LAST_ROLL, "") != currentYm()

    /**
     * 월간 갱신 실행 (카테고리별): 이번 달 1등을 전당 규칙대로 반영.
     * 자격: run = 러닝 풀코스(42.195km) 1등, bike = 자전거 200km 1등.
     * @param topScore 20석이 찬 뒤 19등과 비교용 점수 (클수록 좋음).
     */
    fun rollMonthly(c: Context, category: String, topNickname: String, topRecordText: String, topScore: Long) {
        if (!needsMonthlyRoll(c)) return
        val ym = currentYm()
        val hof = listFor(c, category).toMutableList()
        if (hof.size < 20) {
            hof.add(HofEntry(topNickname, topRecordText, ym, hof.size + 1, category))
        } else {
            if (topScore > 0) {
                hof.removeAt(19)                                  // 20등 탈락
                hof.add(19, HofEntry(topNickname, topRecordText, ym, 19, category)) // 19등 삽입
            }
        }
        val renum = hof.mapIndexed { i, e -> e.copy(enshrinedRank = i + 1) }
        save(c, category, renum)
        c.getSharedPreferences(PREFS, 0).edit().putString(KEY_LAST_ROLL, ym).apply()
    }
}

object AchievementStore {
    private const val PREFS = "achievements"
    private const val KEY = "ach_json"

    data class Achievement(
        val ym: String,        // "2026년 1월"
        val rank: Int,         // 1~100
        val medal: String,     // 🥇🥈🥉⭐
        val recordText: String,
        val pace: String,
        val routeKey: String?, // 그때의 경로 공유키 (있으면)
        val dateMillis: Long
    )

    fun list(c: Context): List<Achievement> = try {
        val arr = org.json.JSONArray(c.getSharedPreferences(PREFS, 0).getString(KEY, "[]") ?: "[]")
        val real = (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Achievement(
                o.getString("ym"), o.getInt("rank"), o.getString("medal"),
                o.getString("recordText"), o.optString("pace", ""),
                o.optString("routeKey", null).takeIf { it.isNotBlank() },
                o.optLong("dateMillis", 0L)
            )
        }.sortedByDescending { it.dateMillis }
        // ✅ v63 업적 테스트용 데모 10개 (실제 업적이 없을 때만)
        if (real.isNotEmpty()) real else demoAchievements()
    } catch (_: Exception) { demoAchievements() }

    private fun demoAchievements(): List<Achievement> {
        val now = System.currentTimeMillis()
        val mo = 30L * 24 * 3600 * 1000
        fun medal(r: Int) = when (r) { 1 -> "🥇"; 2 -> "🥈"; 3 -> "🥉"; else -> "⭐" }
        val data = listOf(
            Triple("2026년 7월", 1, "풀코스 2:58:14"), Triple("2026년 6월", 3, "10km 41:22"),
            Triple("2026년 5월", 2, "하프 1:32:05"), Triple("2026년 4월", 7, "5km 19:48"),
            Triple("2026년 3월", 15, "10km 44:10"), Triple("2026년 2월", 28, "5km 21:30"),
            Triple("2026년 1월", 42, "3km 13:12"), Triple("2025년 12월", 55, "5km 22:40"),
            Triple("2025년 11월", 71, "10km 48:33"), Triple("2025년 10월", 99, "3km 14:55")
        )
        return data.mapIndexed { i, (ym, rank, rec) ->
            Achievement(ym, rank, medal(rank), rec, "", null, now - i * mo)
        }
    }

    /** 매달 100등 안에 들었을 때 1회 기록 (삭제 불가 - add만 존재) */
    fun record(c: Context, rank: Int, recordText: String, pace: String, routeKey: String?) {
        if (rank !in 1..100) return
        val ym = java.text.SimpleDateFormat("yyyy년 M월", java.util.Locale.KOREA).format(java.util.Date())
        val existing = try {
            val arr = org.json.JSONArray(c.getSharedPreferences(PREFS, 0).getString(KEY, "[]") ?: "[]")
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Achievement(o.getString("ym"), o.getInt("rank"), o.getString("medal"),
                    o.getString("recordText"), o.optString("pace",""), null, o.optLong("dateMillis",0L))
            }
        } catch (_: Exception) { emptyList() }
        if (existing.any { it.ym == ym }) return   // 그 달 업적은 1개만
        val medal = when (rank) { 1 -> "🥇"; 2 -> "🥈"; 3 -> "🥉"; else -> "⭐" }
        val arr = org.json.JSONArray()
        (existing + Achievement(ym, rank, medal, recordText, pace, routeKey, System.currentTimeMillis()))
            .forEach {
                arr.put(org.json.JSONObject().apply {
                    put("ym", it.ym); put("rank", it.rank); put("medal", it.medal)
                    put("recordText", it.recordText); put("pace", it.pace)
                    put("routeKey", it.routeKey ?: ""); put("dateMillis", it.dateMillis)
                })
            }
        c.getSharedPreferences(PREFS, 0).edit().putString(KEY, arr.toString()).apply()
    }

    fun medalLabel(rank: Int): String = when (rank) {
        1 -> "금메달"; 2 -> "은메달"; 3 -> "동메달"; else -> "은색 별 ${rank}등"
    }
}
