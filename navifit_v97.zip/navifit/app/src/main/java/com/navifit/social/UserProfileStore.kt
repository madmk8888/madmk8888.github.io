package com.navifit.social

import android.content.Context
// ✅ v96 `by mutableStateOf` 위임을 쓰려면 getValue/setValue 확장이 import 돼야 함
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf

/**
 * ✅ v64 인스타식 SNS 프로필 저장소.
 *  · 내 소개(bio), 프로필 사진 경로, 프로필 표시 방식(마커+테두리 / 사진) 저장.
 *  · 운동 이력·업적 공개 여부.
 *  실서버 연동 시 users/{uid} 문서로 옮기면 됨. 지금은 로컬(SharedPreferences).
 */
object UserProfileStore {
    private const val PREFS = "user_profile_sns"

    /**
     * ✅ v85 변경 리비전 (반응형).
     *  SharedPreferences는 Compose가 관찰하지 못해서, 프로필 사진·아바타 방식을 바꿔도
     *  화면을 나갔다 들어와야 반영됐다.
     *  쓰기가 일어날 때마다 이 값을 올리고, 화면에서 이 값을 읽으면 즉시 재구성된다.
     */
    var revision by mutableStateOf(0)
        private set

    private fun bump() { revision++ }

    fun bio(c: Context): String =
        c.getSharedPreferences(PREFS, 0).getString("bio", "") ?: ""
    fun setBio(c: Context, v: String) {
        c.getSharedPreferences(PREFS, 0).edit().putString("bio", v.take(150)).apply(); bump()
    }

    fun profilePhotoPath(c: Context): String? =
        c.getSharedPreferences(PREFS, 0).getString("photo", null)
    fun setProfilePhotoPath(c: Context, path: String?) {
        c.getSharedPreferences(PREFS, 0).edit().putString("photo", path).apply(); bump()
    }

    /** 프로필 아이콘 표시 방식: true=사진, false=마커+테두리(랭킹/RM/운동장 공통) */
    fun usePhotoAvatar(c: Context): Boolean =
        c.getSharedPreferences(PREFS, 0).getBoolean("use_photo", false)
    fun setUsePhotoAvatar(c: Context, v: Boolean) {
        c.getSharedPreferences(PREFS, 0).edit().putBoolean("use_photo", v).apply(); bump()
    }

    /** 운동 이력 공개 여부 */
    fun showWorkoutHistory(c: Context): Boolean =
        c.getSharedPreferences(PREFS, 0).getBoolean("show_history", true)
    fun setShowWorkoutHistory(c: Context, v: Boolean) =
        c.getSharedPreferences(PREFS, 0).edit().putBoolean("show_history", v).apply()

    /** 업적 공개 여부 */
    fun showAchievements(c: Context): Boolean =
        c.getSharedPreferences(PREFS, 0).getBoolean("show_ach", true)
    fun setShowAchievements(c: Context, v: Boolean) =
        c.getSharedPreferences(PREFS, 0).edit().putBoolean("show_ach", v).apply()

    /** ✅ v76 콘텐츠 종류별 공개 범위: kind="post"|"photo"|"video", scope="all"|"friends"|"me"|"none" */
    fun contentScope(c: Context, kind: String): String =
        c.getSharedPreferences(PREFS, 0).getString("scope_$kind", "all") ?: "all"
    fun setContentScope(c: Context, kind: String, scope: String) =
        c.getSharedPreferences(PREFS, 0).edit().putString("scope_$kind", scope).apply()
}
