package com.navifit.navigation

import android.content.Context
import java.util.Properties

/**
 * v29 무료 API 키 로더.
 * app/src/main/assets/api_keys.properties 파일에 키를 넣으면 자동 활성화:
 *
 *   kakao_rest_key=카카오 REST API 키          (developers.kakao.com → 앱 만들기 → REST API 키)
 *   data_go_kr_key=공공데이터포털 인증키(Decoding) (data.go.kr → 전국무인교통단속카메라표준데이터 활용신청)
 *
 * 키가 없으면 해당 기능은 자동으로 건너뛰고 기존 방식(ORS/구글/내장 카메라파일)으로 동작.
 */
object NavApiKeys {
    private var loaded = false
    private var kakao: String? = null
    private var dataGoKr: String? = null
    private var openAi: String? = null        // ✅ v47 OpenAI Moderation (Perspective 대체, 무료)
    private var its: String? = null           // ✅ v47 ITS 국가교통정보센터 (정체구간 - data.go.kr과 별개 키!)
    private var ex: String? = null            // ✅ v48 한국도로공사 (휴게소·돌발정보·교통량)
    private var safeBrowsing: String? = null  // ✅ v42 악성 링크 검사 (무료)
    private var googleMaps: String? = null    // ✅ v46 지도·장소검색·경로(백업)
    private var ors: String? = null           // ✅ v46 도보·자전거 경로

    fun kakaoRestKey(c: Context): String? { load(c); return kakao }
    fun dataGoKrKey(c: Context): String? { load(c); return dataGoKr }
    fun openAiKey(c: Context): String? { load(c); return openAi }
    fun itsKey(c: Context): String? { load(c); return its }
    fun exKey(c: Context): String? { load(c); return ex }
    fun safeBrowsingKey(c: Context): String? { load(c); return safeBrowsing }

    /** 구글 지도/장소/경로 키 (없으면 빈 문자열 - 지도가 회색으로 뜸) */
    fun googleMapsKey(c: Context): String { load(c); return googleMaps ?: "" }

    /** OpenRouteService 키 (도보·자전거 경로. 없으면 구글로 대체) */
    fun orsKey(c: Context): String { load(c); return ors ?: "" }

    private fun load(c: Context) {
        if (loaded) return
        loaded = true
        try {
            c.assets.open("api_keys.properties").use { ins ->
                val p = Properties().apply { load(ins) }
                kakao = p.getProperty("kakao_rest_key")?.trim()?.takeIf { it.isNotBlank() && !it.startsWith("여기에") }
                dataGoKr = p.getProperty("data_go_kr_key")?.trim()?.takeIf { it.isNotBlank() && !it.startsWith("여기에") }
                openAi = p.getProperty("openai_key")?.trim()?.takeIf { it.isNotBlank() && !it.startsWith("여기에") }
                its = p.getProperty("its_key")?.trim()?.takeIf { it.isNotBlank() && !it.startsWith("여기에") }
                ex = p.getProperty("ex_key")?.trim()?.takeIf { it.isNotBlank() && !it.startsWith("여기에") }
                safeBrowsing = p.getProperty("safe_browsing_key")?.trim()?.takeIf { it.isNotBlank() && !it.startsWith("여기에") }
                googleMaps = p.getProperty("google_maps_key")?.trim()?.takeIf { it.isNotBlank() && !it.startsWith("여기에") }
                ors = p.getProperty("ors_key")?.trim()?.takeIf { it.isNotBlank() && !it.startsWith("여기에") }
            }
        } catch (_: Exception) { /* 파일 없으면 기능 비활성 */ }
    }
}
