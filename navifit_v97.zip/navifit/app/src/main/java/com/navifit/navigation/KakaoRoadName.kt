package com.navifit.navigation

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * ✅ v73 카카오 로컬 API(coord2address) 실시간 현재 도로명 조회 — 무료 쿼터(하루 10만) 사용.
 *
 * Roads API(유료) 없이도 "지금 내가 어느 도로 위인지"를 실시간에 가깝게 표시.
 * 비용 방지: 30초에 한 번 + 100m 이상 이동 시에만 호출(1회 운동에 수십 건 → 무료 쿼터 안).
 */
object KakaoRoadName {
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()

    private var lastLat = 0.0
    private var lastLng = 0.0
    private var lastAtMs = 0L
    private var cached: String? = null

    /**
     * 현재 좌표의 도로명 주소를 반환(없으면 지번). 호출 빈도 제한 내장(무료 쿼터 보호).
     * @return "테헤란로" 같은 도로명, 실패 시 null
     */
    suspend fun currentRoad(context: Context, lat: Double, lng: Double): String? {
        val now = System.currentTimeMillis()
        val moved = haversine(lastLat, lastLng, lat, lng)
        // 30초 이내 또는 100m 미만 이동이면 캐시 반환 (쿼터 절약)
        if (now - lastAtMs < 30_000 && moved < 100) return cached
        val key = NavApiKeys.kakaoRestKey(context) ?: return cached
        lastAtMs = now; lastLat = lat; lastLng = lng
        return withContext(Dispatchers.IO) {
            try {
                val url = "https://dapi.kakao.com/v2/local/geo/coord2address.json?x=$lng&y=$lat"
                val res = client.newCall(
                    Request.Builder().url(url).addHeader("Authorization", "KakaoAK $key").build()
                ).execute()
                val body = res.body?.string() ?: return@withContext cached
                val docs = JSONObject(body).optJSONArray("documents") ?: return@withContext cached
                if (docs.length() == 0) return@withContext cached
                val d = docs.getJSONObject(0)
                val road = d.optJSONObject("road_address")
                val name = road?.optString("road_name")?.takeIf { it.isNotBlank() }
                    ?: d.optJSONObject("address")?.optString("region_3depth_name")
                cached = name
                name
            } catch (_: Exception) { cached }
        }
    }

    private fun haversine(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
        if (lat1 == 0.0 && lng1 == 0.0) return Double.MAX_VALUE
        val r = 6371000.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLng = Math.toRadians(lng2 - lng1)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLng / 2) * Math.sin(dLng / 2)
        return r * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    }
}
