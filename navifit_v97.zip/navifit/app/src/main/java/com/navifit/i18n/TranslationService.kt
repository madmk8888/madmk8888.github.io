package com.navifit.i18n

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

/**
 * ✅ v44 번역 서비스 (동시성 버그 수정).
 *
 * ── v43까지의 치명적 버그 ──
 * 화면이 뜰 때 tr()이 100개 이상 동시에 번역을 호출하는데:
 *  ① cache/translators가 일반 mutableMap이라 동시 쓰기로 맵이 깨짐
 *     → ConcurrentModificationException이 조용히 삼켜지며 번역이 실패
 *  ② 같은 언어팩 다운로드를 100번 동시에 요청 → 대부분 실패
 * 이것이 "번역이 되는 것도 있고 안 되는 것도 있는" 증상의 원인이었음.
 *
 * ── v44 ──
 *  · ConcurrentHashMap + Mutex로 동시성 보장
 *  · 언어팩 다운로드를 쌍(pair)당 딱 1회만 수행하고, 나머지는 그 결과를 기다림
 *  · 다운로드 완료 여부를 기록해 매번 재확인하지 않음
 *
 * ML Kit 온디바이스 번역: 무료·무제한·오프라인·API 키 불필요.
 */
object TranslationService {

    private val cache = ConcurrentHashMap<String, String>()
    private val translators = ConcurrentHashMap<String, Translator>()
    private val downloaded = ConcurrentHashMap<String, Boolean>()

    private val translatorLock = Mutex()   // Translator 생성 직렬화
    private val downloadLocks = ConcurrentHashMap<String, Mutex>()

    private fun toMlKit(code: String): String? = when (code) {
        "ko" -> TranslateLanguage.KOREAN
        "en" -> TranslateLanguage.ENGLISH
        "ja" -> TranslateLanguage.JAPANESE
        "zh" -> TranslateLanguage.CHINESE
        "es" -> TranslateLanguage.SPANISH
        "fr" -> TranslateLanguage.FRENCH
        "de" -> TranslateLanguage.GERMAN
        "pt" -> TranslateLanguage.PORTUGUESE
        "vi" -> TranslateLanguage.VIETNAMESE
        "th" -> TranslateLanguage.THAI
        "id" -> TranslateLanguage.INDONESIAN
        "ru" -> TranslateLanguage.RUSSIAN
        "it" -> TranslateLanguage.ITALIAN
        "ar" -> TranslateLanguage.ARABIC
        "hi" -> TranslateLanguage.HINDI
        else -> null
    }

    /** 번역 지원 여부 (UI에서 버튼 노출 판단용) */
    fun isSupported(code: String?) = code != null && toMlKit(code) != null

    suspend fun detectLanguage(text: String): String? = suspendCancellableCoroutine { cont ->
        if (text.isBlank()) { cont.resume(null); return@suspendCancellableCoroutine }
        try {
            LanguageIdentification.getClient()
                .identifyLanguage(text)
                .addOnSuccessListener { code -> cont.resume(if (code == "und") null else code) }
                .addOnFailureListener { cont.resume(null) }
        } catch (_: Exception) { cont.resume(null) }
    }

    /**
     * @param sourceCode 원문 언어. null이면 자동 감지.
     * @param targetCode 목표 언어 (보는 사람의 언어)
     * @return 번역문. 같은 언어이거나 실패 시 null.
     */
    suspend fun translate(text: String, sourceCode: String?, targetCode: String): String? {
        if (text.isBlank()) return null

        val src = sourceCode ?: detectLanguage(text) ?: return null
        if (src == targetCode) return null

        val cacheKey = "$src|$targetCode|$text"
        cache[cacheKey]?.let { return it }

        val srcMl = toMlKit(src) ?: return null
        val tgtMl = toMlKit(targetCode) ?: return null
        val pairKey = "$srcMl-$tgtMl"

        // ① Translator 생성은 한 번만 (동시 생성 시 리소스 누수·깨짐 방지)
        val translator: Translator = translators[pairKey] ?: translatorLock.withLock {
            translators.getOrPut(pairKey) {
                Translation.getClient(
                    TranslatorOptions.Builder()
                        .setSourceLanguage(srcMl)
                        .setTargetLanguage(tgtMl)
                        .build()
                )
            }
        }

        // ② 언어팩 다운로드는 쌍당 딱 1회 (100개 동시 요청 → 1회로 축소, 나머지는 대기)
        if (downloaded[pairKey] != true) {
            val lock = downloadLocks.getOrPut(pairKey) { Mutex() }
            lock.withLock {
                if (downloaded[pairKey] != true) {
                    val ok = suspendCancellableCoroutine<Boolean> { cont ->
                        try {
                            translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
                                .addOnSuccessListener { cont.resume(true) }
                                .addOnFailureListener { cont.resume(false) }
                        } catch (_: Exception) { cont.resume(false) }
                    }
                    downloaded[pairKey] = ok
                }
            }
        }
        if (downloaded[pairKey] != true) return null

        // ③ 번역
        val result = suspendCancellableCoroutine<String?> { cont ->
            try {
                translator.translate(text)
                    .addOnSuccessListener { cont.resume(it) }
                    .addOnFailureListener { cont.resume(null) }
            } catch (_: Exception) { cont.resume(null) }
        }
        result?.let { cache[cacheKey] = it }
        return result
    }

    /** 언어팩이 이미 준비됐는지 (UI에서 "다운로드 중" 표시용) */
    fun isReady(src: String, tgt: String): Boolean {
        val s = toMlKit(src) ?: return false
        val t = toMlKit(tgt) ?: return false
        return downloaded["$s-$t"] == true
    }

    fun close() {
        translators.values.forEach { runCatching { it.close() } }
        translators.clear()
        downloaded.clear()
        cache.clear()
    }
}
