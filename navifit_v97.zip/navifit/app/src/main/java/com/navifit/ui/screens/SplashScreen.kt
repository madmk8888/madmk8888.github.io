package com.navifit.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

/**
 * 첫 화면 스플래시 - "RRN" 세로 배치.
 * R = 러닝(Running) · R = 랭킹(Ranking) · N = 네비(Navi) - NaviFit의 3대 핵심 기능 이니셜.
 *
 * 연출:
 * 1) 글자가 위에서 통통 튕기며 하나씩 순서대로 떨어짐 (스프링 바운스)
 * 2) 다 등장하면 살짝 씰룩씰룩 웃는 듯한 미세 흔들림(wiggle) 반복
 * 3) 맨 위(첫 R) 위쪽 여백에 "ㅋㅋ" 말풍선이 통통 튀며 나타남 (글자를 가리지 않음)
 * 4) 사람들이 충분히 볼 수 있도록 넉넉히 멈췄다가 다음 화면으로 넘어감
 */
@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val letters = listOf(
        Triple("R", "Running", Color(0xFFFF6F91)),
        Triple("R", "Ranking", Color(0xFF8B9FFF)),
        Triple("N", "Navi", Color(0xFF39C98E))
    )

    val visibleCount = remember { mutableStateOf(0) }
    var showLaugh by remember { mutableStateOf(false) }
    // ✅ v81 로딩 문구 (운동 정보를 불러오는 동안 표시)
    var loadingMsg by remember { mutableStateOf("운동 정보를 불러오는 중입니다...") }

    LaunchedEffect(Unit) {
        delay(150)
        for (i in letters.indices) {
            visibleCount.value = i + 1
            delay(260) // 통통 튕기며 순서대로 등장 (조금 더 여유 있게)
        }
        delay(300)
        showLaugh = true
        // ✅ v81 스플래시 시간을 넉넉히 (기존 1.1초 → 약 3.6초). 문구가 순서대로 바뀜.
        delay(1200)
        loadingMsg = "지도와 경로를 준비하는 중입니다..."
        delay(1200)
        loadingMsg = "거의 다 됐어요!"
        delay(1200)
        onFinished()
    }

    // ✅ v81 배경 그라데이션 고급스럽게 재구성
    //   기존: 흰색 → 보라빛 회색 (탁하고 촌스러움)
    //   변경: 딥 네이비 → 미드나잇 블루 → 차콜 (프리미엄 스포츠 앱 톤)
    Box(
        Modifier.fillMaxSize()
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF0B1220),   // 딥 네이비
                        Color(0xFF14243D),   // 미드나잇 블루
                        Color(0xFF1B2A3A),   // 슬레이트
                        Color(0xFF0E1520)    // 차콜
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            // ✅ "ㅋㅋ" 말풍선을 글자 스택 맨 위(첫 R 위쪽)에 배치 - 글자를 절대 안 가림
            Box(
                Modifier.height(44.dp),
                contentAlignment = Alignment.BottomCenter
            ) {
                if (showLaugh) LaughBubble()
            }
            Spacer(Modifier.height(6.dp))

            letters.forEachIndexed { i, (letter, label, color) ->
                if (i < visibleCount.value) {
                    BouncyLetter(letter = letter, label = label, color = color)
                    if (i != letters.lastIndex) Spacer(Modifier.height(10.dp))
                }
            }
            Spacer(Modifier.height(28.dp))
            Text(
                "NaviFit",
                fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFFAFC3E8),
                modifier = Modifier.graphicsLayer { alpha = if (visibleCount.value >= letters.size) 1f else 0f }
            )
            Spacer(Modifier.height(18.dp))
            // ✅ v81 로딩 안내 문구 + 점 애니메이션
            if (visibleCount.value >= letters.size) {
                val dots by rememberInfiniteTransition(label = "dots").animateFloat(
                    0f, 3f, infiniteRepeatable(tween(1500, easing = LinearEasing)), label = "d")
                Text(
                    loadingMsg,
                    fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFF7B90B5)
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    repeat(3) { idx ->
                        val active = dots.toInt() % 3 == idx
                        Box(
                            Modifier.size(if (active) 7.dp else 5.dp)
                                .clip(RoundedCornerShape(50))
                                .background(if (active) Color(0xFF5B8DEF) else Color(0xFF34415C))
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LaughBubble() {
    val scale = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        scale.animateTo(1f, animationSpec = spring(dampingRatio = Spring.DampingRatioHighBouncy, stiffness = Spring.StiffnessMedium))
    }
    // ✅ v81 "ㅋㅋ"가 등장 후에도 계속 통통 튀며 움직이게 (위아래 + 살짝 회전)
    val infinite = rememberInfiniteTransition(label = "laugh")
    val bob by infinite.animateFloat(
        initialValue = 0f, targetValue = -9f,
        animationSpec = infiniteRepeatable(tween(480, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bob"
    )
    val tilt by infinite.animateFloat(
        initialValue = -6f, targetValue = 6f,
        animationSpec = infiniteRepeatable(tween(620, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "tilt"
    )
    Box(
        Modifier
            .graphicsLayer {
                scaleX = scale.value; scaleY = scale.value
                translationY = bob
                rotationZ = tilt
            }
            .shadow(6.dp, RoundedCornerShape(14.dp))
            .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp, bottomEnd = 14.dp, bottomStart = 2.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF243B5E), Color(0xFF16233A))))
            .padding(horizontal = 13.dp, vertical = 7.dp)
    ) {
        Text("ㅋㅋ 😆", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFFDCE7FF))
    }
}

@Composable
private fun BouncyLetter(letter: String, label: String, color: Color) {
    val dropAnim = remember { Animatable(-120f) }
    val scaleAnim = remember { Animatable(0.6f) }
    LaunchedEffect(Unit) {
        dropAnim.animateTo(0f, animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow))
    }
    LaunchedEffect(Unit) {
        scaleAnim.animateTo(1f, animationSpec = spring(dampingRatio = Spring.DampingRatioHighBouncy, stiffness = Spring.StiffnessMedium))
    }

    val infinite = rememberInfiniteTransition(label = "giggle")
    val wiggle by infinite.animateFloat(
        initialValue = -4f, targetValue = 4f,
        animationSpec = infiniteRepeatable(tween(220, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "wg"
    )

    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .graphicsLayer {
                    translationY = dropAnim.value
                    scaleX = scaleAnim.value; scaleY = scaleAnim.value
                    rotationZ = wiggle
                }
                .shadow(8.dp, RoundedCornerShape(20.dp))
                .clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(listOf(color, color.copy(alpha = 0.75f))))
                .size(84.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(letter, fontSize = 42.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
        }
        Spacer(Modifier.width(14.dp))
        Text(
            label, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFFEDEAF4),
            modifier = Modifier.graphicsLayer { alpha = if (dropAnim.value == 0f) 1f else 0f }
        )
    }
}
