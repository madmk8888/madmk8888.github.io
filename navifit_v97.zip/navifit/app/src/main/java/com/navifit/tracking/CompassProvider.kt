package com.navifit.tracking

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.abs

/**
 * ✅ v81 나침반(방위) 제공자 — 지도 heading-up 정렬용.
 *
 * 기존 문제: GPS bearing만 쓰면 정지·저속에서 방위가 튀어 지도가 엉뚱한 방향을 봄.
 * 해결: 안드로이드 ROTATION_VECTOR 센서(가속도+자이로+지자기 융합)를 사용.
 *       기기 자체가 계산해주는 안정적인 방위라 별도 알고리즘이 필요 없다.
 *
 * · 이동 중(3km/h↑)에는 GPS bearing이 더 정확하므로 그쪽을 우선한다.
 * · 정지·저속에서는 나침반 방위를 쓴다.
 * · 급격한 각도 변화는 지수평활(EMA)로 완만하게 만들어 지도 떨림을 막는다.
 */
class CompassProvider(context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val rotationSensor: Sensor? =
        sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
            ?: sensorManager.getDefaultSensor(Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR)

    /** 0~360, 지도 정북 기준 방위 */
    @Volatile var headingDegrees: Float = 0f; private set
    @Volatile var available: Boolean = false; private set

    private val rotationMatrix = FloatArray(9)
    private val orientation = FloatArray(3)
    private var smoothed = Float.NaN

    fun start() {
        rotationSensor?.let {
            available = true
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    fun stop() {
        sensorManager.unregisterListener(this)
        smoothed = Float.NaN
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ROTATION_VECTOR &&
            event.sensor.type != Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR) return

        SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
        SensorManager.getOrientation(rotationMatrix, orientation)
        var deg = Math.toDegrees(orientation[0].toDouble()).toFloat()
        if (deg < 0) deg += 360f

        smoothed = if (smoothed.isNaN()) deg else emaAngle(smoothed, deg, 0.18f)
        headingDegrees = ((smoothed % 360f) + 360f) % 360f
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    companion object {
        /** 각도 지수평활 (359°→1° 같은 경계에서도 자연스럽게) */
        fun emaAngle(prev: Float, next: Float, alpha: Float): Float {
            var diff = next - prev
            while (diff > 180f) diff -= 360f
            while (diff < -180f) diff += 360f
            return prev + alpha * diff
        }

        /** 두 각도의 최소 차이(0~180) */
        fun angleDelta(a: Float, b: Float): Float {
            var d = abs(a - b) % 360f
            if (d > 180f) d = 360f - d
            return d
        }
    }
}
