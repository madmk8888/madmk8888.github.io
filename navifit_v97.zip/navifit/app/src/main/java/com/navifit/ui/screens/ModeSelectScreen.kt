package com.navifit.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.navifit.i18n.tr
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.libraries.places.api.net.PlacesClient
import com.google.maps.android.compose.*
import com.navifit.navigation.LatLngPoint
import com.navifit.navigation.PlacesAutocompleteField
import com.navifit.navigation.TravelMode
import com.navifit.i18n.LocalStrings
import kotlinx.coroutines.launch

/**
 * ✅ 전면 개편 (카카오내비 모바일 스타일):
 *  - 지도가 화면 전체를 차지하고, 모든 UI는 지도 위에 떠 있는 반투명 오버레이
 *  - 달리기 🏃 / 자전거 🚴 두 모드만 (자동차·오토바이 제거)
 *  - 상단: 검색바 + 모드 토글 + 🔑 공유경로 키 버튼
 *  - 자주 가는 곳 / 최근 목적지: 지도를 밀어내지 않는 얇은 칩 오버레이
 *  - 하단: 목적지를 고르면 반투명 카드가 떠오르고 큰 "길찾기" 버튼 (잘림 없음)
 *  - 지도 컨트롤: ＋/− 줌 버튼 · 내 위치 버튼 · 회전 제스처/나침반
 */
@Composable
fun ModeSelectScreen(
    placesClient: PlacesClient,
    onModeSelected: (TravelMode) -> Unit,
    onSearchDestination: (String, Double, Double, TravelMode) -> Unit,
    onOpenRouteKey: () -> Unit = {},          // 🔑 공유경로 키 입력 다이얼로그 열기
    onStartFreeRun: (TravelMode) -> Unit = {}  // ✅ v67 자유 운동 시작 (경로 없이 내 궤적만)
) {
    var selectedMode by remember { mutableStateOf(TravelMode.WALK) }
    var destName by remember { mutableStateOf<String?>(null) }
    var destLat by remember { mutableStateOf<Double?>(null) }
    var destLng by remember { mutableStateOf<Double?>(null) }
    var destAddress by remember { mutableStateOf<String?>(null) }
    var mapLoaded by remember { mutableStateOf(false) }
    var reverseGeocoding by remember { mutableStateOf(false) }

    val seoul = LatLng(37.5665, 126.9780)
    var realLocation by remember { mutableStateOf<LatLng?>(null) }
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(seoul, 13f)
    }
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val fusedClient = remember { com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(context) }

    var hasLocationPermission by remember {
        mutableStateOf(
            androidx.core.content.ContextCompat.checkSelfPermission(
                context, android.Manifest.permission.ACCESS_FINE_LOCATION
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }
    var locating by remember { mutableStateOf(false) }

    fun moveToMyLocation() {
        if (!hasLocationPermission) return
        locating = true
        try {
            fusedClient.getCurrentLocation(
                com.google.android.gms.location.Priority.PRIORITY_HIGH_ACCURACY,
                com.google.android.gms.tasks.CancellationTokenSource().token
            ).addOnSuccessListener { loc ->
                locating = false
                loc?.let {
                    val here = LatLng(it.latitude, it.longitude)
                    realLocation = here
                    scope.launch {
                        cameraPositionState.animate(
                            CameraUpdateFactory.newLatLngZoom(here, 16f), 500)
                    }
                }
            }.addOnFailureListener { locating = false }
        } catch (e: SecurityException) { locating = false }
    }

    LaunchedEffect(Unit) {
        try {
            fusedClient.lastLocation.addOnSuccessListener { loc ->
                loc?.let {
                    val here = LatLng(it.latitude, it.longitude)
                    realLocation = here
                    if (destLat == null) cameraPositionState.position =
                        CameraPosition.fromLatLngZoom(here, 15f)
                }
            }
        } catch (e: SecurityException) { }
    }

    fun selectMapTapAsDestination(latLng: LatLng) {
        destLat = latLng.latitude; destLng = latLng.longitude
        destName = "선택한 위치"; destAddress = null
        reverseGeocoding = true
        try {
            @Suppress("DEPRECATION")
            val results = android.location.Geocoder(context, java.util.Locale.KOREA)
                .getFromLocation(latLng.latitude, latLng.longitude, 1)
            val addr = results?.firstOrNull()
            if (addr != null) {
                destName = addr.featureName?.takeIf { it.isNotBlank() && it != addr.thoroughfare }
                    ?: addr.thoroughfare ?: "선택한 위치"
                destAddress = addr.getAddressLine(0)
            }
        } catch (_: Exception) { }
        reverseGeocoding = false
    }

    // ═══════════ 전체화면 지도 + 오버레이 구성 ═══════════
    Box(Modifier.fillMaxSize()) {

        // ── 지도 (풀스크린 베이스) ──
        GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = cameraPositionState,
            properties = MapProperties(isMyLocationEnabled = hasLocationPermission),
            uiSettings = MapUiSettings(
                myLocationButtonEnabled = false,
                zoomControlsEnabled = false,
                compassEnabled = true,               // ✅ 나침반 (지도 회전 시 표시)
                rotationGesturesEnabled = true,      // ✅ 두 손가락 회전
                tiltGesturesEnabled = true
            ),
            onMapLoaded = { mapLoaded = true },
            onMapClick = { latLng -> selectMapTapAsDestination(latLng) }
        ) {
            // ✅ v83 강제 언랩 제거: 값을 안전하게 꺼내 쓴다
            val dLat = destLat; val dLng = destLng
            if (dLat != null && dLng != null) {
                Marker(state = MarkerState(LatLng(dLat, dLng)), title = destName ?: "목적지")
            }
        }
        if (!mapLoaded) {
            Column(
                Modifier.fillMaxSize().background(Color(0xFF121420)),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                CircularProgressIndicator(color = Color(0xFF7C93F5))
                Spacer(Modifier.height(10.dp))
                Text(tr("지도 불러오는 중..."), fontSize = 12.sp, color = Color.Gray)
            }
        }

        // ── 상단 오버레이: 검색바 + 모드/공유키 + 자주가는곳/최근 (지도를 밀지 않음) ──
        Column(
            Modifier.fillMaxWidth().align(Alignment.TopCenter)
                .statusBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            // 검색바 (카카오내비처럼 카드형)
            Surface(
                shape = RoundedCornerShape(18.dp), color = Color(0xF21B1E2C),
                shadowElevation = 8.dp, modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
                    PlacesAutocompleteField(
                        placesClient = placesClient,
                        currentLocation = realLocation?.let { LatLngPoint(it.latitude, it.longitude) }
                    ) { name, lat, lng, address ->
                        destName = name; destLat = lat; destLng = lng; destAddress = address
                        scope.launch {
                            cameraPositionState.animate(
                                CameraUpdateFactory.newLatLngZoom(LatLng(lat, lng), 15f), 500)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    // ✅ v77 1행: 달리기 · 자전거 · 자유운동
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        listOf(TravelMode.WALK to "🏃 달리기", TravelMode.BIKE to "🚴 자전거").forEach { (m, label) ->
                            val sel = selectedMode == m
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(
                                        if (sel) Brush.horizontalGradient(
                                            listOf(Color(0xFF34C77B), Color(0xFF2AA968))
                                        ) else Brush.horizontalGradient(
                                            listOf(Color(0xFF262A3C), Color(0xFF262A3C)))
                                    )
                                    .clickable { selectedMode = m; onModeSelected(m) }
                                    .padding(horizontal = 13.dp, vertical = 8.dp)
                            ) {
                                Text(label, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold,
                                    color = if (sel) Color.White else Color(0xFFAAB0C4))
                            }
                            Spacer(Modifier.width(7.dp))
                        }
                        // 자유 운동 (길안내 없이 제자리에서 내 궤적만 그림)
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(Color(0xFF203A2E))
                                .border(1.dp, Color(0xFF34D399), RoundedCornerShape(20.dp))
                                .clickable { onStartFreeRun(selectedMode) }
                                .padding(horizontal = 13.dp, vertical = 8.dp)
                        ) {
                            Text("🏃 자유 운동", fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                color = Color(0xFFB6F5D8))
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    // ✅ v77 2행: 공유경로
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(Color(0xFF2A3350))
                                .border(1.dp, Color(0xFF7C93F5), RoundedCornerShape(20.dp))
                                .clickable { onOpenRouteKey() }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text("🔑 공유경로 키 입력", fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                color = Color(0xFFD6DEFF))
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            // 자주 가는 곳 + 최근 목적지: 지도 위 얇은 칩 (지도가 밀리거나 잘리지 않음)
            val frequentPlaces = remember { com.navifit.navigation.SearchHistoryManager.topFrequent(context) }
            val recentPlaces = remember {
                com.navifit.navigation.SearchHistoryManager.loadAll(context)
                    .sortedByDescending { it.lastUsedAt }.take(5)
            }
            val ctxFav = context
            var favorites by remember { mutableStateOf(com.navifit.navigation.FavoritePlaces.all(ctxFav)) }

            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                // 집/회사 즐겨찾기
                items(listOf("home" to ("🏠" to "집"), "work" to ("🏢" to "회사"))) { (id, pair) ->
                    val (icon, label) = pair
                    val fav = favorites.firstOrNull { it.id == id }
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xE6262A3C))
                            .clickable {
                                if (fav != null) {
                                    destName = fav.name; destLat = fav.lat; destLng = fav.lng; destAddress = fav.name
                                    onSearchDestination(fav.name, fav.lat, fav.lng, selectedMode)
                                } else if (destLat != null && destLng != null) {
                                    // ✅ v83 강제 언랩 제거
                                    val fLat = destLat ?: 0.0; val fLng = destLng ?: 0.0
                                    com.navifit.navigation.FavoritePlaces.save(
                                        ctxFav,
                                        com.navifit.navigation.FavoritePlaces.Favorite(
                                            id = id, label = label, icon = icon,
                                            name = (destName ?: "").ifBlank { "저장한 장소" },
                                            lat = fLat, lng = fLng
                                        )
                                    )
                                    favorites = com.navifit.navigation.FavoritePlaces.all(ctxFav)
                                    android.widget.Toast.makeText(ctxFav, "$label(으)로 등록했어요", android.widget.Toast.LENGTH_SHORT).show()
                                } else {
                                    // ✅ v67 등록할 목적지가 없을 때 안내 (기존엔 아무 반응 없어 버튼이 고장난 줄 알았음)
                                    android.widget.Toast.makeText(ctxFav,
                                        "먼저 위에서 장소를 검색해 목적지를 선택한 뒤 $label 등록을 누르세요",
                                        android.widget.Toast.LENGTH_LONG).show()
                                }
                            }
                            .padding(horizontal = 11.dp, vertical = 7.dp)
                    ) {
                        Text(if (fav != null) "$icon $label" else "$icon $label 등록",
                            fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFECEDF4))
                    }
                }
                items(frequentPlaces) { place ->
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xE62A3350))
                            .clickable {
                                destName = place.name; destLat = place.lat; destLng = place.lng; destAddress = place.address
                                onSearchDestination(place.name, place.lat, place.lng, selectedMode)
                            }
                            .padding(horizontal = 11.dp, vertical = 7.dp)
                    ) { Text("⭐ ${place.name}", fontSize = 11.sp, fontWeight = FontWeight.Bold,
                        color = Color(0xFFD6DEFF), maxLines = 1) }
                }
                items(recentPlaces) { place ->
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xE6262A3C))
                            .clickable {
                                destName = place.name; destLat = place.lat; destLng = place.lng; destAddress = place.address
                                onSearchDestination(place.name, place.lat, place.lng, selectedMode)
                            }
                            .padding(horizontal = 11.dp, vertical = 7.dp)
                    ) { Text("🕐 ${place.name}", fontSize = 11.sp, color = Color(0xFFAAB0C4), maxLines = 1) }
                }
            }
        }

        // ── 우측 지도 컨트롤: ＋/− 줌 + 내 위치 ──
        Column(
            Modifier.align(Alignment.CenterEnd).padding(end = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(shape = RoundedCornerShape(14.dp), color = Color(0xF21B1E2C), shadowElevation = 6.dp) {
                Column {
                    Text("＋", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFFECEDF4),
                        modifier = Modifier
                            .clickable { scope.launch { cameraPositionState.animate(CameraUpdateFactory.zoomIn(), 200) } }
                            .padding(horizontal = 14.dp, vertical = 8.dp))
                    HorizontalDivider(color = Color(0xFF2C3145), thickness = 1.dp,
                        modifier = Modifier.width(34.dp).align(Alignment.CenterHorizontally))
                    Text("−", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFFECEDF4),
                        modifier = Modifier
                            .clickable { scope.launch { cameraPositionState.animate(CameraUpdateFactory.zoomOut(), 200) } }
                            .padding(horizontal = 14.dp, vertical = 8.dp))
                }
            }
            Spacer(Modifier.height(10.dp))
            Surface(shape = CircleShape, color = Color(0xF21B1E2C), shadowElevation = 6.dp,
                modifier = Modifier.size(46.dp).clickable { moveToMyLocation() }) {
                Box(contentAlignment = Alignment.Center) {
                    if (locating) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color(0xFF7C93F5))
                    else Text("🎯", fontSize = 18.sp)
                }
            }
        }

        if (!hasLocationPermission) {
            Text(tr("위치 권한이 없어 내 위치를 표시할 수 없어요"),
                fontSize = 10.sp, color = Color.White,
                modifier = Modifier.align(Alignment.Center)
                    .background(Color(0xAA000000), RoundedCornerShape(10.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp))
        }

        // ── 하단 오버레이: 목적지 확인 카드 + 큰 길찾기 버튼 (반투명, 버튼 잘림 없음) ──
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .padding(horizontal = 12.dp)
                .navigationBarsPadding().padding(bottom = 10.dp)
        ) {
            if (destName != null) {
                Surface(
                    shape = RoundedCornerShape(20.dp), color = Color(0xF01B1E2C),
                    shadowElevation = 10.dp, modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.Top) {
                            Text("📍", fontSize = 20.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(destName ?: "", fontWeight = FontWeight.ExtraBold,
                                    fontSize = 17.sp, color = Color(0xFFECEDF4))
                                Spacer(Modifier.height(2.dp))
                                if (reverseGeocoding) {
                                    Text(tr("상세주소 확인 중..."), fontSize = 11.sp, color = Color.Gray)
                                } else {
                                    val addr = destAddress
                                    if (!addr.isNullOrBlank())
                                        Text(addr, fontSize = 12.sp, color = Color(0xFF9AA0B4), lineHeight = 16.sp)
                                }
                            }
                            // 목적지 취소
                            Text("✕", fontSize = 14.sp, color = Color(0xFF6B7188),
                                modifier = Modifier
                                    .clickable { destName = null; destLat = null; destLng = null; destAddress = null }
                                    .padding(4.dp))
                        }
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = {
                                // ✅ v83 강제 언랩 제거 (안내 시작 시 앱이 꺼지던 위험 제거)
                                val n = destName; val la = destLat; val ln = destLng
                                if (!n.isNullOrBlank() && la != null && ln != null) {
                                    onSearchDestination(n, la, ln, selectedMode)
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedMode == TravelMode.WALK) Color(0xFF34C77B) else Color(0xFF7C93F5))
                        ) {
                            Text(
                                if (selectedMode == TravelMode.WALK) "🏃 달리기 경로 찾기" else "🚴 자전거 경로 찾기",
                                fontWeight = FontWeight.ExtraBold, fontSize = 16.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
