package com.navifit.auth

import android.content.Context
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await

data class UserProfile(
    val uid: String,
    val nickname: String,
    val isAnonymous: Boolean,
    val googleEmail: String? = null
)

/**
 * 유저 프로필 저장/복원.
 * - Firestore users/{uid} 문서에 저장 -> 로그아웃 후 같은 구글 계정으로 다시 로그인하면 그대로 복원됨
 * - 로컬(SharedPreferences)에도 캐시 -> 오프라인에서도 닉네임 유지
 */
class UserProfileRepository(context: Context) {

    private val prefs = context.getSharedPreferences("user_profile", Context.MODE_PRIVATE)
    private val db get() = FirebaseFirestore.getInstance()

    suspend fun save(profile: UserProfile) {
        // 로컬 캐시 (즉시)
        prefs.edit()
            .putString("nickname_${profile.uid}", profile.nickname)
            .putBoolean("anon_${profile.uid}", profile.isAnonymous)
            .putString("email_${profile.uid}", profile.googleEmail)
            .apply()
        // 서버 저장 (실패해도 로컬은 유지 - 다음 기회에 다시 동기화)
        try {
            db.collection("users").document(profile.uid).set(
                mapOf(
                    "nickname" to profile.nickname,
                    "isAnonymous" to profile.isAnonymous,
                    "googleEmail" to profile.googleEmail,
                    "updatedAt" to System.currentTimeMillis()
                ),
                SetOptions.merge()
            ).await()
        } catch (_: Exception) { /* 오프라인 - 로컬 캐시로 동작 */ }
    }

    /**
     * 프로필 복원. 서버 우선, 실패하면 로컬 캐시.
     * 구글 재로그인 시 이 함수 덕분에 이전 닉네임/정보가 살아남.
     */
    suspend fun load(uid: String): UserProfile? {
        try {
            val snap = db.collection("users").document(uid).get().await()
            if (snap.exists()) {
                val nickname = snap.getString("nickname")
                if (!nickname.isNullOrBlank()) {
                    return UserProfile(
                        uid = uid,
                        nickname = nickname,
                        isAnonymous = snap.getBoolean("isAnonymous") ?: false,
                        googleEmail = snap.getString("googleEmail")
                    )
                }
            }
        } catch (_: Exception) { /* 서버 실패 -> 로컬 캐시로 */ }

        val cached = prefs.getString("nickname_$uid", null) ?: return null
        return UserProfile(
            uid = uid,
            nickname = cached,
            isAnonymous = prefs.getBoolean("anon_$uid", true),
            googleEmail = prefs.getString("email_$uid", null)
        )
    }
}
