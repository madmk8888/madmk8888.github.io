package com.navifit.ui.map

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import com.navifit.gacha.BgStyle
import com.navifit.gacha.MarkerColor
import com.navifit.gacha.SymbolId

/**
 * 마커 심볼(12+6종)과 등급별 배경을 Canvas에 직접 그리는 렌더러 (이모지 대체, v26).
 * 좌표계는 34x34 기준 벡터를 그대로 옮겨, (cx,cy) 중심에 size 크기로 스케일해서 그림.
 */
object MarkerSymbolRenderer {

    /** 원형 배경을 등급 스타일대로 채운다. rotation은 홀로/레전더리 흐름·스파클 각도. */
    fun drawBackground(canvas: Canvas, color: MarkerColor?, cx: Float, cy: Float, r: Float, rotationDegrees: Float) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val stops = color?.stops ?: emptyList()
        when (color?.bgStyle) {
            null, BgStyle.SOLID -> {
                paint.color = parse(color?.hex ?: "#8B9FFF")
            }
            BgStyle.MATTE_GRAD -> {
                val cs = colorInts(stops, intArrayOf(0xFF7FD4FF.toInt(), 0xFF1F5FD0.toInt()))
                paint.shader = LinearGradient(cx, cy - r, cx, cy + r, cs, null, Shader.TileMode.CLAMP)
            }
            BgStyle.EPIC_ORB -> {
                val cs = colorInts(stops, intArrayOf(0xFFD5ECFF.toInt(), 0xFF2F7FFF.toInt(), 0xFF123A8F.toInt()))
                paint.shader = RadialGradient(cx - r * 0.32f, cy - r * 0.35f, r * 1.4f, cs, floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
            }
            BgStyle.HOLO_FLOW -> {
                val cs = holoInts(color)
                // 흐름: rotation에 따라 그라데이션 시작점을 좌우로 밀어 흐르는 느낌
                val shift = ((rotationDegrees / 360f) % 1f) * r * 2
                paint.shader = LinearGradient(cx - r * 2 + shift, cy, cx + r * 2 + shift, cy, cs, null, Shader.TileMode.MIRROR)
            }
            BgStyle.LEGENDARY -> {
                val cs = holoInts(color)
                paint.shader = SweepLike(cx, cy, cs)
            }
        }
        canvas.drawCircle(cx, cy, r, paint)

        // 유니크/레전더리: 광택 스윕 + 스파클
        if (color?.bgStyle == BgStyle.HOLO_FLOW || color?.bgStyle == BgStyle.LEGENDARY) {
            drawGlossSweep(canvas, cx, cy, r, rotationDegrees)
        }
        if (color?.bgStyle == BgStyle.LEGENDARY) {
            drawSparkles(canvas, cx, cy, r, rotationDegrees)
        }
    }

    private fun SweepLike(cx: Float, cy: Float, cs: IntArray): Shader =
        android.graphics.SweepGradient(cx, cy, cs, null)

    private fun drawGlossSweep(canvas: Canvas, cx: Float, cy: Float, r: Float, rot: Float) {
        val t = ((rot / 360f * 1.6f) % 1f)
        val x = cx - r + t * r * 2
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(x - r * 0.3f, cy, x + r * 0.3f, cy,
            intArrayOf(Color.TRANSPARENT, 0x88FFFFFF.toInt(), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        val save = canvas.save()
        val clip = Path().apply { addCircle(cx, cy, r, Path.Direction.CW) }
        canvas.clipPath(clip)
        canvas.drawCircle(cx, cy, r, p)
        canvas.restoreToCount(save)
    }

    private fun drawSparkles(canvas: Canvas, cx: Float, cy: Float, r: Float, rot: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; textSize = r * 0.34f }
        listOf(0f, 130f, 250f).forEachIndexed { i, base ->
            val ph = Math.toRadians((rot * 2 + i * 120).toDouble())
            val a = (128 + 127 * Math.sin(ph)).toInt().coerceIn(30, 255)
            p.alpha = a
            val ang = Math.toRadians((base + i * 20).toDouble())
            val px = cx + Math.cos(ang).toFloat() * r * 0.62f
            val py = cy + Math.sin(ang).toFloat() * r * 0.62f - r * 0.1f
            canvas.drawText("✦", px, py, p)
        }
    }

    /** 중심(cx,cy)에 size(=지름) 크기로 심볼을 그린다. */
    fun drawSymbol(canvas: Canvas, symbol: SymbolId?, cx: Float, cy: Float, size: Float) {
        if (symbol == null) { drawPin(canvas, cx, cy, size); return }
        val s = size / 34f // 34x34 기준 벡터 → 실제 크기 스케일
        val ox = cx - 17f * s
        val oy = cy - 17f * s
        fun x(v: Float) = ox + v * s
        fun y(v: Float) = oy + v * s
        fun fill(hex: String) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = parse(hex); style = Paint.Style.FILL }
        fun stroke(hex: String, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = parse(hex); style = Paint.Style.STROKE; strokeWidth = w * s; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
        fun vgrad(x0: Float, y0: Float, x1: Float, y1: Float, vararg cols: String) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(x(x0), y(y0), x(x1), y(y1), colorInts(cols.toList(), intArrayOf(Color.WHITE, Color.GRAY)), null, Shader.TileMode.CLAMP)
        }
        fun p(block: Path.() -> Unit) = Path().apply(block)
        fun moveL(path: Path, pts: List<Pair<Float, Float>>) {
            pts.forEachIndexed { i, (px, py) -> if (i == 0) path.moveTo(x(px), y(py)) else path.lineTo(x(px), y(py)) }
            path.close()
        }

        when (symbol) {
            SymbolId.LIGHTNING -> {
                val path = p { moveTo(x(20f), y(2f)); lineTo(x(8f), y(19f)); lineTo(x(14f), y(19f)); lineTo(x(12f), y(32f)); lineTo(x(26f), y(13f)); lineTo(x(19f), y(13f)); close() }
                canvas.drawPath(path, vgrad(0f, 2f, 0f, 32f, "#FFFDE7", "#FFD93B", "#E8960C"))
                canvas.drawPath(path, stroke("#A86E00", 0.9f))
            }
            SymbolId.STAR -> {
                val path = starPath(::x, ::y)
                canvas.drawPath(path, vgrad(0f, 2f, 0f, 26f, "#FFFBE0", "#FFD21E", "#D19000"))
                canvas.drawPath(path, stroke("#B8860B", 1f))
            }
            SymbolId.BLOSSOM -> {
                val pt = fill("#FFB3D1")
                for (i in 0 until 5) {
                    val ang = Math.toRadians((i * 72 - 90).toDouble())
                    val pxc = 17f + Math.cos(ang).toFloat() * 8f
                    val pyc = 17f + Math.sin(ang).toFloat() * 8f
                    canvas.drawCircle(x(pxc), y(pyc), 5f * s, pt)
                }
                canvas.drawCircle(x(17f), y(17f), 3.4f * s, fill("#FFE06B"))
            }
            SymbolId.CLOVER -> {
                val pt = fill("#4BBF5E")
                for (i in 0 until 4) {
                    val ang = Math.toRadians((i * 90 - 45).toDouble())
                    val pxc = 17f + Math.cos(ang).toFloat() * 7f
                    val pyc = 15f + Math.sin(ang).toFloat() * 7f
                    canvas.drawCircle(x(pxc), y(pyc), 5.5f * s, pt)
                }
                canvas.drawLine(x(17f), y(16f), x(20f), y(30f), stroke("#1A7A33", 1.8f))
                canvas.drawCircle(x(17f), y(16f), 1.6f * s, fill("#FFE06B"))
            }
            SymbolId.MOON -> {
                // 초승달: 바깥원 Path에서 안쪽원 Path를 빼서(Op.DIFFERENCE) 그림 (CLEAR는 배경까지 지워서 사용 안 함)
                val outer = Path().apply { addCircle(x(16.4f), y(16.4f), 13.4f * s, Path.Direction.CW) }
                val cut = Path().apply { addCircle(x(21.5f), y(13f), 11f * s, Path.Direction.CW) }
                val crescent = Path()
                crescent.op(outer, cut, Path.Op.DIFFERENCE)
                canvas.drawPath(crescent, vgrad(0f, 3f, 0f, 30f, "#FFFBE0", "#FFE06B", "#E0A800"))
                canvas.drawPath(crescent, stroke("#B8860B", 0.8f))
                // 별
                canvas.drawCircle(x(25.5f), y(9f), 1.6f * s, fill("#FFFFFF"))
            }
            SymbolId.SNOW -> {
                val st = stroke("#9FD9F5", 2.2f)
                val cxp = 17f; val cyp = 17f
                for (i in 0 until 6) {
                    val ang = Math.toRadians((i * 60).toDouble())
                    val ex = cxp + Math.cos(ang).toFloat() * 13f
                    val ey = cyp + Math.sin(ang).toFloat() * 13f
                    canvas.drawLine(x(cxp), y(cyp), x(ex), y(ey), st)
                    // 잔가지
                    val mx = cxp + Math.cos(ang).toFloat() * 8f
                    val my = cyp + Math.sin(ang).toFloat() * 8f
                    val a1 = ang + 0.5; val a2 = ang - 0.5
                    canvas.drawLine(x(mx), y(my), x(mx + Math.cos(a1).toFloat() * 3.5f), y(my + Math.sin(a1).toFloat() * 3.5f), st)
                    canvas.drawLine(x(mx), y(my), x(mx + Math.cos(a2).toFloat() * 3.5f), y(my + Math.sin(a2).toFloat() * 3.5f), st)
                }
                canvas.drawCircle(x(17f), y(17f), 3.4f * s, fill("#FFFFFF"))
            }
            SymbolId.GEM -> {
                val path = p { moveTo(x(9f), y(7f)); lineTo(x(25f), y(7f)); lineTo(x(31f), y(15f)); lineTo(x(17f), y(30f)); lineTo(x(3f), y(15f)); close() }
                canvas.drawPath(path, vgrad(0f, 7f, 0f, 30f, "#EAFCFF", "#6FD8F0", "#1489B8"))
                canvas.drawPath(path, stroke("#0D6A8F", 1f))
                canvas.drawLine(x(3f), y(15f), x(31f), y(15f), stroke("#0D6A8F", 0.8f))
                canvas.drawLine(x(9f), y(7f), x(17f), y(30f), stroke("#0D6A8F", 0.8f))
                canvas.drawLine(x(25f), y(7f), x(17f), y(30f), stroke("#0D6A8F", 0.8f))
            }
            SymbolId.HEARTGEM -> {
                val path = heartPath(::x, ::y)
                canvas.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = RadialGradient(x(13f), y(11f), 20f * s, colorInts(listOf("#FFE3EF", "#FF7EB3", "#D0326E"), intArrayOf()), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
                })
                canvas.drawPath(path, stroke("#B02258", 1f))
            }
            SymbolId.FLAME -> {
                val path = p {
                    moveTo(x(18.5f), y(2f))
                    cubicTo(x(16f), y(5.5f), x(20.5f), y(7.5f), x(21.8f), y(10.6f))
                    cubicTo(x(24.4f), y(12.8f), x(25.5f), y(15f), x(25.5f), y(18f))
                    cubicTo(x(25.5f), y(22.7f), x(21.7f), y(26.5f), x(17f), y(26.5f))
                    cubicTo(x(12.3f), y(26.5f), x(8.5f), y(22.7f), x(8.5f), y(18f))
                    cubicTo(x(8.5f), y(14.4f), x(10.5f), y(12.4f), x(11.7f), y(9.4f))
                    cubicTo(x(12.7f), y(11.6f), x(14.7f), y(13f), x(15.5f), y(13.6f))
                    cubicTo(x(14.4f), y(10f), x(13f), y(5.8f), x(18.5f), y(2f))
                    close()
                }
                canvas.drawPath(path, vgrad(0f, 2f, 0f, 26f, "#FFB45C", "#FF6A1F", "#C21807"))
                canvas.drawPath(path, stroke("#8F1500", 0.9f))
                // 안쪽 흰 코어
                val inner = p {
                    moveTo(x(17.2f), y(16f)); cubicTo(x(16.6f), y(17.6f), x(18f), y(18.3f), x(18.4f), y(19.4f))
                    cubicTo(x(18.9f), y(21f), x(17.9f), y(22.5f), x(16f), y(22.5f))
                    cubicTo(x(14.3f), y(22.5f), x(13.4f), y(21f), x(13.6f), y(19.4f))
                    cubicTo(x(14f), y(18f), x(16f), y(17.4f), x(17.2f), y(16f)); close()
                }
                canvas.drawPath(inner, fill("#FFFBE6"))
            }
            SymbolId.WING -> {
                val path = p {
                    moveTo(x(30f), y(5f))
                    cubicTo(x(19f), y(3f), x(9f), y(7f), x(5f), y(19f))
                    cubicTo(x(7.4f), y(18f), x(9.4f), y(17.7f), x(11.6f), y(18f))
                    cubicTo(x(10.2f), y(19.6f), x(9.3f), y(21.2f), x(8.8f), y(23.4f))
                    cubicTo(x(11f), y(22.7f), x(13f), y(22.4f), x(15f), y(22.8f))
                    cubicTo(x(14.2f), y(24.3f), x(13.7f), y(25.7f), x(13.5f), y(27.5f))
                    cubicTo(x(24f), y(25f), x(30f), y(17f), x(30f), y(5f))
                    close()
                }
                canvas.drawPath(path, vgrad(0f, 5f, 0f, 27f, "#FFFFFF", "#F3ECDC", "#D9C48F"))
                canvas.drawPath(path, stroke("#B8A35E", 1f))
            }
            SymbolId.ROSE -> {
                canvas.drawCircle(x(17f), y(13f), 10f * s, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = RadialGradient(x(17f), y(13f), 10f * s, colorInts(listOf("#FFB3C8", "#E84D78", "#9E1240"), intArrayOf()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
                })
                canvas.drawCircle(x(17f), y(13f), 10f * s, stroke("#B02258", 1f))
                // 소용돌이
                val sp = stroke("#9E1240", 1.3f)
                val spiral = Path()
                for (i in 0..40) {
                    val t = i / 40f
                    val ang = t * 4 * Math.PI
                    val rad = (1 - t) * 7f
                    val px = 17f + Math.cos(ang).toFloat() * rad
                    val py = 13f + Math.sin(ang).toFloat() * rad
                    if (i == 0) spiral.moveTo(x(px), y(py)) else spiral.lineTo(x(px), y(py))
                }
                canvas.drawPath(spiral, sp)
                // 줄기·잎
                canvas.drawLine(x(17f), y(22.6f), x(17f), y(31f), stroke("#2E7D32", 2f))
            }
            SymbolId.CROWN -> {
                val path = p { moveTo(x(6f), y(25f)); lineTo(x(5f), y(11f)); lineTo(x(11.5f), y(16f)); lineTo(x(17f), y(6f)); lineTo(x(22.5f), y(16f)); lineTo(x(29f), y(11f)); lineTo(x(28f), y(25f)); close() }
                canvas.drawPath(path, vgrad(0f, 6f, 0f, 25f, "#FFF8D0", "#FFD21E", "#C78A00"))
                canvas.drawPath(path, stroke("#8A6400", 1.1f))
                canvas.drawCircle(x(12f), y(21f), 1.7f * s, fill("#E63757"))
                canvas.drawCircle(x(17f), y(20.3f), 1.7f * s, fill("#3F8EFC"))
                canvas.drawCircle(x(22f), y(21f), 1.7f * s, fill("#10B981"))
            }
            // ── 레전더리 전용 ──
            SymbolId.DRAGON -> {
                val path = p {
                    moveTo(x(5f), y(19f)); cubicTo(x(7f), y(11f), x(13f), y(6f), x(22f), y(6f))
                    lineTo(x(19.4f), y(9f)); cubicTo(x(22.4f), y(9f), x(25.4f), y(10.6f), x(27.4f), y(13.6f))
                    lineTo(x(22.8f), y(14.2f)); cubicTo(x(24.4f), y(15.6f), x(25.2f), y(17.2f), x(25.4f), y(19.4f))
                    lineTo(x(21.2f), y(18.2f)); cubicTo(x(21.6f), y(20.4f), x(21.2f), y(22.4f), x(20f), y(24.4f))
                    cubicTo(x(18.4f), y(21.6f), x(16.6f), y(20f), x(14f), y(19.4f))
                    cubicTo(x(15f), y(22f), x(14.6f), y(24.4f), x(13f), y(27f))
                    cubicTo(x(11.6f), y(23.6f), x(9.4f), y(21.4f), x(5f), y(19f)); close()
                }
                canvas.drawPath(path, vgrad(0f, 6f, 34f, 34f, "#B9F6D3", "#2FBF83", "#0F9D63"))
                canvas.drawPath(path, stroke("#0A5C3A", 1.1f))
                canvas.drawCircle(x(20.4f), y(11.6f), 1.6f * s, fill("#141C26"))
            }
            SymbolId.PHOENIX -> {
                val path = p {
                    moveTo(x(17f), y(3f))
                    cubicTo(x(18f), y(6.4f), x(20.4f), y(7.6f), x(23.4f), y(7.8f))
                    cubicTo(x(21.8f), y(9.4f), x(20.2f), y(10.2f), x(18.4f), y(10.4f))
                    cubicTo(x(23.4f), y(11.6f), x(26.8f), y(14.8f), x(28f), y(20.2f))
                    cubicTo(x(25f), y(18.2f), x(22.4f), y(17.4f), x(19.4f), y(17.8f))
                    cubicTo(x(21.2f), y(20.4f), x(21.8f), y(23.2f), x(21.2f), y(26.8f))
                    cubicTo(x(19.2f), y(23.8f), x(17.2f), y(22.2f), x(14.6f), y(21.4f))
                    cubicTo(x(15f), y(24f), x(14.6f), y(26.2f), x(13.2f), y(28.4f))
                    cubicTo(x(12.2f), y(25.4f), x(10.8f), y(23.6f), x(8.4f), y(22.2f))
                    cubicTo(x(6.4f), y(22.6f), x(4.8f), y(23.6f), x(3f), y(25.4f))
                    cubicTo(x(3.6f), y(19.8f), x(6.2f), y(16f), x(11f), y(14f))
                    cubicTo(x(9f), y(13.4f), x(7.4f), y(12.4f), x(6f), y(10.6f))
                    cubicTo(x(9.2f), y(10.2f), x(11.6f), y(9.2f), x(13.4f), y(7.4f))
                    cubicTo(x(14.4f), y(6f), x(15.4f), y(4.6f), x(17f), y(3f)); close()
                }
                canvas.drawPath(path, vgrad(0f, 3f, 0f, 28f, "#FFD600", "#FF7A00", "#E03000"))
                canvas.drawPath(path, stroke("#A3210C", 1f))
            }
            SymbolId.COMET -> {
                // 꼬리
                val tail = p { moveTo(x(3f), y(3f)); lineTo(x(23f), y(20f)); lineTo(x(19.4f), y(23.6f)); close() }
                canvas.drawPath(tail, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = LinearGradient(x(3f), y(3f), x(23f), y(23f), intArrayOf(0x00E0F2FE, 0xB37DD3FC.toInt(), Color.WHITE), null, Shader.TileMode.CLAMP)
                })
                canvas.drawCircle(x(24f), y(24f), 7f * s, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = RadialGradient(x(22f), y(22f), 8f * s, colorInts(listOf("#FFFFFF", "#BFE9FF", "#3F8EFC"), intArrayOf()), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
                })
                canvas.drawCircle(x(24f), y(24f), 7f * s, stroke("#1F5FD0", 1f))
            }
            SymbolId.GODCROWN -> {
                val rays = stroke("#FFE06B", 1.7f)
                canvas.drawLine(x(17f), y(1.4f), x(17f), y(5.4f), rays)
                canvas.drawLine(x(8f), y(3.8f), x(9.8f), y(7.4f), rays)
                canvas.drawLine(x(26f), y(3.8f), x(24.2f), y(7.4f), rays)
                val path = p { moveTo(x(7f), y(27f)); lineTo(x(6f), y(13f)); lineTo(x(12.4f), y(17.6f)); lineTo(x(17f), y(9f)); lineTo(x(21.6f), y(17.6f)); lineTo(x(28f), y(13f)); lineTo(x(27f), y(27f)); close() }
                canvas.drawPath(path, vgrad(0f, 9f, 0f, 27f, "#FFF8D0", "#FFD21E", "#C78A00"))
                canvas.drawPath(path, stroke("#8A6400", 1.2f))
                canvas.drawCircle(x(17f), y(21f), 2.4f * s, fill("#FFFFFF"))
            }
            SymbolId.INFINITY -> {
                val path = p {
                    moveTo(x(17f), y(17f))
                    cubicTo(x(13f), y(11f), x(5f), y(11.4f), x(5f), y(17f))
                    cubicTo(x(5f), y(23f), x(13f), y(23f), x(17f), y(17f))
                    cubicTo(x(21f), y(11f), x(29f), y(11.4f), x(29f), y(17f))
                    cubicTo(x(29f), y(23f), x(21f), y(23f), x(17f), y(17f))
                    close()
                }
                canvas.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE; strokeWidth = 3.6f * s; strokeCap = Paint.Cap.ROUND
                    shader = LinearGradient(x(5f), y(17f), x(29f), y(17f), intArrayOf(0xFFFF3CAC.toInt(), 0xFFFFD700.toInt(), 0xFF5B7FFF.toInt()), null, Shader.TileMode.CLAMP)
                })
            }
            SymbolId.NEONBOLT -> {
                val path = p { moveTo(x(20f), y(2f)); lineTo(x(8f), y(19f)); lineTo(x(14f), y(19f)); lineTo(x(12f), y(32f)); lineTo(x(26f), y(13f)); lineTo(x(19f), y(13f)); close() }
                canvas.drawPath(path, fill("#08222B"))
                canvas.drawPath(path, stroke("#00F5FF", 1.7f))
            }
        }
    }

    private fun starPath(x: (Float) -> Float, y: (Float) -> Float): Path {
        val cx = 17f; val cy = 17f; val outer = 15f; val inner = 6.2f
        val path = Path()
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) outer else inner
            val ang = Math.toRadians((i * 36 - 90).toDouble())
            val px = cx + Math.cos(ang).toFloat() * r
            val py = cy + Math.sin(ang).toFloat() * r
            if (i == 0) path.moveTo(x(px), y(py)) else path.lineTo(x(px), y(py))
        }
        path.close(); return path
    }

    private fun heartPath(x: (Float) -> Float, y: (Float) -> Float): Path = Path().apply {
        moveTo(x(17f), y(29f))
        cubicTo(x(8f), y(22.5f), x(4f), y(17.5f), x(4f), y(12.2f))
        cubicTo(x(4f), y(8f), x(7f), y(5f), x(10.8f), y(5f))
        cubicTo(x(13.5f), y(5f), x(15.8f), y(6.5f), x(17f), y(8.8f))
        cubicTo(x(18.2f), y(6.5f), x(20.5f), y(5f), x(23.2f), y(5f))
        cubicTo(x(27f), y(5f), x(30f), y(8f), x(30f), y(12.2f))
        cubicTo(x(30f), y(17.5f), x(26f), y(22.5f), x(17f), y(29f))
        close()
    }

    private fun drawPin(canvas: Canvas, cx: Float, cy: Float, size: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF8B9FFF.toInt() }
        canvas.drawCircle(cx, cy, size * 0.32f, p)
    }

    private fun holoInts(color: MarkerColor): IntArray {
        if (color.hex == "RAINBOW") return intArrayOf(0xFFFF5F6D.toInt(), 0xFFFFC371.toInt(), 0xFF47E5BC.toInt(), 0xFF5B7FFF.toInt(), 0xFFC471F5.toInt(), 0xFFFF5F6D.toInt())
        val fromStops = colorInts(color.stops, intArrayOf())
        return if (fromStops.size >= 2) fromStops else intArrayOf(parse(color.hex), parse(color.hex))
    }

    private fun colorInts(stops: List<String>, fallback: IntArray): IntArray {
        if (stops.isEmpty()) return fallback
        return stops.map { parse(it) }.toIntArray()
    }

    private fun parse(hex: String): Int = try {
        when (hex) {
            "RAINBOW", "PRISM", "AURORA", "DIAMOND", "GALAXY" -> 0xFFFFFFFF.toInt()
            else -> Color.parseColor(hex)
        }
    } catch (e: Exception) { 0xFF8B9FFF.toInt() }
}
