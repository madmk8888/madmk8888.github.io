package com.navifit.ui.screens

import android.app.Activity
import android.content.res.Configuration
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import com.navifit.i18n.tr
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.*
import com.google.maps.android.compose.*
import com.navifit.gacha.BorderCatalog
import com.navifit.gacha.DrawnMarker
import com.navifit.navigation.*
import com.navifit.tracking.SafetyScoreTracker
import kotlin.math.atan2

/**
 * 통합 내비게이션 화면 (v17 전면 개편).
 *
 * ✅ 가로모드 지원: 가로에선 안내판이 왼쪽 사이드로, 지도가 오른쪽 풀사이즈로
 * ✅ 자동 풀스크린: 주행 중 상태바/내비바 숨김 + 화면 항상 켜짐
 * ✅ 차선 표시등: 다음 안내 방향(좌/우/직진/유턴)에 형광 불이 들어옴
 * ✅ 상세 안내: "300m 앞 우회전 (OO로)" + 남은 거리/시간/진행률 실시간
 * ✅ 내 위치 복귀 버튼: 지도를 딴 데로 옮겨도 🎯 한 번에 복귀 (팔로우 재개)
 * ✅ 형광 진행 표시: 지나온 경로가 형광색으로 칠해짐
 * ✅ 내 위치 = 장착 마커 + 장착 테두리 + 닉네임 티커
 */

/** ✅ v61 화장실 정보 (카카오 로컬 검색 결과) */
data class ToiletInfo(
    val pos: LatLng,
    val name: String,
    val address: String,
    val category: String
)

@Composable
fun NavigationMapScreen(
    mode: TravelMode,
    nickname: String,
    rerouting: Boolean = false,                 // ✅ v56 재탐색 중 배너 표시
    onEmergencyToilet: (LatLng, String) -> Unit = { _, _ -> },   // ✅ v61 긴급 화장실 안내 시작
    isEmergencyDetour: Boolean = false,         // 지금 긴급 안내(화장실 경유) 중인지
    onReturnFromEmergency: () -> Unit = {},     // 원래 운동으로 복귀
    currentLocation: LatLngPoint?,
    plannedRoute: RouteResult?,
    traveledPath: List<LatLngPoint>,
    equippedMarker: DrawnMarker?,
    deviceBearing: Float = 0f,          // ✅ v67 GPS 실시간 진행방향 (heading-up 카메라용)
    equippedBorderKey: String?,
    elapsedSeconds: Long,
    distanceMeters: Double,
    speedKmh: Double,
    safetyTracker: SafetyScoreTracker?,
    onFinish: () -> Unit,
    // ── v27 확장 (전부 기본값 - 기존 호출 호환) ──
    alternativeRoutes: List<RouteResult> = emptyList(),          // 대체경로 (회색 표시, 탭하면 교체)
    onSelectAlternative: (RouteResult) -> Unit = {},
    suggestedRoute: RouteResult? = null,                           // ✅ v32: 더 빠른 길 제안 (연한 파란색, 자동전환 안 함)
    suggestedSavedMinutes: Int = 0,
    trafficSegments: List<Pair<List<LatLngPoint>, com.navifit.navigation.TrafficFlowRepository.Level>> = emptyList(), // ✅ v32 정체 색상
    hazardAlert: com.navifit.safety.HazardAlert? = null,          // 카메라/방지턱 경보 (800m 전~통과)
    isViolationWarning: Boolean = false,                           // 위반 중 - 빨간 프레임 깜빡임
    isGpsEstimating: Boolean = false,                              // 터널 추측항법 중 표시
    gpsAccuracyMeters: Float = 0f,                                 // ✅ v33 GPS 신호 품질 표시
    gpsSatellites: Int = 0,                                        // ✅ v84 측위 사용 위성 개수 (실측)
    elevationGainMeters: Double = 0.0,                             // ✅ v90 누적 상승고도(m)
    roadInfo: com.navifit.navigation.RoadInfoResolver.RoadInfo? = null, // 현재 도로명/번호/고도
    followRouteState: FollowRouteGuide.FollowState? = null,        // 친구 길 따라가기 모드 상태
    approachRoute: RouteResult? = null                              // ✅ 공유경로 따라가기: 현위치→출발점 접근 경로 (파란선)
) {
    val isDrivingMode = !mode.isWorkoutMode
    val seoul = LatLng(37.5665, 126.9780)
    val context = LocalContext.current
    val view = LocalView.current
    val density = LocalDensity.current.density
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    // ===== 자동 풀스크린(몰입 모드) + 화면 항상 켜짐 =====
    DisposableEffect(Unit) {
        val window = (context as? Activity)?.window
        window?.let { w ->
            w.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            val controller = WindowCompat.getInsetsController(w, view)
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        }
        onDispose {
            window?.let { w ->
                w.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                WindowCompat.getInsetsController(w, view).show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    // ✅ 내 위치를 못 찾을 때 대응: 풀스크린 진입 직후 위치 서비스가 아직 첫 fix를 못 받았을 수 있어서
    //    몇 초 이상 위치가 안 잡히면 별도로 즉시 측위를 몇 번 재시도 (놓치지 않도록 보강)
    var fallbackLocation by remember { mutableStateOf<LatLngPoint?>(null) }
    var locatingRetryCount by remember { mutableStateOf(0) }
    val effectiveLocation = currentLocation ?: fallbackLocation
    LaunchedEffect(currentLocation) {
        if (currentLocation != null) { locatingRetryCount = 0; return@LaunchedEffect }
        val fusedClient = com.google.android.gms.location.LocationServices.getFusedLocationProviderClient(context)
        repeat(3) { attempt ->
            kotlinx.coroutines.delay(2500L)
            if (currentLocation != null) return@repeat // 그 사이 정상 측위가 들어왔으면 중단
            try {
                fusedClient.getCurrentLocation(
                    com.google.android.gms.location.Priority.PRIORITY_HIGH_ACCURACY,
                    com.google.android.gms.tasks.CancellationTokenSource().token
                ).addOnSuccessListener { loc ->
                    loc?.let { fallbackLocation = LatLngPoint(it.latitude, it.longitude) }
                }
            } catch (_: SecurityException) {}
            locatingRetryCount = attempt + 1
        }
    }

    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(
            effectiveLocation?.let { LatLng(it.latitude, it.longitude) } ?: seoul,
            if (isDrivingMode) 18f else 16f
        )
    }
    val overviewCameraState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(seoul, 13f)
    }

    // ===== 팔로우 모드: 손으로 지도를 움직이면 잠시 해제 =====
    var followMe by remember { mutableStateOf(true) }
    LaunchedEffect(cameraPositionState.isMoving) {
        if (cameraPositionState.isMoving &&
            cameraPositionState.cameraMoveStartedReason == CameraMoveStartedReason.GESTURE
        ) followMe = false
    }

    // ✅ v81 방위 산출 전면 개편 — 나침반(ROTATION_VECTOR) + GPS 진행방향 융합
    //   · 3km/h 이상 이동 중: GPS bearing이 정확 → 우선 사용
    //   · 정지/저속: 나침반 방위 사용 (GPS bearing이 튀는 구간)
    //   · 둘 다 없으면 궤적 기반 폴백
    val compass = remember { com.navifit.tracking.CompassProvider(context) }
    DisposableEffect(Unit) {
        compass.start()
        onDispose { compass.stop() }
    }
    var compassHeading by remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(120)
            compassHeading = compass.headingDegrees
        }
    }
    val bearing = remember(deviceBearing, compassHeading, speedKmh, traveledPath.size) {
        when {
            speedKmh >= 3.0 && deviceBearing != 0f -> deviceBearing
            compass.available -> compassHeading
            traveledPath.size >= 2 ->
                computeBearing(traveledPath[traveledPath.size - 2], traveledPath[traveledPath.size - 1])
            else -> 0f
        }
    }

    // ===== 경로 포인트 & 실시간 진행 계산 =====
    val routePoints = remember(plannedRoute) {
        plannedRoute?.let { decodePolyline(it.overviewPolyline) } ?: emptyList()
    }
    val progress = remember(effectiveLocation, routePoints) {
        if (effectiveLocation != null && plannedRoute != null && routePoints.isNotEmpty()) {
            NavigationProgressCalculator.compute(
                routePoints, plannedRoute.steps,
                plannedRoute.totalDistanceMeters, plannedRoute.totalDurationSeconds,
                effectiveLocation,
                offRouteThresholdMeters = if (mode.isWorkoutMode) 40.0 else 55.0
            )
        } else null
    }
    // ✅ v31 맵매칭: 경로 위에 있을 땐 마커·카메라가 도로선을 정확히 타고 감 (시중 내비처럼)
    val displayLocation = progress?.snappedLocation ?: effectiveLocation
    // ✅ 이탈 배너 오탐 방지: 순간 GPS 튐이 아니라 5초 이상 + 60m 이상 벗어났을 때만 배너 표시
    var offBannerStreak by remember { mutableStateOf(0) }
    LaunchedEffect(progress?.isOffRoute, progress?.distanceFromRouteMeters) {
        val pg = progress
        offBannerStreak = if (pg?.isOffRoute == true && pg.distanceFromRouteMeters > 60) offBannerStreak + 1 else 0
    }
    val showOffRouteBanner = offBannerStreak >= 5


    // ✅ v38 안내 중 화면 꺼짐 방지 (내비인데 화면이 꺼져버리는 치명적 누락이었음)
    // ✅ v41 선택 언어
    val navCtx = androidx.compose.ui.platform.LocalContext.current
    val navLang = com.navifit.i18n.LanguageStore.current(navCtx).code
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    // ✅ v38 야간 모드: 해 진 뒤엔 지도를 어둡게 (눈부심 방지 - 시중 내비 기본 기능)
    val isNight = remember {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        h >= 19 || h < 6
    }

    // ✅ v27 자동 확대: 다음 회전 300m 이내 접근 -> 교차로 상세 줌(18.7)로 자동 확대,
    //    직진 구간으로 돌아오면 사용자가 정한 기본 줌으로 복귀 (줌 버튼으로 축척 조절 가능)
    var userBaseZoom by remember { mutableStateOf(NavSettings.baseZoom(context)) }
    val scope = rememberCoroutineScope()   // ✅ 줌 버튼 카메라 애니메이션용

    // ✅ v61 화장실 상시 표시: 카카오 로컬 검색(무료)으로 반경 2km 화장실을 지도에 마커로.
    //    남/녀 아이콘(빨강·파랑) 커스텀 마커, 탭하면 이름·건물·주소 + [긴급 안내] 제공.
    //    운동 모드가 아니어도(주행 포함) 항상 표시. 400m 이동 시 자동 갱신.
    var toiletMarkers by remember { mutableStateOf<List<ToiletInfo>>(emptyList()) }
    var lastToiletFetchAt by remember { mutableStateOf<LatLngPoint?>(null) }
    LaunchedEffect(currentLocation) {
        val loc = currentLocation ?: return@LaunchedEffect
        val prev = lastToiletFetchAt
        if (prev != null && NavigationProgressCalculator.fastDistanceMeters(prev, loc) < 400) return@LaunchedEffect
        lastToiletFetchAt = loc
        val key = com.navifit.navigation.NavApiKeys.kakaoRestKey(context) ?: return@LaunchedEffect
        toiletMarkers = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            // ✅ v81 화장실이 2개만 나오던 문제 개조:
            //   ① 키워드를 여러 개로 확장 (공중/개방 화장실 + 실제로 화장실을 쓸 수 있는 공공장소)
            //   ② 반경 2km → 3km, 각 키워드당 15건 → 합쳐서 최대 60건
            //   ③ 좌표 중복 제거 후 가까운 순 정렬
            val client = okhttp3.OkHttpClient.Builder()
                .connectTimeout(6, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(6, java.util.concurrent.TimeUnit.SECONDS).build()
            val keywords = listOf(
                "화장실", "공중화장실", "개방화장실",
                "공원", "지하철역", "주민센터", "공공도서관"
            )
            val collected = LinkedHashMap<String, ToiletInfo>()
            for (kw in keywords) {
                try {
                    val url = "https://dapi.kakao.com/v2/local/search/keyword.json" +
                        "?query=" + java.net.URLEncoder.encode(kw, "UTF-8") +
                        "&x=${loc.longitude}&y=${loc.latitude}&radius=3000&size=15&sort=distance"
                    val res = client.newCall(
                        okhttp3.Request.Builder().url(url).addHeader("Authorization", "KakaoAK $key").build()
                    ).execute()
                    val body = res.body?.string() ?: continue
                    val docs = org.json.JSONObject(body).optJSONArray("documents") ?: continue
                    for (i in 0 until docs.length()) {
                        val d = docs.optJSONObject(i) ?: continue
                        val lat = d.optString("y").toDoubleOrNull() ?: continue
                        val lng = d.optString("x").toDoubleOrNull() ?: continue
                        val dedupKey = "%.5f_%.5f".format(lat, lng)
                        if (collected.containsKey(dedupKey)) continue
                        val placeName = d.optString("place_name", kw)
                        // 화장실 직접 검색이 아닌 공공장소는 "(화장실 이용 가능)" 표기
                        val isDirectToilet = kw.contains("화장실") || placeName.contains("화장실")
                        collected[dedupKey] = ToiletInfo(
                            pos = LatLng(lat, lng),
                            name = if (isDirectToilet) placeName else "$placeName (화장실 이용 가능)",
                            address = d.optString("road_address_name", "").ifBlank { d.optString("address_name", "") },
                            category = d.optString("category_name", "")
                        )
                    }
                } catch (_: Exception) { /* 키워드 하나 실패해도 나머지는 계속 */ }
                if (collected.size >= 60) break
            }
            collected.values.sortedBy {
                NavigationProgressCalculator.fastDistanceMeters(
                    loc, LatLngPoint(it.pos.latitude, it.pos.longitude))
            }
        }
    }
    // 선택된 화장실(정보창 표시용)
    var selectedToilet by remember { mutableStateOf<ToiletInfo?>(null) }
    // 화장실 커스텀 마커 아이콘 (남/녀 상징 색 - 파랑/빨강 조합, HUE_ROSE로 눈에 띄게)
    val toiletMarkerIcon = remember { BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ROSE) }
    val autoZoomOn = NavSettings.autoZoomEnabled(context)   // ✅ v43 설정 변경 즉시 반영 (기존엔 앱 재시작해야 적용됐음)
    // ✅ v43 히스테리시스: 300m 경계에서 299m/301m를 오가면 줌이 확대/축소를 반복해 깜빡였음.
    //    → 300m 이내로 들어오면 확대, 380m 밖으로 나가야 축소 (한 번 확대되면 쉽게 안 풀림)
    var approachingTurn by remember { mutableStateOf(false) }
    LaunchedEffect(progress?.distanceToNextTurnMeters, progress?.laneDirection) {
        val d = progress?.distanceToNextTurnMeters ?: return@LaunchedEffect
        val isTurn = progress.laneDirection != LaneDirection.STRAIGHT
        approachingTurn = when {
            !isTurn -> false
            d in 1..300 -> true
            d > 380 -> false
            else -> approachingTurn   // 300~380m 사이는 현재 상태 유지
        }
    }

    // ✅ v43 카메라 덜컥임 수정 (내비가 "이상하게" 보이던 주원인):
    //    기존엔 애니메이션이 1.4초인데 GPS는 1~2초마다 들어와서, 애니메이션이 끝나기 전에
    //    LaunchedEffect가 취소·재시작되며 지도가 계속 튀었음.
    //    → 애니메이션 시간을 갱신 주기보다 짧게(600ms) 줄여서 매번 부드럽게 완료되게 함.
    //    또 방위각이 3도 미만으로 미세하게 떨릴 때는 회전을 갱신하지 않아 화면 흔들림 제거.
    // ✅ v81 지도 방향 정렬 전면 재구성
    //   · 달리기(WALK): 항상 북쪽이 위 (bearing 0 고정). 사용자가 손으로 돌린 경우만 예외.
    //   · 자전거/오토바이/자동차: 진행방향이 화면 위로 (자동차 내비처럼 heading-up).
    //   · 각도는 최단 회전 경로로 지수평활해서 359°→1° 구간에서도 부드럽게 돈다.
    val headingUpMode = mode == TravelMode.BIKE || isDrivingMode
    var smoothedBearing by remember { mutableStateOf(0f) }
    LaunchedEffect(bearing, headingUpMode) {
        if (!headingUpMode) { smoothedBearing = 0f; return@LaunchedEffect }
        // 최단 회전 방향으로 부드럽게 (급회전 시 화면이 홱 돌지 않게)
        val delta = com.navifit.tracking.CompassProvider.angleDelta(smoothedBearing, bearing)
        if (delta >= 2f) {
            smoothedBearing = com.navifit.tracking.CompassProvider.emaAngle(smoothedBearing, bearing, 0.5f)
        }
    }
    LaunchedEffect(displayLocation, smoothedBearing, followMe, approachingTurn, userBaseZoom, headingUpMode) {
        if (!followMe) return@LaunchedEffect
        displayLocation?.let {
            val target = LatLng(it.latitude, it.longitude)
            if (headingUpMode) {
                val zoom = if (autoZoomOn && approachingTurn) 18.7f else userBaseZoom
                val tilt = when {
                    autoZoomOn && approachingTurn -> 45f
                    isDrivingMode -> 50f
                    else -> 40f   // 자전거
                }
                cameraPositionState.animate(
                    CameraUpdateFactory.newCameraPosition(
                        CameraPosition.Builder().target(target).zoom(zoom).tilt(tilt)
                            .bearing(smoothedBearing).build()
                    ), 800
                )
            } else {
                // 달리기: 북쪽 고정 — 위치만 따라가고 회전/기울기는 0으로 확실히 리셋
                cameraPositionState.animate(
                    CameraUpdateFactory.newCameraPosition(
                        CameraPosition.Builder().target(target).zoom(userBaseZoom)
                            .tilt(0f).bearing(0f).build()
                    ), 800
                )
            }
        }
    }
    LaunchedEffect(plannedRoute) {
        if (routePoints.isNotEmpty()) {
            val bounds = LatLngBounds.builder()
                .apply { routePoints.forEach { p -> include(LatLng(p.latitude, p.longitude)) } }.build()
            try { overviewCameraState.move(CameraUpdateFactory.newLatLngBounds(bounds, 40)) } catch (_: Exception) {}
        }
    }

    // 내 위치 커스텀 마커 (닉네임 티커 + 장착 테두리)
    val equippedBorderDef = remember(equippedBorderKey) { BorderCatalog.all.find { it.key == equippedBorderKey } }

    // ✅ 애니메이션 테두리(회전+반짝임) 또는 에픽 이상 마커(티커 반짝임/움직임)를 장착 중이면
    //    주기적으로 애니메이션 값을 갱신해서 마커 비트맵을 다시 그림
    //    (일반/레어 마커 + 일반 테두리는 굳이 매번 다시 그릴 필요 없어서 배터리 절약을 위해 고정 유지)
    var ringRotation by remember { mutableStateOf(0f) }
    val markerTierOrdinal = equippedMarker?.effectiveTierOrdinal ?: -1
    val needsAnimation = equippedBorderDef?.isAnimated == true || markerTierOrdinal >= 2
    LaunchedEffect(needsAnimation) {
        if (needsAnimation) {
            while (true) {
                ringRotation = (ringRotation + 6f) % 360f
                kotlinx.coroutines.delay(120)
            }
        }
    }

    val myMarkerIcon = remember(nickname, equippedMarker, equippedBorderDef, ringRotation) {
        com.navifit.ui.map.MyLocationMarkerFactory.build(
            nickname = nickname,
            marker = equippedMarker,
            border = equippedBorderDef,
            density = density,
            rotationDegrees = ringRotation
        )
    }
    val myMarkerState = remember { MarkerState(displayLocation?.let { LatLng(it.latitude, it.longitude) } ?: seoul) }
    // ✅ 부드러운 실시간 추적: GPS가 1초에 한 번 튀듯 갱신돼 마커가 깜빡이며 순간이동하던 문제
    //    → 이전 위치에서 새 위치까지 0.9초 동안 30단계로 보간(lerp)해 미끄러지듯 따라감
    LaunchedEffect(displayLocation) {
        val target = displayLocation ?: return@LaunchedEffect
        val from = myMarkerState.position
        val to = LatLng(target.latitude, target.longitude)
        val jump = NavigationProgressCalculator.fastDistanceMeters(
            LatLngPoint(from.latitude, from.longitude), target)
        if (jump > 150.0 || jump < 0.3) { myMarkerState.position = to; return@LaunchedEffect }
        val steps = 30
        repeat(steps) { i ->
            val t = (i + 1) / steps.toFloat()
            // ease-out: 시작은 빠르게, 끝은 부드럽게
            val e = 1f - (1f - t) * (1f - t)
            myMarkerState.position = LatLng(
                from.latitude + (to.latitude - from.latitude) * e,
                from.longitude + (to.longitude - from.longitude) * e
            )
            kotlinx.coroutines.delay(30)
        }
    }

    // ===== 지도 콘텐츠 (세로/가로 공용) =====
    val mapContent: @Composable () -> Unit = {
        Box(Modifier.fillMaxSize()) {
            GoogleMap(
                modifier = Modifier.fillMaxSize(),
                cameraPositionState = cameraPositionState,
                properties = MapProperties(
                    mapStyleOptions = if (isNight)
                        com.google.android.gms.maps.model.MapStyleOptions(NIGHT_MAP_STYLE) else null,isMyLocationEnabled = false),
                uiSettings = MapUiSettings(
                    zoomControlsEnabled = false,          // 기본 컨트롤 대신 아래 커스텀 ＋/− 버튼 사용
                    scrollGesturesEnabled = true, // 딴 데 볼 수 있게 항상 허용 (🎯 버튼으로 복귀)
                    myLocationButtonEnabled = false,
                    compassEnabled = true,                // ✅ 나침반: 지도 회전 시 좌상단에 표시, 탭하면 북쪽 복귀
                    rotationGesturesEnabled = true,       // ✅ 두 손가락 회전으로 동서남북 전환
                    zoomGesturesEnabled = true
                )
            ) {
                // ✅ v32 정체 구간: 경로 위에 노랑(서행)/빨강(정체) 덧칠
                trafficSegments.forEach { (seg, level) ->
                    val pts = seg.map { LatLng(it.latitude, it.longitude) }
                    if (pts.size >= 2) {
                        Polyline(
                            points = pts, zIndex = 120f, width = 14f,
                            color = if (level == com.navifit.navigation.TrafficFlowRepository.Level.JAM)
                                Color(0xFFE53935) else Color(0xFFFFB300)
                        )
                    }
                }
                // ✅ v32 제안 경로: 연한 파란색 - 이쪽으로 가면 자동으로 안내 전환됨
                suggestedRoute?.let { sug ->
                    val sugPts = decodePolyline(sug.overviewPolyline).map { LatLng(it.latitude, it.longitude) }
                    if (sugPts.size >= 2) {
                        Polyline(points = sugPts, color = Color(0x9964B5FF), width = 16f, zIndex = 60f)
                    }
                }
                // ✅ v27 대체경로: 회색 반투명 - 탭하면 그 경로로 교체
                alternativeRoutes.forEach { alt ->
                    val altPts = decodePolyline(alt.overviewPolyline).map { LatLng(it.latitude, it.longitude) }
                    if (altPts.size >= 2) {
                        Polyline(
                            points = altPts, color = Color(0x999E9E9E), width = 12f, zIndex = 50f,
                            clickable = true, onClick = { onSelectAlternative(alt) }
                        )
                    }
                }
                // ✅ v61: 단속카메라/방지턱 마커 지도 표시 제거 (요청)
                //    (경보음/제한속도 뱃지도 이미 없앴고, 지도에 마커도 안 띄움)
                if (routePoints.isNotEmpty()) {
                    val allPts = routePoints.map { LatLng(it.latitude, it.longitude) }
                    // ✅ 따라가야 할 경로: 형광 빨강 - 가장 눈에 띄게, 다른 모든 선 위에 덮어서 표시
                    // (아직 안 간 구간까지 포함한 전체 경로를 항상 빨강으로 유지해야 "이 길로 가야 한다"가 명확함)
                    Polyline(points = allPts, color = Color(0x66FF1744), width = 30f, zIndex = 90f) // 빨강 글로우(후광)
                    Polyline(points = allPts, color = Color(0xFFFF1744), width = 13f, zIndex = 100f) // 형광 빨강 본선 (최상단)

                    // 지나온 구간 진행 표시: 빨강 경로 위에 살짝 얇게 덧그려서 "여기까지 왔다"만 보조 표시
                    progress?.let { pg ->
                        if (pg.nearestRouteIndex >= 1) {
                            val covered = allPts.subList(0, (pg.nearestRouteIndex + 1).coerceAtMost(allPts.size))
                            Polyline(points = covered, color = Color(0xFFFFD54F), width = 6f, zIndex = 101f)
                        }
                    }
                }
                // ✅ 공유경로 따라가기: 현위치→공유경로 출발점까지 "접근 경로"를 파란색으로 안내
                //    (파란선 따라 출발점에 도착하면, 거기서부터 빨간 공유경로를 그대로 따라가면 됨)
                approachRoute?.let { ap ->
                    val apPts = decodePolyline(ap.overviewPolyline).map { LatLng(it.latitude, it.longitude) }
                    if (apPts.size >= 2) {
                        Polyline(points = apPts, color = Color(0x662979FF), width = 26f, zIndex = 88f)  // 파랑 글로우
                        Polyline(points = apPts, color = Color(0xFF2979FF), width = 12f, zIndex = 98f)  // 파랑 본선
                        // 출발점 마커
                        Marker(
                            state = MarkerState(apPts.last()), title = "공유경로 출발점",
                            icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)
                        )
                    }
                }
                // ✅ v61 화장실 마커 상시 표시 - 탭하면 정보창(이름/건물/주소 + 긴급안내)
                toiletMarkers.forEach { t ->
                    Marker(
                        state = MarkerState(t.pos),
                        title = "🚻 ${t.name}",
                        snippet = t.address,
                        icon = toiletMarkerIcon,
                        onClick = { selectedToilet = t; false }   // false: 기본 정보창도 뜨게
                    )
                }

                // 실제 이동 궤적 (경로를 이탈해도 내가 실제로 지나온 길은 옅은 색으로 남김 - 메인 빨강 경로 아래에)
                if (traveledPath.size >= 2) {
                    val pts = traveledPath.map { LatLng(it.latitude, it.longitude) }
                    Polyline(points = pts, color = Color(0xFF8B9FFF), width = 7f, zIndex = 10f)
                }
                // 목적지 마커
                routePoints.lastOrNull()?.let {
                    Marker(
                        state = MarkerState(LatLng(it.latitude, it.longitude)), title = "목적지",
                        icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ROSE)
                    )
                }
                // 내 위치: 장착 마커 + 테두리 + 닉네임 티커
                if (effectiveLocation != null) {
                    Marker(
                        state = myMarkerState,
                        icon = myMarkerIcon,
                        anchor = Offset(0.5f, 1f),
                        zIndex = 10f
                    )
                }
            }

            // 상단 턴바이턴 안내판 (세로모드 + 주행 모드에서만 - ✅ v58 운동 모드는 화살표/내비 패널 제거)
            if (!isLandscape && !mode.isWorkoutMode) {
                progress?.let { pg ->
                    Column(Modifier.align(Alignment.TopCenter).padding(10.dp).fillMaxWidth()) {
                        TurnByTurnPanel(pg, navLang, Modifier.fillMaxWidth())
                        // ✅ 회전 접근 팝업: 지도를 확대하는 대신, 회전 300m 이내에서만
                        //    작은 안내 창이 잠깐 떠서 어디로 빠져야 하는지 알려주고 지나가면 자동으로 사라짐.
                        //    (메인 지도를 가리지 않는 얇은 배너 형태)
                        androidx.compose.animation.AnimatedVisibility(
                            visible = approachingTurn && pg.laneDirection != LaneDirection.STRAIGHT,
                            enter = androidx.compose.animation.fadeIn() + androidx.compose.animation.expandVertically(),
                            exit = androidx.compose.animation.fadeOut() + androidx.compose.animation.shrinkVertically()
                        ) {
                            val arrow = when (pg.laneDirection) {
                                LaneDirection.LEFT -> "⬅️"; LaneDirection.RIGHT -> "➡️"
                                LaneDirection.UTURN -> "↩️"; else -> "⬆️"
                            }
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xF206C167),   // ✅ 카카오 초록 통일
                                modifier = Modifier.padding(top = 6.dp)
                            ) {
                                Row(Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                    verticalAlignment = Alignment.CenterVertically) {
                                    Text(arrow, fontSize = 16.sp)
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        "${NavigationProgressCalculator.formatDistance(pg.distanceToNextTurnMeters)} 앞 · " +
                                            (pg.nextStep?.instruction?.take(24) ?: "방향 전환"),
                                        color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // ═══════════ v27 오버레이들 ═══════════

            // ✅ v56 카카오내비식 원형 속도계 (좌하단)
            //    - 평상시: 짙은 원 + 큰 흰 숫자
            //    - 단속카메라 접근 중 제한속도 초과: 빨간 링 + 숫자 빨강
            //    - 옆에 제한속도 표지판(빨간 원) 뱃지
            if (isDrivingMode) {   // ✅ v58: 속도계/제한속도 뱃지는 주행 모드 전용 (운동 화면에서 제거)
                val nearLimit = hazardAlert?.takeIf { it.phase != com.navifit.safety.AlertPhase.CLEARED }?.hazard?.limitKmh
                val violating = nearLimit != null && speedKmh > nearLimit
                Row(
                    Modifier.align(Alignment.BottomStart).padding(start = 14.dp, bottom = 84.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(66.dp)
                                .background(if (violating) Color(0xFFD32F2F) else Color(0xFF2C3145), CircleShape)
                                .padding(3.dp)
                                .background(Color(0xF0161A28), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${speedKmh.toInt()}",
                                    color = if (violating) Color(0xFFFF6B6B) else Color.White,
                                    fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                                Text("km/h", color = Color(0xFF8B93AC), fontSize = 8.sp)
                            }
                        }
                        Spacer(Modifier.height(4.dp))
                        // 부가 정보는 속도계 아래 작은 캡슐로 (기존의 긴 세로 나열 대신 컴팩트하게)
                        Column(
                            Modifier.background(Color(0xCC101828), RoundedCornerShape(10.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("🧭 " + FollowRouteGuide.bearingToKorean(bearing),
                                color = Color(0xFF7EDDB8), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            roadInfo?.roadName?.let {
                                Text(it, color = Color(0xFFFFD86B), fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            }
                            if (gpsAccuracyMeters > 25f) {
                                Text("📶 ±${gpsAccuracyMeters.toInt()}m",
                                    color = Color(0xFFFFAB40), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    // 제한속도 표지판 뱃지 (단속 구간 접근 중일 때만)
                    nearLimit?.let { lim ->
                        Spacer(Modifier.width(7.dp))
                        Box(
                            Modifier.size(44.dp)
                                .background(Color(0xFFD32F2F), CircleShape)
                                .padding(4.dp)
                                .background(Color.White, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("$lim", color = Color(0xFF1A1A1A), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }

            // ✅ v60 운동 모드 상단 HUD (2줄): 
            //   윗줄 - 진행시간 · 남은 거리
            //   아랫줄 - 운동 거리 · 운동 속도 · 경로 진행률
            if (mode.isWorkoutMode && !isLandscape) {
                val remainMeters = progress?.remainingMeters ?: 0
                Column(
                    Modifier.align(Alignment.TopCenter).padding(top = 10.dp)
                        .fillMaxWidth(0.94f)
                        .background(Color(0xCC0E1116), RoundedCornerShape(18.dp))
                        .padding(horizontal = 14.dp, vertical = 11.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        HudStat("진행시간", formatElapsed(elapsedSeconds), Color.White)
                        HudStat("남은 거리",
                            if (progress != null) NavigationProgressCalculator.formatDistance(remainMeters) else "-",
                            Color(0xFFFFC879))
                    }
                    Spacer(Modifier.height(9.dp))
                    HorizontalDivider(color = Color(0x22FFFFFF), thickness = 0.6.dp)
                    Spacer(Modifier.height(9.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        HudStat("운동 거리", "%.2f km".format(distanceMeters / 1000), Color(0xFF6FE3A5))
                        HudStat("운동 속도", "%.1f km/h".format(speedKmh), Color.White)
                        // ✅ v90 진행률 대신 상승고도 (러닝·자전거의 실제 난이도 지표)
                        //   경로 안내 중이면 진행률, 자유운동이면 상승고도를 보여준다
                        if (progress != null) {
                            HudStat("진행률", "${(progress.traveledRatio * 100).toInt()}%", Color(0xFF7CC7FF))
                        } else {
                            HudStat("상승고도", "${elevationGainMeters.toInt()}m", Color(0xFFFFB86C))
                        }
                    }
                    // ✅ v78 가장 가까운 화장실 거리 표시 + 긴급 안내 버튼
                    val nearestToilet = remember(toiletMarkers, displayLocation) {
                        val loc = displayLocation
                        if (loc == null || toiletMarkers.isEmpty()) null
                        else toiletMarkers.minByOrNull {
                            NavigationProgressCalculator.fastDistanceMeters(
                                LatLngPoint(loc.latitude, loc.longitude),
                                LatLngPoint(it.pos.latitude, it.pos.longitude))
                        }?.let { t ->
                            t to NavigationProgressCalculator.fastDistanceMeters(
                                LatLngPoint(loc.latitude, loc.longitude),
                                LatLngPoint(t.pos.latitude, t.pos.longitude))
                        }
                    }
                    if (nearestToilet != null) {
                        Spacer(Modifier.height(9.dp))
                        HorizontalDivider(color = Color(0x22FFFFFF), thickness = 0.6.dp)
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            val (t, dist) = nearestToilet
                            Text("🚻 ${t.name}", fontSize = 11.sp, color = Color(0xFFF7A8C4), maxLines = 1, modifier = Modifier.weight(1f))
                            Text("${dist.toInt()}m", fontSize = 11.sp, color = Color(0xFFFFC879), fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(8.dp))
                            Box(
                                Modifier.background(Color(0xFFE53935), RoundedCornerShape(12.dp))
                                    .clickable { onEmergencyToilet(t.pos, t.name) }
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                            ) { Text(tr("🚨 긴급 안내"), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White) }
                        }
                    }
                }
            }

            // ✅ v58 운동 모드 하단: "운동 종료" 작은 버튼 하나만 + 2단계 확인
            //    (주머니 오터치 방지 - 한 번 누르면 "정말 종료할까요?" 확인창, 확인해야 종료 → 이후 저장/저장안함)
            if (mode.isWorkoutMode && !isLandscape) {
                var confirmEnd by remember { mutableStateOf(false) }
                Button(
                    onClick = { confirmEnd = true },
                    modifier = Modifier.align(Alignment.BottomStart).padding(start = 14.dp, bottom = 20.dp).height(38.dp),
                    shape = RoundedCornerShape(19.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xE6E53935)),
                    contentPadding = PaddingValues(horizontal = 16.dp)
                ) { Text(tr("운동 종료"), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White) }
                if (confirmEnd) {
                    AlertDialog(
                        onDismissRequest = { confirmEnd = false },
                        title = { Text(tr("운동 종료")) },
                        text = { Text(tr("정말 운동을 종료할까요?\n(종료 후 저장 여부를 다시 물어봐요)"), fontSize = 13.sp) },
                        confirmButton = {
                            Button(onClick = { confirmEnd = false; onFinish() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935))
                            ) { Text(tr("종료")) }
                        },
                        dismissButton = { TextButton(onClick = { confirmEnd = false }) { Text(tr("계속 운동")) } }
                    )
                }
            }

            // ✅ v75 화장실 정보 카드 - 이름/별명/별점/댓글(층·개방여부) + [긴급 안내] + [리뷰 남기기]
            selectedToilet?.let { t ->
                val toiletKey = remember(t) { com.navifit.navigation.ToiletReviewStore.keyOf(t.pos.latitude, t.pos.longitude) }
                var meta by remember(toiletKey) { mutableStateOf(com.navifit.navigation.ToiletReviewStore.get(context, toiletKey)) }
                var showReviewDialog by remember { mutableStateOf(false) }
                Surface(
                    Modifier.align(Alignment.BottomCenter).padding(bottom = 90.dp, start = 16.dp, end = 16.dp).fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp), color = Color(0xF01B1E26), shadowElevation = 8.dp
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🚻", fontSize = 22.sp)
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(meta.nickname.ifBlank { t.name }, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = Color.White, maxLines = 1)
                                if (meta.nickname.isNotBlank() && meta.nickname != t.name)
                                    Text(t.name, fontSize = 10.sp, color = Color(0xFF8B93AC), maxLines = 1)
                                if (meta.reviewCount > 0)
                                    Text("⭐ %.1f (%d)".format(meta.avgRating, meta.reviewCount), fontSize = 11.sp, color = Color(0xFFFFD22E))
                                else if (t.address.isNotBlank())
                                    Text("📍 ${t.address}", fontSize = 11.sp, color = Color(0xFFAAB0BD), maxLines = 1)
                            }
                            Text("✕", fontSize = 16.sp, color = Color(0xFF8B93AC),
                                modifier = Modifier.clickable { selectedToilet = null }.padding(4.dp))
                        }
                        // ✅ v85 리뷰 전체를 스크롤로 볼 수 있게 (기존엔 2개만 보였음)
                        //   리뷰가 많으면 카드 안에서 세로 스크롤 → 지도를 가리지 않도록 높이 제한
                        if (meta.reviews.isNotEmpty()) {
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(tr("리뷰 %s개").format(meta.reviews.size), fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold, color = Color(0xFFAAB0BD))
                                Spacer(Modifier.weight(1f))
                                if (meta.reviews.size > 2)
                                    Text(tr("↕ 스크롤해서 더 보기"), fontSize = 9.sp, color = Color(0xFF8B93AC))
                            }
                            Spacer(Modifier.height(4.dp))
                            androidx.compose.foundation.lazy.LazyColumn(
                                modifier = Modifier.fillMaxWidth().heightIn(max = 190.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                items(meta.reviews.size) { idx ->
                                    val r = meta.reviews[idx]
                                    Column(Modifier.fillMaxWidth()
                                        .background(Color(0x22FFFFFF), RoundedCornerShape(8.dp)).padding(8.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("⭐".repeat(r.rating.coerceIn(1,5)), fontSize = 10.sp)
                                            Spacer(Modifier.width(6.dp))
                                            if (r.floor.isNotBlank()) Text(
                                                // ✅ v81 건물 표시 옆에 "층" 글자까지 노출 (예: 🏢 지하 1층)
                                                "🏢 " + r.floor.trim() + (if (r.floor.trim().endsWith("층")) "" else "층"),
                                                fontSize = 10.sp, color = Color(0xFF9FE7C0))
                                            Spacer(Modifier.width(6.dp))
                                            if (r.isOpen.isNotBlank()) Text(
                                                if (r.isOpen == "열림") "🟢 열림" else "🔴 닫힘",
                                                fontSize = 10.sp, color = Color(0xFFAAB0BD))
                                            Spacer(Modifier.weight(1f))
                                            Text(r.nickname.take(8), fontSize = 9.sp, color = Color(0xFF8B93AC))
                                        }
                                        if (r.comment.isNotBlank())
                                            Text(r.comment, fontSize = 11.sp, color = Color(0xFFECEEF2), maxLines = 3)
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { onEmergencyToilet(t.pos, meta.nickname.ifBlank { t.name }); selectedToilet = null },
                                modifier = Modifier.weight(1f).height(44.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935))
                            ) { Text(tr("🚨 여기로 안내"), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = Color.White) }
                            OutlinedButton(
                                onClick = { showReviewDialog = true },
                                modifier = Modifier.weight(1f).height(44.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) { Text(tr("💬 리뷰"), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                        }
                        Text(tr("운동 중 안내를 받아도 운동 기록은 계속 측정돼요 (쉬는 꼼수 방지)"),
                            fontSize = 10.sp, color = Color(0xFF8B93AC), modifier = Modifier.padding(top = 6.dp))
                    }
                }
                if (showReviewDialog) {
                    ToiletReviewDialog(
                        currentNickname = meta.nickname.ifBlank { t.name },
                        onDismiss = { showReviewDialog = false },
                        onSubmit = { toiletNick, rating, comment, floor, isOpen ->
                            com.navifit.navigation.ToiletReviewStore.addReview(context, toiletKey,
                                com.navifit.navigation.ToiletReviewStore.Review(nickname, rating, comment, floor, isOpen, System.currentTimeMillis()),
                                toiletNickname = toiletNick)
                            meta = com.navifit.navigation.ToiletReviewStore.get(context, toiletKey)
                            showReviewDialog = false
                        }
                    )
                }
            }

            // ✅ v75 긴급 안내 중 배너 + 운동 복귀 버튼 (운동 기록은 계속 측정 중)
            if (isEmergencyDetour) {
                Column(Modifier.align(Alignment.TopCenter).padding(top = 70.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Surface(shape = RoundedCornerShape(20.dp), color = Color(0xF0E53935)) {
                        Text(tr("🚨 화장실 안내 중 · 운동 기록은 계속 측정돼요"), color = Color.White, fontSize = 12.sp,
                            fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp))
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = { onReturnFromEmergency() },
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF34C77B))
                    ) { Text(tr("↩️ 원래 운동 안내로"), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White) }
                }
            }

            // ✅ v56 재탐색 배너 (카카오내비의 "경로를 다시 탐색합니다"와 동일한 위치/느낌)
            androidx.compose.animation.AnimatedVisibility(
                visible = rerouting,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 120.dp),
                enter = androidx.compose.animation.fadeIn(),
                exit = androidx.compose.animation.fadeOut()
            ) {
                Row(
                    Modifier.background(Color(0xF0202A44), RoundedCornerShape(20.dp))
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp, color = Color(0xFF7C93F5))
                    Spacer(Modifier.width(8.dp))
                    Text(tr("경로를 다시 탐색하고 있어요"), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            // ✅ 카메라/방지턱 경보 패널 (하단 중앙 위) - 800m 전부터 통과까지
            hazardAlert?.let { alert ->
                if (alert.phase != com.navifit.safety.AlertPhase.CLEARED && !mode.isWorkoutMode) {   // ✅ v58 운동 모드 제외
                    Row(
                        Modifier.align(Alignment.BottomCenter).padding(bottom = 76.dp)
                            .background(
                                if (alert.isViolating) Color(0xEED32F2F) else Color(0xEE1E2A3A),
                                RoundedCornerShape(14.dp)
                            )
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(alert.hazard.type.icon, fontSize = 20.sp)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(
                                "${alert.hazard.type.label} ${alert.distanceMeters}m",
                                color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold
                            )
                            alert.hazard.limitKmh?.let {
                                Text(
                                    if (alert.isViolating) "⚠️ 제한 ${it}km 초과 중!" else "제한속도 ${it}km",
                                    color = if (alert.isViolating) Color(0xFFFFCDD2) else Color(0xFF9CA3AF),
                                    fontSize = 10.sp, fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // ✅ 위반 경고: 화면 겉 프레임이 빨갛게 깜빡임 (길 안 가리게 테두리만)
            if (isViolationWarning) {
                val flashTransition = rememberInfiniteTransition(label = "violationFlash")
                val flashAlpha by flashTransition.animateFloat(
                    initialValue = 0.15f, targetValue = 0.85f,
                    animationSpec = infiniteRepeatable(tween(420), RepeatMode.Reverse), label = "fa"
                )
                Box(
                    Modifier.fillMaxSize()
                        .border(6.dp, Color.Red.copy(alpha = flashAlpha), RoundedCornerShape(2.dp))
                )
            }

            // ✅ v32 빠른 길 제안 배너
            if (suggestedRoute != null) {
                Row(
                    Modifier.align(Alignment.BottomCenter).padding(bottom = 128.dp)
                        .background(Color(0xEE1565C0), RoundedCornerShape(14.dp))
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("💡", fontSize = 18.sp)
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text(tr("약 %s분 빠른 길이 있어요").format(suggestedSavedMinutes),
                            color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                        Text(tr("연한 파란색 길로 가시면 자동으로 안내합니다"),
                            color = Color(0xFFBBDEFB), fontSize = 10.sp)
                    }
                }
            }

            // ✅ v84 운동 안내 상태 배지 — 위성 실측 기반.
            //    "하늘이 보이는 곳으로" 문구는 위성이 실제로 부족할 때만 띄운다.
            //    (야외인데 이 문구가 뜨던 오탐 제거)
            run {
                // ✅ v91 오프라인이면 가장 먼저 알린다.
                //   (경로 탐색·화장실 검색은 안 되지만 운동 기록은 계속된다는 걸 알려야 함)
                val offline = !com.navifit.tracking.NetworkMonitor.isOnline.value
                val statusText: String? = when {
                    offline -> "📴 오프라인 - 경로 탐색은 안 되지만 운동 기록은 계속돼요"
                    isGpsEstimating -> "🕳️ 위성 신호 없음 - 센서로 위치 추정 중"
                    displayLocation == null -> "📡 GPS 위치를 찾는 중이에요..."
                    // 위성 정보를 받는 기기: 위성 개수가 실제로 적을 때만 경고
                    gpsSatellites in 1..3 -> "📶 위성 ${gpsSatellites}개 - 하늘이 보이는 곳으로 이동해 주세요"
                    // 위성은 충분한데 오차만 큰 경우: 안내만, 이동 요구 안 함
                    gpsSatellites >= 4 && gpsAccuracyMeters > 30f ->
                        "📶 GPS 보정 중 (위성 ${gpsSatellites}개 · 오차 ${gpsAccuracyMeters.toInt()}m)"
                    // 위성 정보를 못 받는 구형 기기 폴백
                    gpsSatellites == 0 && gpsAccuracyMeters > 40f ->
                        "📶 GPS 정확도 낮음 (${gpsAccuracyMeters.toInt()}m)"
                    else -> null
                }
                val statusBg = when {
                    offline -> Color(0xCC37474F)
                    isGpsEstimating -> Color(0xCC5D4037)
                    displayLocation == null -> Color(0xCC1E3A5F)
                    else -> Color(0xCC6B4E00)
                }
                if (statusText != null) {
                    Text(
                        statusText,
                        fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.TopStart).padding(top = 90.dp, start = 12.dp)
                            .background(statusBg, RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            // ✅ 친구 길 따라가기 모드 배지 + 이탈 시 복귀 안내
            followRouteState?.let { fs ->
                Column(Modifier.align(Alignment.TopEnd).padding(top = 90.dp, end = 12.dp)) {
                    Text(
                        "👣 친구 길 따라가기 ${(fs.progressRatio * 100).toInt()}%",
                        fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold,
                        modifier = Modifier.background(Color(0xDD6E85F0), RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                    if (fs.isOffPath) {
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "↩️ ${FollowRouteGuide.bearingToKorean(fs.returnBearingDeg)} ${fs.returnDistanceMeters}m - 경로로 복귀",
                            fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold,
                            modifier = Modifier.background(Color(0xDDFF6F00), RoundedCornerShape(10.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // ===== ✅ 지도 확대/축소 커스텀 버튼 (기본 컨트롤이 안 눌리던 문제 → 자체 버튼으로 교체) =====
            Column(
                Modifier.align(Alignment.CenterEnd).padding(end = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(shape = RoundedCornerShape(14.dp), color = Color(0xF21B1E2C), shadowElevation = 6.dp) {
                    Column {
                        Text("＋", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFFECEDF4),
                            modifier = Modifier
                                .clickable {
                                    userBaseZoom = (userBaseZoom + 1f).coerceAtMost(20f)
                                    scope.launch { cameraPositionState.animate(CameraUpdateFactory.zoomIn(), 180) }
                                }
                                .padding(horizontal = 13.dp, vertical = 7.dp))
                        Text("−", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFFECEDF4),
                            modifier = Modifier
                                .clickable {
                                    userBaseZoom = (userBaseZoom - 1f).coerceAtLeast(10f)
                                    scope.launch { cameraPositionState.animate(CameraUpdateFactory.zoomOut(), 180) }
                                }
                                .padding(horizontal = 13.dp, vertical = 7.dp))
                    }
                }
            }

            // ===== 내 위치 버튼 2종 (하단 우측) =====
            Column(
                Modifier.align(Alignment.BottomEnd).padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // ✅ v63 기본 확대로 + 내 위치 중앙 (되돌아가기)
                FilledIconButton(
                    onClick = {
                        followMe = true
                        val defZoom = if (mode == TravelMode.BIKE) 17f else 16.5f
                        userBaseZoom = defZoom
                        effectiveLocation?.let {
                            scope.launch {
                                // ✅ v78 달리기는 북쪽(bearing 0)으로 리셋, 자전거는 진행방향 유지
                                val resetBearing = if (mode == TravelMode.BIKE || isDrivingMode) smoothedBearing else 0f
                                cameraPositionState.animate(
                                    CameraUpdateFactory.newCameraPosition(
                                        CameraPosition.Builder()
                                            .target(LatLng(it.latitude, it.longitude))
                                            .zoom(defZoom).bearing(resetBearing).tilt(0f).build()
                                    ), 450
                                )
                            }
                        }
                    },
                    modifier = Modifier.size(46.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFF2A3346))
                ) { Text("🎯", fontSize = 18.sp) }
                Spacer(Modifier.height(9.dp))
                // ✅ v85 현재 축척을 "유지"한 채 내 위치만 중앙으로 (따라가기 재개)
                //   기존 버그: followMe=true가 되면 카메라 추종 효과가 userBaseZoom(기본 줌)으로
                //   되돌려버려서 🎯 버튼과 결과가 똑같아졌음.
                //   → 지금 보고 있는 줌을 userBaseZoom에 반영해서 사용자가 맞춘 축척을 지킨다.
                FilledIconButton(
                    onClick = {
                        userBaseZoom = cameraPositionState.position.zoom
                        followMe = true
                        effectiveLocation?.let {
                            scope.launch {
                                cameraPositionState.animate(
                                    CameraUpdateFactory.newCameraPosition(
                                        CameraPosition.Builder()
                                            .target(LatLng(it.latitude, it.longitude))
                                            .zoom(cameraPositionState.position.zoom)
                                            .bearing(cameraPositionState.position.bearing)
                                            .tilt(cameraPositionState.position.tilt)
                                            .build()
                                    ), 350
                                )
                            }
                        }
                    },
                    modifier = Modifier.size(52.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = if (followMe) Color(0xFF3B82F6) else Color(0xFF2A3346)
                    )
                ) { Text("➤", fontSize = 20.sp, color = Color.White) }
            }

            if (!followMe) {
                Text(
                    tr("지도를 살펴보는 중 · 🎯 버튼으로 내 위치 복귀"),
                    fontSize = 10.sp, color = Color.White,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp)
                        .background(Color(0xAA000000), RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }

            // ✅ 내 위치를 아직 못 찾았을 때 - 재시도 중임을 알려줌 (풀스크린 진입 직후 첫 측위 지연 대응)
            if (effectiveLocation == null) {
                Row(
                    modifier = Modifier.align(Alignment.Center)
                        .background(Color(0xDD1E2A3A), RoundedCornerShape(14.dp))
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp, color = Color.White)
                    Spacer(Modifier.width(10.dp))
                    Text(tr("내 위치를 찾는 중이에요..."), color = Color.White, fontSize = 12.sp)
                }
            }

            // 경로 이탈 경고 (✅ 확정 이탈일 때만 - 순간 튐으로 계속 뜨던 문제 수정)
            if (showOffRouteBanner) {
                Text(
                    tr("⚠️ 경로를 벗어났어요"),
                    fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.TopCenter)
                        .padding(top = if (isLandscape) 12.dp else 120.dp)
                        .background(Color(0xDDFF6B81), RoundedCornerShape(12.dp))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }

            // 운전 모드 전용: 전체경로 미니맵 (PIP)
            if (isDrivingMode) {
                Box(
                    Modifier.align(Alignment.TopEnd).padding(14.dp)
                        .padding(top = if (isLandscape) 0.dp else 100.dp)
                        .size(100.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .border(2.dp, Color.White, RoundedCornerShape(16.dp))
                ) {
                    GoogleMap(
                        modifier = Modifier.fillMaxSize(),
                        cameraPositionState = overviewCameraState,
                        uiSettings = MapUiSettings(
                            zoomControlsEnabled = false, scrollGesturesEnabled = false,
                            zoomGesturesEnabled = false, rotationGesturesEnabled = false, tiltGesturesEnabled = false
                        )
                    ) {
                        if (routePoints.isNotEmpty()) {
                            Polyline(points = routePoints.map { LatLng(it.latitude, it.longitude) }, color = Color(0xFF8B9FFF), width = 5f)
                        }
                        effectiveLocation?.let { loc -> Marker(state = MarkerState(LatLng(loc.latitude, loc.longitude))) }
                    }
                    Box(Modifier.align(Alignment.BottomStart).background(Color(0xAA000000)).fillMaxWidth()) {
                        Text(tr("전체경로"), color = Color.White, fontSize = 9.sp, modifier = Modifier.padding(2.dp))
                    }
                }
            }
        }
    }

    // ===== 하단(세로) / 사이드(가로) 정보 패널 =====
    val infoPanel: @Composable ColumnScope.() -> Unit = {
        if (isLandscape) {
            progress?.let { pg -> TurnByTurnPanel(pg, navLang, Modifier.fillMaxWidth()); Spacer(Modifier.height(8.dp)) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            StatItem("경과", formatElapsed(elapsedSeconds))
            StatItem("거리", "%.2fkm".format(distanceMeters / 1000))
            StatItem("속도", "%.1fkm/h".format(speedKmh))
        }
        progress?.let { pg ->
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                StatItem("남은거리", NavigationProgressCalculator.formatDistance(pg.remainingMeters))
                StatItem("남은시간", NavigationProgressCalculator.formatDuration(pg.remainingSeconds))
                StatItem("진행률", "${(pg.traveledRatio * 100).toInt()}%")
            }
        }

        if (safetyTracker != null && isDrivingMode) {
            Spacer(Modifier.height(8.dp))
            Card(shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text(
                        "🛡️ 안전운전 ${safetyTracker.currentScore()}점",
                        fontWeight = FontWeight.ExtraBold, fontSize = 16.sp,
                        color = when {
                            safetyTracker.currentScore() >= 90 -> Color(0xFF5BBD8B)
                            safetyTracker.currentScore() >= 70 -> Color(0xFFE8B34B)
                            else -> Color(0xFFFF8FA3)
                        }
                    )
                    Text(
                        "과속 ${safetyTracker.speedingCount}회 · 급가속 ${safetyTracker.suddenAccelCount}회 · 최고 ${"%.0f".format(safetyTracker.maxSpeedKmh)}km/h",
                        fontSize = 10.sp, color = Color.Gray
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Button(
            onClick = onFinish, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7EDDB8))
        ) { Text(if (mode.isWorkoutMode) "🏁 운동 종료" else "🏁 주행 종료", fontWeight = FontWeight.Bold) }
    }

    if (isLandscape) {
        // 가로모드: 왼쪽 정보 패널 + 오른쪽 지도 풀사이즈
        Row(Modifier.fillMaxSize()) {
            Column(
                Modifier.width(280.dp).fillMaxHeight()
                    .background(Color(0xFFFAF7FB))
                    .verticalScroll(rememberScrollState())
                    .padding(12.dp)
            ) { infoPanel() }
            Box(Modifier.weight(1f).fillMaxHeight()) { mapContent() }
        }
    } else {
        // ✅ 세로모드: 지도가 화면 전체를 꽉 채우고, 정보패널은 그 위에 떠 있는 카드로 표시
        //    (예전엔 지도 아래 별도 공간을 차지해서 지도가 좁아 보였음)
        Box(Modifier.fillMaxSize()) {
            mapContent() // 지도가 풀스크린으로 배경 전체를 채움
            if (!mode.isWorkoutMode)   // ✅ v58 운동 모드는 반투명 상단바+종료버튼만 (하단 카드 제거)
            Card(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .heightIn(max = 168.dp)  // ✅ 지도 가림 최소화: 260 → 168dp
                    .shadow(10.dp, RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)),
                shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF15182A).copy(alpha = 0.82f))  // ✅ 반투명: 패널 밑으로 길이 비쳐 보임
            ) {
                Column(
                    Modifier
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) { infoPanel() }
            }
        }
    }
}

/**
 * 턴바이턴 안내판 - 시중 내비 스타일.
 * 차선 표시등(⬅⬆➡↩)에서 가야 할 방향만 형광으로 점등 + "300m 앞 우회전" 상세 안내.
 */
@Composable
private fun TurnByTurnPanel(pg: NavProgress, langCode: String = "ko", modifier: Modifier = Modifier) {
    // ✅ v57 티맵/카카오식 턴바이턴 패널:
    //   왼쪽 큰 방향 화살표 박스(초록) + 오른쪽 거리 초대형 + 안내문 + 하단 ETA 줄
    //   차선등은 화살표 박스 아래 소형으로
    val arrow = when (pg.laneDirection) {
        LaneDirection.LEFT -> "⬅"; LaneDirection.RIGHT -> "➡"
        LaneDirection.UTURN -> "↩"; else -> "⬆"
    }
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xF5121212)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF262626))
    ) {
        Column {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                // 방향 화살표 큰 박스 (카카오 초록)
                Box(
                    Modifier.size(58.dp).clip(RoundedCornerShape(13.dp))
                        .background(Color(0xFF06C167)),
                    contentAlignment = Alignment.Center
                ) { Text(arrow, fontSize = 32.sp, color = Color.White, fontWeight = FontWeight.ExtraBold) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        NavigationProgressCalculator.formatDistance(pg.distanceToNextTurnMeters),
                        color = Color(0xFF06C167), fontWeight = FontWeight.ExtraBold, fontSize = 28.sp
                    )
                    // ✅ v42~43: 안내문 선택 언어 번역 (캐시 우선) - 기존 로직 그대로 유지
                    val rawInstruction = pg.nextStep?.instruction ?: ""
                    val panelCtx = androidx.compose.ui.platform.LocalContext.current
                    val cachedIns = if (langCode != "ko" && rawInstruction.isNotBlank())
                        com.navifit.i18n.TranslationCache.get(panelCtx, rawInstruction, langCode) else null
                    var shownInstruction by remember(rawInstruction, langCode) {
                        mutableStateOf(cachedIns ?: rawInstruction)
                    }
                    LaunchedEffect(rawInstruction, langCode) {
                        if (rawInstruction.isBlank() || langCode == "ko") { shownInstruction = rawInstruction; return@LaunchedEffect }
                        val hit = com.navifit.i18n.TranslationCache.get(panelCtx, rawInstruction, langCode)
                        if (hit != null) { shownInstruction = hit; return@LaunchedEffect }
                        com.navifit.i18n.TranslationService.translate(rawInstruction, "ko", langCode)?.let {
                            com.navifit.i18n.TranslationCache.put(panelCtx, rawInstruction, langCode, it)
                            shownInstruction = it
                        }
                    }
                    Text(
                        shownInstruction.ifBlank { com.navifit.i18n.UiText.get("nav_follow_route", langCode) },
                        color = Color(0xFFF5F5F5), fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1
                    )
                }
            }
            // 하단 ETA 스트립 (티맵 하단 정보줄 느낌)
            val etaMillis = System.currentTimeMillis() + pg.remainingSeconds * 1000L
            val etaText = java.text.SimpleDateFormat("a h:mm", java.util.Locale.KOREA)
                .format(java.util.Date(etaMillis))
            Row(
                Modifier.fillMaxWidth().background(Color(0xFF1C1C1E))
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
            ) {
                Text(tr("🏁 %s 도착").format(etaText), color = Color(0xFFF5F5F5), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(NavigationProgressCalculator.formatDistance(pg.remainingMeters),
                    color = Color(0xFFA8A8A8), fontSize = 12.sp)
                Text(tr("%s분 남음").format(pg.remainingSeconds / 60), color = Color(0xFFA8A8A8), fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    LaneLight("⬅", active = pg.laneDirection == LaneDirection.LEFT)
                    LaneLight("⬆", active = pg.laneDirection == LaneDirection.STRAIGHT)
                    LaneLight("➡", active = pg.laneDirection == LaneDirection.RIGHT)
                }
            }
        }
    }
}

/** 차선 방향 표시등 - 활성화되면 형광 점등 */
@Composable
private fun LaneLight(arrow: String, active: Boolean) {
    Box(
        Modifier.size(32.dp).clip(RoundedCornerShape(9.dp))
            .background(if (active) Color(0xFF39FF88) else Color(0xFF2A3A4E)),
        contentAlignment = Alignment.Center
    ) {
        Text(arrow, fontSize = 16.sp, color = if (active) Color(0xFF10331F) else Color(0xFF4A5A6E))
    }
}

@Composable
private fun StatItem(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
        Text(label, fontSize = 10.sp, color = Color.Gray)
    }
}

private fun formatElapsed(sec: Long): String = "%02d:%02d".format(sec / 60, sec % 60)

/** ✅ v60 운동 HUD 스탯 한 칸 (라벨+값 세로) */
@Composable
private fun HudStat(label: String, value: String, valueColor: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Color(0x99FFFFFF), fontSize = 10.sp)
        Spacer(Modifier.height(2.dp))
        Text(value, color = valueColor, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
    }
}

private fun computeBearing(a: LatLngPoint, b: LatLngPoint): Float {
    val lat1 = Math.toRadians(a.latitude); val lat2 = Math.toRadians(b.latitude)
    val dLng = Math.toRadians(b.longitude - a.longitude)
    val y = Math.sin(dLng) * Math.cos(lat2)
    val x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng)
    val bearing = Math.toDegrees(atan2(y, x))
    return ((bearing + 360) % 360).toFloat()
}

fun decodePolyline(encoded: String): List<LatLngPoint> {
    val poly = mutableListOf<LatLngPoint>()
    var index = 0; var lat = 0; var lng = 0
    while (index < encoded.length) {
        var b: Int; var shift = 0; var result = 0
        do { b = encoded[index++].code - 63; result = result or (b and 0x1f shl shift); shift += 5 } while (b >= 0x20)
        lat += if (result and 1 != 0) (result shr 1).inv() else (result shr 1)
        shift = 0; result = 0
        do { b = encoded[index++].code - 63; result = result or (b and 0x1f shl shift); shift += 5 } while (b >= 0x20)
        lng += if (result and 1 != 0) (result shr 1).inv() else (result shr 1)
        poly.add(LatLngPoint(lat / 1E5, lng / 1E5))
    }
    return poly
}

/** 이동 경로를 인코딩 폴리라인으로 (랭킹 경로 표시용 기록 저장) */
fun encodeTravelPolyline(points: List<LatLngPoint>): String {
    val sb = StringBuilder()
    var prevLat = 0; var prevLng = 0
    points.forEach { p ->
        val lat = Math.round(p.latitude * 1e5).toInt()
        val lng = Math.round(p.longitude * 1e5).toInt()
        encodePolyValue(lat - prevLat, sb)
        encodePolyValue(lng - prevLng, sb)
        prevLat = lat; prevLng = lng
    }
    return sb.toString()
}

private fun encodePolyValue(value: Int, sb: StringBuilder) {
    var v = value shl 1
    if (value < 0) v = v.inv()
    while (v >= 0x20) {
        sb.append(((0x20 or (v and 0x1f)) + 63).toChar())
        v = v shr 5
    }
    sb.append((v + 63).toChar())
}


/** ✅ v38 야간 지도 스타일 (구글 맵 다크 테마) */
private const val NIGHT_MAP_STYLE = """
[
  {"elementType":"geometry","stylers":[{"color":"#242f3e"}]},
  {"elementType":"labels.text.fill","stylers":[{"color":"#746855"}]},
  {"elementType":"labels.text.stroke","stylers":[{"color":"#242f3e"}]},
  {"featureType":"poi","elementType":"labels.text.fill","stylers":[{"color":"#d59563"}]},
  {"featureType":"road","elementType":"geometry","stylers":[{"color":"#38414e"}]},
  {"featureType":"road","elementType":"geometry.stroke","stylers":[{"color":"#212a37"}]},
  {"featureType":"road","elementType":"labels.text.fill","stylers":[{"color":"#9ca5b3"}]},
  {"featureType":"road.highway","elementType":"geometry","stylers":[{"color":"#746855"}]},
  {"featureType":"road.highway","elementType":"geometry.stroke","stylers":[{"color":"#1f2835"}]},
  {"featureType":"road.highway","elementType":"labels.text.fill","stylers":[{"color":"#f3d19c"}]},
  {"featureType":"water","elementType":"geometry","stylers":[{"color":"#17263c"}]},
  {"featureType":"water","elementType":"labels.text.fill","stylers":[{"color":"#515c6d"}]}
]
"""

/** ✅ v75 화장실 리뷰 작성 다이얼로그 (별명·별점·댓글·층·개방여부) */
@androidx.compose.runtime.Composable
private fun ToiletReviewDialog(
    currentNickname: String,
    onDismiss: () -> Unit,
    onSubmit: (toiletNick: String, rating: Int, comment: String, floor: String, isOpen: String) -> Unit
) {
    var toiletNick by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(currentNickname) }
    var rating by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(5) }
    var comment by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
    var floor by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("") }
    var isOpen by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf("열림") }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { androidx.compose.material3.Text(tr("화장실 리뷰 남기기")) },
        text = {
            androidx.compose.foundation.layout.Column {
                androidx.compose.material3.OutlinedTextField(
                    value = toiletNick, onValueChange = { toiletNick = it.take(20) },
                    label = { androidx.compose.material3.Text(tr("별명 (예: 공원 입구 화장실)")) }, singleLine = true,
                    modifier = androidx.compose.ui.Modifier.fillMaxWidth()
                )
                androidx.compose.foundation.layout.Spacer(androidx.compose.ui.Modifier.height(8.dp))
                // 별점
                androidx.compose.foundation.layout.Row {
                    (1..5).forEach { star ->
                        androidx.compose.material3.Text(
                            if (star <= rating) "⭐" else "☆", fontSize = 26.sp,
                            modifier = androidx.compose.ui.Modifier
                                .clickable { rating = star }
                                .padding(horizontal = 2.dp)
                        )
                    }
                }
                androidx.compose.foundation.layout.Spacer(androidx.compose.ui.Modifier.height(8.dp))
                // 층 + 개방여부
                androidx.compose.foundation.layout.Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                    androidx.compose.material3.OutlinedTextField(
                        value = floor, onValueChange = { floor = it.take(10) },
                        label = { androidx.compose.material3.Text(tr("몇 층")) }, singleLine = true,
                        modifier = androidx.compose.ui.Modifier.weight(1f)
                    )
                    androidx.compose.foundation.layout.Column(androidx.compose.ui.Modifier.weight(1f)) {
                        androidx.compose.material3.Text(tr("개방 여부"), fontSize = 11.sp, color = Color(0xFF8B93AC))
                        androidx.compose.foundation.layout.Row {
                            listOf("열림", "닫힘").forEach { st ->
                                androidx.compose.material3.FilterChip(
                                    selected = isOpen == st, onClick = { isOpen = st },
                                    label = { androidx.compose.material3.Text(st, fontSize = 11.sp) },
                                    modifier = androidx.compose.ui.Modifier.padding(end = 4.dp)
                                )
                            }
                        }
                    }
                }
                androidx.compose.foundation.layout.Spacer(androidx.compose.ui.Modifier.height(8.dp))
                androidx.compose.material3.OutlinedTextField(
                    value = comment, onValueChange = { comment = it.take(200) },
                    label = { androidx.compose.material3.Text(tr("댓글 (깨끗한지, 휴지 있는지 등)")) },
                    modifier = androidx.compose.ui.Modifier.fillMaxWidth().height(80.dp)
                )
            }
        },
        confirmButton = {
            androidx.compose.material3.TextButton(onClick = { onSubmit(toiletNick, rating, comment, floor, isOpen) }) {
                androidx.compose.material3.Text(tr("등록"))
            }
        },
        dismissButton = { androidx.compose.material3.TextButton(onClick = onDismiss) { androidx.compose.material3.Text(tr("취소")) } }
    )
}
