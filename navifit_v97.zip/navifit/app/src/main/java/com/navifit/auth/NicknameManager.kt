package com.navifit.auth

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

/**
 * 닉네임 중복 방지 시스템.
 *
 * Firestore 구조:
 *   nicknames/{소문자 닉네임} -> { uid: "소유자 uid" }
 *   users/{uid}              -> { nickname, linkedGoogle, email, updatedAt }  (UserProfileRepository가 관리)
 *
 * 규칙:
 * - 닉네임 예약은 트랜잭션으로 처리 -> 두 명이 동시에 같은 닉네임을 눌러도 한 명만 성공
 * - 닉네임을 바꾸면 이전 예약은 해제
 * - 게스트(익명) 자동 닉네임은 uid 기반이라 애초에 충돌이 없음
 */
class NicknameManager {
    // ✅ lazy: google-services.json 없이 실행돼도 객체 생성 시점엔 안 죽음
    private val db: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    sealed class ClaimResult {
        object Success : ClaimResult()
        object Taken : ClaimResult()
        data class Error(val message: String) : ClaimResult()
    }

    /** 닉네임 유효성 (2~12자, 한글/영문/숫자/언더바만) */
    fun validate(nickname: String): String? {
        val trimmed = nickname.trim()
        if (trimmed.length < 2) return "닉네임은 2자 이상이어야 해요"
        if (trimmed.length > 12) return "닉네임은 12자 이하여야 해요"
        if (!Regex("^[가-힣a-zA-Z0-9_]+$").matches(trimmed)) return "한글/영문/숫자/언더바만 사용할 수 있어요"
        return null
    }

    /**
     * 닉네임 예약 시도 (트랜잭션 - 동시성 안전).
     * @param previousNickname 기존 닉네임이 있었다면 예약 해제를 위해 전달
     */
    suspend fun claim(nickname: String, uid: String, previousNickname: String? = null): ClaimResult {
        val key = nickname.trim().lowercase()
        validate(nickname)?.let { return ClaimResult.Error(it) }

        return try {
            db.runTransaction { tx ->
                val ref = db.collection("nicknames").document(key)
                val prevKey = previousNickname?.trim()?.lowercase()?.takeIf { it.isNotBlank() && it != key }
                val prevRef = prevKey?.let { db.collection("nicknames").document(it) }

                // ═══ ① 읽기를 전부 먼저 수행 ═══
                //  ⚠️ Firestore 트랜잭션은 "모든 read가 모든 write보다 먼저" 실행돼야 한다.
                //     (기존 버그: tx.set() 뒤에 tx.get(prevRef)를 호출해서
                //      "Firestore transactions require all reads to be executed before all writes" 에러 발생)
                val snap = tx.get(ref)
                val prevSnap = prevRef?.let { tx.get(it) }

                // ═══ ② 검증 ═══
                if (snap.exists() && snap.getString("uid") != uid) {
                    throw NicknameTakenException()
                }

                // ═══ ③ 쓰기를 전부 나중에 수행 ═══
                tx.set(ref, mapOf("uid" to uid, "nickname" to nickname.trim()))
                if (prevRef != null && prevSnap != null &&
                    prevSnap.exists() && prevSnap.getString("uid") == uid) {
                    tx.delete(prevRef)
                }
                null
            }.await()
            ClaimResult.Success
        } catch (e: NicknameTakenException) {
            ClaimResult.Taken
        } catch (e: Exception) {
            // Firestore 트랜잭션은 예외를 감싸서 던지기도 해서 원인 체크
            if (e.cause is NicknameTakenException || e.message?.contains("taken") == true) ClaimResult.Taken
            else ClaimResult.Error("서버 연결에 실패했어요. 네트워크 확인 후 다시 시도해주세요 (${e.message})")
        }
    }

    /**
     * 게스트(비회원) 자동 닉네임 생성.
     * uid 뒷자리를 붙여서 만들기 때문에 중복이 발생하지 않음.
     * 예: "달리는감자_a3f9"
     */
    fun generateGuestNickname(uid: String): String {
        val adjectives = listOf("달리는", "질주하는", "번개같은", "여유로운", "새벽의", "바람의", "무한동력", "폭주하는", "슬기로운", "행복한")
        val nouns = listOf("감자", "치타", "거북이", "로켓", "고양이", "다람쥐", "펭귄", "호랑이", "토끼", "라이더")
        val seed = uid.hashCode()
        val adj = adjectives[Math.floorMod(seed, adjectives.size)]
        val noun = nouns[Math.floorMod(seed / 31, nouns.size)]
        return "$adj$noun${uid.takeLast(4)}"
    }

    private class NicknameTakenException : Exception("nickname taken")
}
