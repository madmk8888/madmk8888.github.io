package com.navifit.auth

import android.app.Activity
import android.content.Intent
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.tasks.await

/**
 * 로그인: 구글 + 익명(비회원) 두 가지만 지원.
 *
 * 흐름:
 * 1. 앱 처음 켜면 자동으로 익명 로그인 (랜덤 UID 부여, 닉네임도 "게스트1234" 식으로 자동)
 * 2. 익명 상태에선 글쓰기/마커장착 등에 제한 걸림 (아래 AnonymousLimits 참고)
 * 3. 나중에 "구글 계정 연결" 누르면 -> 익명 계정에 구글 자격증명을 "연결(link)"함
 *    -> UID는 그대로 유지되면서 구글 계정으로 승격됨 (그동안 쌓은 기록 안 날아감)
 * 4. 연결 성공하면 닉네임 재설정 다이얼로그 띄움
 */
class AuthRepository(private val activity: Activity) {

    // ✅ google-services.json이 없으면 getInstance()가 예외를 던져 앱이 시작하자마자 죽었음
    //    → null로 두고 모든 기능이 "실패 결과"를 돌려주게 함 (앱은 오프라인 게스트로 계속 동작)
    val firebaseAuth: FirebaseAuth? = try { FirebaseAuth.getInstance() } catch (_: Throwable) { null }

    private val googleSignInClient: GoogleSignInClient by lazy {
        // ✅ google-services.json이 없으면 R.string.default_web_client_id 리소스 자체가 생성되지 않아
        //    빌드가 깨졌음 → 컴파일 시점 참조 대신 런타임 조회로 변경.
        //    (json을 넣고 다시 빌드하면 플러그인이 리소스를 만들어 정상 동작)
        val resId = activity.resources.getIdentifier(
            "default_web_client_id", "string", activity.packageName)
        val webClientId = if (resId != 0) activity.getString(resId) else ""
        val builder = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
        if (webClientId.isNotBlank()) builder.requestIdToken(webClientId)
        val gso = builder.requestEmail().build()
        GoogleSignIn.getClient(activity, gso)
    }

    /** 앱 시작시 호출 - 로그인된 게 없으면 자동으로 익명 로그인 */
    suspend fun ensureSignedIn(): Result<FirebaseUser> {
        val fa = firebaseAuth ?: return Result.failure(
            IllegalStateException("Firebase 미설정: app/google-services.json을 넣고 다시 빌드하세요"))
        fa.currentUser?.let { return Result.success(it) }
        return try {
            val result = fa.signInAnonymously().await()
            Result.success(result.user!!)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun isAnonymous(): Boolean = firebaseAuth?.currentUser?.isAnonymous ?: true

    fun getGoogleSignInIntent(): Intent = googleSignInClient.signInIntent

    /**
     * 구글 계정 연결 처리.
     * - 현재 익명 상태면: linkWithCredential로 "승격" (UID 유지, 기존 데이터 보존)
     * - 이미 구글로 로그인된 상태면: 그냥 재로그인
     *
     * ⚠️ ApiException code 10(DEVELOPER_ERROR)은 앱 코드 문제가 아니라 콘솔 설정 문제입니다:
     *   1) google-services.json이 app/ 폴더에 없거나 패키지명(com.navifit)이 안 맞음
     *   2) Firebase 콘솔에 디버그 키스토어의 SHA-1 지문이 등록 안 됨
     *      (터미널에서 gradlew.bat signingReport 실행 → "Variant: debug"의 SHA1 값을 등록)
     *   3) Firebase 콘솔 Authentication에서 Google 로그인이 "사용 설정"으로 켜져있는지 확인
     * 세 가지를 확인하면 100% 해결됩니다.
     */
    suspend fun handleGoogleSignInResult(data: Intent?): Result<FirebaseUser> {
        return try {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            val account = task.getResult(ApiException::class.java)
            val credential = GoogleAuthProvider.getCredential(account.idToken, null)

            val fa = firebaseAuth ?: return Result.failure(
                IllegalStateException("Firebase 미설정: app/google-services.json을 넣고 다시 빌드하세요"))
            val currentUser = fa.currentUser
            val authResult = if (currentUser != null && currentUser.isAnonymous) {
                // 익명 → 구글 승격 시도. 단, 이 구글 계정이 이미 다른 UID에 연결돼 있으면
                // "credential is already associated" 예외 → 그냥 그 구글 계정으로 로그인 (승격 대신 전환)
                try {
                    currentUser.linkWithCredential(credential).await()
                } catch (link: com.google.firebase.auth.FirebaseAuthUserCollisionException) {
                    fa.signInWithCredential(credential).await()
                } catch (link: com.google.firebase.FirebaseException) {
                    // 그 외 링크 실패(이미 다른 자격증명 연결 등)도 일반 로그인으로 폴백
                    fa.signInWithCredential(credential).await()
                }
            } else {
                fa.signInWithCredential(credential).await()
            }
            Result.success(authResult.user!!)
        } catch (e: ApiException) {
            val msg = when (e.statusCode) {
                10 -> "설정 오류(코드 10): google-services.json 배치 · SHA-1 지문 등록 · Firebase Authentication에서 Google 로그인 활성화, 이 3가지를 확인해주세요."
                7 -> "네트워크 연결을 확인해주세요."
                12501 -> "로그인이 취소됐어요."
                else -> "구글 로그인 오류(코드 ${e.statusCode}): ${e.message}"
            }
            Result.failure(Exception(msg))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun signOut() {
        firebaseAuth?.signOut()
        googleSignInClient.signOut()
    }

    fun currentUser(): FirebaseUser? = firebaseAuth?.currentUser
}

/** 익명(비회원) 유저에게 적용되는 제한 - 구글 연결하면 다 풀림 */
object AnonymousLimits {
    const val MAX_POSTS_PER_DAY = 3          // 정회원은 제한 없음
    const val MAX_STICKER_TIER = "RARE"      // 정회원만 에픽/레전더리 마커 장착 가능 (레어까지만 허용)
    const val CAN_SEND_DM = false            // 비회원은 DM 발신 불가 (스팸 방지 목적도 겸함)
    const val CAN_UPLOAD_MEDIA = false       // 비회원은 사진/동영상 첨부 불가, 텍스트만
}
