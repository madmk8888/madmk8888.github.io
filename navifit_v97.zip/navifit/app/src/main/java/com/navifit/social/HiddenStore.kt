package com.navifit.social

import android.content.Context

/**
 * ✅ v88 "이 글 가리기" 저장소.
 *  신고와 달리 내 피드에서만 조용히 숨긴다. 작성자는 알 수 없다.
 *  (작성자 자체를 숨기려면 BlockStore를 쓴다)
 */
object HiddenStore {
    private const val PREFS = "hidden_posts_local"
    private const val KEY = "ids"

    fun all(c: Context): Set<String> =
        c.getSharedPreferences(PREFS, 0).getStringSet(KEY, emptySet()) ?: emptySet()

    fun isHidden(c: Context, postId: String): Boolean = postId in all(c)

    fun hide(c: Context, postId: String) {
        val cur = all(c).toMutableSet()
        cur.add(postId)
        c.getSharedPreferences(PREFS, 0).edit().putStringSet(KEY, cur).apply()
    }

    fun unhide(c: Context, postId: String) {
        val cur = all(c).toMutableSet()
        cur.remove(postId)
        c.getSharedPreferences(PREFS, 0).edit().putStringSet(KEY, cur).apply()
    }
}
