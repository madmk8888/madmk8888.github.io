package com.navifit.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.navifit.social.GroupRoomStore
import com.navifit.social.LocalRmStore

/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  RM 화면 (v83 전면 재작성)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * 기존 문제: 화면이 Firebase 스트림을 직접 구독해서, 서버 오류가 나면
 *           컴포지션 안에서 예외가 터져 앱이 그대로 꺼졌다(= RM 튕김).
 *
 * 새 설계: 화면은 오직 LocalRmStore(로컬 저장소)만 본다.
 *         네트워크 예외가 UI에 도달할 수 없으므로 구조적으로 크래시가 불가능하다.
 */

/** RM 받은함 — 개인 대화 / 요청함 / 단체방 */
@Composable
fun RmInboxScreen(
    myNickname: String,
    onOpenThread: (peerUid: String, peerNickname: String) -> Unit,
    onOpenGroupRoom: (roomId: String) -> Unit,
    onOpenFriends: () -> Unit,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { LocalRmStore.load(ctx) }
    val allThreads by LocalRmStore.threads.collectAsState()

    var tabIdx by remember { mutableStateOf(0) }   // 0=받은 RM 1=요청함 2=단체방
    var groupRooms by remember { mutableStateOf(emptyList<GroupRoomStore.Room>()) }
    var showCreateGroup by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<GroupRoomStore.Room?>(null) }
    var deleteTarget by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { groupRooms = GroupRoomStore.list(ctx) }

    val normal = allThreads.filter { !it.isRequest }
    val requests = allThreads.filter { it.isRequest }

    // ── 단체방 만들기 ──
    if (showCreateGroup) {
        var roomName by remember { mutableStateOf("") }
        val picked = remember { mutableStateListOf<String>() }
        AlertDialog(
            onDismissRequest = { showCreateGroup = false },
            title = { Text("단체 대화방 만들기") },
            text = {
                Column {
                    OutlinedTextField(
                        value = roomName, onValueChange = { roomName = it.take(24) },
                        label = { Text("방 이름 (예: 한강 러닝크루)") },
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("참여할 친구 선택", fontSize = 12.sp, fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface)
                    Spacer(Modifier.height(4.dp))
                    if (allThreads.isEmpty()) {
                        Text("대화한 친구가 없어요", fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    allThreads.forEach { t ->
                        val sel = t.peerUid in picked
                        Row(
                            Modifier.fillMaxWidth()
                                .clickable { if (sel) picked.remove(t.peerUid) else picked.add(t.peerUid) }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(if (sel) "☑" else "☐", fontSize = 16.sp)
                            Spacer(Modifier.width(8.dp))
                            Text(t.peerNickname, fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(enabled = picked.isNotEmpty(), onClick = {
                    val members = allThreads.filter { it.peerUid in picked }
                        .map { GroupRoomStore.Member(it.peerUid, it.peerNickname) }
                    GroupRoomStore.create(ctx, roomName, members)
                    groupRooms = GroupRoomStore.list(ctx)
                    showCreateGroup = false; tabIdx = 2
                }) { Text("만들기") }
            },
            dismissButton = { TextButton(onClick = { showCreateGroup = false }) { Text("취소") } }
        )
    }

    renameTarget?.let { room ->
        var newName by remember(room.id) { mutableStateOf(room.name) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("방 이름 변경") },
            text = {
                OutlinedTextField(value = newName, onValueChange = { newName = it.take(24) },
                    singleLine = true, modifier = Modifier.fillMaxWidth())
            },
            confirmButton = {
                TextButton(onClick = {
                    GroupRoomStore.rename(ctx, room.id, newName)
                    groupRooms = GroupRoomStore.list(ctx)
                    renameTarget = null
                }) { Text("저장") }
            },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("취소") } }
        )
    }

    deleteTarget?.let { uid ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("대화 삭제") },
            text = { Text("이 대화를 삭제할까요? 주고받은 RM이 사라져요.") },
            confirmButton = {
                TextButton(onClick = {
                    LocalRmStore.deleteThread(ctx, uid); deleteTarget = null
                }) { Text("삭제", color = Color(0xFFFF6B6B)) }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("취소") } }
        )
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("←", fontSize = 20.sp,
                modifier = Modifier.clickable(onClick = onBack).padding(end = 12.dp))
            Text("RM", style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
            Text("👥 친구", fontSize = 13.sp, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.clickable(onClick = onOpenFriends).padding(6.dp))
        }

        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = tabIdx == 0, onClick = { tabIdx = 0 },
                label = { Text("받은 RM (${normal.size})", fontSize = 12.sp) })
            FilterChip(selected = tabIdx == 1, onClick = { tabIdx = 1 },
                label = { Text(if (requests.isNotEmpty()) "요청함 ${requests.size} 🔴" else "요청함", fontSize = 12.sp) })
            FilterChip(selected = tabIdx == 2, onClick = { tabIdx = 2 },
                label = { Text("👥 단체방 (${groupRooms.size})", fontSize = 12.sp) })
        }

        when (tabIdx) {
            2 -> {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                    Button(onClick = { showCreateGroup = true },
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                        Text("➕ 단체 대화방 만들기", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
                if (groupRooms.isEmpty()) EmptyBox("👥", "아직 단체방이 없어요", "친구들과 함께 뛸 방을 만들어보세요")
                else LazyColumn {
                    items(groupRooms, key = { it.id }) { room ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onOpenGroupRoom(room.id) }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AvatarCircle("👥",
                                listOf(Color(0xFF8B9FFF), Color(0xFF34D399), Color(0xFF8B9FFF)))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(room.name, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurface)
                                Text("${room.members.size + 1}명 · ${room.lastMessage}",
                                    fontSize = 12.sp, maxLines = 1,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text("🏷️", fontSize = 15.sp,
                                modifier = Modifier.clickable { renameTarget = room }.padding(6.dp))
                        }
                    }
                }
            }
            else -> {
                val list = if (tabIdx == 1) requests else normal
                if (tabIdx == 1 && requests.isNotEmpty()) {
                    Text("모르는 사람이 보낸 RM예요. 수락하면 받은 RM으로 이동해요",
                        fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp))
                }
                if (list.isEmpty()) EmptyBox("✉️", "아직 대화가 없어요", "친구를 추가하거나 운동장에서 RM을 보내보세요")
                else LazyColumn {
                    items(list, key = { it.peerUid }) { t ->
                        Row(
                            Modifier.fillMaxWidth()
                                .clickable { onOpenThread(t.peerUid, t.peerNickname) }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AvatarCircle("🏃",
                                listOf(Color(0xFFFF8FA3), Color(0xFFC9A5F5), Color(0xFF8B9FFF), Color(0xFFFF8FA3)))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(t.peerNickname, fontSize = 14.sp,
                                    fontWeight = if (t.unread) FontWeight.ExtraBold else FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurface)
                                Text(t.lastText, fontSize = 12.sp, maxLines = 1,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(rmTimeAgo(t.lastAt), fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.height(4.dp))
                                if (t.isRequest) {
                                    Text("수락", fontSize = 11.sp, fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.clickable { LocalRmStore.acceptRequest(ctx, t.peerUid) })
                                } else if (t.unread) {
                                    Box(Modifier.size(9.dp).clip(CircleShape).background(Color(0xFFFF3B5C)))
                                }
                            }
                            Text("✕", fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.clickable { deleteTarget = t.peerUid }.padding(start = 8.dp))
                        }
                    }
                }
            }
        }
    }
}

/** RM 1:1 대화 화면 */
@Composable
fun RmChatScreen(
    myNickname: String,
    peerUid: String,
    peerNickname: String,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    LaunchedEffect(peerUid) {
        LocalRmStore.load(ctx)
        LocalRmStore.ensureThread(ctx, peerUid, peerNickname)
        LocalRmStore.markRead(ctx, peerUid)
    }
    val threads by LocalRmStore.threads.collectAsState()
    val thread = threads.firstOrNull { it.peerUid == peerUid }
    val messages = thread?.messages ?: emptyList()
    var draft by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) runCatching { listState.animateScrollToItem(messages.size - 1) }
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("←", fontSize = 20.sp,
                modifier = Modifier.clickable(onClick = onBack).padding(end = 12.dp))
            Text(peerNickname.ifBlank { "상대" }, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp,
                modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onBackground)
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

        if (messages.isEmpty()) {
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("✉️", fontSize = 40.sp)
                    Text("첫 RM을 보내보세요", fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), state = listState) {
                items(messages, key = { it.id }) { m ->
                    Column(
                        Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalAlignment = if (m.fromMe) Alignment.End else Alignment.Start
                    ) {
                        if (!m.fromMe) Text(m.senderName, fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Box(
                            Modifier.background(
                                if (m.fromMe) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceVariant,
                                RoundedCornerShape(14.dp)
                            ).padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(m.text, fontSize = 14.sp,
                                color = if (m.fromMe) MaterialTheme.colorScheme.onPrimary
                                        else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(rmTimeAgo(m.at), fontSize = 9.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = draft, onValueChange = { draft = it.take(500) },
                placeholder = { Text("RM 입력", fontSize = 13.sp) },
                modifier = Modifier.weight(1f), shape = RoundedCornerShape(20.dp), maxLines = 3
            )
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = {
                    if (draft.isBlank()) return@Button
                    LocalRmStore.send(ctx, peerUid, peerNickname, myNickname, draft)
                    draft = ""
                },
                shape = CircleShape, contentPadding = PaddingValues(14.dp)
            ) { Text("↑", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold) }
        }
    }
}

@Composable
private fun AvatarCircle(emoji: String, colors: List<Color>) {
    Box(
        Modifier.size(46.dp).clip(CircleShape).background(Brush.sweepGradient(colors)),
        contentAlignment = Alignment.Center
    ) { Text(emoji, fontSize = 19.sp) }
}

@Composable
private fun ColumnScope.EmptyBox(emoji: String, title: String, sub: String) {
    Column(
        Modifier.fillMaxWidth().weight(1f),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(emoji, fontSize = 40.sp)
        Text(title, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(sub, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun rmTimeAgo(ts: Long): String {
    if (ts <= 0L) return ""
    val d = (System.currentTimeMillis() - ts) / 1000
    return when {
        d < 60 -> "방금 전"
        d < 3600 -> "${d / 60}분 전"
        d < 86400 -> "${d / 3600}시간 전"
        else -> "${d / 86400}일 전"
    }
}
