package com.navifit.social

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import kotlin.random.Random

/**
 * 개인 고유코드 시스템: "국가코드-6자리숫자" (예: KR-048291).
 * - 닉네임처럼 실제로 겹치지 않는지 Firestore 트랜잭션으로 확인 후 발급
 * - 한 번 발급되면 평생 유지 (uid에 귀속)
 * - 이 코드를 아는 사람만 RM을 보내거나 친구로 추가할 수 있음 (닉네임 검색으로는 안 됨 - 스팸/사칭 방지)
 */
class UniqueCodeManager {
    private val db: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }  // ✅ lazy

    /** 처음 한 번만 호출 - 이미 있으면 그대로 반환, 없으면 새로 발급 */
    suspend fun getOrCreate(uid: String, countryCode: String?): String {
        val userDoc = db.collection("users").document(uid).get().await()
        val existing = userDoc.getString("uniqueCode")
        if (!existing.isNullOrBlank()) return existing

        val country = (countryCode?.uppercase()?.takeIf { it.length == 2 }) ?: "XX"
        // ✅ v60: 숫자 6자리(100만개) → 영문+숫자 6자리로 확장.
        //   헷갈리는 문자(0/O/1/I) 제외한 32글자 × 6자리 = 약 10억 개 → 전세계 사용자 수용
        val alphabet = "23456789ABCDEFGHJKLMNPQRSTUVWXYZ"
        fun randomCode() = (1..6).map { alphabet.random() }.joinToString("")
        repeat(20) { // 충돌 시 재시도
            val candidate = "$country-${randomCode()}"
            val claimed = try {
                db.runTransaction { tx ->
                    val ref = db.collection("unique_codes").document(candidate)
                    if (tx.get(ref).exists()) throw CodeTakenException()
                    tx.set(ref, mapOf("uid" to uid))
                    null
                }.await()
                true
            } catch (e: Exception) { false }
            if (claimed) {
                db.collection("users").document(uid).set(mapOf("uniqueCode" to candidate), com.google.firebase.firestore.SetOptions.merge()).await()
                return candidate
            }
        }
        return "$country-${randomCode()}" // 최후 폴백
    }

    /** 코드로 uid 조회 (RM 보내기/친구추가용) */
    suspend fun findUidByCode(code: String): String? = try {
        db.collection("unique_codes").document(code.trim().uppercase()).get().await().getString("uid")
    } catch (e: Exception) { null }

    private class CodeTakenException : Exception("code taken")
}

data class FriendEntry(val uid: String, val nickname: String, val addedAt: Long, val lastSeenAt: Long = 0L) {
    /** 🟢 접속중 판정: 최근 2분 안에 하트비트가 찍혔으면 온라인 */
    val isOnline: Boolean get() = System.currentTimeMillis() - lastSeenAt < 2 * 60_000L
    val lastSeenLabel: String get() {
        if (lastSeenAt <= 0L) return "접속 기록 없음"
        if (isOnline) return "🟢 접속중"
        val diffMin = (System.currentTimeMillis() - lastSeenAt) / 60_000L
        return when {
            diffMin < 60 -> "${diffMin}분 전 접속"
            diffMin < 60 * 24 -> "${diffMin / 60}시간 전 접속"
            else -> "${diffMin / (60 * 24)}일 전 접속"
        }
    }
}

data class ListedUser(val uid: String, val nickname: String, val at: Long)

/**
 * 친구/차단/스팸 관리 (v25 확장).
 * - friends/{myUid}/list/{friendUid}: 친구 목록
 * - blocked/{myUid}/list/{blockedUid}: 차단 - 서로 RM을 주고받을 수 없음 (상대는 모름)
 * - spam/{myUid}/list/{spamUid}: 스팸 - 그 사람이 보내는 RM이 조용히 버려짐 (상대는 모름)
 * - users/{uid}.lastSeenAt: 접속 하트비트 (친구 화면의 "접속중/N분 전 접속" 표시용)
 *
 * ✅ 친구 삭제는 "상호 삭제": 내가 지우면 상대 목록에서도 내가 사라짐.
 * ✅ 차단/스팸은 상대에게 어떤 알림도 가지 않음 - 상대는 계속 보낼 수 있지만 도착하지 않음.
 */
class FriendRepository {
    private val db: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }  // ✅ lazy

    /** ✅ 접속 하트비트 - 앱이 켜져 있는 동안 주기적으로 호출 (친구들에게 접속중으로 보임) */
    suspend fun heartbeat(myUid: String) {
        if (myUid.isBlank()) return
        try {
            db.collection("users").document(myUid)
                .set(mapOf("lastSeenAt" to System.currentTimeMillis()), com.google.firebase.firestore.SetOptions.merge()).await()
        } catch (e: Exception) { /* 오프라인이면 무시 */ }
    }

    suspend fun addFriendByCode(myUid: String, code: String, codeManager: UniqueCodeManager): Result<String> {
        val targetUid = codeManager.findUidByCode(code) ?: return Result.failure(Exception("존재하지 않는 코드예요"))
        if (targetUid == myUid) return Result.failure(Exception("본인은 추가할 수 없어요"))
        val targetProfile = db.collection("users").document(targetUid).get().await()
        val nickname = targetProfile.getString("nickname") ?: "알 수 없음"
        db.collection("friends").document(myUid).collection("list").document(targetUid)
            .set(mapOf("nickname" to nickname, "addedAt" to System.currentTimeMillis())).await()
        // ✅ 상대 목록에도 나를 등록 (상호 친구) - 내 닉네임을 조회해서 넣음
        try {
            val myNickname = db.collection("users").document(myUid).get().await().getString("nickname") ?: "알 수 없음"
            db.collection("friends").document(targetUid).collection("list").document(myUid)
                .set(mapOf("nickname" to myNickname, "addedAt" to System.currentTimeMillis())).await()
        } catch (e: Exception) { /* 상대측 등록 실패해도 내 쪽은 유지 */ }
        return Result.success(nickname)
    }

    /**
     * ✅ v86 런친(러닝 친구) 요청 보내기.
     * 상대의 friend_requests 컬렉션에 대기 항목을 만든다. 상대가 수락하면 서로 친구가 된다.
     */
    suspend fun sendRequest(myUid: String, targetUid: String, myNickname: String) {
        if (myUid.isBlank() || targetUid.isBlank() || myUid == targetUid) return
        try {
            db.collection("friend_requests").document(targetUid)
                .collection("incoming").document(myUid)
                .set(mapOf(
                    "fromUid" to myUid,
                    "fromNickname" to myNickname,
                    "at" to System.currentTimeMillis(),
                    "status" to "pending"
                )).await()
        } catch (_: Exception) { }
    }

    suspend fun listFriends(myUid: String): List<FriendEntry> = try {
        val base = db.collection("friends").document(myUid).collection("list").get().await().documents.map { d ->
            FriendEntry(d.id, d.getString("nickname") ?: "알 수 없음", d.getLong("addedAt") ?: 0L)
        }
        // 접속상태(lastSeenAt) 붙이기
        base.map { f ->
            val lastSeen = try {
                db.collection("users").document(f.uid).get().await().getLong("lastSeenAt") ?: 0L
            } catch (e: Exception) { 0L }
            f.copy(lastSeenAt = lastSeen)
        }.sortedWith(compareByDescending<FriendEntry> { it.isOnline }.thenByDescending { it.lastSeenAt })
    } catch (e: Exception) { emptyList() }

    /** ✅ 상호 삭제: 내 목록과 상대 목록 양쪽에서 동시에 지움 */
    suspend fun removeFriend(myUid: String, friendUid: String) {
        db.collection("friends").document(myUid).collection("list").document(friendUid).delete().await()
        try {
            db.collection("friends").document(friendUid).collection("list").document(myUid).delete().await()
        } catch (e: Exception) { /* 상대측 삭제 실패는 무시 - 다음 동기화 때 정리 */ }
    }

    // ===== 차단 (서로 못 주고받음, 상대는 모름) =====
    suspend fun block(myUid: String, targetUid: String) {
        db.collection("blocked").document(myUid).collection("list").document(targetUid)
            .set(mapOf("blockedAt" to System.currentTimeMillis())).await()
    }

    suspend fun unblock(myUid: String, targetUid: String) {
        db.collection("blocked").document(myUid).collection("list").document(targetUid).delete().await()
    }

    suspend fun isBlocked(myUid: String, targetUid: String): Boolean = try {
        db.collection("blocked").document(myUid).collection("list").document(targetUid).get().await().exists()
    } catch (e: Exception) { false }

    suspend fun listBlocked(myUid: String): List<ListedUser> = listOf("blocked").flatMap { col ->
        try {
            db.collection(col).document(myUid).collection("list").get().await().documents.map { d ->
                val nick = try { db.collection("users").document(d.id).get().await().getString("nickname") ?: "알 수 없음" } catch (e: Exception) { "알 수 없음" }
                ListedUser(d.id, nick, d.getLong("blockedAt") ?: 0L)
            }
        } catch (e: Exception) { emptyList() }
    }

    // ===== 스팸 (상대가 보내는 RM만 조용히 버림, 상대는 모름) =====
    suspend fun markSpam(myUid: String, targetUid: String) {
        db.collection("spam").document(myUid).collection("list").document(targetUid)
            .set(mapOf("markedAt" to System.currentTimeMillis())).await()
    }

    suspend fun unmarkSpam(myUid: String, targetUid: String) {
        db.collection("spam").document(myUid).collection("list").document(targetUid).delete().await()
    }

    suspend fun isSpammed(myUid: String, targetUid: String): Boolean = try {
        db.collection("spam").document(myUid).collection("list").document(targetUid).get().await().exists()
    } catch (e: Exception) { false }

    suspend fun listSpam(myUid: String): List<ListedUser> = try {
        db.collection("spam").document(myUid).collection("list").get().await().documents.map { d ->
            val nick = try { db.collection("users").document(d.id).get().await().getString("nickname") ?: "알 수 없음" } catch (e: Exception) { "알 수 없음" }
            ListedUser(d.id, nick, d.getLong("markedAt") ?: 0L)
        }
    } catch (e: Exception) { emptyList() }

    /** 내가 차단했거나 상대가 나를 차단했으면 true (양방향 체크 - RM 전송 전 확인용) */
    suspend fun isBlockedEitherWay(myUid: String, targetUid: String): Boolean {
        val iBlockedThem = isBlocked(myUid, targetUid)
        val theyBlockedMe = isBlocked(targetUid, myUid)
        return iBlockedThem || theyBlockedMe
    }

    /**
     * ✅ RM 전달 가능 여부 (전송 직전에 호출):
     * - 어느 한쪽이 차단했으면 전달 안 됨
     * - 받는 사람이 보낸 사람을 스팸 처리했으면 전달 안 됨
     * 보낸 사람에게는 정상 전송된 것처럼 보임 (상대가 눈치 못 채게)
     */
    suspend fun canDeliver(fromUid: String, toUid: String): Boolean {
        if (isBlockedEitherWay(fromUid, toUid)) return false
        if (isSpammed(myUid = toUid, targetUid = fromUid)) return false
        return true
    }
}
